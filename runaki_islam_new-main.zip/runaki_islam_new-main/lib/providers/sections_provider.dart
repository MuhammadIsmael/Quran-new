import 'package:runaki_islam/providers/settings_provider.dart';

import '../database/database_helper.dart';
import '../models/section_model.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'sebha_provider.dart';

class SectionsProvider with ChangeNotifier {
  final List<SectionModel> _sections = <SectionModel>[];
  DatabaseHelper databaseHelper = DatabaseHelper();
  Future<bool>? _initializationFuture;
  final Map<String, Future<String>> _legacyJsonAssetLoads =
      <String, Future<String>>{};

  bool _newUser = true;

  bool get isNewUser => _newUser;

  String get table => 'sections';

  int get length => _sections.length;

  SectionModel getSection(int index) {
    return _sections[index];
  }

  List<int> getCategoriesIndex(int id) {
    return _sections[id].categoriesIndex;
  }

  Future<bool> initialAllSections() async {
    try {
      List<Map<String, dynamic>> tempSections = await databaseHelper.getData(
        table,
        '-1',
      );

      _sections.clear();

      debugPrint('tempSections.length : ${tempSections.length}');

      for (int i = 0; i < tempSections.length; i++) {
        _sections.add(SectionModel.fromMap(tempSections[i]));
      }

      debugPrint('_sections.length : ${_sections.length}');
      notifyListeners();
      return true;
    } catch (e) {
      debugPrint('Faild initialAllSections');
      debugPrint('e : $e');
      return false;
    }
  }

  Future<bool> ensureInitialized({
    BuildContext? context,
    SettingsProvider? settingsProvider,
    SebhaProvider? sebhaProvider,
  }) {
    _initializationFuture ??= _tryToGetData(
      context: context,
      settingsProvider: settingsProvider,
      sebhaProvider: sebhaProvider,
    );
    return _initializationFuture!;
  }

  Future<bool> _tryToGetData({
    BuildContext? context,
    SettingsProvider? settingsProvider,
    SebhaProvider? sebhaProvider,
  }) async {
    final resolvedSettingsProvider =
        settingsProvider ??
        (context != null
            ? Provider.of<SettingsProvider>(context, listen: false)
            : null);
    final resolvedSebhaProvider =
        sebhaProvider ??
        (context != null
            ? Provider.of<SebhaProvider>(context, listen: false)
            : null);

    if (resolvedSettingsProvider == null || resolvedSebhaProvider == null) {
      throw ArgumentError(
        'SectionsProvider.ensureInitialized requires a BuildContext or '
        'explicit SettingsProvider and SebhaProvider instances.',
      );
    }

    bool doesUserExists = await databaseHelper.isFileExists();

    _newUser = !doesUserExists;
    debugPrint('tryToGetData _newUser = $_newUser');

    await initialAllSections();
    debugPrint('initialAllSections');
    try {
      await resolvedSettingsProvider.initialSettings();
      await resolvedSebhaProvider.initialAllItemsOfSebha();

      debugPrint('initialAll ');
    } catch (e) {
      debugPrint('_initial e  : $e');
    }
    notifyListeners();
    return true;
  }

  Future<String> loadLegacyJsonAsset(String assetPath) {
    final normalizedPath = assetPath.replaceAll('\\', '/');
    return _legacyJsonAssetLoads.putIfAbsent(
      normalizedPath,
      () async {
        try {
          return await databaseHelper.loadLegacyJsonAsset(normalizedPath);
        } catch (_) {
          _legacyJsonAssetLoads.remove(normalizedPath);
          rethrow;
        }
      },
    );
  }

  Future<List<Map<String, dynamic>>> getContentItemsByAssetPath(
    String assetPath,
  ) {
    return databaseHelper.getContentItemsByAssetPath(
      assetPath.replaceAll('\\', '/'),
    );
  }
}
