import 'dart:convert';
import 'dart:math' as math;

import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

enum QuranDetailViewMode { list, paper }

class QuranHifzPlan {
  const QuranHifzPlan({
    required this.surahIndex,
    required this.startAyah,
    required this.dailyNewAyahs,
    required this.dailyReviewAyahs,
    required this.startDateEpochMs,
  });

  final int surahIndex;
  final int startAyah;
  final int dailyNewAyahs;
  final int dailyReviewAyahs;
  final int startDateEpochMs;

  DateTime get startDate =>
      DateTime.fromMillisecondsSinceEpoch(startDateEpochMs);

  QuranHifzDailyAssignment assignmentForDate(
    DateTime date, {
    required int ayahTotal,
  }) {
    if (ayahTotal < 1) {
      return const QuranHifzDailyAssignment(
        dayIndex: 0,
        completed: true,
        memorizeStart: 1,
        memorizeEnd: 1,
      );
    }
    final today = DateTime(date.year, date.month, date.day);
    final start = startDate;
    final startDay = DateTime(start.year, start.month, start.day);
    final dayIndex = math.max(0, today.difference(startDay).inDays);
    final memorizeStart = startAyah + (dayIndex * dailyNewAyahs);
    if (memorizeStart > ayahTotal) {
      return QuranHifzDailyAssignment(
        dayIndex: dayIndex,
        completed: true,
        memorizeStart: ayahTotal,
        memorizeEnd: ayahTotal,
      );
    }
    final memorizeEnd = math.min(ayahTotal, memorizeStart + dailyNewAyahs - 1);

    int? reviewStart;
    int? reviewEnd;
    if (dailyReviewAyahs > 0 && memorizeStart > 1) {
      reviewEnd = memorizeStart - 1;
      reviewStart = math.max(1, reviewEnd - dailyReviewAyahs + 1);
    }

    return QuranHifzDailyAssignment(
      dayIndex: dayIndex,
      completed: false,
      memorizeStart: memorizeStart,
      memorizeEnd: memorizeEnd,
      reviewStart: reviewStart,
      reviewEnd: reviewEnd,
    );
  }

  Map<String, dynamic> toMap() {
    return <String, dynamic>{
      'surah_index': surahIndex,
      'start_ayah': startAyah,
      'daily_new_ayahs': dailyNewAyahs,
      'daily_review_ayahs': dailyReviewAyahs,
      'start_date_ms': startDateEpochMs,
    };
  }

  static QuranHifzPlan? tryParse(String? raw) {
    if (raw == null || raw.trim().isEmpty) return null;
    try {
      final decoded = jsonDecode(raw);
      if (decoded is! Map<String, dynamic>) return null;
      final surahIndex = _toInt(decoded['surah_index']);
      final startAyah = _toInt(decoded['start_ayah']);
      final dailyNewAyahs = _toInt(decoded['daily_new_ayahs']);
      final dailyReviewAyahs = _toInt(decoded['daily_review_ayahs']);
      final startDateEpochMs = _toInt(decoded['start_date_ms']);
      if (surahIndex == null ||
          startAyah == null ||
          dailyNewAyahs == null ||
          dailyReviewAyahs == null ||
          startDateEpochMs == null) {
        return null;
      }
      if (surahIndex < 1 || startAyah < 1 || dailyNewAyahs < 1) {
        return null;
      }
      return QuranHifzPlan(
        surahIndex: surahIndex,
        startAyah: startAyah,
        dailyNewAyahs: dailyNewAyahs,
        dailyReviewAyahs: dailyReviewAyahs.clamp(0, 5000).toInt(),
        startDateEpochMs: startDateEpochMs,
      );
    } catch (_) {
      return null;
    }
  }

  static int? _toInt(dynamic value) {
    if (value is int) return value;
    if (value is num) return value.toInt();
    if (value is String) return int.tryParse(value);
    return null;
  }
}

class QuranHifzDailyAssignment {
  const QuranHifzDailyAssignment({
    required this.dayIndex,
    required this.completed,
    required this.memorizeStart,
    required this.memorizeEnd,
    this.reviewStart,
    this.reviewEnd,
  });

  final int dayIndex;
  final bool completed;
  final int memorizeStart;
  final int memorizeEnd;
  final int? reviewStart;
  final int? reviewEnd;
}

class QuranHifzTestResult {
  const QuranHifzTestResult({
    required this.surahIndex,
    required this.rangeStartAyah,
    required this.rangeEndAyah,
    required this.totalQuestions,
    required this.correctAnswers,
    required this.takenAtEpochMs,
  });

  final int surahIndex;
  final int rangeStartAyah;
  final int rangeEndAyah;
  final int totalQuestions;
  final int correctAnswers;
  final int takenAtEpochMs;

  double get scorePercent {
    if (totalQuestions < 1) return 0;
    return (correctAnswers / totalQuestions) * 100;
  }

  Map<String, dynamic> toMap() {
    return <String, dynamic>{
      'surah_index': surahIndex,
      'range_start': rangeStartAyah,
      'range_end': rangeEndAyah,
      'total': totalQuestions,
      'correct': correctAnswers,
      'taken_at_ms': takenAtEpochMs,
    };
  }

  static QuranHifzTestResult? fromMap(dynamic value) {
    if (value is! Map) return null;
    final map = Map<String, dynamic>.from(value);
    final surahIndex = _toInt(map['surah_index']);
    final rangeStartAyah = _toInt(map['range_start']);
    final rangeEndAyah = _toInt(map['range_end']);
    final totalQuestions = _toInt(map['total']);
    final correctAnswers = _toInt(map['correct']);
    final takenAtEpochMs = _toInt(map['taken_at_ms']);
    if (surahIndex == null ||
        rangeStartAyah == null ||
        rangeEndAyah == null ||
        totalQuestions == null ||
        correctAnswers == null ||
        takenAtEpochMs == null) {
      return null;
    }
    if (surahIndex < 1 ||
        rangeStartAyah < 1 ||
        rangeEndAyah < rangeStartAyah ||
        totalQuestions < 1 ||
        correctAnswers < 0) {
      return null;
    }
    return QuranHifzTestResult(
      surahIndex: surahIndex,
      rangeStartAyah: rangeStartAyah,
      rangeEndAyah: rangeEndAyah,
      totalQuestions: totalQuestions,
      correctAnswers: correctAnswers.clamp(0, totalQuestions).toInt(),
      takenAtEpochMs: takenAtEpochMs,
    );
  }

  static int? _toInt(dynamic value) {
    if (value is int) return value;
    if (value is num) return value.toInt();
    if (value is String) return int.tryParse(value);
    return null;
  }
}

class QuranStateProvider extends ChangeNotifier {
  static const String _favoriteSurahsKey = 'quran.favorite_surahs';
  static const String _bookmarkedSurahsKey = 'quran.bookmarked_surahs';
  static const String _bookmarkedAyahsKey = 'quran.bookmarked_ayahs';
  static const String _lastReadSurahKey = 'quran.last_read_surah';
  static const String _lastReadAyahKey = 'quran.last_read_ayah';

  static const String _tajweedEnabledKey = 'quran.tajweed_enabled';
  static const String _tajweedPaletteKey = 'quran.tajweed_palette';
  static const String _tajweedOpacityKey = 'quran.tajweed_opacity';
  static const String _showTajweedLegendKey = 'quran.show_tajweed_legend';
  static const String _detailViewModeKey = 'quran.detail_view_mode';
  static const String _preferOfflineAudioKey = 'quran.prefer_offline_audio';
  static const String _lastReciterIdKey = 'quran.last_reciter_id';
  static const String _lastReciterNameKey = 'quran.last_reciter_name';
  static const String _hifzPlanKey = 'quran.hifz_plan';
  static const String _hifzTestResultsKey = 'quran.hifz_test_results';

  final Set<int> _favoriteSurahs = <int>{};
  final Set<int> _bookmarkedSurahs = <int>{};
  final Map<int, Set<int>> _bookmarkedAyahsBySurah = <int, Set<int>>{};
  final List<QuranHifzTestResult> _hifzTestResults = <QuranHifzTestResult>[];

  SharedPreferences? _preferences;
  late final Future<void> _initialization;

  int? _lastReadSurahIndex;
  int _lastReadAyah = 1;
  bool _ready = false;

  bool _tajweedEnabled = true;
  int _tajweedPalette = 0;
  double _tajweedOpacity = 1.0;
  bool _showTajweedLegend = true;
  QuranDetailViewMode _detailViewMode = QuranDetailViewMode.list;
  bool _preferOfflineAudio = true;
  String _lastReciterId = 'ar.alafasy';
  String _lastReciterName = 'مشاري العفاسي';
  QuranHifzPlan? _hifzPlan;

  QuranStateProvider() {
    _initialization = _loadFromStorage();
  }

  bool get isReady => _ready;
  int? get lastReadSurahIndex => _lastReadSurahIndex;
  int get lastReadAyah => _lastReadAyah;
  Set<int> get favoriteSurahs => Set<int>.unmodifiable(_favoriteSurahs);
  Set<int> get bookmarkedSurahs => Set<int>.unmodifiable(_bookmarkedSurahs);

  bool get tajweedEnabled => _tajweedEnabled;
  int get tajweedPalette => _tajweedPalette;
  double get tajweedOpacity => _tajweedOpacity;
  bool get showTajweedLegend => _showTajweedLegend;
  QuranDetailViewMode get detailViewMode => _detailViewMode;
  bool get preferOfflineAudio => _preferOfflineAudio;
  String get lastReciterId => _lastReciterId;
  String get lastReciterName => _lastReciterName;
  QuranHifzPlan? get hifzPlan => _hifzPlan;
  List<QuranHifzTestResult> get hifzTestResults =>
      List<QuranHifzTestResult>.unmodifiable(_hifzTestResults);

  bool isFavoriteSurah(int surahIndex) => _favoriteSurahs.contains(surahIndex);

  bool isSurahBookmarked(int surahIndex) {
    return _bookmarkedSurahs.contains(surahIndex);
  }

  bool isAyahBookmarked(int surahIndex, int ayahNumber) {
    return _bookmarkedAyahsBySurah[surahIndex]?.contains(ayahNumber) ?? false;
  }

  Set<int> bookmarkedAyahsForSurah(int surahIndex) {
    final value = _bookmarkedAyahsBySurah[surahIndex];
    if (value == null) return <int>{};
    return Set<int>.unmodifiable(value);
  }

  Future<void> setLastRead({
    required int surahIndex,
    required int ayahNumber,
  }) async {
    await _initialization;
    final normalizedAyah = ayahNumber < 1 ? 1 : ayahNumber;
    final changed =
        _lastReadSurahIndex != surahIndex || _lastReadAyah != normalizedAyah;
    _lastReadSurahIndex = surahIndex;
    _lastReadAyah = normalizedAyah;
    if (changed) {
      notifyListeners();
    }
    await _saveLastRead();
  }

  Future<void> toggleFavoriteSurah(int surahIndex) async {
    await _initialization;
    if (!_favoriteSurahs.add(surahIndex)) {
      _favoriteSurahs.remove(surahIndex);
    }
    notifyListeners();
    await _saveIntSet(_favoriteSurahsKey, _favoriteSurahs);
  }

  Future<void> setSurahBookmarked(int surahIndex, bool bookmarked) async {
    await _initialization;
    if (bookmarked) {
      _bookmarkedSurahs.add(surahIndex);
    } else {
      _bookmarkedSurahs.remove(surahIndex);
    }
    notifyListeners();
    await _saveIntSet(_bookmarkedSurahsKey, _bookmarkedSurahs);
  }

  Future<void> toggleSurahBookmark(int surahIndex) async {
    await _initialization;
    if (!_bookmarkedSurahs.add(surahIndex)) {
      _bookmarkedSurahs.remove(surahIndex);
    }
    notifyListeners();
    await _saveIntSet(_bookmarkedSurahsKey, _bookmarkedSurahs);
  }

  Future<bool> toggleAyahBookmark(int surahIndex, int ayahNumber) async {
    await _initialization;
    final normalizedAyah = ayahNumber < 1 ? 1 : ayahNumber;
    final set = _bookmarkedAyahsBySurah.putIfAbsent(surahIndex, () => <int>{});
    final added = set.add(normalizedAyah);
    if (!added) {
      set.remove(normalizedAyah);
    }
    if (set.isEmpty) {
      _bookmarkedAyahsBySurah.remove(surahIndex);
    }
    notifyListeners();
    await _saveBookmarkedAyahs();
    return added;
  }

  Future<void> setAyahBookmarked({
    required int surahIndex,
    required int ayahNumber,
    required bool bookmarked,
  }) async {
    await _initialization;
    final normalizedAyah = ayahNumber < 1 ? 1 : ayahNumber;
    final set = _bookmarkedAyahsBySurah.putIfAbsent(surahIndex, () => <int>{});
    if (bookmarked) {
      set.add(normalizedAyah);
    } else {
      set.remove(normalizedAyah);
      if (set.isEmpty) {
        _bookmarkedAyahsBySurah.remove(surahIndex);
      }
    }
    notifyListeners();
    await _saveBookmarkedAyahs();
  }

  Future<void> setTajweedEnabled(bool enabled) async {
    await _initialization;
    if (_tajweedEnabled == enabled) return;
    _tajweedEnabled = enabled;
    notifyListeners();
    final prefs = await _ensurePreferences();
    await prefs.setBool(_tajweedEnabledKey, enabled);
  }

  Future<void> setShowTajweedLegend(bool visible) async {
    await _initialization;
    if (_showTajweedLegend == visible) return;
    _showTajweedLegend = visible;
    notifyListeners();
    final prefs = await _ensurePreferences();
    await prefs.setBool(_showTajweedLegendKey, visible);
  }

  Future<void> setTajweedPalette(int paletteIndex) async {
    await _initialization;
    final normalized = paletteIndex.clamp(0, 3).toInt();
    if (_tajweedPalette == normalized) return;
    _tajweedPalette = normalized;
    notifyListeners();
    final prefs = await _ensurePreferences();
    await prefs.setInt(_tajweedPaletteKey, normalized);
  }

  Future<void> setTajweedOpacity(double opacity) async {
    await _initialization;
    final normalized = opacity.clamp(0.35, 1.0).toDouble();
    if ((_tajweedOpacity - normalized).abs() < 0.001) return;
    _tajweedOpacity = normalized;
    notifyListeners();
    final prefs = await _ensurePreferences();
    await prefs.setDouble(_tajweedOpacityKey, normalized);
  }

  Future<void> setDetailViewMode(QuranDetailViewMode mode) async {
    await _initialization;
    if (_detailViewMode == mode) return;
    _detailViewMode = mode;
    notifyListeners();
    final prefs = await _ensurePreferences();
    await prefs.setString(_detailViewModeKey, mode.name);
  }

  Future<void> setPreferOfflineAudio(bool prefer) async {
    await _initialization;
    if (_preferOfflineAudio == prefer) return;
    _preferOfflineAudio = prefer;
    notifyListeners();
    final prefs = await _ensurePreferences();
    await prefs.setBool(_preferOfflineAudioKey, prefer);
  }

  Future<void> setPreferredReciter({
    required String reciterId,
    required String reciterName,
  }) async {
    await _initialization;
    final id = reciterId.trim();
    final name = reciterName.trim();
    if (id.isEmpty || name.isEmpty) return;
    final changed = _lastReciterId != id || _lastReciterName != name;
    _lastReciterId = id;
    _lastReciterName = name;
    if (changed) {
      notifyListeners();
    }
    final prefs = await _ensurePreferences();
    await prefs.setString(_lastReciterIdKey, id);
    await prefs.setString(_lastReciterNameKey, name);
  }

  Future<void> saveHifzPlan(QuranHifzPlan plan) async {
    await _initialization;
    _hifzPlan = plan;
    notifyListeners();
    final prefs = await _ensurePreferences();
    await prefs.setString(_hifzPlanKey, jsonEncode(plan.toMap()));
  }

  Future<void> clearHifzPlan() async {
    await _initialization;
    _hifzPlan = null;
    notifyListeners();
    final prefs = await _ensurePreferences();
    await prefs.remove(_hifzPlanKey);
  }

  Future<void> addHifzTestResult(QuranHifzTestResult result) async {
    await _initialization;
    _hifzTestResults.insert(0, result);
    if (_hifzTestResults.length > 80) {
      _hifzTestResults.removeRange(80, _hifzTestResults.length);
    }
    notifyListeners();
    await _saveHifzTestResults();
  }

  Future<void> clearHifzTestResults() async {
    await _initialization;
    _hifzTestResults.clear();
    notifyListeners();
    final prefs = await _ensurePreferences();
    await prefs.remove(_hifzTestResultsKey);
  }

  Future<void> _loadFromStorage() async {
    final prefs = await _ensurePreferences();

    _favoriteSurahs
      ..clear()
      ..addAll(_toIntSet(prefs.getStringList(_favoriteSurahsKey)));

    _bookmarkedSurahs
      ..clear()
      ..addAll(_toIntSet(prefs.getStringList(_bookmarkedSurahsKey)));

    _lastReadSurahIndex = prefs.getInt(_lastReadSurahKey);
    _lastReadAyah = (prefs.getInt(_lastReadAyahKey) ?? 1)
        .clamp(1, 9999)
        .toInt();

    _bookmarkedAyahsBySurah
      ..clear()
      ..addAll(_decodeBookmarkedAyahs(prefs.getString(_bookmarkedAyahsKey)));

    _tajweedEnabled = prefs.getBool(_tajweedEnabledKey) ?? true;
    _showTajweedLegend = prefs.getBool(_showTajweedLegendKey) ?? true;
    _tajweedPalette = (prefs.getInt(_tajweedPaletteKey) ?? 0)
        .clamp(0, 3)
        .toInt();
    _tajweedOpacity = (prefs.getDouble(_tajweedOpacityKey) ?? 1.0)
        .clamp(0.35, 1.0)
        .toDouble();
    _preferOfflineAudio = prefs.getBool(_preferOfflineAudioKey) ?? true;
    _detailViewMode = _parseDetailViewMode(
      prefs.getString(_detailViewModeKey) ?? QuranDetailViewMode.list.name,
    );
    _lastReciterId = prefs.getString(_lastReciterIdKey) ?? 'ar.alafasy';
    _lastReciterName = prefs.getString(_lastReciterNameKey) ?? 'مشاري العفاسي';
    _hifzPlan = QuranHifzPlan.tryParse(prefs.getString(_hifzPlanKey));

    _hifzTestResults
      ..clear()
      ..addAll(_decodeHifzTestResults(prefs.getString(_hifzTestResultsKey)));

    _ready = true;
    notifyListeners();
  }

  Future<SharedPreferences> _ensurePreferences() async {
    _preferences ??= await SharedPreferences.getInstance();
    return _preferences!;
  }

  Future<void> _saveIntSet(String key, Set<int> values) async {
    final prefs = await _ensurePreferences();
    final list = values.map((value) => value.toString()).toList()..sort();
    await prefs.setStringList(key, list);
  }

  Future<void> _saveBookmarkedAyahs() async {
    final prefs = await _ensurePreferences();
    await prefs.setString(_bookmarkedAyahsKey, _encodeBookmarkedAyahs());
  }

  Future<void> _saveLastRead() async {
    final prefs = await _ensurePreferences();
    if (_lastReadSurahIndex != null) {
      await prefs.setInt(_lastReadSurahKey, _lastReadSurahIndex!);
    }
    await prefs.setInt(_lastReadAyahKey, _lastReadAyah);
  }

  Future<void> _saveHifzTestResults() async {
    final prefs = await _ensurePreferences();
    final encoded = _hifzTestResults.map((item) => item.toMap()).toList();
    await prefs.setString(_hifzTestResultsKey, jsonEncode(encoded));
  }

  Set<int> _toIntSet(List<String>? values) {
    if (values == null) return <int>{};
    return values
        .map<int?>((value) => int.tryParse(value))
        .whereType<int>()
        .toSet();
  }

  Map<int, Set<int>> _decodeBookmarkedAyahs(String? raw) {
    if (raw == null || raw.trim().isEmpty) return <int, Set<int>>{};
    try {
      final decoded = jsonDecode(raw);
      if (decoded is! Map<String, dynamic>) return <int, Set<int>>{};

      final result = <int, Set<int>>{};
      decoded.forEach((surahKey, value) {
        final surah = int.tryParse(surahKey);
        if (surah == null) return;
        if (value is! List) return;
        final ayahs = value
            .map<int?>((item) {
              if (item is int) return item;
              if (item is num) return item.toInt();
              if (item is String) return int.tryParse(item);
              return null;
            })
            .whereType<int>()
            .where((item) => item > 0)
            .toSet();
        if (ayahs.isNotEmpty) {
          result[surah] = ayahs;
        }
      });
      return result;
    } catch (_) {
      return <int, Set<int>>{};
    }
  }

  List<QuranHifzTestResult> _decodeHifzTestResults(String? raw) {
    if (raw == null || raw.trim().isEmpty) return <QuranHifzTestResult>[];
    try {
      final decoded = jsonDecode(raw);
      if (decoded is! List) return <QuranHifzTestResult>[];
      return decoded
          .map<QuranHifzTestResult?>((item) {
            return QuranHifzTestResult.fromMap(item);
          })
          .whereType<QuranHifzTestResult>()
          .toList();
    } catch (_) {
      return <QuranHifzTestResult>[];
    }
  }

  String _encodeBookmarkedAyahs() {
    final encoded = <String, List<int>>{};
    final keys = _bookmarkedAyahsBySurah.keys.toList()..sort();
    for (final surah in keys) {
      final ayahs = _bookmarkedAyahsBySurah[surah];
      if (ayahs == null || ayahs.isEmpty) continue;
      final sortedAyahs = ayahs.toList()..sort();
      encoded['$surah'] = sortedAyahs;
    }
    return jsonEncode(encoded);
  }

  QuranDetailViewMode _parseDetailViewMode(String raw) {
    switch (raw.trim().toLowerCase()) {
      case 'paper':
        return QuranDetailViewMode.paper;
      default:
        return QuranDetailViewMode.list;
    }
  }
}
