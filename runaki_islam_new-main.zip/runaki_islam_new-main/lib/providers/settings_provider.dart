import 'package:runaki_islam/database/database_helper.dart';
import 'package:runaki_islam/util/quran_font_registry.dart';

import '../models/settings_model.dart';
import 'package:flutter/foundation.dart';

class SettingsProvider with ChangeNotifier {
  SettingsModel _settings = SettingsModel.defaults();
  DatabaseHelper databaseHelper = DatabaseHelper();

  String get table => 'settings';

  dynamic getsettingField(String nameField) {
    switch (nameField) {
      case 'font_family':
        return _settings.fontFamily;

      case 'font_size':
        return _settings.fontSize;

      case 'speed_factor':
        return _settings.speedFactor;

      case 'quran_font_family':
        return _settings.quranFontFamily;

      case 'quran_font_size':
        return _settings.quranFontSize;
    }
    return _settings;
  }

  Future updateSettings(String nameField, dynamic value) async {
    debugPrint(' updateSettings $nameField');
    dynamic storedValue = value;
    switch (nameField) {
      case 'font_family':
        _settings.setFontFamily(_asInt(value, _settings.fontFamily));
        break;

      case 'speed_factor':
        _settings.setSpeedFactor(_asDouble(value, _settings.speedFactor));
        break;

      case 'quran_font_family':
        storedValue = normalizeQuranFontFamily(value);
        _settings.setQuranFontFamily(storedValue);
        break;

      case 'quran_font_size':
        _settings.setQuranFontSize(_asDouble(value, _settings.quranFontSize));
        break;

      case 'font_size':
        _settings.setFontSize(_asDouble(value, _settings.fontSize));
        break;
    }

    try {
      await databaseHelper.updateSettings(nameField, storedValue);
      debugPrint('updateField : true');
      notifyListeners();
      return true;
    } catch (e) {
      debugPrint('updateField e : $e');
      return false;
    }
  }

  Future<bool> initialSettings() async {
    try {
      List<Map<String, dynamic>> tempSettings = await databaseHelper.getData(
        table,
        '-1',
      );
      debugPrint('tempSettings.length : ${tempSettings.length}');

      if (tempSettings.isNotEmpty) {
        _settings = SettingsModel.fromMap(tempSettings[0]);
      } else {
        _settings = SettingsModel.defaults();
      }

      debugPrint('My font is : ${_settings.fontFamily}');
      debugPrint('My font size is : ${_settings.fontSize}');
      debugPrint('My speed factor is : ${_settings.speedFactor}');
      debugPrint('My quran font is : ${_settings.quranFontFamily}');
      debugPrint('My quran font size is : ${_settings.quranFontSize}');
      notifyListeners();
      return true;
    } catch (e) {
      debugPrint('Faild initialSettings');
      debugPrint('e : $e');
      _settings = SettingsModel.defaults();
      return false;
    }
  }

  double _asDouble(dynamic value, double fallback) {
    if (value is num) {
      return value.toDouble();
    }
    return fallback;
  }

  int _asInt(dynamic value, int fallback) {
    if (value is int) {
      return value;
    }
    if (value is num) {
      return value.toInt();
    }
    return fallback;
  }
}
