import 'package:flutter/material.dart';
import 'package:runaki_islam/theme/theme.dart';
import 'package:runaki_islam/util/constans.dart';
import 'package:shared_preferences/shared_preferences.dart';

ThemeData lightMode = AppTheme.light;
ThemeData darkMode = AppTheme.dark;

class ThemeNotifier extends ChangeNotifier {
  final String key = "theme";
  SharedPreferences? _preferences;
  bool _darkMode = false;

  bool get darkMode => _darkMode;
  ThemeMode get themeMode => _darkMode ? ThemeMode.dark : ThemeMode.light;
  ThemeData get currentTheme {
    if (_darkMode) {
      return AppTheme.dark;
    }
    return AppTheme.light;
  }

  ThemeNotifier() {
    applyLegacyPalette(dark: false);
    _loadFromPreferences();
  }

  Future<void> _initialPreferences() async {
    _preferences ??= _preferences = await SharedPreferences.getInstance();
  }

  Future<void> _savePreferences() async {
    await _initialPreferences();
    await _preferences!.setBool(key, _darkMode);
  }

  Future<void> _loadFromPreferences() async {
    await _initialPreferences();
    _darkMode = _preferences!.getBool(key) ?? false;
    applyLegacyPalette(dark: _darkMode);
    notifyListeners();
  }

  void toggleChangeTheme() {
    _darkMode = !_darkMode;
    applyLegacyPalette(dark: _darkMode);
    _savePreferences();
    notifyListeners();
  }
}
