import 'dart:async';
import 'dart:convert';
import 'dart:math';

import 'package:flutter/widgets.dart';
import 'package:get/get.dart';
import 'package:runaki_islam/models/questions.dart';
import 'package:runaki_islam/services/quiz_api_service.dart';
import 'package:runaki_islam/util/mojibake_fixer.dart';
import 'package:shared_preferences/shared_preferences.dart';

class QuizStartOptions {
  final String categoryId;
  final int questionCount;
  final int timePerQuestion;
  final bool shuffleQuestions;
  final bool shuffleOptions;

  const QuizStartOptions({
    required this.categoryId,
    required this.questionCount,
    required this.timePerQuestion,
    required this.shuffleQuestions,
    required this.shuffleOptions,
  });

  factory QuizStartOptions.defaults() {
    return const QuizStartOptions(
      categoryId: 'all',
      questionCount: 10,
      timePerQuestion: 25,
      shuffleQuestions: true,
      shuffleOptions: true,
    );
  }

  QuizStartOptions copyWith({
    String? categoryId,
    int? questionCount,
    int? timePerQuestion,
    bool? shuffleQuestions,
    bool? shuffleOptions,
  }) {
    return QuizStartOptions(
      categoryId: categoryId ?? this.categoryId,
      questionCount: questionCount ?? this.questionCount,
      timePerQuestion: timePerQuestion ?? this.timePerQuestion,
      shuffleQuestions: shuffleQuestions ?? this.shuffleQuestions,
      shuffleOptions: shuffleOptions ?? this.shuffleOptions,
    );
  }
}

class QuizAnswerRecord {
  final Question question;
  final int questionNumber;
  final int selectedIndex;
  final int correctIndex;
  final bool timedOut;

  const QuizAnswerRecord({
    required this.question,
    required this.questionNumber,
    required this.selectedIndex,
    required this.correctIndex,
    this.timedOut = false,
  });

  bool get isSkipped => selectedIndex < 0;
  bool get isCorrect => selectedIndex == correctIndex;
}

class QuestionController extends GetxController {
  QuestionController({QuizApiService? quizApiService})
    : _quizApiService = quizApiService ?? QuizApiService();

  static const String _allSelectionId = 'all';
  static const List<int> availableTimers = <int>[15, 20, 25, 30, 45, 60];
  static const String _bestScoreKey = 'quiz_best_score';
  static const String _quizCategoriesCacheKey = 'quiz_categories_cache_v2';
  static const String _quizCollectionsCacheKey = 'quiz_collections_cache_v2';

  final QuizApiService _quizApiService;
  final Random _random = Random();
  final PageController _legacyPageController = PageController();
  final Map<int, Future<QuizCollection?>> _detailRequests =
      <int, Future<QuizCollection?>>{};

  final RxList<QuizCategory> _quizCategories = <QuizCategory>[].obs;
  final RxList<QuizCollection> _quizCollections = <QuizCollection>[].obs;
  final RxList<Question> _allQuestions = <Question>[].obs;
  final RxList<Question> _questions = <Question>[].obs;
  final RxList<QuizAnswerRecord> _answerHistory = <QuizAnswerRecord>[].obs;
  final Rx<QuizStartOptions> _startOptions = QuizStartOptions.defaults().obs;
  final RxString _activeCategoryLabel = 'هەموو'.obs;
  final RxString _catalogError = ''.obs;
  final RxString _preparingSelectionId = ''.obs;

  final RxInt _currentQuestionIndex = 0.obs;
  final RxInt _questionNumber = 1.obs;
  final RxInt _remainingSeconds = 25.obs;
  final RxInt _selectedAnswerIndex = (-1).obs;
  final RxInt _correctAnswers = 0.obs;
  final RxInt _bestScore = 0.obs;
  final RxBool _isAnswered = false.obs;
  final RxBool _isFinished = false.obs;
  final RxBool _hasSessionStarted = false.obs;
  final RxBool _isCatalogLoading = false.obs;
  final RxBool _isSelectionPreparing = false.obs;
  final RxBool _hasLoadedCatalog = false.obs;

  SharedPreferences? _prefs;
  Timer? _timer;
  DateTime? _catalogLoadStartedAt;
  bool _isWarmingQuizDetails = false;

  static const Question _emptyQuestion = Question(
    id: 0,
    question: '',
    options: <String>[],
    answer: 0,
    category: _allSelectionId,
  );

  List<Question> get allQuestions => _allQuestions;
  List<Question> get questions => _questions;
  List<QuizAnswerRecord> get answerHistory => _answerHistory;
  List<QuizCategory> get quizCategories => _quizCategories;
  List<QuizCollection> get quizCollections => _quizCollections;
  PageController get pageController => _legacyPageController;
  RxInt get questionNumber => _questionNumber;

  QuizStartOptions get startOptions => _startOptions.value;
  String get activeCategoryLabel => _activeCategoryLabel.value;
  String get catalogError => _catalogError.value;
  String get preparingSelectionId => _preparingSelectionId.value;

  int get numOfCorrectAns => _correctAnswers.value;
  int get bestScore => _bestScore.value;
  int get selectedAns => _selectedAnswerIndex.value;
  int get correctAns => currentQuestion.answer ?? -1;
  int get remainingSeconds => _remainingSeconds.value;
  int get totalQuestions => _questions.length;
  int get currentQuestionIndex => _currentQuestionIndex.value;
  int get answeredQuestions => _answerHistory.length;
  int get currentQuestionNumber => _currentQuestionIndex.value + 1;
  int get unansweredQuestions =>
      (_questions.length - _answerHistory.length).clamp(0, _questions.length);
  int get totalPoints => _correctAnswers.value * 10;

  bool get isAnswered => _isAnswered.value;
  bool get isFinished => _isFinished.value;
  bool get isCatalogLoading => _isCatalogLoading.value;
  bool get isSelectionPreparing => _isSelectionPreparing.value;
  bool get hasLoadedQuizCatalog => _hasLoadedCatalog.value;
  bool get hasQuizCatalog =>
      _quizCategories.isNotEmpty || _quizCollections.isNotEmpty;
  bool get hasActiveQuiz =>
      _hasSessionStarted.value && _questions.isNotEmpty && !_isFinished.value;
  bool get canResumeQuiz => hasActiveQuiz;
  bool get isLastQuestion =>
      _currentQuestionIndex.value >= _questions.length - 1;
  bool get hasRemoteQuizCatalog =>
      _quizCollections.any((QuizCollection item) => item.isRemote);

  int get skippedAnswers =>
      _answerHistory.where((QuizAnswerRecord item) => item.isSkipped).length;
  int get wrongAnswers => _answerHistory
      .where((QuizAnswerRecord item) => !item.isSkipped && !item.isCorrect)
      .length;

  double get scorePercent =>
      _questions.isEmpty ? 0 : _correctAnswers.value / _questions.length;
  double get accuracyPercent => _answerHistory.isEmpty
      ? 0
      : (_correctAnswers.value / _answerHistory.length) * 100;
  double get timerProgress {
    final int base = _startOptions.value.timePerQuestion;
    if (base <= 0) return 0;
    return _remainingSeconds.value / base;
  }

  double get questionProgress => _questions.isEmpty
      ? 0
      : (_currentQuestionIndex.value + 1) / _questions.length;

  Question get currentQuestion {
    if (_questions.isEmpty) return _emptyQuestion;
    return _questions[_currentQuestionIndex.value];
  }

  Animation<double> get animation => AlwaysStoppedAnimation(1 - timerProgress);

  String get resultTitle {
    if (scorePercent >= 0.9) return 'ناوازە';
    if (scorePercent >= 0.75) return 'کارێکی زۆر باش';
    if (scorePercent >= 0.5) return 'هەوڵێکی باش';
    return 'بەردەوام بە لە ڕاهێنان';
  }

  String get resultSubtitle {
    if (scorePercent >= 0.9) {
      return 'زانیارییەکی زۆر باشت هەیە لەم تاقیکردنەوەیەدا.';
    }
    if (scorePercent >= 0.75) {
      return 'ئەنجامەکەت بەهێزە. هەوڵێکی تر دەتوانێت زیاتر باشتربکات.';
    }
    if (scorePercent >= 0.5) {
      return 'دەستپێکی باشە. وەڵامەکان پێداچوونەوەیان بکە و دووبارە هەوڵبدە.';
    }
    return 'وەڵامە ڕاستەکان ببینە و دووبارە تاقیکردنەوەکە بکە.';
  }

  @override
  void onInit() {
    super.onInit();
    unawaited(_bootstrap());
  }

  @override
  void onClose() {
    _timer?.cancel();
    _legacyPageController.dispose();
    super.onClose();
  }

  static String repairText(String text) {
    return MojibakeFixer.repairText(text);
  }

  void ensureQuestionsLoaded({bool forceRefresh = false}) {
    if (_isCatalogLoading.value) {
      if (_isCatalogLoadStale()) {
        _isCatalogLoading.value = false;
        _catalogLoadStartedAt = null;
      } else {
        return;
      }
    }
    if (hasQuizCatalog && !forceRefresh) {
      return;
    }
    unawaited(loadQuizCatalog(forceRefresh: forceRefresh));
  }

  void recoverCatalogLoading() {
    _isCatalogLoading.value = false;
    _catalogLoadStartedAt = null;
    unawaited(loadQuizCatalog(forceRefresh: true));
  }

  bool hasCategory(String selectionId) {
    return hasSelection(selectionId);
  }

  bool hasSelection(String selectionId) {
    if (selectionId == _allSelectionId) {
      return true;
    }
    if (_parseCategorySelectionId(selectionId) != null) {
      return _findCategoryBySelectionId(selectionId) != null;
    }
    if (_parseQuizSelectionId(selectionId) != null) {
      return _findQuizBySelectionId(selectionId) != null;
    }
    return false;
  }

  bool canStartSelection(String selectionId) {
    final List<QuizCollection> relevant = _collectionsForSelection(selectionId);
    return relevant.isNotEmpty;
  }

  bool isSelectionLoaded(String selectionId) {
    final List<QuizCollection> relevant = _collectionsForSelection(selectionId);
    return relevant.isNotEmpty &&
        relevant.every((QuizCollection item) => item.isLoaded);
  }

  List<QuizCollection> quizCollectionsForCategory(String selectionId) {
    final int? categoryId = _parseCategorySelectionId(selectionId);
    if (selectionId == _allSelectionId || categoryId == null) {
      return List<QuizCollection>.from(_quizCollections);
    }

    return _quizCollections
        .where((QuizCollection item) => item.categoryId == categoryId)
        .toList();
  }

  String categoryTitleForQuiz(QuizCollection collection) {
    final QuizCategory? category = _findCategoryById(collection.categoryId);
    if (category == null) {
      return '';
    }
    return category.title;
  }

  Future<void> loadQuizCatalog({bool forceRefresh = false}) async {
    if (_isCatalogLoading.value) return;
    if (_hasLoadedCatalog.value && hasQuizCatalog && !forceRefresh) return;

    _isCatalogLoading.value = true;
    _catalogLoadStartedAt = DateTime.now();
    _catalogError.value = '';

    try {
      final List<dynamic> results = await Future.wait<dynamic>(<Future<dynamic>>[
        _quizApiService.fetchQuizCategories(),
        _quizApiService.fetchQuizCatalog(),
      ]);

      final List<QuizCategory> categories =
          results[0] as List<QuizCategory>;
      final List<QuizCollection> summaries =
          results[1] as List<QuizCollection>;

      _quizCategories.assignAll(categories);
      _mergeQuizCollections(summaries);
      _hasLoadedCatalog.value = true;
      _catalogError.value = _quizCollections.isEmpty
          ? 'هێشتا هیچ تاقیکردنەوەیەک بەردەست نییە.'
          : '';

      await _persistCatalogCache();
      unawaited(_warmQuizDetails(forceRefresh: forceRefresh));
    } on QuizApiException catch (error) {
      _catalogError.value = repairText(error.message);
      if (!hasQuizCatalog) {
        _allQuestions.clear();
      }
    } catch (_) {
      _catalogError.value = 'بارکردنی تاقیکردنەوەکان سەرکەوتوو نەبوو.';
      if (!hasQuizCatalog) {
        _allQuestions.clear();
      }
    } finally {
      _catalogLoadStartedAt = null;
      _isCatalogLoading.value = false;
    }
  }

  int totalQuestionsForCategory(String selectionId) {
    return totalQuestionsForSelection(selectionId);
  }

  int totalQuestionsForSelection(String selectionId) {
    return _questionsForSelection(selectionId).length;
  }

  Future<int> prepareSelection(String selectionId) async {
    await loadQuizCatalog();

    if (!canStartSelection(selectionId)) {
      return 0;
    }

    final List<int> missingQuizIds = _missingQuizIdsForSelection(selectionId);
    if (missingQuizIds.isEmpty) {
      return totalQuestionsForSelection(selectionId);
    }

    _isSelectionPreparing.value = true;
    _preparingSelectionId.value = selectionId;

    try {
      await Future.wait<void>(
        missingQuizIds.map((int quizId) async {
          await _loadQuizDetail(quizId);
        }),
      );
      await _persistCatalogCache();
      return totalQuestionsForSelection(selectionId);
    } finally {
      if (_preparingSelectionId.value == selectionId) {
        _preparingSelectionId.value = '';
      }
      _isSelectionPreparing.value = false;
    }
  }

  void startQuiz({QuizStartOptions? options}) {
    ensureQuestionsLoaded();
    final QuizStartOptions config = options ?? _startOptions.value;

    List<Question> prepared = _questionsForSelection(config.categoryId);
    _activeCategoryLabel.value = _selectionLabelForId(config.categoryId);

    if (config.shuffleOptions) {
      prepared = prepared.map(_shuffleQuestionOptions).toList();
    } else {
      prepared = prepared
          .map(
            (Question item) => item.copyWith(
              options: List<String>.from(item.options ?? const <String>[]),
            ),
          )
          .toList();
    }

    if (config.shuffleQuestions) {
      prepared.shuffle(_random);
    }

    if (prepared.isEmpty) {
      _startOptions.value = config.copyWith(questionCount: 0);
      _questions.clear();
      _answerHistory.clear();
      _currentQuestionIndex.value = 0;
      _questionNumber.value = 1;
      _remainingSeconds.value = config.timePerQuestion;
      _selectedAnswerIndex.value = -1;
      _correctAnswers.value = 0;
      _isAnswered.value = false;
      _isFinished.value = false;
      _hasSessionStarted.value = false;
      _timer?.cancel();
      return;
    }

    final int safeCount = config.questionCount.clamp(1, prepared.length);
    _startOptions.value = config.copyWith(questionCount: safeCount);

    _questions.assignAll(prepared.take(safeCount).toList());
    _answerHistory.clear();
    _currentQuestionIndex.value = 0;
    _questionNumber.value = 1;
    _remainingSeconds.value = config.timePerQuestion;
    _selectedAnswerIndex.value = -1;
    _correctAnswers.value = 0;
    _isAnswered.value = false;
    _isFinished.value = false;
    _hasSessionStarted.value = true;

    _startTimer();
  }

  void selectAnswer(int selectedIndex) {
    if (_isAnswered.value || _isFinished.value || _questions.isEmpty) return;
    _lockCurrentQuestion(selectedIndex: selectedIndex);
  }

  void checkAns(Question question, int selectedIndex) {
    selectAnswer(selectedIndex);
  }

  void skipQuestion({bool timedOut = false}) {
    if (_isAnswered.value || _isFinished.value || _questions.isEmpty) return;
    _lockCurrentQuestion(selectedIndex: -1, timedOut: timedOut);
  }

  void nextQuestion() {
    if (_isFinished.value || _questions.isEmpty) return;

    if (!_isAnswered.value) {
      skipQuestion();
    }

    if (_currentQuestionIndex.value >= _questions.length - 1) {
      finishQuiz();
      return;
    }

    _currentQuestionIndex.value += 1;
    _questionNumber.value = _currentQuestionIndex.value + 1;
    _remainingSeconds.value = _startOptions.value.timePerQuestion;
    _selectedAnswerIndex.value = -1;
    _isAnswered.value = false;
    _startTimer();
  }

  void updateTheQnNum(int index) {
    if (index < 0 || index >= _questions.length) return;
    _currentQuestionIndex.value = index;
    _questionNumber.value = index + 1;
  }

  void finishQuiz() {
    _timer?.cancel();
    _isFinished.value = true;
    if (_correctAnswers.value > _bestScore.value) {
      _bestScore.value = _correctAnswers.value;
      unawaited(_saveBestScore(_bestScore.value));
    }
  }

  void pauseTimer() {
    _timer?.cancel();
  }

  void resumeTimer() {
    if (_questions.isEmpty || _isFinished.value || _isAnswered.value) return;
    _startTimer();
  }

  void continueQuiz() {
    resumeTimer();
  }

  Future<void> _bootstrap() async {
    await _loadBestScore();
    await _restoreCatalogCache();
    await loadQuizCatalog(forceRefresh: true);
  }

  bool _isCatalogLoadStale() {
    final DateTime? startedAt = _catalogLoadStartedAt;
    if (startedAt == null) {
      return false;
    }
    return DateTime.now().difference(startedAt) >
        const Duration(seconds: 15);
  }

  Future<void> _restoreCatalogCache() async {
    try {
      final SharedPreferences prefs = await _prefsInstance();
      final String? categoriesRaw = prefs.getString(_quizCategoriesCacheKey);
      final String? collectionsRaw = prefs.getString(_quizCollectionsCacheKey);

      final List<QuizCategory> categories = _decodeCategories(categoriesRaw);
      final List<QuizCollection> collections = _decodeCollections(collectionsRaw);

      if (categories.isNotEmpty) {
        _quizCategories.assignAll(categories);
      }
      if (collections.isNotEmpty) {
        _quizCollections.assignAll(collections);
        _rebuildAllQuestions();
      }

      if (categories.isNotEmpty || collections.isNotEmpty) {
        _hasLoadedCatalog.value = true;
        _activeCategoryLabel.value = _selectionLabelForId(
          _startOptions.value.categoryId,
        );
      }
    } catch (_) {}
  }

  Future<void> _persistCatalogCache() async {
    try {
      final SharedPreferences prefs = await _prefsInstance();
      await prefs.setString(
        _quizCategoriesCacheKey,
        jsonEncode(
          _quizCategories
              .map((QuizCategory item) => item.toJson())
              .toList(),
        ),
      );
      await prefs.setString(
        _quizCollectionsCacheKey,
        jsonEncode(
          _quizCollections
              .map((QuizCollection item) => item.toJson())
              .toList(),
        ),
      );
    } catch (_) {}
  }

  Future<void> _warmQuizDetails({bool forceRefresh = false}) async {
    if (_isWarmingQuizDetails) {
      return;
    }

    final List<int> pendingIds = _quizCollections
        .where(
          (QuizCollection item) =>
              item.id != null && (forceRefresh || !item.isLoaded),
        )
        .map((QuizCollection item) => item.id!)
        .toList();

    if (pendingIds.isEmpty) {
      return;
    }

    _isWarmingQuizDetails = true;
    try {
      await Future.wait<void>(
        pendingIds.map((int quizId) async {
          await _loadQuizDetail(quizId);
        }),
      );
      await _persistCatalogCache();
    } finally {
      _isWarmingQuizDetails = false;
    }
  }

  Future<QuizCollection?> _loadQuizDetail(int quizId) {
    return _detailRequests.putIfAbsent(quizId, () async {
      try {
        final QuizCollection detail = await _quizApiService.fetchQuizDetail(
          quizId,
        );
        _upsertQuizCollection(detail);
        return detail;
      } catch (_) {
        return null;
      } finally {
        _detailRequests.remove(quizId);
      }
    });
  }

  void _mergeQuizCollections(List<QuizCollection> summaries) {
    final Map<int, QuizCollection> existingById = <int, QuizCollection>{};
    for (final QuizCollection item in _quizCollections) {
      if (item.id != null) {
        existingById[item.id!] = item;
      }
    }

    final List<QuizCollection> merged = summaries.map((QuizCollection summary) {
      final QuizCollection? existing =
          summary.id == null ? null : existingById[summary.id!];
      if (existing == null) {
        return summary;
      }

      return summary.copyWith(
        questions: existing.questions,
        isLoaded: existing.isLoaded,
      );
    }).toList();

    _quizCollections.assignAll(merged);
    _rebuildAllQuestions();
  }

  void _upsertQuizCollection(QuizCollection detail) {
    final int index = _quizCollections.indexWhere(
      (QuizCollection item) => item.id == detail.id,
    );

    if (index >= 0) {
      final QuizCollection existing = _quizCollections[index];
      _quizCollections[index] = detail.copyWith(
        title: detail.title.isEmpty ? existing.title : detail.title,
        description: detail.description.isEmpty
            ? existing.description
            : detail.description,
        categoryId: detail.categoryId ?? existing.categoryId,
        status: detail.status.isEmpty ? existing.status : detail.status,
        isRemote: existing.isRemote || detail.isRemote,
        isLoaded: true,
      );
      _quizCollections.refresh();
    } else {
      _quizCollections.add(detail);
    }

    _rebuildAllQuestions();
  }

  void _rebuildAllQuestions() {
    _allQuestions.assignAll(
      _quizCollections.expand((QuizCollection item) => item.questions),
    );

    if (!_hasSessionStarted.value) {
      _questions.clear();
      _activeCategoryLabel.value = _selectionLabelForId(
        _startOptions.value.categoryId,
      );
    }
  }

  void _lockCurrentQuestion({
    required int selectedIndex,
    bool timedOut = false,
  }) {
    final Question question = currentQuestion;
    final int correctIndex = question.answer ?? -1;

    _isAnswered.value = true;
    _selectedAnswerIndex.value = selectedIndex;
    _timer?.cancel();

    if (selectedIndex == correctIndex) {
      _correctAnswers.value += 1;
    }

    _answerHistory.add(
      QuizAnswerRecord(
        question: question,
        questionNumber: _currentQuestionIndex.value + 1,
        selectedIndex: selectedIndex,
        correctIndex: correctIndex,
        timedOut: timedOut,
      ),
    );
  }

  void _startTimer() {
    _timer?.cancel();

    if (_remainingSeconds.value <= 0) {
      _remainingSeconds.value = _startOptions.value.timePerQuestion;
    }

    _timer = Timer.periodic(const Duration(seconds: 1), (Timer timer) {
      if (_remainingSeconds.value <= 1) {
        _remainingSeconds.value = 0;
        timer.cancel();
        if (!_isAnswered.value) {
          skipQuestion(timedOut: true);
        }
        return;
      }
      _remainingSeconds.value -= 1;
    });
  }

  List<QuizCollection> _collectionsForSelection(String selectionId) {
    if (selectionId == _allSelectionId) {
      return List<QuizCollection>.from(_quizCollections);
    }

    final int? categoryId = _parseCategorySelectionId(selectionId);
    if (categoryId != null) {
      return _quizCollections
          .where((QuizCollection item) => item.categoryId == categoryId)
          .toList();
    }

    final int? quizId = _parseQuizSelectionId(selectionId);
    if (quizId != null) {
      final QuizCollection? collection = _findQuizById(quizId);
      return collection == null ? const <QuizCollection>[] : <QuizCollection>[collection];
    }

    return const <QuizCollection>[];
  }

  List<Question> _questionsForSelection(String selectionId) {
    return _collectionsForSelection(selectionId)
        .expand((QuizCollection item) => item.questions)
        .toList();
  }

  List<int> _missingQuizIdsForSelection(String selectionId) {
    return _collectionsForSelection(selectionId)
        .where(
          (QuizCollection item) =>
              item.id != null && (!item.isLoaded || item.questions.isEmpty),
        )
        .map((QuizCollection item) => item.id!)
        .toList();
  }

  Question _shuffleQuestionOptions(Question original) {
    final List<String> originalOptions = List<String>.from(
      original.options ?? const <String>[],
    );
    if (originalOptions.isEmpty) {
      return original;
    }

    final int originalAnswerIndex = original.answer ?? 0;
    final List<int> order = List<int>.generate(
      originalOptions.length,
      (int index) => index,
    );
    order.shuffle(_random);

    final List<String> shuffledOptions = order
        .map((int originalIndex) => originalOptions[originalIndex])
        .toList();
    final int newAnswerIndex = order.indexOf(originalAnswerIndex);

    return original.copyWith(
      options: shuffledOptions,
      answer: newAnswerIndex < 0 ? 0 : newAnswerIndex,
    );
  }

  String _selectionLabelForId(String selectionId) {
    if (selectionId == _allSelectionId) {
      return 'هەموو';
    }

    final QuizCategory? category = _findCategoryBySelectionId(selectionId);
    if (category != null) {
      return category.title;
    }

    final QuizCollection? quiz = _findQuizBySelectionId(selectionId);
    if (quiz != null) {
      return quiz.title;
    }

    return 'هەموو';
  }

  QuizCategory? _findCategoryById(int? id) {
    if (id == null) {
      return null;
    }

    for (final QuizCategory item in _quizCategories) {
      if (item.id == id) {
        return item;
      }
    }
    return null;
  }

  QuizCategory? _findCategoryBySelectionId(String selectionId) {
    final int? categoryId = _parseCategorySelectionId(selectionId);
    return _findCategoryById(categoryId);
  }

  QuizCollection? _findQuizById(int? id) {
    if (id == null) {
      return null;
    }

    for (final QuizCollection item in _quizCollections) {
      if (item.id == id) {
        return item;
      }
    }
    return null;
  }

  QuizCollection? _findQuizBySelectionId(String selectionId) {
    final int? quizId = _parseQuizSelectionId(selectionId);
    return _findQuizById(quizId);
  }

  int? _parseCategorySelectionId(String selectionId) {
    if (!selectionId.startsWith('category:')) {
      return null;
    }
    return int.tryParse(selectionId.substring('category:'.length));
  }

  int? _parseQuizSelectionId(String selectionId) {
    if (!selectionId.startsWith('quiz:')) {
      return null;
    }
    return int.tryParse(selectionId.substring('quiz:'.length));
  }

  Future<SharedPreferences> _prefsInstance() async {
    if (_prefs != null) {
      return _prefs!;
    }

    _prefs = await SharedPreferences.getInstance();
    return _prefs!;
  }

  Future<void> _loadBestScore() async {
    try {
      final SharedPreferences prefs = await _prefsInstance();
      _bestScore.value = prefs.getInt(_bestScoreKey) ?? 0;
    } catch (_) {
      _bestScore.value = _bestScore.value;
    }
  }

  Future<void> _saveBestScore(int score) async {
    try {
      final SharedPreferences prefs = await _prefsInstance();
      await prefs.setInt(_bestScoreKey, score);
    } catch (_) {}
  }

  List<QuizCategory> _decodeCategories(String? raw) {
    if (raw == null || raw.trim().isEmpty) {
      return const <QuizCategory>[];
    }

    try {
      final dynamic decoded = jsonDecode(raw);
      if (decoded is! List) {
        return const <QuizCategory>[];
      }

      return decoded
          .whereType<Map>()
          .map(
            (Map item) => QuizCategory.fromJson(Map<String, dynamic>.from(item)),
          )
          .where((QuizCategory item) => item.id > 0)
          .toList();
    } catch (_) {
      return const <QuizCategory>[];
    }
  }

  List<QuizCollection> _decodeCollections(String? raw) {
    if (raw == null || raw.trim().isEmpty) {
      return const <QuizCollection>[];
    }

    try {
      final dynamic decoded = jsonDecode(raw);
      if (decoded is! List) {
        return const <QuizCollection>[];
      }

      return decoded
          .whereType<Map>()
          .map(
            (Map item) =>
                QuizCollection.fromJson(Map<String, dynamic>.from(item)),
          )
          .where((QuizCollection item) => item.id != null)
          .toList();
    } catch (_) {
      return const <QuizCollection>[];
    }
  }
}
