import 'dart:convert';
import 'dart:io';
import 'package:flutter/cupertino.dart';
import 'package:flutter/services.dart';
import 'package:runaki_islam/models/allah_names_model.dart';
import 'package:runaki_islam/models/farmuda_model.dart';
import 'package:runaki_islam/models/sebha_model.dart';
import 'package:runaki_islam/util/mojibake_fixer.dart';
import 'package:path_provider/path_provider.dart';
import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';

class DatabaseHelper {
  static final DatabaseHelper _instance = DatabaseHelper.internal();
  static const int _contentSchemaVersion = 3;
  static const String _contentSchemaVersionKey = 'content_schema_version';
  static const String _bundledDatabaseAssetPath =
      'assets/db/content/app_data.db';
  static const String _bundledFarmudaDatabaseAssetPath =
      'assets/db/content/farmuda.db';
  static const String _bundledCherokDatabaseAssetPath =
      'assets/db/content/cherok.db';
  static const String _bundledAllahNamesDatabaseAssetPath =
      'assets/db/content/allah_names.db';
  static const String _localDatabaseFileName = 'app_data.db';
  static const String _legacyLocalDatabaseFileName = 'assets_icons_icon_2.png';

  static const String sectionZekr = 'zekr';
  static const String sectionPrsyarAyne = 'prsyar_ayne';
  static const String sectionDua = 'dua';
  static const String sectionProphetBiography = 'prophet_biography';
  static const String sectionProphetMiracles = 'prophet_miracles';
  static const String sectionZhyanNamayPexambaran = 'zhyan_namay_pexambaran';
  static const String sectionTawanaGawrakan = 'tawana_gawrakan';
  static const String sectionHawalanePexambar = 'hawalane_pexambar';
  static const String sectionZanyareQuran = 'zanyare_quran';
  static const String sectionRamadanPage15 = 'ramadan_page_15';
  static const String sectionRamadanPage16 = 'ramadan_page_16';
  static const String sectionRamadanPage17 = 'ramadan_page_17';
  static const String sectionRamadanPage18 = 'ramadan_page_18';
  static const String sectionWtawAmozhgary = 'wtaw_amozhgary';
  static const String sectionSunatakan = 'sunatakan';
  static const String sectionHaramkrawakan = 'haramkrawakan';
  static const String sectionPuxtaySaheheMuslim = 'puxtay_sahehe_muslim';
  static const String sectionPrsyarRozheDway = 'prsyar_rozhe_dway';
  static const String sectionFarmuda = 'farmuda';
  static const String sectionCherok = 'cherok';
  static const String sectionAllahNames = 'allah_names';

  static const Map<String, String> _legacyAssetSectionKeys = <String, String>{
    'assets/data/content/zekr.json': sectionZekr,
    'assets/data/content/prsyar_ayne.json': sectionPrsyarAyne,
    'assets/data/content/dua.json': sectionDua,
    'assets/data/content/prophet_biography.json': sectionProphetBiography,
    'assets/data/content/prophet_miracles.json': sectionProphetMiracles,
    'assets/data/content/zhyan_namay_pexambaran.json':
        sectionZhyanNamayPexambaran,
    'assets/data/content/tawana_gawrakan.json': sectionTawanaGawrakan,
    'assets/data/content/hawalane_pexambar.json': sectionHawalanePexambar,
    'assets/data/content/zanyare_quran.json': sectionZanyareQuran,
    'assets/data/content/ramadan_page_15.json': sectionRamadanPage15,
    'assets/data/content/ramadan_page_16.json': sectionRamadanPage16,
    'assets/data/content/ramadan_page_17.json': sectionRamadanPage17,
    'assets/data/content/ramadan_page_18.json': sectionRamadanPage18,
    'assets/data/content/wtaw_amozhgary.json': sectionWtawAmozhgary,
    'assets/data/content/sunatakan.json': sectionSunatakan,
    'assets/data/content/haramkrawakan.json': sectionHaramkrawakan,
    'assets/data/content/puxtay_sahehe_muslim.json': sectionPuxtaySaheheMuslim,
    'assets/data/content/prsyar_rozhe_dway.json': sectionPrsyarRozheDway,
  };

  DatabaseHelper.internal();

  factory DatabaseHelper() => _instance;

  Database? _database;
  Future<void>? _contentInitializationFuture;
  final Map<String, List<Map<String, dynamic>>> _contentCache =
      <String, List<Map<String, dynamic>>>{};

  Future<Database> get database async {
    if (_database != null) return _database!;

    _database = await initialDatabase();
    return _database!;
  }

  Future<bool> isFileExists() async {
    final path = await _databasePath();
    if (await File(path).exists()) {
      return true;
    }

    final legacyPath = await _legacyDatabasePath();
    return File(legacyPath).exists();
  }

  Future<Database> initialDatabase() async {
    final String path = await _databasePath();
    if (!await File(path).exists()) {
      final legacyPath = await _legacyDatabasePath();
      final legacyFile = File(legacyPath);
      if (await legacyFile.exists()) {
        await legacyFile.rename(path);
      } else {
        ByteData data = await rootBundle.load(_bundledDatabaseAssetPath);
        List<int> bytes = data.buffer.asUint8List(
          data.offsetInBytes,
          data.lengthInBytes,
        );

        await File(path).writeAsBytes(bytes);
      }
    }
    return await openDatabase(path);
  }

  Future<String> _databasePath() async {
    Directory directory = await getApplicationDocumentsDirectory();
    return join(directory.path, _localDatabaseFileName);
  }

  Future<String> _legacyDatabasePath() async {
    Directory directory = await getApplicationDocumentsDirectory();
    return join(directory.path, _legacyLocalDatabaseFileName);
  }

  Future<List<Map<String, dynamic>>> getData(String table, String ids) async {
    var dbClient = await database;
    String sqlCommand;
    if (ids == '-1') {
      sqlCommand = 'SELECT * FROM $table';
    } else {
      sqlCommand = 'SELECT * FROM $table WHERE id IN ($ids)';
    }

    final List<Map<String, dynamic>> result = await dbClient.rawQuery(
      sqlCommand,
    );

    debugPrint('getData $table done : ${result.length} ');
    return _repairRowList(result);
  }

  Future<int> insert(String table, Map<String, dynamic> map) async {
    var dbClient = await database;
    int result = await dbClient.insert(table, map);
    debugPrint('addFavorite : $result');
    return result;
  }

  Future<int> delete({
    required String? table,
    String tableField = 'id',
    required int? id,
  }) async {
    var dbClient = await database;
    int result = await dbClient.delete(
      table!,
      where: '$tableField = ?',
      whereArgs: [id],
    );

    debugPrint('delete done : $result ');
    return result;
  }

  Future<int> updateItemFromSebha(SebhaModel sebha) async {
    var dbClient = await database;
    int result = await dbClient.rawUpdate(
      'UPDATE tasbih SET name = ? , counter = ? WHERE id = ${sebha.id}',
      [sebha.name, sebha.counter],
    );
    debugPrint('addFavorite : $result');
    return result;
  }

  Future<int> updateFavoriteInTables(
    String tableName,
    int favorite,
    int id,
  ) async {
    var dbClient = await database;
    int result = await dbClient.rawUpdate(
      'UPDATE $tableName SET favorite=$favorite WHERE id=$id',
    );

    debugPrint('uptadeFavoriteIn $tableName : $result');
    return result;
  }

  Future<int> updateSettings(String nameField, dynamic value) async {
    var dbClient = await database;
    int result = await dbClient.rawUpdate(
      'UPDATE settings SET $nameField=$value WHERE id=0',
    );

    debugPrint('updateSettings : $result');
    return result;
  }

  Future<void> _ensureZekrFavoritesTable(Database dbClient) async {
    await dbClient.execute('''
      CREATE TABLE IF NOT EXISTS zekr_favorites (
        item_key TEXT PRIMARY KEY
      )
    ''');
  }

  Future<Set<String>> getZekrFavoriteKeys() async {
    final dbClient = await database;
    await _ensureZekrFavoritesTable(dbClient);
    final result = await dbClient.query(
      'zekr_favorites',
      columns: ['item_key'],
    );

    return result.map((row) => row['item_key']).whereType<String>().toSet();
  }

  Future<void> setZekrFavorite(String itemKey, bool isFavorite) async {
    final dbClient = await database;
    await _ensureZekrFavoritesTable(dbClient);

    if (isFavorite) {
      await dbClient.insert('zekr_favorites', <String, Object?>{
        'item_key': itemKey,
      }, conflictAlgorithm: ConflictAlgorithm.replace);
      return;
    }

    await dbClient.delete(
      'zekr_favorites',
      where: 'item_key = ?',
      whereArgs: [itemKey],
    );
  }

  Future<void> _ensureZekrStateTable(Database dbClient) async {
    await dbClient.execute('''
      CREATE TABLE IF NOT EXISTS zekr_state (
        state_key TEXT PRIMARY KEY,
        state_value TEXT
      )
    ''');
  }

  Future<String?> getZekrLastOpenedKey() async {
    final dbClient = await database;
    await _ensureZekrStateTable(dbClient);
    final result = await dbClient.query(
      'zekr_state',
      columns: ['state_value'],
      where: 'state_key = ?',
      whereArgs: ['last_opened_key'],
      limit: 1,
    );
    if (result.isEmpty) return null;
    return result.first['state_value'] as String?;
  }

  Future<void> setZekrLastOpenedKey(String itemKey) async {
    final dbClient = await database;
    await _ensureZekrStateTable(dbClient);
    await dbClient.insert('zekr_state', <String, Object?>{
      'state_key': 'last_opened_key',
      'state_value': itemKey,
    }, conflictAlgorithm: ConflictAlgorithm.replace);
  }

  Future<void> _ensureFarmudaFavoritesTable(Database dbClient) async {
    await dbClient.execute('''
      CREATE TABLE IF NOT EXISTS farmuda_favorites (
        item_key TEXT PRIMARY KEY
      )
    ''');
  }

  Future<Set<String>> getFarmudaFavoriteKeys() async {
    final dbClient = await database;
    await _ensureFarmudaFavoritesTable(dbClient);
    final result = await dbClient.query(
      'farmuda_favorites',
      columns: ['item_key'],
    );

    return result.map((row) => row['item_key']).whereType<String>().toSet();
  }

  Future<void> setFarmudaFavorite(String itemKey, bool isFavorite) async {
    final dbClient = await database;
    await _ensureFarmudaFavoritesTable(dbClient);

    if (isFavorite) {
      await dbClient.insert('farmuda_favorites', <String, Object?>{
        'item_key': itemKey,
      }, conflictAlgorithm: ConflictAlgorithm.replace);
      return;
    }

    await dbClient.delete(
      'farmuda_favorites',
      where: 'item_key = ?',
      whereArgs: [itemKey],
    );
  }

  Future<void> _ensureFarmudaStateTable(Database dbClient) async {
    await dbClient.execute('''
      CREATE TABLE IF NOT EXISTS farmuda_state (
        state_key TEXT PRIMARY KEY,
        state_value TEXT
      )
    ''');
  }

  Future<String?> getFarmudaLastOpenedKey() async {
    final dbClient = await database;
    await _ensureFarmudaStateTable(dbClient);
    final result = await dbClient.query(
      'farmuda_state',
      columns: ['state_value'],
      where: 'state_key = ?',
      whereArgs: ['last_opened_key'],
      limit: 1,
    );
    if (result.isEmpty) return null;
    return result.first['state_value'] as String?;
  }

  Future<void> setFarmudaLastOpenedKey(String itemKey) async {
    final dbClient = await database;
    await _ensureFarmudaStateTable(dbClient);
    await dbClient.insert('farmuda_state', <String, Object?>{
      'state_key': 'last_opened_key',
      'state_value': itemKey,
    }, conflictAlgorithm: ConflictAlgorithm.replace);
  }

  Future<void> _ensurePrsyarFavoritesTable(Database dbClient) async {
    await dbClient.execute('''
      CREATE TABLE IF NOT EXISTS prsyar_favorites (
        item_key TEXT PRIMARY KEY
      )
    ''');
  }

  Future<Set<String>> getPrsyarFavoriteKeys() async {
    final dbClient = await database;
    await _ensurePrsyarFavoritesTable(dbClient);
    final result = await dbClient.query(
      'prsyar_favorites',
      columns: ['item_key'],
    );

    return result.map((row) => row['item_key']).whereType<String>().toSet();
  }

  Future<void> setPrsyarFavorite(String itemKey, bool isFavorite) async {
    final dbClient = await database;
    await _ensurePrsyarFavoritesTable(dbClient);

    if (isFavorite) {
      await dbClient.insert('prsyar_favorites', <String, Object?>{
        'item_key': itemKey,
      }, conflictAlgorithm: ConflictAlgorithm.replace);
      return;
    }

    await dbClient.delete(
      'prsyar_favorites',
      where: 'item_key = ?',
      whereArgs: [itemKey],
    );
  }

  Future<void> _ensurePrsyarStateTable(Database dbClient) async {
    await dbClient.execute('''
      CREATE TABLE IF NOT EXISTS prsyar_state (
        state_key TEXT PRIMARY KEY,
        state_value TEXT
      )
    ''');
  }

  Future<String?> getPrsyarLastOpenedKey() async {
    final dbClient = await database;
    await _ensurePrsyarStateTable(dbClient);
    final result = await dbClient.query(
      'prsyar_state',
      columns: ['state_value'],
      where: 'state_key = ?',
      whereArgs: ['last_opened_key'],
      limit: 1,
    );
    if (result.isEmpty) return null;
    return result.first['state_value'] as String?;
  }

  Future<void> setPrsyarLastOpenedKey(String itemKey) async {
    final dbClient = await database;
    await _ensurePrsyarStateTable(dbClient);
    await dbClient.insert('prsyar_state', <String, Object?>{
      'state_key': 'last_opened_key',
      'state_value': itemKey,
    }, conflictAlgorithm: ConflictAlgorithm.replace);
  }

  Future<void> _ensureCherokFavoritesTable(Database dbClient) async {
    await dbClient.execute('''
      CREATE TABLE IF NOT EXISTS cherok_favorites (
        item_key TEXT PRIMARY KEY
      )
    ''');
  }

  Future<Set<String>> getCherokFavoriteKeys() async {
    final dbClient = await database;
    await _ensureCherokFavoritesTable(dbClient);
    final result = await dbClient.query(
      'cherok_favorites',
      columns: ['item_key'],
    );

    return result.map((row) => row['item_key']).whereType<String>().toSet();
  }

  Future<void> setCherokFavorite(String itemKey, bool isFavorite) async {
    final dbClient = await database;
    await _ensureCherokFavoritesTable(dbClient);

    if (isFavorite) {
      await dbClient.insert('cherok_favorites', <String, Object?>{
        'item_key': itemKey,
      }, conflictAlgorithm: ConflictAlgorithm.replace);
      return;
    }

    await dbClient.delete(
      'cherok_favorites',
      where: 'item_key = ?',
      whereArgs: [itemKey],
    );
  }

  Future<void> _ensureCherokStateTable(Database dbClient) async {
    await dbClient.execute('''
      CREATE TABLE IF NOT EXISTS cherok_state (
        state_key TEXT PRIMARY KEY,
        state_value TEXT
      )
    ''');
  }

  Future<String?> getCherokLastOpenedKey() async {
    final dbClient = await database;
    await _ensureCherokStateTable(dbClient);
    final result = await dbClient.query(
      'cherok_state',
      columns: ['state_value'],
      where: 'state_key = ?',
      whereArgs: ['last_opened_key'],
      limit: 1,
    );
    if (result.isEmpty) return null;
    return result.first['state_value'] as String?;
  }

  Future<void> setCherokLastOpenedKey(String itemKey) async {
    final dbClient = await database;
    await _ensureCherokStateTable(dbClient);
    await dbClient.insert('cherok_state', <String, Object?>{
      'state_key': 'last_opened_key',
      'state_value': itemKey,
    }, conflictAlgorithm: ConflictAlgorithm.replace);
  }

  Future<List<Map<String, dynamic>>> getContentItems(String sectionKey) async {
    final normalizedSection = sectionKey.trim();
    final cachedItems = _contentCache[normalizedSection];
    if (cachedItems != null) {
      return _cloneContentItems(cachedItems);
    }

    final dbClient = await database;
    await _ensureUnifiedContentTables(dbClient);
    final rows = await dbClient.query(
      'content_items',
      columns: <String>['payload_json'],
      where: 'section_key = ?',
      whereArgs: <Object>[normalizedSection],
      orderBy: 'sort_order ASC, item_id ASC',
    );

    final decodedItems = rows
        .map<Map<String, dynamic>?>((row) => _decodeStoredPayload(row))
        .whereType<Map<String, dynamic>>()
        .toList(growable: false);

    _contentCache[normalizedSection] = decodedItems;
    return _cloneContentItems(decodedItems);
  }

  Future<List<Map<String, dynamic>>> getContentItemsByAssetPath(
    String assetPath,
  ) async {
    final normalizedPath = _normalizeAssetPath(assetPath);
    final sectionKey = _legacyAssetSectionKeys[normalizedPath];
    if (sectionKey != null) {
      return getContentItems(sectionKey);
    }

    final raw = await rootBundle.loadString(normalizedPath);
    return _decodeJsonList(raw);
  }

  Future<String> loadLegacyJsonAsset(String assetPath) async {
    final items = await getContentItemsByAssetPath(assetPath);
    return jsonEncode(items);
  }

  Future<List<Map<String, dynamic>>> getFarmudaRows() async {
    return getContentItems(sectionFarmuda);
  }

  Future<List<Map<String, dynamic>>> getCherokRows() async {
    return getContentItems(sectionCherok);
  }

  Future<List<Map<String, dynamic>>> getAllahNameRows() async {
    return getContentItems(sectionAllahNames);
  }

  Future<void> _ensureUnifiedContentTables(Database dbClient) {
    _contentInitializationFuture ??= _initializeUnifiedContentTables(dbClient)
        .catchError((Object error) {
          _contentInitializationFuture = null;
          throw error;
        });
    return _contentInitializationFuture!;
  }

  Future<void> _initializeUnifiedContentTables(Database dbClient) async {
    await dbClient.execute('''
      CREATE TABLE IF NOT EXISTS app_meta (
        key TEXT PRIMARY KEY,
        value TEXT
      )
    ''');

    await dbClient.execute('''
      CREATE TABLE IF NOT EXISTS content_items (
        section_key TEXT NOT NULL,
        item_id INTEGER NOT NULL,
        sort_order INTEGER NOT NULL,
        title TEXT,
        body TEXT,
        extra_text TEXT,
        payload_json TEXT NOT NULL,
        PRIMARY KEY (section_key, item_id)
      )
    ''');

    await dbClient.execute('''
      CREATE INDEX IF NOT EXISTS idx_content_items_section
      ON content_items(section_key, sort_order, item_id)
    ''');

    final metaRows = await dbClient.query(
      'app_meta',
      columns: <String>['value'],
      where: 'key = ?',
      whereArgs: <Object>[_contentSchemaVersionKey],
      limit: 1,
    );
    final currentVersion = metaRows.isEmpty
        ? null
        : int.tryParse(metaRows.first['value']?.toString() ?? '');

    if (currentVersion == _contentSchemaVersion) {
      return;
    }

    await dbClient.transaction((txn) async {
      await txn.delete('content_items');

      for (final entry in _legacyAssetSectionKeys.entries) {
        final rows = await _readJsonAssetRows(entry.key);
        await _insertContentRows(txn, entry.value, rows);
      }

      await _importBundledDatabaseSection(
        txn,
        sectionKey: sectionFarmuda,
        assetPath: _bundledFarmudaDatabaseAssetPath,
        tableName: 'farmuday_mrwary_main',
      );
      await _importBundledDatabaseSection(
        txn,
        sectionKey: sectionCherok,
        assetPath: _bundledCherokDatabaseAssetPath,
        tableName: 'derman',
      );
      await _importBundledDatabaseSection(
        txn,
        sectionKey: sectionAllahNames,
        assetPath: _bundledAllahNamesDatabaseAssetPath,
        tableName: 'new',
      );

      await txn.insert('app_meta', <String, Object?>{
        'key': _contentSchemaVersionKey,
        'value': _contentSchemaVersion.toString(),
      }, conflictAlgorithm: ConflictAlgorithm.replace);
    });

    _contentCache.clear();
  }

  Future<void> _importBundledDatabaseSection(
    DatabaseExecutor executor, {
    required String sectionKey,
    required String assetPath,
    required String tableName,
  }) async {
    final rows = await _readBundledDatabaseRows(assetPath, tableName);
    final decodedRows = rows
        .map<Map<String, dynamic>>(
          (row) => _repairRow(Map<String, dynamic>.from(row)),
        )
        .toList(growable: false);
    await _insertContentRows(executor, sectionKey, decodedRows);
  }

  Future<List<Map<String, Object?>>> _readBundledDatabaseRows(
    String assetPath,
    String tableName,
  ) async {
    final supportDirectory = await getApplicationSupportDirectory();
    final copyPath = join(
      supportDirectory.path,
      '${basenameWithoutExtension(assetPath)}_$tableName.sqlite',
    );

    final data = await rootBundle.load(_normalizeAssetPath(assetPath));
    final bytes = data.buffer.asUint8List(
      data.offsetInBytes,
      data.lengthInBytes,
    );
    await File(copyPath).writeAsBytes(bytes, flush: true);

    final db = await openDatabase(copyPath, readOnly: true);
    try {
      final rows = await db.query(tableName);
      return _repairRowList(rows);
    } finally {
      await db.close();
    }
  }

  Future<List<Map<String, dynamic>>> _readJsonAssetRows(
    String assetPath,
  ) async {
    final raw = await rootBundle.loadString(_normalizeAssetPath(assetPath));
    return _decodeJsonList(raw);
  }

  Future<void> _insertContentRows(
    DatabaseExecutor executor,
    String sectionKey,
    List<Map<String, dynamic>> rows,
  ) async {
    for (int index = 0; index < rows.length; index++) {
      final row = rows[index];
      final summary = _buildContentSummary(sectionKey, row, index);
      await executor.insert('content_items', <String, Object?>{
        'section_key': sectionKey,
        'item_id': summary.itemId,
        'sort_order': index,
        'title': summary.title,
        'body': summary.body,
        'extra_text': summary.extra,
        'payload_json': jsonEncode(row),
      }, conflictAlgorithm: ConflictAlgorithm.replace);
    }
  }

  _ContentSummary _buildContentSummary(
    String sectionKey,
    Map<String, dynamic> row,
    int index,
  ) {
    final itemId = _resolveContentItemId(sectionKey, row, index);
    switch (sectionKey) {
      case sectionPrsyarAyne:
        return _ContentSummary(
          itemId: itemId,
          title: _readText(row, <String>['babat', 'prsyar']),
          body: _readText(row, <String>['prsyar', 'walam']),
          extra: _readText(row, <String>['walam']),
        );
      case sectionWtawAmozhgary:
        return _ContentSummary(
          itemId: itemId,
          title: _compactText(_readText(row, <String>['text']), 64),
          body: _readText(row, <String>['text']),
        );
      case sectionPuxtaySaheheMuslim:
        return _ContentSummary(
          itemId: itemId,
          title: _readText(row, <String>['sarder']),
          body: _readText(row, <String>['drezha']),
          extra: _readText(row, <String>['page_num']),
        );
      case sectionPrsyarRozheDway:
        return _ContentSummary(
          itemId: itemId,
          title: _readText(row, <String>['sarder']),
          body: _readText(row, <String>['drezha']),
          extra: _readText(row, <String>['bash']),
        );
      case sectionFarmuda:
        return _ContentSummary(
          itemId: itemId,
          title: _readText(row, <String>['title']),
          body: _readText(row, <String>['ku_desc']),
          extra: _readText(row, <String>['ar_desc']),
        );
      case sectionCherok:
        return _ContentSummary(
          itemId: itemId,
          title: _readText(row, <String>['nawe']),
          body: _readText(row, <String>['nbuss']),
        );
      case sectionAllahNames:
        return _ContentSummary(
          itemId: itemId,
          title: _readText(row, <String>['t1']),
          body: _readText(row, <String>['t2']),
        );
      default:
        return _ContentSummary(
          itemId: itemId,
          title: _readText(row, <String>['title', 'sarder']),
          body: _readText(row, <String>[
            'description',
            'desc',
            'drezha',
            'description2',
            'text',
          ]),
          extra: _readText(row, <String>['description2', 'bash']),
        );
    }
  }

  int _resolveContentItemId(
    String sectionKey,
    Map<String, dynamic> row,
    int index,
  ) {
    // `page_num` groups many PSM rows under the same section number, so using it
    // as a primary key collapses 1686 rows down to 70 unique records.
    if (sectionKey == sectionPuxtaySaheheMuslim) {
      return index + 1;
    }

    const candidateKeys = <String>['id', '_id', 'page_num'];
    for (final key in candidateKeys) {
      final value = row[key];
      if (value is int) return value;
      final parsed = int.tryParse(value?.toString() ?? '');
      if (parsed != null) {
        return parsed;
      }
    }
    return index + 1;
  }

  String? _readText(Map<String, dynamic> row, List<String> keys) {
    for (final key in keys) {
      final rawValue = row[key]?.toString().trim();
      final value = rawValue == null
          ? null
          : MojibakeFixer.repairText(rawValue);
      if (value != null && value.isNotEmpty) {
        return value;
      }
    }
    return null;
  }

  String? _compactText(String? value, int limit) {
    if (value == null) return null;
    final compact = value.replaceAll(RegExp(r'\s+'), ' ').trim();
    if (compact.isEmpty) return null;
    if (compact.length <= limit) return compact;
    return '${compact.substring(0, limit).trim()}...';
  }

  Map<String, dynamic>? _decodeStoredPayload(Map<String, Object?> row) {
    final raw = row['payload_json']?.toString();
    if (raw == null || raw.trim().isEmpty) {
      return null;
    }

    try {
      final decoded = jsonDecode(raw);
      if (decoded is Map<String, dynamic>) {
        return _repairRow(decoded);
      }
      if (decoded is Map) {
        return _repairRow(Map<String, dynamic>.from(decoded));
      }
    } catch (_) {}
    return null;
  }

  List<Map<String, dynamic>> _decodeJsonList(String raw) {
    final decoded = jsonDecode(raw);
    if (decoded is! List) {
      return const <Map<String, dynamic>>[];
    }
    return decoded
        .whereType<Map>()
        .map<Map<String, dynamic>>(
          (entry) => _repairRow(Map<String, dynamic>.from(entry)),
        )
        .toList(growable: false);
  }

  List<Map<String, dynamic>> _cloneContentItems(
    List<Map<String, dynamic>> items,
  ) {
    return items
        .map<Map<String, dynamic>>(
          (item) => _repairRow(Map<String, dynamic>.from(item)),
        )
        .toList(growable: false);
  }

  List<Map<String, dynamic>> _repairRowList(List<Map<String, Object?>> rows) {
    return rows
        .map<Map<String, dynamic>>(
          (row) => _repairRow(Map<String, dynamic>.from(row)),
        )
        .toList(growable: false);
  }

  Map<String, dynamic> _repairRow(Map<String, dynamic> row) {
    final repaired = MojibakeFixer.repairObject(row);
    if (repaired is Map<String, dynamic>) {
      return repaired;
    }
    return Map<String, dynamic>.from(repaired as Map);
  }

  String _normalizeAssetPath(String assetPath) {
    return assetPath.replaceAll('\\', '/');
  }
}

class _ContentSummary {
  const _ContentSummary({
    required this.itemId,
    this.title,
    this.body,
    this.extra,
  });

  final int itemId;
  final String? title;
  final String? body;
  final String? extra;
}

//Farmuday Mrwrary Database Helper
class DbHelper {
  static final DbHelper _instance = DbHelper.internal();
  factory DbHelper() => _instance;

  DbHelper.internal();
  final DatabaseHelper _databaseHelper = DatabaseHelper();

  Future<int> createCourse(FarmudaData course) async {
    final db = await _databaseHelper.database;
    return db.insert('content_items', <String, Object?>{
      'section_key': DatabaseHelper.sectionFarmuda,
      'item_id': course.id,
      'sort_order': course.id,
      'title': course.title,
      'body': course.kuDesc,
      'extra_text': course.arDesc,
      'payload_json': jsonEncode(course.toMap()),
    }, conflictAlgorithm: ConflictAlgorithm.replace);
  }

  Future<List> allCourses() async {
    return _databaseHelper.getFarmudaRows();
  }
}

//cherokn database
class DbHelper2 {
  static final DbHelper2 _instance = DbHelper2.internal();
  factory DbHelper2() => _instance;

  DbHelper2.internal();
  final DatabaseHelper _databaseHelper = DatabaseHelper();

  Future<int> createCourse(FarmudaData course) async {
    final db = await _databaseHelper.database;
    return db.insert('content_items', <String, Object?>{
      'section_key': DatabaseHelper.sectionCherok,
      'item_id': course.id,
      'sort_order': course.id,
      'title': course.title,
      'body': course.kuDesc,
      'extra_text': course.arDesc,
      'payload_json': jsonEncode(course.toMap()),
    }, conflictAlgorithm: ConflictAlgorithm.replace);
  }

  Future<List> allCourses() async {
    return _databaseHelper.getCherokRows();
  }
}

//allah names database
class DatabaseHelper2 {
  static final DatabaseHelper2 _instance = DatabaseHelper2.internal();
  factory DatabaseHelper2() => _instance;
  final DatabaseHelper _databaseHelper = DatabaseHelper();

  Future<Database> get db async {
    return _databaseHelper.database;
  }

  DatabaseHelper2.internal();

  Future<Database> initDb() async {
    return _databaseHelper.database;
  }
}

class QueryCtr {
  DatabaseHelper2 con = DatabaseHelper2();

  Future<List<AllahNamesdata>> getAllFruits() async {
    final res = await DatabaseHelper().getAllahNameRows();

    if (res.isEmpty) {
      return <AllahNamesdata>[];
    }

    return res.map((c) => AllahNamesdata.fromMap(c)).toList();
  }
}

//! settings database
