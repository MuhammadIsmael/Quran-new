import 'package:flutter/material.dart';
import 'package:flutter_staggered_animations/flutter_staggered_animations.dart';

class ScaleIn extends StatelessWidget {
  const ScaleIn({
    super.key,
    required this.duration,
    required this.child,
  });

  final int? duration;
  final Widget? child;
  @override
  Widget build(BuildContext context) {
    return AnimationLimiter(
      child: AnimationConfiguration.synchronized(
        child: ScaleAnimation(
          curve: Curves.fastLinearToSlowEaseIn,
          duration: Duration(milliseconds: duration!),
          child: child!,
        ),
      ),
    );
  }
}