import 'package:flutter/foundation.dart';

class PlatformFeatureFlags {
  const PlatformFeatureFlags._();

  static bool get isIos =>
      !kIsWeb && defaultTargetPlatform == TargetPlatform.iOS;

  static bool get supportsPrayerWidgets =>
      !kIsWeb &&
      (defaultTargetPlatform == TargetPlatform.android ||
          defaultTargetPlatform == TargetPlatform.iOS);
}
