import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:runaki_islam/providers/settings_provider.dart';
import 'constans.dart';

class ItemCard2 extends StatefulWidget {
  final String? title;
  final VoidCallback? onPress;
  final String? count;
  final bool? show;

  const ItemCard2(
      {super.key, this.title, this.count, this.onPress, this.show = false});

  @override
  State<ItemCard2> createState() => _ItemCard2State();
}

class _ItemCard2State extends State<ItemCard2> {
  int? fontType;
  @override
  void initState() {
    super.initState();

    fontType = Provider.of<SettingsProvider>(context, listen: false)
        .getsettingField('font_family');

  }
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(left: 12, right: 12, bottom: 12),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(13),
        child: Container(
          width: double.infinity,
          decoration: BoxDecoration(
            color: backgroundColor,
            borderRadius: BorderRadius.circular(13),
            boxShadow: [
              BoxShadow(
                offset: const Offset(0, 17),
                blurRadius: 17,
                spreadRadius: -23,
                color: kShadowColor,
              ),
            ],
          ),
          child: Material(
            color: Colors.transparent,
            child: InkWell(
              onTap: widget.onPress!,
              child: ListTile(
                contentPadding: const EdgeInsets.only(left: 8, right: 8),
                leading: widget.show!
                    ? Container(
                        padding: const EdgeInsets.all(2),
                        decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(4),
                            color: thirdColor.withValues(alpha: 0.5)),
                        child: Icon(
                          Icons.download_outlined,
                          color: kActiveIconColor.withValues(alpha: 0.5),
                        ),
                      )
                    : Container(
                        width: 10,
                        height: 10,
                        padding: const EdgeInsets.all(3),
                        decoration: BoxDecoration(
                            color: thirdColor, shape: BoxShape.circle),
                      ),
                title: Text(
                  widget.title!,
                  textAlign: TextAlign.right,
                  style: TextStyle(fontFamily: fontType.toString() ,
                      fontSize: 16, color: kTextColor.withValues(alpha: 0.5)),
                ),
                trailing: Container(
                  margin: const EdgeInsets.only(left: 8, top: 4, bottom: 4),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(10),
                    color: thirdColor.withValues(alpha: 0.7),
                  ),
                  child: CircleAvatar(
                    backgroundColor: Colors.transparent,
                    child: Text(
                      widget.count!,
                      style: TextStyle(color: kActiveIconColor),
                    ),
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
