import 'package:flutter/material.dart';
import 'package:runaki_islam/theme/theme.dart';

const Color _lightBg = Color(0xFFF7F2E8);
const Color _lightPrimary = Color(0xFF0F6B53);
const Color _lightSecondary = Color(0xFFE2C98E);
const Color _lightSurface = Color(0xFFEEE4D1);
const Color _lightShadow = Color(0x1E153124);

var bgColor = _lightBg;
var primaryColor = _lightPrimary;
var secondColor = _lightSecondary;
var thirdColor = _lightSurface;
var splashColor = const Color(0x1A0F6B53);
var captionTextColor = const Color(0xFF1E2E27);
var titleTextColor = const Color(0xFF49635A);
var descriptionTectColor = const Color(0xFF7C8F88);
var iconColor = const Color(0xFF4E6A60);
var kActiveIconColor = _lightPrimary;
var kTextColor = const Color(0xFF10241E);
var kShadowColor = _lightShadow;
var backgroundColor = const Color(0xFFFDF9F1);
var bottomNavIconColor = const Color(0xFF8EA59B);
var bgImageColor = const Color(0x148A7A59);
var myColor = const Color(0xFFE9F2EE);
var strokeColor = const Color(0x2231836A);

var bigTextStyle = TextStyle(
  color: captionTextColor,
  fontSize: 18,
  fontWeight: FontWeight.w600,
);

var simpleTextStyle = TextStyle(color: titleTextColor, fontSize: 16);

var smallTextStyle = TextStyle(color: descriptionTectColor, fontSize: 14);

var quranStyle = TextStyle(color: kActiveIconColor, fontSize: 18);
var kErrTextStyle = const TextStyle(
  color: Colors.black,
  fontWeight: FontWeight.w600,
  height: 1.5,
);

var kPrimaryGradient = const LinearGradient(
  colors: [Color(0xFF0E7C5A), Color(0xFF52B38E), Color(0xFFE2C98E)],
  begin: Alignment.centerLeft,
  end: Alignment.centerRight,
);

void applyLegacyPalette({required bool dark}) {
  applyLegacyPaletteFromTheme(dark ? AppTheme.dark : AppTheme.light);
}

void applyLegacyPaletteFromTheme(ThemeData theme) {
  final scheme = theme.colorScheme;
  final isDark = theme.brightness == Brightness.dark;

  bgColor = theme.scaffoldBackgroundColor;
  primaryColor = scheme.primary;
  secondColor = scheme.secondary;
  thirdColor = scheme.surfaceContainerHighest;
  splashColor = scheme.primary.withValues(alpha: isDark ? 0.18 : 0.10);

  captionTextColor = scheme.onSurface;
  titleTextColor = scheme.onSurfaceVariant;
  descriptionTectColor = scheme.onSurfaceVariant.withValues(
    alpha: isDark ? 0.78 : 0.90,
  );
  iconColor = scheme.onSurfaceVariant;
  kActiveIconColor = scheme.primary;
  kTextColor = scheme.onSurface;

  kShadowColor = scheme.shadow;
  backgroundColor = scheme.surface;
  bottomNavIconColor = scheme.onSurfaceVariant.withValues(
    alpha: isDark ? 0.72 : 0.82,
  );
  bgImageColor = scheme.primary.withValues(alpha: isDark ? 0.10 : 0.08);
  myColor = Color.alphaBlend(
    scheme.primary.withValues(alpha: isDark ? 0.14 : 0.08),
    scheme.surface,
  );
  strokeColor = scheme.outline.withValues(alpha: isDark ? 0.34 : 0.18);

  bigTextStyle = TextStyle(
    color: captionTextColor,
    fontSize: 18,
    fontWeight: FontWeight.w600,
  );
  simpleTextStyle = TextStyle(color: titleTextColor, fontSize: 16);
  smallTextStyle = TextStyle(color: descriptionTectColor, fontSize: 14);
  quranStyle = TextStyle(color: kActiveIconColor, fontSize: 18);
}
