import 'dart:ui';

import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:provider/provider.dart';
import 'package:runaki_islam/providers/settings_provider.dart';
import 'package:runaki_islam/util/constans.dart';

class ItemCard extends StatefulWidget {
  const ItemCard({
    super.key,
    this.title,
    this.color,
    this.image,
    this.onPress,
    this.isImage = false,
  });

  final String? title;
  final Color? color;
  final String? image;
  final VoidCallback? onPress;
  final bool isImage;

  @override
  State<ItemCard> createState() => _ItemCardState();
}

class _ItemCardState extends State<ItemCard> {
  int? fontType;

  @override
  void initState() {
    super.initState();
    fontType = Provider.of<SettingsProvider>(
      context,
      listen: false,
    ).getsettingField('font_family');
  }

  @override
  Widget build(BuildContext context) {
    final colorScheme = Theme.of(context).colorScheme;
    return Padding(
      padding: const EdgeInsets.only(left: 12, right: 12, bottom: 12),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(16),
        child: BackdropFilter(
          filter: ImageFilter.blur(sigmaX: 2.5, sigmaY: 2.5),
          child: Container(
            decoration: BoxDecoration(
              color: Theme.of(context).cardColor.withValues(
                alpha: Theme.of(context).brightness == Brightness.dark
                    ? 0.86
                    : 0.94,
              ),
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: strokeColor),
              boxShadow: [
                BoxShadow(
                  offset: const Offset(0, 10),
                  blurRadius: 20,
                  spreadRadius: -16,
                  color: kShadowColor.withValues(alpha: 0.7),
                ),
              ],
            ),
            child: Material(
              color: Colors.transparent,
              child: InkWell(
                onTap: widget.onPress,
                splashColor: kActiveIconColor.withValues(alpha: 0.06),
                highlightColor: Colors.transparent,
                child: Padding(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 10,
                    vertical: 8,
                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: <Widget>[
                      Expanded(
                        child: Text(
                          widget.title ?? '',
                          textAlign: TextAlign.right,
                          style: TextStyle(
                            fontFamily: fontType.toString(),
                            fontSize: 18,
                            fontWeight: FontWeight.w600,
                            color: colorScheme.onSurface.withValues(
                              alpha: 0.84,
                            ),
                          ),
                        ),
                      ),
                      const SizedBox(width: 10),
                      Hero(
                        tag: 'item_icon_${widget.title}_${widget.image}',
                        child: Container(
                          height: 62,
                          width: 62,
                          padding: const EdgeInsets.all(12),
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(14),
                            color: (widget.color ?? kActiveIconColor)
                                .withValues(alpha: 0.9),
                            boxShadow: [
                              BoxShadow(
                                color: (widget.color ?? kActiveIconColor)
                                    .withValues(alpha: 0.28),
                                blurRadius: 14,
                                offset: const Offset(0, 8),
                              ),
                            ],
                          ),
                          child: widget.isImage
                              ? Image.asset(
                                  widget.image ?? '',
                                  color: Colors.white,
                                )
                              : SvgPicture.asset(
                                  widget.image ?? '',
                                  colorFilter: const ColorFilter.mode(
                                    Colors.white,
                                    BlendMode.srcIn,
                                  ),
                                ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class ItemCard2 extends StatefulWidget {
  const ItemCard2({
    super.key,
    this.title,
    this.count,
    this.onPress,
    this.isNumber = true,
  });

  final String? title;
  final VoidCallback? onPress;
  final String? count;
  final bool? isNumber;

  @override
  State<ItemCard2> createState() => _ItemCard2State();
}

class _ItemCard2State extends State<ItemCard2> {
  int? fontType;

  @override
  void initState() {
    super.initState();
    fontType = Provider.of<SettingsProvider>(
      context,
      listen: false,
    ).getsettingField('font_family');
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(left: 12, right: 12, bottom: 12),
      child: Container(
        decoration: BoxDecoration(
          color: Theme.of(context).cardColor.withValues(
            alpha: Theme.of(context).brightness == Brightness.dark
                ? 0.86
                : 0.94,
          ),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: strokeColor),
          boxShadow: [
            BoxShadow(
              offset: const Offset(0, 10),
              blurRadius: 20,
              spreadRadius: -16,
              color: kShadowColor.withValues(alpha: 0.7),
            ),
          ],
        ),
        child: Material(
          color: Colors.transparent,
          child: InkWell(
            borderRadius: BorderRadius.circular(16),
            onTap: widget.onPress,
            child: ListTile(
              title: Text(
                widget.title ?? '',
                textAlign: TextAlign.right,
                overflow: TextOverflow.ellipsis,
                style: TextStyle(
                  fontFamily: fontType.toString(),
                  fontSize: 16,
                  fontWeight: FontWeight.w600,
                  color: kTextColor.withValues(alpha: 0.88),
                ),
              ),
              trailing: widget.isNumber == true
                  ? Container(
                      margin: const EdgeInsets.only(
                        left: 10,
                        top: 4,
                        bottom: 4,
                      ),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(12),
                        gradient: LinearGradient(
                          begin: Alignment.topLeft,
                          end: Alignment.bottomRight,
                          colors: [
                            kActiveIconColor.withValues(alpha: 0.18),
                            secondColor.withValues(alpha: 0.24),
                          ],
                        ),
                      ),
                      child: CircleAvatar(
                        backgroundColor: Colors.transparent,
                        child: Text(
                          widget.count ?? '',
                          style: TextStyle(color: kActiveIconColor),
                        ),
                      ),
                    )
                  : const SizedBox(width: 20),
              contentPadding: const EdgeInsets.symmetric(horizontal: 10),
            ),
          ),
        ),
      ),
    );
  }
}
