import 'package:flutter/material.dart';
import 'package:runaki_islam/util/constans.dart';

class Background extends StatelessWidget {
  const Background({super.key});

  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size;

    return Container(
      height: size.height,
      width: size.width,
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [
            Theme.of(context).colorScheme.surface.withValues(alpha: 0.96),
            bgColor,
          ],
        ),
      ),
      child: Image.asset(
        'assets/images/background/background.png',
        color: bgImageColor,
        filterQuality: FilterQuality.low,
        fit: BoxFit.cover,
        cacheWidth: (size.width * MediaQuery.of(context).devicePixelRatio)
            .round(),
        height: size.height,
      ),
    );
  }
}

class Background2 extends StatelessWidget {
  const Background2({super.key});

  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size;

    return SizedBox(
      height: size.height,
      width: size.width,
      child: Image.asset(
        'assets/images/background/background.png',
        color: const Color(0x11286B86),
        filterQuality: FilterQuality.low,
        fit: BoxFit.cover,
        cacheWidth: (size.width * MediaQuery.of(context).devicePixelRatio)
            .round(),
        height: size.height,
      ),
    );
  }
}

class CustomBackground extends StatelessWidget {
  final Color? color;
  final Color? imageColor;

  const CustomBackground({super.key, this.color, this.imageColor});

  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size;

    return Container(
      color: color,
      height: size.height,
      width: size.width,
      child: Image.asset(
        'assets/images/background/background.png',
        color: imageColor,
        filterQuality: FilterQuality.low,
        fit: BoxFit.cover,
        cacheWidth: (size.width * MediaQuery.of(context).devicePixelRatio)
            .round(),
        height: size.height,
      ),
    );
  }
}

class CustomBackground2 extends StatelessWidget {
  final Color? color;
  final String? customImage;
  final bool haveColor;
  final double? opacity;
  final double? height;
  final double? width;

  const CustomBackground2({
    super.key,
    this.color,
    this.customImage,
    this.haveColor = true,
    this.opacity,
    this.height,
    this.width,
  });

  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size;

    return SizedBox(
      height: height ?? size.height,
      width: width ?? size.width,
      child: Opacity(
        opacity: opacity ?? 1,
        child: Image.asset(
          customImage ?? 'assets/images/background/background.png',
          color: haveColor ? color ?? const Color(0x08423C33) : null,
          filterQuality: FilterQuality.low,
          fit: BoxFit.cover,
          cacheWidth:
              ((width ?? size.width) * MediaQuery.of(context).devicePixelRatio)
                  .round(),
          height: height ?? size.height,
        ),
      ),
    );
  }
}
