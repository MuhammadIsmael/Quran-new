import 'package:flutter/material.dart';

class AppMotion {
  static const bool reduceMotion = true;
  static const Duration fast = Duration.zero;
  static const Duration page = Duration.zero;
  static const Curve curve = Curves.easeInOutCubic;

  static Route<T> fadeSlidePage<T>({
    required Widget page,
    Offset begin = const Offset(0, 0.035),
  }) {
    return PageRouteBuilder<T>(
      transitionDuration: AppMotion.reduceMotion
          ? Duration.zero
          : AppMotion.page,
      reverseTransitionDuration: AppMotion.reduceMotion
          ? Duration.zero
          : AppMotion.page,
      pageBuilder: (context, animation, secondaryAnimation) => page,
      transitionsBuilder: (context, animation, secondaryAnimation, child) {
        if (AppMotion.reduceMotion) {
          return child;
        }
        final curved = CurvedAnimation(
          parent: animation,
          curve: AppMotion.curve,
        );
        return FadeTransition(
          opacity: curved,
          child: SlideTransition(
            position: Tween<Offset>(begin: begin, end: Offset.zero).animate(
              CurvedAnimation(parent: animation, curve: AppMotion.curve),
            ),
            child: child,
          ),
        );
      },
    );
  }
}

class FadeSlideIn extends StatefulWidget {
  const FadeSlideIn({
    super.key,
    required this.child,
    this.duration = AppMotion.page,
    this.delay = Duration.zero,
    this.offsetY = 10,
  });

  final Widget child;
  final Duration duration;
  final Duration delay;
  final double offsetY;

  @override
  State<FadeSlideIn> createState() => _FadeSlideInState();
}

class _FadeSlideInState extends State<FadeSlideIn>
    with SingleTickerProviderStateMixin {
  AnimationController? _controller;
  Animation<double>? _animation;

  @override
  void initState() {
    super.initState();
    if (AppMotion.reduceMotion) {
      return;
    }
    _controller = AnimationController(vsync: this, duration: widget.duration);
    _animation = CurvedAnimation(parent: _controller!, curve: AppMotion.curve);

    if (widget.delay == Duration.zero) {
      _controller!.forward();
    } else {
      Future<void>.delayed(widget.delay, () {
        if (mounted) _controller!.forward();
      });
    }
  }

  @override
  void dispose() {
    _controller?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (AppMotion.reduceMotion) {
      return widget.child;
    }

    return AnimatedBuilder(
      animation: _animation!,
      builder: (context, child) {
        final value = _animation!.value;
        return Opacity(
          opacity: value,
          child: Transform.translate(
            offset: Offset(0, (1 - value) * widget.offsetY),
            child: child,
          ),
        );
      },
      child: widget.child,
    );
  }
}

class PremiumAnimatedSwitcher extends StatelessWidget {
  const PremiumAnimatedSwitcher({
    super.key,
    required this.child,
    this.duration = AppMotion.fast,
  });

  final Widget child;
  final Duration duration;

  @override
  Widget build(BuildContext context) {
    if (AppMotion.reduceMotion) {
      return child;
    }
    return AnimatedSwitcher(
      duration: duration,
      switchInCurve: AppMotion.curve,
      switchOutCurve: AppMotion.curve,
      transitionBuilder: (child, animation) {
        return FadeTransition(
          opacity: animation,
          child: SlideTransition(
            position:
                Tween<Offset>(
                  begin: const Offset(0, 0.03),
                  end: Offset.zero,
                ).animate(
                  CurvedAnimation(parent: animation, curve: AppMotion.curve),
                ),
            child: child,
          ),
        );
      },
      child: child,
    );
  }
}
