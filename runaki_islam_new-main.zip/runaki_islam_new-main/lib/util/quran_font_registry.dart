class QuranFontOption {
  const QuranFontOption({
    required this.familyId,
    required this.order,
    required this.label,
    this.preview = kQuranFontPreviewText,
  });

  final int familyId;
  final int order;
  final String label;
  final String preview;

  String get family => familyId.toString();
}

const String kQuranFontPreviewText = 'بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ';
const int kDefaultQuranFontFamily = 13;

const List<QuranFontOption> kQuranFontOptions = <QuranFontOption>[
  QuranFontOption(familyId: 13, order: 1, label: 'فۆنتی قورئان 1'),
  QuranFontOption(familyId: 14, order: 2, label: 'فۆنتی قورئان 2'),
  QuranFontOption(familyId: 15, order: 3, label: 'فۆنتی قورئان 3'),
  QuranFontOption(familyId: 16, order: 4, label: 'فۆنتی قورئان 4'),
  QuranFontOption(familyId: 17, order: 5, label: 'فۆنتی قورئان 5'),
  QuranFontOption(familyId: 18, order: 6, label: 'فۆنتی قورئان 6'),
  QuranFontOption(familyId: 22, order: 7, label: 'فۆنتی قورئان 7'),
  QuranFontOption(familyId: 23, order: 8, label: 'فۆنتی قورئان 8'),
];

int normalizeQuranFontFamily(dynamic value) {
  final int? candidate = switch (value) {
    int number => number,
    num number => number.toInt(),
    String text => int.tryParse(text),
    _ => null,
  };
  if (candidate == null) return kDefaultQuranFontFamily;
  if (candidate == 19 || candidate == 20 || candidate == 21) {
    return 18;
  }
  final valid = kQuranFontOptions.any((option) => option.familyId == candidate);
  return valid ? candidate : kDefaultQuranFontFamily;
}
