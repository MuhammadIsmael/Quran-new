import 'package:flutter/foundation.dart';
import 'package:flutter/widgets.dart';

/// Kurdish widget-level labels with an RTL direction.
///
/// Extending Flutter's default implementation keeps this delegate compatible
/// when Flutter adds new accessibility labels.
class KurdishFallbackWidgetsLocalizations extends DefaultWidgetsLocalizations {
  const KurdishFallbackWidgetsLocalizations();

  @override
  TextDirection get textDirection => TextDirection.rtl;

  @override
  String get copyButtonLabel => 'کۆپی';

  @override
  String get cutButtonLabel => 'بڕین';

  @override
  String get lookUpButtonLabel => 'بە دوا دا گەڕان';

  @override
  String get pasteButtonLabel => 'پەیست';

  @override
  String get radioButtonUnselectedLabel => 'هەڵنەبژێردراوە';

  @override
  String get reorderItemDown => 'بۆ خوارەوە';

  @override
  String get reorderItemLeft => 'بۆ لای چەپ';

  @override
  String get reorderItemRight => 'بۆ لای راست';

  @override
  String get reorderItemToEnd => 'بۆ کۆتایی';

  @override
  String get reorderItemToStart => 'بۆ سەرەتای';

  @override
  String get reorderItemUp => 'بۆ سەرەوە';

  @override
  String get searchWebButtonLabel => 'گەڕان لە وێب';

  @override
  String get selectAllButtonLabel => 'هەموو هەڵبژێرە';

  @override
  String get shareButtonLabel => 'هاوبەشکردن';
}

class KurdishFallbackWidgetsLocalizationsDelegate
    extends LocalizationsDelegate<WidgetsLocalizations> {
  const KurdishFallbackWidgetsLocalizationsDelegate();

  @override
  bool isSupported(Locale locale) => locale.languageCode == 'ku';

  @override
  Future<WidgetsLocalizations> load(Locale locale) {
    return SynchronousFuture<WidgetsLocalizations>(
      const KurdishFallbackWidgetsLocalizations(),
    );
  }

  @override
  bool shouldReload(KurdishFallbackWidgetsLocalizationsDelegate old) => false;
}
