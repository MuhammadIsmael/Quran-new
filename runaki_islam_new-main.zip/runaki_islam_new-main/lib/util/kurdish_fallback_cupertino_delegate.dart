import 'package:flutter/cupertino.dart';
import 'package:flutter/foundation.dart';

/// Provides a safe Cupertino localization for Kurdish locale.
///
/// The current third-party Kurdish Cupertino delegate can throw at startup in
/// some environments, so this fallback keeps the app stable by returning the
/// default Cupertino strings.
class KurdishFallbackCupertinoLocalizationsDelegate
    extends LocalizationsDelegate<CupertinoLocalizations> {
  const KurdishFallbackCupertinoLocalizationsDelegate();

  @override
  bool isSupported(Locale locale) => locale.languageCode == 'ku';

  @override
  Future<CupertinoLocalizations> load(Locale locale) {
    return SynchronousFuture<CupertinoLocalizations>(
      const DefaultCupertinoLocalizations(),
    );
  }

  @override
  bool shouldReload(KurdishFallbackCupertinoLocalizationsDelegate old) {
    return false;
  }
}
