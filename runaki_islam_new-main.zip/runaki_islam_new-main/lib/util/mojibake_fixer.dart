import 'dart:convert';

class MojibakeFixer {
  static const Set<int> _markerCodeUnits = <int>{
    0x00C2, // Â
    0x00C3, // Ã
    0x00D8, // Ø
    0x00D9, // Ù
    0x00DB, // Û
    0x00E2, // â
    0x00EF, // ï
  };

  static String repairText(String value, {int maxPasses = 3}) {
    var repaired = value;

    for (int pass = 0; pass < maxPasses; pass++) {
      if (!_looksBroken(repaired)) {
        break;
      }

      final decoded = _decodeLatin1AsUtf8(repaired);
      if (decoded == null || decoded == repaired) {
        break;
      }
      repaired = decoded;
    }

    return repaired;
  }

  static dynamic repairObject(dynamic value) {
    if (value is String) {
      return repairText(value);
    }

    if (value is List) {
      return value.map<dynamic>(repairObject).toList(growable: false);
    }

    if (value is Map) {
      return value.map<dynamic, dynamic>(
        (key, item) => MapEntry<dynamic, dynamic>(key, repairObject(item)),
      );
    }

    return value;
  }

  static bool _looksBroken(String value) {
    if (value.isEmpty) {
      return false;
    }

    for (final codeUnit in value.codeUnits) {
      if (_markerCodeUnits.contains(codeUnit)) {
        return true;
      }
    }

    return false;
  }

  static String? _decodeLatin1AsUtf8(String value) {
    try {
      return utf8.decode(latin1.encode(value));
    } catch (_) {
      return null;
    }
  }
}
