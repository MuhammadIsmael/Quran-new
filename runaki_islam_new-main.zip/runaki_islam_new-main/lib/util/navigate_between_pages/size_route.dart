import 'package:flutter/material.dart';
import 'package:runaki_islam/util/animation_helper.dart';

class SizeRoute extends PageRouteBuilder {
  final Widget? page;
  SizeRoute({this.page})
    : super(
        pageBuilder:
            (
              BuildContext context,
              Animation<double> animation,
              Animation<double> secondaryAnimation,
            ) => page!,
        transitionsBuilder:
            (
              BuildContext context,
              Animation<double> animation,
              Animation<double> secondaryAnimation,
              Widget child,
            ) => AppMotion.reduceMotion
            ? child
            : Align(
                child: SizeTransition(
                  sizeFactor: CurvedAnimation(
                    parent: animation,
                    curve: AppMotion.curve,
                  ),
                  child: child,
                ),
              ),
        transitionDuration: AppMotion.reduceMotion
            ? Duration.zero
            : AppMotion.page,
        reverseTransitionDuration: AppMotion.reduceMotion
            ? Duration.zero
            : AppMotion.page,
      );
}
