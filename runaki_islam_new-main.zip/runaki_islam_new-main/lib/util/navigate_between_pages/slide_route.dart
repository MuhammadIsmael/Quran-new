import 'package:flutter/material.dart';
import 'package:runaki_islam/util/animation_helper.dart';

class SlideRightRoute extends PageRouteBuilder {
  final Widget? page;
  SlideRightRoute({this.page})
    : super(
        pageBuilder:
            (
              BuildContext context,
              Animation<double> animation,
              Animation<double> secondaryAnimation,
            ) => page!,
        transitionsBuilder:
            (
              BuildContext context,
              Animation<double> animation,
              Animation<double> secondaryAnimation,
              Widget child,
            ) => AppMotion.reduceMotion
            ? child
            : SlideTransition(
                position:
                    Tween<Offset>(
                      begin: const Offset(-1.0, 0.0),
                      end: Offset.zero,
                    ).animate(
                      CurvedAnimation(
                        parent: animation,
                        curve: AppMotion.curve,
                      ),
                    ),
                child: child,
              ),
        transitionDuration: AppMotion.reduceMotion
            ? Duration.zero
            : AppMotion.page,
        reverseTransitionDuration: AppMotion.reduceMotion
            ? Duration.zero
            : AppMotion.page,
      );
}

class SlideLeftRoute extends PageRouteBuilder {
  final Widget? page;
  SlideLeftRoute({this.page})
    : super(
        pageBuilder:
            (
              BuildContext context,
              Animation<double> animation,
              Animation<double> secondaryAnimation,
            ) => page!,
        transitionsBuilder:
            (
              BuildContext context,
              Animation<double> animation,
              Animation<double> secondaryAnimation,
              Widget child,
            ) => AppMotion.reduceMotion
            ? child
            : SlideTransition(
                position:
                    Tween<Offset>(
                      begin: const Offset(1, 0),
                      end: Offset.zero,
                    ).animate(
                      CurvedAnimation(
                        parent: animation,
                        curve: AppMotion.curve,
                      ),
                    ),
                child: child,
              ),
        transitionDuration: AppMotion.reduceMotion
            ? Duration.zero
            : AppMotion.page,
        reverseTransitionDuration: AppMotion.reduceMotion
            ? Duration.zero
            : AppMotion.page,
      );
}

class SlideTopRoute extends PageRouteBuilder {
  final Widget? page;
  SlideTopRoute({this.page})
    : super(
        pageBuilder:
            (
              BuildContext context,
              Animation<double> animation,
              Animation<double> secondaryAnimation,
            ) => page!,
        transitionsBuilder:
            (
              BuildContext context,
              Animation<double> animation,
              Animation<double> secondaryAnimation,
              Widget child,
            ) => AppMotion.reduceMotion
            ? child
            : SlideTransition(
                position:
                    Tween<Offset>(
                      begin: const Offset(0, 1),
                      end: Offset.zero,
                    ).animate(
                      CurvedAnimation(
                        parent: animation,
                        curve: AppMotion.curve,
                      ),
                    ),
                child: child,
              ),
        transitionDuration: AppMotion.reduceMotion
            ? Duration.zero
            : AppMotion.page,
        reverseTransitionDuration: AppMotion.reduceMotion
            ? Duration.zero
            : AppMotion.page,
      );
}

class SlideBottomRoute extends PageRouteBuilder {
  final Widget? page;
  SlideBottomRoute({this.page})
    : super(
        pageBuilder:
            (
              BuildContext context,
              Animation<double> animation,
              Animation<double> secondaryAnimation,
            ) => page!,
        transitionsBuilder:
            (
              BuildContext context,
              Animation<double> animation,
              Animation<double> secondaryAnimation,
              Widget child,
            ) => AppMotion.reduceMotion
            ? child
            : SlideTransition(
                position:
                    Tween<Offset>(
                      begin: const Offset(0, -1),
                      end: Offset.zero,
                    ).animate(
                      CurvedAnimation(
                        parent: animation,
                        curve: AppMotion.curve,
                      ),
                    ),
                child: child,
              ),
        transitionDuration: AppMotion.reduceMotion
            ? Duration.zero
            : AppMotion.page,
        reverseTransitionDuration: AppMotion.reduceMotion
            ? Duration.zero
            : AppMotion.page,
      );
}
