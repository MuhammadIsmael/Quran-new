import 'package:flutter/material.dart';
import 'package:runaki_islam/util/animation_helper.dart';

class ScaleRoute extends PageRouteBuilder {
  final Widget? page;
  ScaleRoute({this.page})
    : super(
        pageBuilder:
            (
              BuildContext context,
              Animation<double> animation,
              Animation<double> secondaryAnimation,
            ) => page!,
        transitionsBuilder:
            (
              BuildContext context,
              Animation<double> animation,
              Animation<double> secondaryAnimation,
              Widget child,
            ) => AppMotion.reduceMotion
            ? child
            : ScaleTransition(
                scale: Tween<double>(begin: 0.92, end: 1.0).animate(
                  CurvedAnimation(parent: animation, curve: AppMotion.curve),
                ),
                child: child,
              ),
        transitionDuration: AppMotion.reduceMotion
            ? Duration.zero
            : AppMotion.page,
        reverseTransitionDuration: AppMotion.reduceMotion
            ? Duration.zero
            : AppMotion.page,
      );
}
