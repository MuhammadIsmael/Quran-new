import 'package:flutter/material.dart';
import 'package:runaki_islam/util/animation_helper.dart';

class FadeRoute extends PageRouteBuilder {
  final Widget? page;
  FadeRoute({this.page})
    : super(
        pageBuilder:
            (
              BuildContext context,
              Animation<double> animation,
              Animation<double> secondaryAnimation,
            ) => page!,
        transitionsBuilder:
            (
              BuildContext context,
              Animation<double> animation,
              Animation<double> secondaryAnimation,
              Widget child,
            ) => AppMotion.reduceMotion
            ? child
            : FadeTransition(
                opacity: CurvedAnimation(
                  parent: animation,
                  curve: AppMotion.curve,
                ),
                child: SlideTransition(
                  position:
                      Tween<Offset>(
                        begin: const Offset(0, 0.03),
                        end: Offset.zero,
                      ).animate(
                        CurvedAnimation(
                          parent: animation,
                          curve: AppMotion.curve,
                        ),
                      ),
                  child: child,
                ),
              ),
        transitionDuration: AppMotion.reduceMotion
            ? Duration.zero
            : AppMotion.page,
        reverseTransitionDuration: AppMotion.reduceMotion
            ? Duration.zero
            : AppMotion.page,
      );
}
