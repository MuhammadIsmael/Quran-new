import 'dart:math' as math;
import 'dart:ui';

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:runaki_islam/providers/settings_provider.dart';
import 'package:runaki_islam/util/animation_helper.dart';
import 'package:runaki_islam/util/constans.dart';

import 'tab_icon_data.dart';

class BottomBarView extends StatefulWidget {
  const BottomBarView({
    super.key,
    required this.tabIconsList,
    required this.changeIndex,
    required this.addClick,
  });

  final List<TabIconData> tabIconsList;
  final Function(int index) changeIndex;
  final Function() addClick;

  @override
  State<BottomBarView> createState() => _BottomBarViewState();
}

class _BottomBarViewState extends State<BottomBarView> {
  int _selectedIndex = 0;
  int? _fontType;

  final List<_NavItem> _items = const [
    _NavItem(
      label: '\u0633\u06d5\u0631\u06d5\u06a9\u06cc',
      icon: Icons.home_rounded,
      activeIcon: Icons.home_filled,
    ),
    _NavItem(
      label: '\u0642\u0648\u0631\u0626\u0627\u0646',
      icon: Icons.menu_book_rounded,
      activeIcon: Icons.menu_book,
    ),
    _NavItem(
      label: 'كاته‌كانی بانگ',
      icon: Icons.mosque_rounded,
      activeIcon: Icons.mosque_sharp,
    ),
    _NavItem(
      label: '\u067e\u0631\u06c6\u0641\u0627\u06cc\u0644',
      icon: Icons.person_outline_rounded,
      activeIcon: Icons.person_rounded,
    ),
  ];

  @override
  void initState() {
    super.initState();
    final selected = widget.tabIconsList.indexWhere((tab) => tab.isSelected);
    _selectedIndex = selected == -1 ? 0 : selected;
    _fontType = Provider.of<SettingsProvider>(
      context,
      listen: false,
    ).getsettingField('font_family');
  }

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final bottomInset = MediaQuery.of(context).padding.bottom;

    return Padding(
      padding: EdgeInsets.fromLTRB(
        14,
        0,
        14,
        math.max(10, 8 + bottomInset * .45),
      ),
      child: Container(
        height: 82,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(26),
          boxShadow: [
            BoxShadow(
              color: kShadowColor.withValues(alpha: 0.24),
              blurRadius: 24,
              offset: const Offset(0, 10),
            ),
          ],
        ),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(26),
          child: BackdropFilter(
            filter: ImageFilter.blur(
              sigmaX: AppMotion.reduceMotion ? 0 : 15,
              sigmaY: AppMotion.reduceMotion ? 0 : 15,
            ),
            child: Container(
              padding: const EdgeInsets.fromLTRB(8, 8, 8, 6),
              decoration: BoxDecoration(
                color: Theme.of(context).cardColor.withValues(
                  alpha: Theme.of(context).brightness == Brightness.dark
                      ? 0.86
                      : 0.94,
                ),
                borderRadius: BorderRadius.circular(26),
                border: Border.all(
                  color: scheme.outline.withValues(alpha: 0.2),
                ),
              ),
              child: LayoutBuilder(
                builder: (context, constraints) {
                  final tabWidth = constraints.maxWidth / _items.length;
                  return Stack(
                    children: [
                      AnimatedPositioned(
                        duration: AppMotion.reduceMotion
                            ? Duration.zero
                            : const Duration(milliseconds: 260),
                        curve: AppMotion.curve,
                        left: (_selectedIndex * tabWidth) + 5,
                        top: 4,
                        child: Container(
                          width: tabWidth - 10,
                          height: 50,
                          decoration: BoxDecoration(
                            color: kActiveIconColor.withValues(alpha: 0.92),
                            borderRadius: BorderRadius.circular(18),
                          ),
                        ),
                      ),
                      Row(
                        children: List.generate(_items.length, (index) {
                          final item = _items[index];
                          final selected = _selectedIndex == index;
                          return Expanded(
                            child: _NavButton(
                              item: item,
                              isSelected: selected,
                              fontType: _fontType,
                              onTap: () => _selectTab(index),
                            ),
                          );
                        }),
                      ),
                    ],
                  );
                },
              ),
            ),
          ),
        ),
      ),
    );
  }

  void _selectTab(int index) {
    if (_selectedIndex == index) return;
    setState(() {
      _selectedIndex = index;
      for (int i = 0; i < widget.tabIconsList.length; i++) {
        widget.tabIconsList[i].isSelected = i == index;
      }
    });
    widget.changeIndex(index);
  }
}

class _NavButton extends StatelessWidget {
  const _NavButton({
    required this.item,
    required this.isSelected,
    required this.onTap,
    required this.fontType,
  });

  final _NavItem item;
  final bool isSelected;
  final VoidCallback onTap;
  final int? fontType;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return InkWell(
      borderRadius: BorderRadius.circular(18),
      splashColor: Colors.transparent,
      highlightColor: Colors.transparent,
      onTap: onTap,
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 4),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            AnimatedScale(
              duration: AppMotion.fast,
              curve: AppMotion.curve,
              scale: isSelected ? 1.06 : 1.0,
              child: Icon(
                isSelected ? item.activeIcon : item.icon,
                size: 21.5,
                color: isSelected
                    ? Colors.white
                    : scheme.onSurfaceVariant.withValues(alpha: 0.88),
              ),
            ),
            const SizedBox(height: 3),
            AnimatedDefaultTextStyle(
              duration: AppMotion.fast,
              curve: AppMotion.curve,
              style: TextStyle(
                fontFamily: fontType.toString(),
                fontSize: 11.3,
                fontWeight: isSelected ? FontWeight.w700 : FontWeight.w500,
                color: isSelected
                    ? Colors.white
                    : scheme.onSurfaceVariant.withValues(alpha: 0.9),
              ),
              child: Text(item.label),
            ),
          ],
        ),
      ),
    );
  }
}

class _NavItem {
  const _NavItem({
    required this.label,
    required this.icon,
    required this.activeIcon,
  });

  final String label;
  final IconData icon;
  final IconData activeIcon;
}
