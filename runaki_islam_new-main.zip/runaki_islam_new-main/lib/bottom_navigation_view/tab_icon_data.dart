class TabIconData {
  TabIconData({
    this.imagePath = '',
    this.index = 0,
    this.selectedImagePath = '',
    this.isSelected = false,
  });

  String imagePath;
  String selectedImagePath;
  bool isSelected;
  int index;

  static List<TabIconData> tabIconsList = <TabIconData>[
    TabIconData(
      imagePath: 'assets/icons/home-1.png',
      selectedImagePath: 'assets/icons/home-2.png',
      isSelected: true,
    ),
    TabIconData(
      imagePath: 'assets/icons/bell-1.png',
      selectedImagePath: 'assets/icons/bell-2.png',
      index: 1,
    ),
    TabIconData(
      imagePath: 'assets/icons/namaz-prayer.png',
      selectedImagePath: 'assets/icons/namaz-prayer.png',
      index: 2,
    ),
    TabIconData(
      imagePath: 'assets/icons/person-1.png',
      selectedImagePath: 'assets/icons/person-2.png',
      index: 3,
    ),
  ];
}
