class FarmudaData {
  int? _id;
  String? _title;
  String? arDesc;
  String? kuDesc;
  FarmudaData(dynamic obj) {
    _id = obj['_id'];
    _title = obj['title'];
    arDesc = obj['ar_desc'];
    kuDesc = obj['ku_desc'];
  }

  FarmudaData.fromMap(Map<String, dynamic> data) {
    _id = data['_id'];
    _title = data['title'];
    arDesc = data['ar_desc'];
    kuDesc = data['ku_desc'];
  }
  Map<String, dynamic> toMap() =>
      {'_id': _id, 'title': _title, 'ar_desc': arDesc, 'ku_desc': kuDesc};

  int get id => _id!;
  String get title => _title!;
  String get arDescr => arDesc!;
  String get kuDescr => kuDesc!;
}
