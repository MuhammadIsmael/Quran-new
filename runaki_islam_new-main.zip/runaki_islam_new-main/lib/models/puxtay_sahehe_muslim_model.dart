class PSMModel {
  final String? sarder;
  final String? drezha;
  final int? pageNum;

  PSMModel({this.sarder, this.drezha, this.pageNum});

  factory PSMModel.formJson(Map<String, dynamic> json) {
    return PSMModel(
      sarder: json['sarder'],
      drezha: json['drezha'],
      pageNum: json['page_num'],
    );
  }
}
