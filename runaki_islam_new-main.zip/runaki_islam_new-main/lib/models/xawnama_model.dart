class XawnData {
  final String? title;
  final String? description;
  final String? description2;

  XawnData({this.title, this.description, this.description2});

  factory XawnData.formJson(Map<String, dynamic> json) {
    return XawnData(
      title: json['title'],
      description: json['description'],
      description2: json['description2'],
    );
  }
}
