import 'package:runaki_islam/util/quran_font_registry.dart';

class SettingsModel {
  late int _fontFamily;
  late double _fontSize;
  late double _speedFactor;
  late int _quranFontFamily;
  late double _quranFontSize;

  SettingsModel(
    this._speedFactor,
    this._fontFamily,
    this._fontSize,
    this._quranFontFamily,
    this._quranFontSize,
  );

  factory SettingsModel.defaults() {
    return SettingsModel(10.0, 0, 16.0, kDefaultQuranFontFamily, 16.0);
  }

  SettingsModel.fromMap(Map<String, dynamic> map) {
    _speedFactor = _toDouble(map['speed_factor'], 10.0);
    _fontFamily = _toInt(map['font_family'], 0);
    _fontSize = _toDouble(map['font_size'], 16.0);
    _quranFontFamily = normalizeQuranFontFamily(map['quran_font_family']);
    _quranFontSize = _toDouble(map['quran_font_size'], 16.0);
  }

  static double _toDouble(dynamic value, double fallback) {
    if (value is num) {
      return value.toDouble();
    }
    return fallback;
  }

  static int _toInt(dynamic value, int fallback) {
    if (value is int) {
      return value;
    }
    if (value is num) {
      return value.toInt();
    }
    return fallback;
  }

  void setSpeedFactor(double value) {
    _speedFactor = value;
  }

  void setFontFamily(int value) {
    _fontFamily = value;
  }

  void setFontSize(double value) {
    _fontSize = value;
  }

  void setQuranFontFamily(int value) {
    _quranFontFamily = normalizeQuranFontFamily(value);
  }

  void setQuranFontSize(double value) {
    _quranFontSize = value;
  }

  double get speedFactor => _speedFactor;

  int get fontFamily => _fontFamily;

  double get fontSize => _fontSize;

  int get quranFontFamily => _quranFontFamily;

  double get quranFontSize => _quranFontSize;
}
