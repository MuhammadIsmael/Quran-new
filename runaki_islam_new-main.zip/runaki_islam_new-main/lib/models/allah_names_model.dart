class AllahNamesdata {
  int? _id;
  String? _t1;
  String? _t2;

  AllahNamesdata(this._id, this._t1, this._t2);

  AllahNamesdata.fromMap(dynamic obj) {
    _id = obj['_id'];
    _t1 = obj['t1'];
    _t2 = obj['t2'];
  }

  int get id => _id!;
  String get t1 => _t1!;
  String get t2 => _t2!;

  Map<String, dynamic> toMap() {
    var map = <String, dynamic>{};
    map["_id"] = _id;
    map['t1'] = _t1;
    map['t2'] = _t2;
    return map;
  }
}
