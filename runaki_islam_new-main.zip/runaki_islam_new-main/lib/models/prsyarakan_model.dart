class PrsyarData {
  final String? babat;
  final String? prsyar;
  final String? walam;

  PrsyarData({
    this.babat,
    this.prsyar,
    this.walam,
  });

  factory PrsyarData.formJson(Map<String, dynamic> json) {
    return PrsyarData(
      babat: json['babat'],
      prsyar: json['prsyar'],
      walam: json['walam'],
    );
  }
}
