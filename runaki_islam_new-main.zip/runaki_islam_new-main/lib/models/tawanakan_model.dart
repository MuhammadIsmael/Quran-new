class TawanakanData {
  final String? title;
  final String? desc;

  TawanakanData({this.title, this.desc});

  factory TawanakanData.formJson(Map<String, dynamic> json) {
    return TawanakanData(title: json['title'], desc: json['desc']);
  }
}
