class RamazanData {
  final String title;
  final String desc;

  RamazanData(this.title, this.desc);
}
