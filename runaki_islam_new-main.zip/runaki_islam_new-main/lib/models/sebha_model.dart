class SebhaModel {
  int? _id, _counter, _favorite;
  String? _name;

  SebhaModel(int? id, String? name, int? counter, int? favorite)
    : _id = id ?? 0,
      _name = name ?? '',
      _counter = counter ?? 0,
      _favorite = favorite ?? 0;

  SebhaModel.fromMap(Map<String, dynamic> map) {
    _id = _toInt(map['id'], 0);
    _name = map['name']?.toString() ?? '';
    _counter = _toInt(map['counter'], 0);
    _favorite = _toInt(map['favorite'], 0);
  }

  Map<String, dynamic> toMap() {
    return {
      'id': _id ?? 0,
      'name': _name ?? '',
      'counter': _counter ?? 0,
      'favorite': _favorite ?? 0,
    };
  }

  void setId(int value) {
    _id = value;
  }

  set setName(String value) {
    _name = value;
  }

  set setCounter(int value) {
    _counter = value;
  }

  void setFavorite(int value) {
    _favorite = value;
  }

  int get id => _id ?? 0;

  String get name => _name ?? '';

  int get counter => _counter ?? 0;

  int get favorite => _favorite ?? 0;

  static int _toInt(dynamic value, int fallback) {
    if (value is int) return value;
    return int.tryParse(value?.toString() ?? '') ?? fallback;
  }
}
