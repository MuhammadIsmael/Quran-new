class WtawAmozhgareModel {
  final String? text;

  WtawAmozhgareModel({this.text});

  factory WtawAmozhgareModel.formJson(Map<String, dynamic> json) {
    return WtawAmozhgareModel(text: json['text']);
  }
}
