class ZekrData {
  final String? title;
  final String? description;

  ZekrData({this.title, this.description});

  factory ZekrData.formJson(Map<String, dynamic> json) {
    return ZekrData(title: json['title'], description: json['description']);
  }
}
