class CherokData {
  String? _section;
  String? _text;
  CherokData(dynamic obj) {
    _section = obj['nawe'];
    _text = obj['nbuss'];
  }

  CherokData.fromMap(Map<String, dynamic> data) {
    _section = data['nawe'];
    _text = data['nbuss'];
  }
  Map<String, dynamic> toMap() => {
        'nawe': _section,
        'nbuss': _text,
      };

  String get section => _section!;
  String get text => _text!;
}
