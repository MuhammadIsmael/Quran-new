import 'package:runaki_islam/util/mojibake_fixer.dart';

class Question {
  final int? id;
  final int? answer;
  final String? question;
  final List<String>? options;
  final String? category;
  final String? explanation;
  final int? quizId;
  final String? quizTitle;

  const Question({
    this.id,
    this.question,
    this.answer,
    this.options,
    this.category,
    this.explanation,
    this.quizId,
    this.quizTitle,
  });

  Question copyWith({
    int? id,
    String? question,
    int? answer,
    List<String>? options,
    String? category,
    String? explanation,
    int? quizId,
    String? quizTitle,
  }) {
    return Question(
      id: id ?? this.id,
      question: question ?? this.question,
      answer: answer ?? this.answer,
      options: options ?? this.options,
      category: category ?? this.category,
      explanation: explanation ?? this.explanation,
      quizId: quizId ?? this.quizId,
      quizTitle: quizTitle ?? this.quizTitle,
    );
  }

  factory Question.fromApi(
    Map<String, dynamic> data, {
    required String selectionId,
    int? quizId,
    String? quizTitle,
  }) {
    final List<dynamic> rawOptions =
        (data['options'] as List<dynamic>? ?? const <dynamic>[]);

    return Question(
      id: _parseInt(data['id']),
      question: _repair(data['question']),
      answer: _parseInt(data['correct_answer']),
      options: rawOptions.map((dynamic item) => _repair(item)).toList(),
      category: selectionId,
      explanation: _repair(data['explanation']),
      quizId: quizId,
      quizTitle: quizTitle != null ? _repair(quizTitle) : null,
    );
  }

  factory Question.fromJson(Map<String, dynamic> data) {
    final List<dynamic> rawOptions =
        (data['options'] as List<dynamic>? ?? const <dynamic>[]);

    return Question(
      id: _parseInt(data['id']),
      question: _repair(data['question']),
      answer: _parseInt(data['answer']),
      options: rawOptions.map((dynamic item) => _repair(item)).toList(),
      category: _repair(data['category']),
      explanation: _repair(data['explanation']),
      quizId: _parseInt(data['quiz_id']),
      quizTitle: _repair(data['quiz_title']),
    );
  }

  Map<String, dynamic> toJson() {
    return <String, dynamic>{
      'id': id,
      'question': question,
      'answer': answer,
      'options': options ?? const <String>[],
      'category': category,
      'explanation': explanation,
      'quiz_id': quizId,
      'quiz_title': quizTitle,
    };
  }
}

class QuizCategory {
  final int id;
  final String title;
  final String slug;
  final String description;
  final String scope;
  final int sortOrder;

  const QuizCategory({
    required this.id,
    required this.title,
    required this.slug,
    required this.description,
    required this.scope,
    required this.sortOrder,
  });

  String get selectionId => 'category:$id';

  factory QuizCategory.fromApi(Map<String, dynamic> data) {
    return QuizCategory(
      id: _parseInt(data['id']) ?? 0,
      title: _repair(data['title']),
      slug: _repair(data['slug']),
      description: _repair(data['description']),
      scope: _repair(data['scope']),
      sortOrder: _parseInt(data['sort_order']) ?? 0,
    );
  }

  factory QuizCategory.fromJson(Map<String, dynamic> data) {
    return QuizCategory(
      id: _parseInt(data['id']) ?? 0,
      title: _repair(data['title']),
      slug: _repair(data['slug']),
      description: _repair(data['description']),
      scope: _repair(data['scope']),
      sortOrder: _parseInt(data['sort_order']) ?? 0,
    );
  }

  Map<String, dynamic> toJson() {
    return <String, dynamic>{
      'id': id,
      'title': title,
      'slug': slug,
      'description': description,
      'scope': scope,
      'sort_order': sortOrder,
    };
  }
}

class QuizCollection {
  final int? id;
  final String selectionId;
  final String title;
  final String description;
  final int? categoryId;
  final String status;
  final List<Question> questions;
  final bool isRemote;
  final bool isLoaded;

  const QuizCollection({
    this.id,
    required this.selectionId,
    required this.title,
    required this.description,
    required this.categoryId,
    required this.status,
    required this.questions,
    required this.isRemote,
    required this.isLoaded,
  });

  int get questionCount => questions.length;
  bool get hasQuestions => questions.isNotEmpty;

  QuizCollection copyWith({
    int? id,
    String? selectionId,
    String? title,
    String? description,
    int? categoryId,
    String? status,
    List<Question>? questions,
    bool? isRemote,
    bool? isLoaded,
  }) {
    return QuizCollection(
      id: id ?? this.id,
      selectionId: selectionId ?? this.selectionId,
      title: title ?? this.title,
      description: description ?? this.description,
      categoryId: categoryId ?? this.categoryId,
      status: status ?? this.status,
      questions: questions ?? this.questions,
      isRemote: isRemote ?? this.isRemote,
      isLoaded: isLoaded ?? this.isLoaded,
    );
  }

  factory QuizCollection.fromApiSummary(Map<String, dynamic> data) {
    final int? id = _parseInt(data['id']);
    return QuizCollection(
      id: id,
      selectionId: 'quiz:${id ?? 0}',
      title: _repair(data['title']),
      description: _repair(data['description']),
      categoryId: _parseInt(data['category_id']),
      status: _repair(data['status']),
      questions: const <Question>[],
      isRemote: true,
      isLoaded: false,
    );
  }

  factory QuizCollection.fromApiDetail(Map<String, dynamic> data) {
    final int? id = _parseInt(data['id']);
    final String selectionId = 'quiz:${id ?? 0}';
    final String title = _repair(data['title']);
    final List<dynamic> rawQuestions =
        (data['questions'] as List<dynamic>? ?? const <dynamic>[]);

    return QuizCollection(
      id: id,
      selectionId: selectionId,
      title: title,
      description: _repair(data['description']),
      categoryId: _parseInt(data['category_id']),
      status: _repair(data['status']),
      questions: rawQuestions
          .whereType<Map>()
          .map(
            (Map item) => Question.fromApi(
              Map<String, dynamic>.from(item),
              selectionId: selectionId,
              quizId: id,
              quizTitle: title,
            ),
          )
          .where((Question item) => (item.question ?? '').trim().isNotEmpty)
          .toList(),
      isRemote: true,
      isLoaded: true,
    );
  }

  factory QuizCollection.fromJson(Map<String, dynamic> data) {
    final List<dynamic> rawQuestions =
        (data['questions'] as List<dynamic>? ?? const <dynamic>[]);

    return QuizCollection(
      id: _parseInt(data['id']),
      selectionId: _repair(data['selection_id']),
      title: _repair(data['title']),
      description: _repair(data['description']),
      categoryId: _parseInt(data['category_id']),
      status: _repair(data['status']),
      questions: rawQuestions
          .whereType<Map>()
          .map(
            (Map item) => Question.fromJson(Map<String, dynamic>.from(item)),
          )
          .toList(),
      isRemote: data['is_remote'] is bool ? data['is_remote'] as bool : true,
      isLoaded: data['is_loaded'] is bool ? data['is_loaded'] as bool : false,
    );
  }

  Map<String, dynamic> toJson() {
    return <String, dynamic>{
      'id': id,
      'selection_id': selectionId,
      'title': title,
      'description': description,
      'category_id': categoryId,
      'status': status,
      'questions': questions.map((Question item) => item.toJson()).toList(),
      'is_remote': isRemote,
      'is_loaded': isLoaded,
    };
  }
}

int? _parseInt(dynamic value) {
  if (value is int) return value;
  if (value is num) return value.toInt();
  if (value is String) return int.tryParse(value.trim());
  return null;
}

String _repair(dynamic value) {
  final String text = (value ?? '').toString().trim();
  if (text.isEmpty) {
    return '';
  }
  return MojibakeFixer.repairText(text);
}
