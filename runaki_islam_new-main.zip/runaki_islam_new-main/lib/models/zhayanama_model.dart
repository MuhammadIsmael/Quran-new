class ZhyanamaData {
  final String? title;
  final String? desc;

  ZhyanamaData({this.title, this.desc});

  factory ZhyanamaData.formJson(Map<String, dynamic> json) {
    return ZhyanamaData(title: json['title'], desc: json['desc']);
  }
}
