class MuhjuzaData {
  final String? title;
  final String? desc;

  MuhjuzaData({this.title, this.desc});

  factory MuhjuzaData.formJson(Map<String, dynamic> json) {
    return MuhjuzaData(title: json['title'], desc: json['desc']);
  }
}
