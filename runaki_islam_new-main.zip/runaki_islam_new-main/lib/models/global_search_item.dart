import 'package:flutter/material.dart';

typedef GlobalSearchOpenAction = void Function(BuildContext context);

enum GlobalSearchKind { section, content }

class GlobalSearchItem {
  GlobalSearchItem({
    required this.id,
    required this.kind,
    required this.title,
    required this.sectionTitle,
    required this.icon,
    required this.onOpen,
    this.subtitle = '',
    this.preview = '',
    this.keywords = const <String>[],
  }) : normalizedTitle = normalizeSearchText(title),
       normalizedSectionTitle = normalizeSearchText(sectionTitle),
       normalizedSearchText = normalizeSearchText(
         <String>[
           title,
           sectionTitle,
           subtitle,
           preview,
           ...keywords,
         ].join(' '),
       );

  final String id;
  final GlobalSearchKind kind;
  final String title;
  final String sectionTitle;
  final String subtitle;
  final String preview;
  final IconData icon;
  final List<String> keywords;
  final GlobalSearchOpenAction onOpen;

  final String normalizedTitle;
  final String normalizedSectionTitle;
  final String normalizedSearchText;
}

String normalizeSearchText(String value) {
  if (value.trim().isEmpty) {
    return '';
  }

  const replacements = <String, String>{
    'أ': 'ا',
    'إ': 'ا',
    'آ': 'ا',
    'ٱ': 'ا',
    'ؤ': 'و',
    'ئ': 'ی',
    'ى': 'ی',
    'ي': 'ی',
    'ك': 'ک',
    'ة': 'ه',
    'ۀ': 'ه',
    'ھ': 'ه',
    'ـ': ' ',
    '_': ' ',
    '-': ' ',
    '/': ' ',
    '\\': ' ',
    '٠': '0',
    '١': '1',
    '٢': '2',
    '٣': '3',
    '٤': '4',
    '٥': '5',
    '٦': '6',
    '٧': '7',
    '٨': '8',
    '٩': '9',
    '۰': '0',
    '۱': '1',
    '۲': '2',
    '۳': '3',
    '۴': '4',
    '۵': '5',
    '۶': '6',
    '۷': '7',
    '۸': '8',
    '۹': '9',
  };

  var normalized = value.toLowerCase();
  replacements.forEach((source, target) {
    normalized = normalized.replaceAll(source, target);
  });

  normalized = normalized
      .replaceAll(RegExp(r'[\u064B-\u065F\u0670]'), '')
      .replaceAll(RegExp(r'[^0-9a-z\u0600-\u06ff ]+'), ' ')
      .replaceAll(RegExp(r'\s+'), ' ')
      .trim();

  return normalized;
}
