class QyamatModel {
  final String? sarder;
  final String? drezha;
  final String? bash;

  QyamatModel({this.sarder, this.drezha, this.bash});

  factory QyamatModel.formJson(Map<String, dynamic> json) {
    return QyamatModel(
      sarder: json['sarder'],
      drezha: json['drezha'],
      bash: json['bash'],
    );
  }
}
