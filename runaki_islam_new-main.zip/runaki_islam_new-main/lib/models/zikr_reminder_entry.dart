class ZikrReminderEntry {
  const ZikrReminderEntry({
    required this.title,
    required this.body,
    required this.detail,
    required this.kind,
  });

  final String title;
  final String body;
  final String detail;
  final String kind;

  String get resolvedDetail {
    final normalized = detail.trim();
    if (normalized.isNotEmpty) {
      return normalized;
    }
    return body.trim();
  }

  String get categoryLabel {
    switch (kind) {
      case 'morning':
        return 'زیکری بەیانیان';
      case 'evening':
        return 'زیکری ئێواران';
      default:
        return 'بیربهێنەوەی زیکر';
    }
  }

  Map<String, Object> toMap() {
    return <String, Object>{
      'title': title,
      'body': body,
      'detail': resolvedDetail,
      'kind': kind,
    };
  }

  static ZikrReminderEntry? fromMap(Map<dynamic, dynamic>? raw) {
    if (raw == null) {
      return null;
    }

    final title = raw['title']?.toString().trim() ?? '';
    final body = raw['body']?.toString().trim() ?? '';
    final detail = raw['detail']?.toString().trim() ?? body;
    final resolvedBody = body.isNotEmpty ? body : detail;
    final resolvedDetail = detail.isNotEmpty ? detail : body;
    if (title.isEmpty || resolvedDetail.isEmpty) {
      return null;
    }

    return ZikrReminderEntry(
      title: title,
      body: resolvedBody,
      detail: resolvedDetail,
      kind: _normalizeKind(raw['kind']?.toString()),
    );
  }

  static String _normalizeKind(String? raw) {
    switch (raw?.trim().toLowerCase()) {
      case 'morning':
        return 'morning';
      case 'evening':
        return 'evening';
      default:
        return 'periodic';
    }
  }
}
