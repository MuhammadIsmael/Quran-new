import 'package:runaki_islam/util/mojibake_fixer.dart';

class Book {
  const Book({
    this.id,
    required this.title,
    required this.description,
    this.category,
    required this.pdfUrl,
    this.coverImageUrl,
    required this.tags,
    this.slug,
    this.createdAt,
  });

  final int? id;
  final String title;
  final String description;
  final String? category;
  final String pdfUrl;
  final String? coverImageUrl;
  final List<String> tags;
  final String? slug;
  final DateTime? createdAt;

  bool get hasPdfUrl => pdfUrl.trim().isNotEmpty;
  bool get hasCategory => (category ?? '').trim().isNotEmpty;
  bool get hasCoverImage => (coverImageUrl ?? '').trim().isNotEmpty;
  bool get hasTags => tags.isNotEmpty;

  String? get primaryTag {
    if (tags.isNotEmpty) {
      return tags.first;
    }
    return category;
  }

  Map<String, dynamic> toStorageMap() {
    return <String, dynamic>{
      'id': id,
      'title': title,
      'description': description,
      'category': category,
      'pdfUrl': pdfUrl,
      'coverUrl': coverImageUrl,
      'tags': tags,
      'slug': slug,
      'createdAt': createdAt?.toIso8601String(),
    };
  }

  factory Book.fromStorageMap(Map<String, dynamic> json) {
    return Book.fromJson(json);
  }

  factory Book.fromJson(Map<String, dynamic> json, {Uri? baseUri}) {
    final rawUrl = _readString(json, const <String>[
      'file',
      'pdf_url',
      'pdfUrl',
      'path',
      'url',
      'file_url',
      'fileUrl',
    ]);
    final resolvedUrl = _resolveUrl(rawUrl, baseUri);
    final rawCoverUrl = _readString(json, const <String>[
      'image',
      'cover',
      'cover_url',
      'coverUrl',
      'thumbnail',
      'thumbnail_url',
      'thumbnailUrl',
    ]);
    final resolvedCoverUrl = _resolveUrl(rawCoverUrl, baseUri);

    final title = MojibakeFixer.repairText(
      _readString(json, const <String>['title', 'name']).trim(),
    );
    final normalizedTitle = title.isEmpty
        ? _filenameFromUrl(resolvedUrl, fallback: 'Untitled Book')
        : title;

    final description = MojibakeFixer.repairText(
      _readString(json, const <String>[
        'description',
        'desc',
        'details',
      ]).trim(),
    );

    final category = _normalizeNullable(
      MojibakeFixer.repairText(
        _readString(json, const <String>['category', 'cat', 'type']).trim(),
      ),
    );
    final tags = _readTags(json);

    final createdRaw = _readString(json, const <String>[
      'created_at',
      'createdAt',
      'date',
    ]).trim();

    return Book(
      id: _asInt(json['id']),
      title: normalizedTitle,
      description: description,
      category: category,
      pdfUrl: resolvedUrl,
      coverImageUrl: _normalizeNullable(resolvedCoverUrl.trim()),
      tags: tags,
      slug: _normalizeNullable(
        _readString(json, const <String>['slug']).trim(),
      ),
      createdAt: _parseDate(createdRaw),
    );
  }

  bool matchesQuery(String query) {
    final normalized = query.trim().toLowerCase();
    if (normalized.isEmpty) {
      return true;
    }
    final inTitle = title.toLowerCase().contains(normalized);
    final inDescription = description.toLowerCase().contains(normalized);
    final inCategory = (category ?? '').toLowerCase().contains(normalized);
    final inTags = tags.any((tag) => tag.toLowerCase().contains(normalized));
    return inTitle || inDescription || inCategory || inTags;
  }

  bool matchesTag(String? tag) {
    final normalized = tag?.trim().toLowerCase() ?? '';
    if (normalized.isEmpty) {
      return true;
    }

    final matchesCategory = (category ?? '').trim().toLowerCase() == normalized;
    if (matchesCategory) {
      return true;
    }

    return tags.any((item) => item.trim().toLowerCase() == normalized);
  }

  static String _readString(Map<String, dynamic> source, List<String> keys) {
    for (final key in keys) {
      final value = source[key];
      if (value == null) continue;
      final text = value.toString().trim();
      if (text.isNotEmpty) {
        return text;
      }
    }
    return '';
  }

  static String _resolveUrl(String rawUrl, Uri? baseUri) {
    if (rawUrl.isEmpty) {
      return '';
    }

    final parsed = Uri.tryParse(rawUrl);
    if (parsed != null && parsed.hasScheme) {
      return parsed.toString();
    }

    if (baseUri == null) {
      return rawUrl;
    }

    return baseUri.resolveUri(Uri.parse(rawUrl)).toString();
  }

  static String _filenameFromUrl(String url, {required String fallback}) {
    if (url.trim().isEmpty) {
      return fallback;
    }
    final uri = Uri.tryParse(url);
    final segments = uri?.pathSegments ?? const <String>[];
    if (segments.isEmpty) {
      return fallback;
    }
    final last = Uri.decodeComponent(segments.last).trim();
    if (last.isEmpty) {
      return fallback;
    }
    return last;
  }

  static int? _asInt(dynamic value) {
    if (value is int) return value;
    if (value is num) return value.toInt();
    if (value is String) return int.tryParse(value);
    return null;
  }

  static DateTime? _parseDate(String value) {
    if (value.isEmpty) return null;
    return DateTime.tryParse(value);
  }

  static List<String> _readTags(Map<String, dynamic> source) {
    final dynamic raw =
        source['tags'] ?? source['tag_list'] ?? source['labels'];
    final values = <String>[];

    if (raw is List) {
      for (final item in raw) {
        final text = MojibakeFixer.repairText(item.toString().trim());
        if (text.isNotEmpty && !values.contains(text)) {
          values.add(text);
        }
      }
    } else if (raw is String) {
      final pieces = raw.split(RegExp(r'[,|]'));
      for (final item in pieces) {
        final text = MojibakeFixer.repairText(item.trim());
        if (text.isNotEmpty && !values.contains(text)) {
          values.add(text);
        }
      }
    }

    return values;
  }

  static String? _normalizeNullable(String value) {
    if (value.isEmpty) {
      return null;
    }
    return value;
  }
}
