class DuaData {
  final String? title;
  final String? description;

  DuaData({this.title, this.description});

  factory DuaData.formJson(Map<String, dynamic> json) {
    return DuaData(title: json['title'], description: json['description']);
  }
}
