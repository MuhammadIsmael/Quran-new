import 'package:flutter/foundation.dart';
import 'package:home_widget/home_widget.dart';
import 'package:runaki_islam/util/platform_feature_flags.dart';

class PrayerHomeWidgetService {
  static const String _iosWidgetKind = 'PrayerTimesWidget';
  static const String _iosAppGroupId = 'group.com.amin.runakeislam.shared';
  static const List<String> _androidProviderNames = <String>[
    'PrayerTimesHomeWidgetProvider',
    'PrayerTimesHomeWidgetCompactProvider',
    'PrayerTimesHomeWidgetMiniProvider',
  ];
  static bool _iosConfigured = false;

  static Future<void> update({
    required String city,
    required String nextLine,
    required String nextTime,
    required String remaining,
    required String dateText,
    required List<String> rowNames,
    required List<String> rowTimes,
  }) async {
    if (kIsWeb) return;
    if (!PlatformFeatureFlags.supportsPrayerWidgets) return;
    if (PlatformFeatureFlags.isIos && !_iosConfigured) {
      await HomeWidget.setAppGroupId(_iosAppGroupId);
      _iosConfigured = true;
    }
    await HomeWidget.saveWidgetData<String>('prayer_city', city);
    await HomeWidget.saveWidgetData<String>('prayer_next_line', nextLine);
    await HomeWidget.saveWidgetData<String>('prayer_next_time', nextTime);
    await HomeWidget.saveWidgetData<String>('prayer_remaining', remaining);
    await HomeWidget.saveWidgetData<String>('prayer_date', dateText);
    for (int i = 0; i < 5; i++) {
      await HomeWidget.saveWidgetData<String>(
        'prayer_row_name_${i + 1}',
        i < rowNames.length ? rowNames[i] : '---',
      );
      await HomeWidget.saveWidgetData<String>(
        'prayer_row_time_${i + 1}',
        i < rowTimes.length ? rowTimes[i] : '--:--',
      );
    }
    for (final providerName in _androidProviderNames) {
      if (PlatformFeatureFlags.isIos) {
        break;
      }
      await HomeWidget.updateWidget(androidName: providerName);
    }
    if (PlatformFeatureFlags.isIos) {
      try {
        await HomeWidget.updateWidget(iOSName: _iosWidgetKind);
      } catch (_) {
        // WidgetKit is unavailable on iOS 13 and below.
      }
    }
  }
}
