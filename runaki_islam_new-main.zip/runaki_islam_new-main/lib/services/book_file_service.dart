import 'dart:convert';
import 'dart:io';

import 'package:dio/dio.dart';
import 'package:path_provider/path_provider.dart';
import 'package:runaki_islam/models/book_model.dart';
import 'package:shared_preferences/shared_preferences.dart';

class BookFileException implements Exception {
  const BookFileException(this.message);

  final String message;

  @override
  String toString() => message;
}

class BookFileService {
  BookFileService({Dio? dio}) : _dio = dio ?? Dio();

  static const String _downloadedBooksPrefsKey = 'downloaded_books_cache_v1';

  final Dio _dio;

  Future<File> localFile(Book book) async {
    final directory = await _booksDirectoryPath();
    return File('$directory/${_fileNameFor(book)}');
  }

  Future<bool> isDownloaded(Book book) async {
    final file = await localFile(book);
    return file.existsSync() && await file.length() > 0;
  }

  Future<File> ensureDownloaded(
    Book book, {
    void Function(double progress)? onProgress,
    bool forceRedownload = false,
  }) async {
    if (!_isValidPdfUrl(book.pdfUrl)) {
      throw const BookFileException('PDF URL is invalid.');
    }

    final file = await localFile(book);
    if (!forceRedownload && file.existsSync() && await file.length() > 0) {
      onProgress?.call(1);
      return file;
    }

    await _dio.download(
      book.pdfUrl,
      file.path,
      deleteOnError: true,
      options: Options(
        sendTimeout: const Duration(seconds: 20),
        receiveTimeout: const Duration(seconds: 90),
      ),
      onReceiveProgress: (received, total) {
        if (onProgress == null || total <= 0) {
          return;
        }
        onProgress((received / total).clamp(0, 1));
      },
    );

    if (!file.existsSync() || await file.length() <= 0) {
      throw const BookFileException('PDF download failed.');
    }

    await rememberDownloadedBook(book);
    onProgress?.call(1);
    return file;
  }

  Future<void> rememberDownloadedBook(Book book) async {
    final cachedBooks = await _readDownloadedBooks();
    final mergedByKey = <String, Book>{};

    for (final item in cachedBooks) {
      mergedByKey[_bookIdentity(item)] = item;
    }
    mergedByKey[_bookIdentity(book)] = book;

    final downloadedBooks = <Book>[];
    for (final item in mergedByKey.values) {
      if (await isDownloaded(item)) {
        downloadedBooks.add(item);
      }
    }

    await _writeDownloadedBooks(downloadedBooks);
  }

  Future<List<Book>> loadDownloadedBooks() async {
    final cachedBooks = await _readDownloadedBooks();
    final downloadedBooks = <Book>[];

    for (final book in cachedBooks) {
      if (await isDownloaded(book)) {
        downloadedBooks.add(book);
      }
    }

    if (downloadedBooks.length != cachedBooks.length) {
      await _writeDownloadedBooks(downloadedBooks);
    }

    return downloadedBooks;
  }

  bool isValidPdfUrl(String value) => _isValidPdfUrl(value);

  Future<String> _booksDirectoryPath() async {
    final directory = await getApplicationDocumentsDirectory();
    final booksDir = await Directory(
      '${directory.path}/runaki_books',
    ).create(recursive: true);
    return booksDir.path;
  }

  String _fileNameFor(Book book) {
    final sourceName = (book.slug ?? book.title).trim();
    var fileName = sourceName.replaceAll(RegExp(r'[\\/:*?"<>|]'), '_').trim();
    if (fileName.isEmpty) {
      fileName = 'book_${book.id ?? DateTime.now().millisecondsSinceEpoch}';
    }
    if (!fileName.toLowerCase().endsWith('.pdf')) {
      fileName = '$fileName.pdf';
    }
    return '${book.id ?? 'book'}_$fileName';
  }

  bool _isValidPdfUrl(String value) {
    final uri = Uri.tryParse(value.trim());
    if (uri == null || uri.host.isEmpty) {
      return false;
    }
    return uri.scheme == 'http' || uri.scheme == 'https';
  }

  Future<List<Book>> _readDownloadedBooks() async {
    final preferences = await SharedPreferences.getInstance();
    final raw = preferences.getString(_downloadedBooksPrefsKey);
    if (raw == null || raw.trim().isEmpty) {
      return const <Book>[];
    }

    try {
      final decoded = jsonDecode(raw);
      if (decoded is! List) {
        return const <Book>[];
      }

      return decoded
          .whereType<Map>()
          .map((item) => Book.fromStorageMap(Map<String, dynamic>.from(item)))
          .toList(growable: false);
    } catch (_) {
      return const <Book>[];
    }
  }

  Future<void> _writeDownloadedBooks(List<Book> books) async {
    final preferences = await SharedPreferences.getInstance();
    final payload = books.map((book) => book.toStorageMap()).toList();
    await preferences.setString(_downloadedBooksPrefsKey, jsonEncode(payload));
  }

  String _bookIdentity(Book book) => '${book.id ?? book.slug ?? book.pdfUrl}';
}
