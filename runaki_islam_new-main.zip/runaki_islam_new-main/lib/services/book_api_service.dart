import 'dart:convert';

import 'package:dio/dio.dart';
import 'package:runaki_islam/models/book_model.dart';

const String _defaultBooksApiUrl = String.fromEnvironment(
  'BOOKS_API_URL',
  defaultValue: 'https://dashboard.runakeislam.com/api/v1/books/index.php',
);

class BookApiException implements Exception {
  const BookApiException(this.message);

  final String message;

  @override
  String toString() => message;
}

class BookApiService {
  BookApiService({Dio? dio, String? endpoint})
    : _dio = dio ?? Dio(),
      endpoint = endpoint ?? _defaultBooksApiUrl;

  final Dio _dio;
  final String endpoint;

  Future<List<Book>> fetchBooks() async {
    if (endpoint.trim().isEmpty) {
      throw const BookApiException(
        'Books API endpoint is empty. Set BOOKS_API_URL or update _defaultBooksApiUrl.',
      );
    }

    Response<dynamic> response;
    try {
      response = await _dio.get<dynamic>(
        endpoint,
        options: Options(
          sendTimeout: const Duration(seconds: 20),
          receiveTimeout: const Duration(seconds: 30),
          responseType: ResponseType.json,
        ),
      );
    } on DioException catch (error) {
      final status = error.response?.statusCode;
      throw BookApiException(
        'Could not reach books API (${status ?? 'network error'}).',
      );
    } catch (_) {
      throw const BookApiException('Could not reach books API.');
    }

    final payload = _normalizePayload(response.data);
    final entries = _extractList(payload);
    final baseUri = Uri.tryParse(endpoint);

    final books = <Book>[];
    for (final entry in entries) {
      if (entry is! Map) continue;
      final item = Book.fromJson(
        Map<String, dynamic>.from(entry),
        baseUri: baseUri,
      );
      if (item.title.trim().isEmpty) continue;
      books.add(item);
    }

    books.sort((left, right) {
      final leftDate = left.createdAt;
      final rightDate = right.createdAt;
      if (leftDate != null && rightDate != null) {
        final byDate = rightDate.compareTo(leftDate);
        if (byDate != 0) return byDate;
      } else if (leftDate != null) {
        return -1;
      } else if (rightDate != null) {
        return 1;
      }
      return left.title.toLowerCase().compareTo(right.title.toLowerCase());
    });

    return books;
  }

  dynamic _normalizePayload(dynamic data) {
    if (data is String) {
      final text = data.trim();
      if (text.isEmpty) {
        throw const BookApiException('Books API returned an empty response.');
      }
      try {
        return jsonDecode(text);
      } catch (_) {
        throw const BookApiException('Books API returned invalid JSON.');
      }
    }
    return data;
  }

  List<dynamic> _extractList(dynamic payload) {
    if (payload is List) {
      return payload;
    }

    if (payload is Map) {
      final map = Map<String, dynamic>.from(payload);
      final status = map['status'];
      final isErrorStatus = status is bool ? !status : false;
      if (isErrorStatus) {
        final message = (map['message'] ?? map['error'] ?? '')
            .toString()
            .trim();
        throw BookApiException(
          message.isEmpty ? 'Books API returned an error.' : message,
        );
      }

      final candidates = <dynamic>[
        map['data'],
        map['books'],
        map['results'],
        map['items'],
      ];

      for (final value in candidates) {
        final extracted = _extractListCandidate(value);
        if (extracted != null) {
          return extracted;
        }
      }
    }

    throw const BookApiException(
      'Books API format is unsupported. Expected a list of books.',
    );
  }

  List<dynamic>? _extractListCandidate(dynamic value) {
    if (value is List) {
      return value;
    }

    if (value is! Map) {
      return null;
    }

    final map = Map<String, dynamic>.from(value);
    final nestedCandidates = <dynamic>[
      map['items'],
      map['data'],
      map['books'],
      map['results'],
    ];

    for (final item in nestedCandidates) {
      if (item is List) {
        return item;
      }
    }

    return null;
  }
}
