import 'dart:convert';

import 'package:shared_preferences/shared_preferences.dart';

enum AiConversationMessageRole { user, assistant, meta }

class AiConversationMessage {
  const AiConversationMessage({
    required this.id,
    required this.role,
    required this.text,
    required this.createdAt,
  });

  final String id;
  final AiConversationMessageRole role;
  final String text;
  final DateTime createdAt;

  bool get isUser => role == AiConversationMessageRole.user;
  bool get isAssistant => role == AiConversationMessageRole.assistant;
  bool get isMeta => role == AiConversationMessageRole.meta;

  AiConversationMessage copyWith({
    String? id,
    AiConversationMessageRole? role,
    String? text,
    DateTime? createdAt,
  }) {
    return AiConversationMessage(
      id: id ?? this.id,
      role: role ?? this.role,
      text: text ?? this.text,
      createdAt: createdAt ?? this.createdAt,
    );
  }

  Map<String, dynamic> toJson() {
    return <String, dynamic>{
      'id': id,
      'role': role.name,
      'text': text,
      'createdAt': createdAt.toIso8601String(),
    };
  }

  factory AiConversationMessage.fromJson(Map<String, dynamic> json) {
    return AiConversationMessage(
      id: (json['id'] ?? '').toString(),
      role: _roleFromString((json['role'] ?? '').toString()),
      text: (json['text'] ?? '').toString(),
      createdAt:
          DateTime.tryParse((json['createdAt'] ?? '').toString()) ??
          DateTime.now(),
    );
  }

  static AiConversationMessageRole _roleFromString(String raw) {
    return AiConversationMessageRole.values.firstWhere(
      (value) => value.name == raw,
      orElse: () => AiConversationMessageRole.meta,
    );
  }
}

class AiConversationRecord {
  const AiConversationRecord({
    required this.id,
    required this.sectionId,
    required this.title,
    required this.preview,
    required this.createdAt,
    required this.updatedAt,
    required this.messages,
  });

  final String id;
  final String sectionId;
  final String title;
  final String preview;
  final DateTime createdAt;
  final DateTime updatedAt;
  final List<AiConversationMessage> messages;

  AiConversationRecord copyWith({
    String? id,
    String? sectionId,
    String? title,
    String? preview,
    DateTime? createdAt,
    DateTime? updatedAt,
    List<AiConversationMessage>? messages,
  }) {
    return AiConversationRecord(
      id: id ?? this.id,
      sectionId: sectionId ?? this.sectionId,
      title: title ?? this.title,
      preview: preview ?? this.preview,
      createdAt: createdAt ?? this.createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
      messages: messages ?? this.messages,
    );
  }

  Map<String, dynamic> toJson() {
    return <String, dynamic>{
      'id': id,
      'sectionId': sectionId,
      'title': title,
      'preview': preview,
      'createdAt': createdAt.toIso8601String(),
      'updatedAt': updatedAt.toIso8601String(),
      'messages': messages.map((message) => message.toJson()).toList(),
    };
  }

  factory AiConversationRecord.fromJson(Map<String, dynamic> json) {
    final rawMessages = json['messages'];
    final messages = rawMessages is List
        ? rawMessages
              .whereType<Map>()
              .map(
                (item) => AiConversationMessage.fromJson(
                  item.map((key, value) => MapEntry(key.toString(), value)),
                ),
              )
              .toList(growable: false)
        : const <AiConversationMessage>[];

    return AiConversationRecord(
      id: (json['id'] ?? '').toString(),
      sectionId: (json['sectionId'] ?? '').toString(),
      title: (json['title'] ?? '').toString(),
      preview: (json['preview'] ?? '').toString(),
      createdAt:
          DateTime.tryParse((json['createdAt'] ?? '').toString()) ??
          DateTime.now(),
      updatedAt:
          DateTime.tryParse((json['updatedAt'] ?? '').toString()) ??
          DateTime.now(),
      messages: messages,
    );
  }
}

class AiChatHistoryService {
  static const String _historyKey = 'ai_chat_history_v2';
  static const String _activeConversationKey = 'ai_chat_active_conversation_v2';
  static const int _maxConversations = 30;

  Future<List<AiConversationRecord>> loadConversations() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString(_historyKey);
    if (raw == null || raw.trim().isEmpty) {
      return const <AiConversationRecord>[];
    }

    try {
      final decoded = jsonDecode(raw);
      if (decoded is! List) {
        return const <AiConversationRecord>[];
      }

      final records = decoded
          .whereType<Map>()
          .map(
            (item) => AiConversationRecord.fromJson(
              item.map((key, value) => MapEntry(key.toString(), value)),
            ),
          )
          .where((record) => record.id.trim().isNotEmpty)
          .toList(growable: false);

      return _sort(records);
    } catch (_) {
      return const <AiConversationRecord>[];
    }
  }

  Future<void> saveConversation(AiConversationRecord record) async {
    final conversations = await loadConversations();
    final next = <AiConversationRecord>[
      record,
      ...conversations.where((item) => item.id != record.id),
    ];

    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(
      _historyKey,
      jsonEncode(
        _sort(next)
            .take(_maxConversations)
            .map((item) => item.toJson())
            .toList(growable: false),
      ),
    );
  }

  Future<void> deleteConversation(String id) async {
    final conversations = await loadConversations();
    final next = conversations.where((item) => item.id != id).toList();
    final prefs = await SharedPreferences.getInstance();

    if (next.isEmpty) {
      await prefs.remove(_historyKey);
    } else {
      await prefs.setString(
        _historyKey,
        jsonEncode(next.map((item) => item.toJson()).toList(growable: false)),
      );
    }

    final activeId = prefs.getString(_activeConversationKey);
    if (activeId == id) {
      await prefs.remove(_activeConversationKey);
    }
  }

  Future<void> saveActiveConversationId(String? id) async {
    final prefs = await SharedPreferences.getInstance();
    if (id == null || id.trim().isEmpty) {
      await prefs.remove(_activeConversationKey);
      return;
    }
    await prefs.setString(_activeConversationKey, id.trim());
  }

  Future<String?> loadActiveConversationId() async {
    final prefs = await SharedPreferences.getInstance();
    final value = prefs.getString(_activeConversationKey)?.trim();
    if (value == null || value.isEmpty) {
      return null;
    }
    return value;
  }

  List<AiConversationRecord> _sort(List<AiConversationRecord> records) {
    final next = List<AiConversationRecord>.from(records);
    next.sort((left, right) => right.updatedAt.compareTo(left.updatedAt));
    return next;
  }
}
