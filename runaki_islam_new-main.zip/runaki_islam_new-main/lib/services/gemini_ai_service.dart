import 'package:dio/dio.dart';
import 'package:shared_preferences/shared_preferences.dart';

class AiChatTurn {
  const AiChatTurn({required this.isUser, required this.text});

  final bool isUser;
  final String text;
}

class GeminiAuthException implements Exception {
  const GeminiAuthException(this.message);
  final String message;

  @override
  String toString() => message;
}

class GeminiApiException implements Exception {
  const GeminiApiException(
    this.message, {
    this.statusCode,
    this.temporary = false,
  });

  final String message;
  final int? statusCode;
  final bool temporary;

  @override
  String toString() => message;
}

class GeminiAiService {
  GeminiAiService({Dio? dio}) : _dio = dio ?? Dio();

  static const String _prefsApiKey = 'gemini_api_key';
  static const String _defaultApiKey =
      'AIzaSyAM_4AEWZBvi1yAR5lwd2L3YMJnhn_RX3g';
  static const List<String> _modelCandidates = <String>[
    'gemini-2.0-flash',
    'gemini-2.5-flash',
    'gemini-flash-latest',
  ];

  static const int _maxOutputTokens = 4096;
  static const int _maxContinuationPasses = 3;
  static const int _maxHistoryTurns = 10;
  static const int _maxCharsPerTurn = 900;

  final Dio _dio;

  Future<String?> loadSavedApiKey() async {
    final prefs = await SharedPreferences.getInstance();
    final savedKey = prefs.getString(_prefsApiKey)?.trim();
    if (savedKey != null && savedKey.isNotEmpty) {
      return savedKey;
    }
    return null;
  }

  String? resolveBuildApiKey() {
    const envKey = String.fromEnvironment('GEMINI_API_KEY');
    if (envKey.trim().isNotEmpty) return envKey.trim();
    if (_defaultApiKey.trim().isNotEmpty) return _defaultApiKey.trim();
    return null;
  }

  Future<String?> resolveApiKey() async {
    final savedKey = await loadSavedApiKey();
    if (savedKey != null) return savedKey;
    final buildKey = resolveBuildApiKey();
    if (buildKey != null) {
      await saveApiKey(buildKey);
    }
    return buildKey;
  }

  Future<void> saveApiKey(String apiKey) async {
    final normalized = apiKey.trim();
    final prefs = await SharedPreferences.getInstance();
    if (normalized.isEmpty) {
      await prefs.remove(_prefsApiKey);
      return;
    }
    await prefs.setString(_prefsApiKey, normalized);
  }

  Future<String> generateReply({
    required String systemPrompt,
    required List<AiChatTurn> history,
    String? apiKey,
  }) async {
    final key = (apiKey?.trim().isNotEmpty ?? false)
        ? apiKey!.trim()
        : await resolveApiKey();

    if (key == null || key.isEmpty) {
      throw const GeminiAuthException(
        'AI is not configured. Add a Gemini API key for this device.',
      );
    }

    if (history.isEmpty) {
      throw const GeminiApiException('No message was sent.');
    }

    final retryHistories = _buildRetryHistories(history);
    DioException? lastNotFoundError;
    GeminiApiException? lastTemporaryError;

    for (final historySlice in retryHistories) {
      final initialContents = _buildContents(historySlice);
      for (final model in _modelCandidates) {
        try {
          return await _generateWithContinuation(
            key: key,
            model: model,
            systemPrompt: systemPrompt,
            initialContents: initialContents,
          );
        } on DioException catch (e) {
          final status = e.response?.statusCode;

          if (status == 401 || status == 403) {
            throw const GeminiAuthException(
              'API key is invalid or does not have permission.',
            );
          }

          if (status == 404) {
            lastNotFoundError = e;
            continue;
          }

          if (_isRetryableStatus(status)) {
            lastTemporaryError = GeminiApiException(
              _friendlyStatusMessage(status),
              statusCode: status,
              temporary: true,
            );
            continue;
          }

          throw GeminiApiException(
            _friendlyStatusMessage(status),
            statusCode: status,
          );
        } on GeminiApiException catch (e) {
          if (!e.temporary) {
            rethrow;
          }
          lastTemporaryError = e;
        }
      }
    }

    if (lastTemporaryError != null) {
      throw lastTemporaryError;
    }

    final status = lastNotFoundError?.response?.statusCode;
    throw GeminiApiException(
      'AI model was not found. Check API/model configuration. (${status ?? '404'})',
    );
  }

  List<List<AiChatTurn>> _buildRetryHistories(List<AiChatTurn> history) {
    final bounded = history.length > _maxHistoryTurns
        ? history.sublist(history.length - _maxHistoryTurns)
        : history;
    final windows = <int>{
      bounded.length,
      if (bounded.length > 8) 8,
      if (bounded.length > 6) 6,
      if (bounded.length > 4) 4,
    };

    return windows
        .map((window) => bounded.sublist(bounded.length - window))
        .toList(growable: false);
  }

  List<Map<String, dynamic>> _buildContents(List<AiChatTurn> history) {
    return history
        .map(
          (turn) => <String, dynamic>{
            'role': turn.isUser ? 'user' : 'model',
            'parts': <Map<String, String>>[
              <String, String>{'text': _normalizeTurnText(turn.text)},
            ],
          },
        )
        .toList(growable: false);
  }

  Future<String> _generateWithContinuation({
    required String key,
    required String model,
    required String systemPrompt,
    required List<Map<String, dynamic>> initialContents,
  }) async {
    final conversation = <Map<String, dynamic>>[
      ...initialContents.map(_cloneMap),
    ];
    final fullOutput = StringBuffer();

    for (var pass = 0; pass < _maxContinuationPasses; pass++) {
      final response = await _postWithRetry(
        key: key,
        model: model,
        systemPrompt: systemPrompt,
        conversation: conversation,
      );

      final parsed = _parseResponse(response.data);
      if (fullOutput.isNotEmpty) {
        fullOutput.writeln();
      }
      fullOutput.write(parsed.text);

      if (!_isTokenCut(parsed.finishReason)) {
        return fullOutput.toString().trim();
      }

      // Model was cut by token limit; ask it to continue from exact point.
      conversation.add(<String, dynamic>{
        'role': 'model',
        'parts': <Map<String, String>>[
          <String, String>{'text': parsed.text},
        ],
      });
      conversation.add(<String, dynamic>{
        'role': 'user',
        'parts': const <Map<String, String>>[
          <String, String>{
            'text':
                'Continue exactly from where you stopped. Do not repeat previous lines. Keep same language and structure.',
          },
        ],
      });
    }

    final fallback = fullOutput.toString().trim();
    if (fallback.isNotEmpty) return fallback;
    throw const GeminiApiException('AI returned an empty answer.');
  }

  Future<Response<dynamic>> _postWithRetry({
    required String key,
    required String model,
    required String systemPrompt,
    required List<Map<String, dynamic>> conversation,
  }) async {
    DioException? lastError;

    for (var attempt = 0; attempt < 3; attempt++) {
      try {
        return await _dio.post(
          'https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent',
          queryParameters: <String, dynamic>{'key': key},
          data: <String, dynamic>{
            'systemInstruction': <String, dynamic>{
              'parts': <Map<String, String>>[
                <String, String>{'text': systemPrompt},
              ],
            },
            'contents': conversation,
            'generationConfig': <String, dynamic>{
              'temperature': 0.28,
              'topP': 0.9,
              'maxOutputTokens': _maxOutputTokens,
              'responseMimeType': 'text/plain',
            },
          },
          options: Options(
            sendTimeout: const Duration(seconds: 20),
            receiveTimeout: const Duration(seconds: 90),
            headers: <String, String>{'Content-Type': 'application/json'},
          ),
        );
      } on DioException catch (error) {
        lastError = error;
        final status = error.response?.statusCode;
        if (!_isRetryableStatus(status) || attempt == 2) {
          rethrow;
        }
        await Future<void>.delayed(Duration(milliseconds: 800 * (attempt + 1)));
      }
    }

    throw lastError ??
        const GeminiApiException(
          'AI service is temporarily busy. Please try again shortly.',
          temporary: true,
        );
  }

  _ParsedModelOutput _parseResponse(dynamic body) {
    if (body is! Map) {
      throw const GeminiApiException('Invalid API response.');
    }

    final candidates = body['candidates'];
    if (candidates is! List || candidates.isEmpty) {
      final promptFeedback = body['promptFeedback'];
      if (promptFeedback is Map &&
          (promptFeedback['blockReason'] ?? '').toString().isNotEmpty) {
        throw GeminiApiException(
          'Response blocked: ${promptFeedback['blockReason']}',
        );
      }
      throw const GeminiApiException('AI did not return a response.');
    }

    final firstCandidate = candidates.first;
    if (firstCandidate is! Map) {
      throw const GeminiApiException('Invalid AI candidate format.');
    }

    final finishReason = firstCandidate['finishReason']?.toString();
    final content = firstCandidate['content'];
    if (content is! Map) {
      throw const GeminiApiException('Response content is missing.');
    }

    final parts = content['parts'];
    if (parts is! List || parts.isEmpty) {
      throw const GeminiApiException('Response text part is missing.');
    }

    final buffer = StringBuffer();
    for (final part in parts) {
      if (part is Map && part['text'] != null) {
        final text = part['text'].toString();
        if (text.trim().isNotEmpty) {
          if (buffer.isNotEmpty) buffer.writeln();
          buffer.write(text.trim());
        }
      }
    }

    final output = buffer.toString().trim();
    if (output.isEmpty) {
      throw const GeminiApiException('AI returned an empty answer.');
    }

    return _ParsedModelOutput(text: output, finishReason: finishReason);
  }

  bool _isTokenCut(String? finishReason) {
    final normalized = (finishReason ?? '').trim().toUpperCase();
    return normalized == 'MAX_TOKENS';
  }

  bool _isRetryableStatus(int? status) {
    return status == 429 ||
        status == 500 ||
        status == 502 ||
        status == 503 ||
        status == 504;
  }

  String _friendlyStatusMessage(int? status) {
    if (status == 429) {
      return 'AI requests are arriving too quickly. Please retry in a moment.';
    }
    if (status == 500 || status == 502 || status == 503 || status == 504) {
      return 'AI service is temporarily busy. Please try again shortly.';
    }
    return 'AI request failed. Please try again.';
  }

  String _normalizeTurnText(String value) {
    final normalized = value.trim();
    if (normalized.length <= _maxCharsPerTurn) {
      return normalized;
    }
    return '${normalized.substring(0, _maxCharsPerTurn).trimRight()}\n[Earlier part trimmed for stability]';
  }

  Map<String, dynamic> _cloneMap(Map<String, dynamic> value) {
    return value.map(
      (key, mapValue) => MapEntry(
        key,
        mapValue is List
            ? mapValue
                  .map(
                    (item) => item is Map
                        ? Map<String, dynamic>.from(
                            item.map((k, v) => MapEntry(k.toString(), v)),
                          )
                        : item,
                  )
                  .toList()
            : mapValue,
      ),
    );
  }
}

class _ParsedModelOutput {
  const _ParsedModelOutput({required this.text, this.finishReason});

  final String text;
  final String? finishReason;
}
