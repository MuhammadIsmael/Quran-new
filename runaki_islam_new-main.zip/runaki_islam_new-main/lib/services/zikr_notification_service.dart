import 'dart:io';

import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart';
import 'package:runaki_islam/database/database_helper.dart';
import 'package:runaki_islam/models/zikr_reminder_entry.dart';

class ZikrNotificationService {
  static const MethodChannel _channel = MethodChannel(
    'runaki_islam/adhan_alarm',
  );
  static const bool _testMode = false;
  static const int _testIntervalMinutes = 1;
  static const int _productionIntervalMinutes = 5 * 60;
  static const String _morningTitle = 'زیکری بەیانیان';
  static const String _eveningTitle = 'زیکری ئێواران';
  static const List<ZikrReminderEntry> _fallbackPeriodicReminders =
      <ZikrReminderEntry>[
        ZikrReminderEntry(
          title: 'بیربهێنەوەی زیکر',
          body: 'سبحان الله',
          detail: 'سبحان الله',
          kind: 'periodic',
        ),
        ZikrReminderEntry(
          title: 'بیربهێنەوەی زیکر',
          body: 'الحمد لله',
          detail: 'الحمد لله',
          kind: 'periodic',
        ),
        ZikrReminderEntry(
          title: 'بیربهێنەوەی زیکر',
          body: 'الله أكبر',
          detail: 'الله أكبر',
          kind: 'periodic',
        ),
      ];
  static const ZikrReminderEntry _fallbackMorningReminder = ZikrReminderEntry(
    title: _morningTitle,
    body: 'بەیانیە. کاتێکی جوانە بۆ دەستپێکردن بە زیکر و یادی خوا.',
    detail: 'بەیانیە. کاتێکی جوانە بۆ دەستپێکردن بە زیکر و یادی خوا.',
    kind: 'morning',
  );
  static const ZikrReminderEntry _fallbackEveningReminder = ZikrReminderEntry(
    title: _eveningTitle,
    body: 'ئێوارەیە. ڕۆژەکەت بە زیکر و دڵنیایی کۆتایی پێ بهێنە.',
    detail: 'ئێوارەیە. ڕۆژەکەت بە زیکر و دڵنیایی کۆتایی پێ بهێنە.',
    kind: 'evening',
  );

  static Future<void> startBackgroundZikrNotifications() async {
    if (!Platform.isAndroid) return;
    final bundle = await _loadReminderBundle();
    final intervalMinutes = _testMode
        ? _testIntervalMinutes
        : _productionIntervalMinutes;

    try {
      await _channel
          .invokeMethod<void>('scheduleZikrReminders', <String, Object>{
            'intervalMinutes': intervalMinutes,
            'periodicReminders': bundle.periodicReminders
                .map((item) => item.toMap())
                .toList(),
            'morningReminder': bundle.morningReminder.toMap(),
            'eveningReminder': bundle.eveningReminder.toMap(),
          });
    } on MissingPluginException catch (error) {
      debugPrint('scheduleZikrReminders missing plugin: $error');
    } on PlatformException catch (error) {
      debugPrint(
        'scheduleZikrReminders platform error: ${error.code} ${error.message}',
      );
    }
  }

  static Future<void> startRandomZikrNotifications() async {
    await startBackgroundZikrNotifications();
  }

  static Future<void> cancelRandomZikrNotifications() async {
    if (!Platform.isAndroid) return;
    try {
      await _channel.invokeMethod<void>('cancelZikrReminders');
    } on MissingPluginException catch (error) {
      debugPrint('cancelZikrReminders missing plugin: $error');
    } on PlatformException catch (error) {
      debugPrint(
        'cancelZikrReminders platform error: ${error.code} ${error.message}',
      );
    }
  }

  static Future<_ZikrReminderBundle> _loadReminderBundle() async {
    try {
      final decoded = await DatabaseHelper().getContentItems(
        DatabaseHelper.sectionZekr,
      );
      if (decoded.isEmpty) {
        return const _ZikrReminderBundle.fallback();
      }

      final reminders = <ZikrReminderEntry>[];
      ZikrReminderEntry? morningReminder;
      ZikrReminderEntry? eveningReminder;

      for (final item in decoded) {
        final title = item['title']?.toString().trim();
        final description = item['description']?.toString().trim();
        if (title == null ||
            title.isEmpty ||
            description == null ||
            description.isEmpty) {
          continue;
        }

        final reminder = ZikrReminderEntry(
          title: title,
          body: _previewBody(description),
          detail: description,
          kind: _resolveKind(title),
        );

        if (reminder.kind == 'morning') {
          morningReminder = reminder;
          continue;
        }
        if (reminder.kind == 'evening') {
          eveningReminder = reminder;
          continue;
        }
        reminders.add(reminder);
      }

      final uniquePeriodic = <String, ZikrReminderEntry>{};
      for (final reminder in reminders) {
        uniquePeriodic['${reminder.title}|${reminder.resolvedDetail}'] =
            reminder;
      }

      return _ZikrReminderBundle(
        periodicReminders: uniquePeriodic.values.take(120).toList(),
        morningReminder: morningReminder ?? _fallbackMorningReminder,
        eveningReminder: eveningReminder ?? _fallbackEveningReminder,
      );
    } catch (_) {
      return const _ZikrReminderBundle.fallback();
    }
  }

  static String _previewBody(String description) {
    final compact = description
        .split('\n')
        .map((line) => line.trim())
        .where((line) => line.isNotEmpty)
        .take(3)
        .join(' ');
    if (compact.isEmpty) {
      return 'بیربهێنەوەی زیکر';
    }
    if (compact.length <= 160) {
      return compact;
    }
    return '${compact.substring(0, 157)}...';
  }

  static String _resolveKind(String title) {
    if (title == _morningTitle) {
      return 'morning';
    }
    if (title == _eveningTitle) {
      return 'evening';
    }
    return 'periodic';
  }
}

class _ZikrReminderBundle {
  const _ZikrReminderBundle({
    required this.periodicReminders,
    required this.morningReminder,
    required this.eveningReminder,
  });

  const _ZikrReminderBundle.fallback()
    : periodicReminders = ZikrNotificationService._fallbackPeriodicReminders,
      morningReminder = ZikrNotificationService._fallbackMorningReminder,
      eveningReminder = ZikrNotificationService._fallbackEveningReminder;

  final List<ZikrReminderEntry> periodicReminders;
  final ZikrReminderEntry morningReminder;
  final ZikrReminderEntry eveningReminder;
}
