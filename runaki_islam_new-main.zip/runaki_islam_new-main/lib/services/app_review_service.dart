import 'package:device_info_plus/device_info_plus.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:in_app_review/in_app_review.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:url_launcher/url_launcher.dart';

class AppReviewService {
  AppReviewService._();

  static const String _feedbackEmail = 'runakeislam@aminsamad.com';
  static const String _reviewPromptCompletedKey =
      'app_review_prompt_completed_v1';
  static const String _reviewPromptLastShownKey =
      'app_review_prompt_last_shown_ms_v1';
  static const Duration _reviewPromptInterval = Duration(days: 7);
  static final InAppReview _inAppReview = InAppReview.instance;
  static final Uri _playStoreUri = Uri.parse(
    'https://play.google.com/store/apps/details?id=com.amin.runakeislam',
  );
  static bool _reviewCheckStartedThisLaunch = false;

  static Future<bool> composeFeedbackEmail({
    required BuildContext context,
    required String subject,
    required String body,
  }) async {
    final messenger = ScaffoldMessenger.maybeOf(context);
    final emailUri = _buildMailtoUri(subject: subject, body: body);

    try {
      final launched = await launchUrl(emailUri);
      if (launched) {
        return true;
      }
    } catch (_) {
      // Fall through to the snackbar below.
    }

    if (messenger != null) {
      messenger.showSnackBar(
        const SnackBar(
          content: Text(
            'نەتوانرا ئیمەیڵی ڕەخنە بکرێتەوە. تکایە دواتر هەوڵبدە.',
          ),
        ),
      );
    }

    return false;
  }

  static Future<void> maybePromptForReview(BuildContext context) async {
    if (_reviewCheckStartedThisLaunch) {
      return;
    }
    _reviewCheckStartedThisLaunch = true;

    if (await _isHuaweiFamilyDevice()) {
      return;
    }

    final SharedPreferences prefs = await SharedPreferences.getInstance();
    if (prefs.getBool(_reviewPromptCompletedKey) ?? false) {
      return;
    }

    final int? lastShownMs = prefs.getInt(_reviewPromptLastShownKey);
    if (lastShownMs != null) {
      final DateTime lastShown =
          DateTime.fromMillisecondsSinceEpoch(lastShownMs);
      if (DateTime.now().difference(lastShown) < _reviewPromptInterval) {
        return;
      }
    }

    await Future<void>.delayed(const Duration(seconds: 2));
    if (!context.mounted) {
      return;
    }

    final bool shouldReview = await _showReviewPrompt(context);
    await prefs.setInt(
      _reviewPromptLastShownKey,
      DateTime.now().millisecondsSinceEpoch,
    );

    if (!shouldReview) {
      return;
    }

    if (!context.mounted) {
      return;
    }

    final bool launched = await requestStoreReview(context);
    if (launched) {
      await prefs.setBool(_reviewPromptCompletedKey, true);
    }
  }

  static Future<bool> requestStoreReview(BuildContext context) async {
    final messenger = ScaffoldMessenger.maybeOf(context);

    if (await _isHuaweiFamilyDevice()) {
      await _openDefaultFeedbackEmail(messenger);
      return true;
    }

    if (await _requestInAppReview()) {
      return true;
    }

    if (await _openStoreListing()) {
      return true;
    }

    await _openDefaultFeedbackEmail(messenger, showFailureMessage: true);
    return false;
  }

  static Future<bool> openFeedback(BuildContext context) {
    return requestStoreReview(context);
  }

  static Future<bool> _isHuaweiFamilyDevice() async {
    if (kIsWeb || defaultTargetPlatform != TargetPlatform.android) {
      return false;
    }

    try {
      final androidInfo = await DeviceInfoPlugin().androidInfo;
      final deviceIdentity = <String>[
        androidInfo.manufacturer,
        androidInfo.brand,
        androidInfo.model,
        androidInfo.product,
      ].join(' ').toLowerCase();

      return deviceIdentity.contains('huawei') ||
          deviceIdentity.contains('honor');
    } catch (_) {
      return false;
    }
  }

  static Future<bool> _requestInAppReview() async {
    try {
      if (!kIsWeb && await _inAppReview.isAvailable()) {
        await _inAppReview.requestReview();
        return true;
      }
    } catch (_) {
      // Fall through to the store listing fallback.
    }

    return false;
  }

  static Future<bool> _openStoreListing() async {
    try {
      await _inAppReview.openStoreListing();
      return true;
    } catch (_) {
      // Fall back to the Play Store URL below.
    }

    try {
      return await launchUrl(
        _playStoreUri,
        mode: LaunchMode.externalApplication,
      );
    } catch (_) {
      return false;
    }
  }

  static Future<bool> _showReviewPrompt(BuildContext context) async {
    return await showModalBottomSheet<bool>(
          context: context,
          backgroundColor: Colors.transparent,
          isScrollControlled: true,
          builder: (context) {
            final theme = Theme.of(context);
            return SafeArea(
              top: false,
              child: Padding(
                padding: const EdgeInsets.fromLTRB(14, 0, 14, 14),
                child: Container(
                  padding: const EdgeInsets.fromLTRB(20, 20, 20, 18),
                  decoration: BoxDecoration(
                    color: theme.colorScheme.surface,
                    borderRadius: BorderRadius.circular(28),
                    boxShadow: const [
                      BoxShadow(
                        color: Color(0x22000000),
                        blurRadius: 28,
                        offset: Offset(0, 16),
                      ),
                    ],
                  ),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: [
                      Row(
                        children: [
                          Container(
                            width: 52,
                            height: 52,
                            decoration: BoxDecoration(
                              gradient: LinearGradient(
                                colors: [
                                  theme.colorScheme.primary,
                                  const Color(0xFFE1C88F),
                                ],
                              ),
                              borderRadius: BorderRadius.circular(16),
                            ),
                            child: const Icon(
                              Icons.star_rounded,
                              color: Colors.white,
                              size: 28,
                            ),
                          ),
                          const Spacer(),
                          Expanded(
                            flex: 4,
                            child: Text(
                              'ئەگەر بەرنامەکە بە دڵت بووە، پلەدانێک لە Google Play زۆر یارمەتیدەر دەبێت.',
                              textAlign: TextAlign.right,
                              textDirection: TextDirection.rtl,
                              style: theme.textTheme.bodyLarge?.copyWith(
                                fontWeight: FontWeight.w700,
                              ),
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 14),
                      Text(
                        'هەر کاتێک دەتوانی پلەی بدەیت. ئەگەر ئێستا نەبێت، دووبارە لە هەفتەی داهاتوودا پێشکەش دەکرێت.',
                        textAlign: TextAlign.right,
                        textDirection: TextDirection.rtl,
                        style: theme.textTheme.bodyMedium?.copyWith(
                          color: theme.colorScheme.onSurfaceVariant,
                          height: 1.55,
                        ),
                      ),
                      const SizedBox(height: 18),
                      Row(
                        children: [
                          Expanded(
                            child: OutlinedButton(
                              onPressed: () => Navigator.of(context).pop(false),
                              child: const Text('دواتر'),
                            ),
                          ),
                          const SizedBox(width: 10),
                          Expanded(
                            child: FilledButton(
                              onPressed: () => Navigator.of(context).pop(true),
                              child: const Text('پلە بدە'),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
            );
          },
        ) ??
        false;
  }

  static Future<void> _openDefaultFeedbackEmail(
    ScaffoldMessengerState? messenger, {
    bool showFailureMessage = false,
  }) async {
    final emailUri = _buildMailtoUri(
      subject: 'Runaki Islam Feedback',
      body: 'Please share your feedback for Runaki Islam.',
    );

    try {
      final launched = await launchUrl(emailUri);
      if (launched) {
        return;
      }
    } catch (_) {
      // Show the same fallback message below.
    }

    if (!showFailureMessage || messenger == null) {
      return;
    }

    messenger.showSnackBar(
      const SnackBar(
        content: Text('نەتوانرا پەیامی ڕەخنە بکرێتەوە. تکایە دواتر هەوڵبدە.'),
      ),
    );
  }
  static Uri _buildMailtoUri({
    required String subject,
    required String body,
  }) {
    final query = <String, String>{
      'subject': subject,
      'body': body,
    }.entries.map((entry) {
      return '${Uri.encodeComponent(entry.key)}='
          '${Uri.encodeComponent(entry.value)}';
    }).join('&');

    return Uri.parse('mailto:$_feedbackEmail?$query');
  }
}
