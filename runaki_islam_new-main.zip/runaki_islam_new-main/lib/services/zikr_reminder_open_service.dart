import 'dart:async';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:runaki_islam/models/zikr_reminder_entry.dart';
import 'package:runaki_islam/widgets/zikr_reminder_detail_sheet.dart';

class ZikrReminderOpenService {
  static const MethodChannel _channel = MethodChannel(
    'runaki_islam/adhan_alarm',
  );

  static final GlobalKey<NavigatorState> navigatorKey =
      GlobalKey<NavigatorState>();

  static bool _initialized = false;
  static bool _isPresenting = false;
  static Timer? _retryTimer;
  static ZikrReminderEntry? _queuedEntry;

  static Future<void> initialize() async {
    if (_initialized || !Platform.isAndroid) {
      return;
    }
    _initialized = true;
    _channel.setMethodCallHandler(_handleMethodCall);

    try {
      final raw = await _channel.invokeMethod<dynamic>(
        'consumePendingZikrReminder',
      );
      final entry = _parseEntry(raw);
      if (entry != null) {
        _queuePresentation(entry);
      }
    } on MissingPluginException catch (error) {
      debugPrint('consumePendingZikrReminder missing plugin: $error');
    } on PlatformException catch (error) {
      debugPrint(
        'consumePendingZikrReminder platform error: ${error.code} ${error.message}',
      );
    }
  }

  static Future<dynamic> _handleMethodCall(MethodCall call) async {
    if (call.method != 'openZikrReminder') {
      return null;
    }

    final entry = _parseEntry(call.arguments);
    if (entry != null) {
      _queuePresentation(entry);
    }
    return null;
  }

  static ZikrReminderEntry? _parseEntry(dynamic raw) {
    if (raw is Map) {
      return ZikrReminderEntry.fromMap(raw);
    }
    return null;
  }

  static void _queuePresentation(ZikrReminderEntry entry) {
    _queuedEntry = entry;
    _retryTimer?.cancel();
    _presentWhenReady();
  }

  static void _presentWhenReady() {
    if (_isPresenting) {
      return;
    }

    final entry = _queuedEntry;
    final context = navigatorKey.currentContext;
    if (entry == null) {
      return;
    }
    if (context == null) {
      _retryTimer = Timer(const Duration(milliseconds: 250), _presentWhenReady);
      return;
    }

    _queuedEntry = null;
    _isPresenting = true;
    WidgetsBinding.instance.addPostFrameCallback((_) async {
      final activeContext = navigatorKey.currentContext;
      if (activeContext == null) {
        _isPresenting = false;
        _queuePresentation(entry);
        return;
      }

      await showZikrReminderDetailSheet(activeContext, entry);
      _isPresenting = false;
      if (_queuedEntry != null) {
        _presentWhenReady();
      }
    });
  }
}
