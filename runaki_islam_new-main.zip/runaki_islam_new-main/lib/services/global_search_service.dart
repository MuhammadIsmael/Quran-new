import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'package:runaki_islam/Screens/DrawerScreens/AboutApp/about_app.dart';
import 'package:runaki_islam/Screens/DrawerScreens/FeedBack/feed_back_page.dart';
import 'package:runaki_islam/Screens/HomeItems/AyatKursi/ayat_kursi.dart';
import 'package:runaki_islam/Screens/HomeItems/Bahasht_Dozax/bahasht_u_dozax_page.dart';
import 'package:runaki_islam/Screens/HomeItems/Books/book_page.dart';
import 'package:runaki_islam/Screens/HomeItems/Cherok/cherok_page.dart';
import 'package:runaki_islam/Screens/HomeItems/Dua/dua_list.dart';
import 'package:runaki_islam/Screens/HomeItems/Farmuda/farmuda_page.dart';
import 'package:runaki_islam/Screens/HomeItems/Haramkrawakan/haramkrawan.dart';
import 'package:runaki_islam/Screens/HomeItems/HawalanePexambar/hawalane_pexambar_page.dart';
import 'package:runaki_islam/Screens/HomeItems/HijriCalendar/hijri_calendar_page.dart';
import 'package:runaki_islam/Screens/HomeItems/IslamicAI/islamic_ai_assistant_page.dart';
import 'package:runaki_islam/Screens/HomeItems/Kafaratakan/kafaratakan.dart';
import 'package:runaki_islam/Screens/HomeItems/MangeRamazan/mange_ramazan_page.dart';
import 'package:runaki_islam/Screens/HomeItems/NeshanakaneRozheDway/neshanakane_rozhe_dway.dart';
import 'package:runaki_islam/Screens/HomeItems/Nwezhkrdn/nwezh_page.dart';
import 'package:runaki_islam/Screens/HomeItems/PayakaneEmanIslam/payakane_eman_islam.dart';
import 'package:runaki_islam/Screens/HomeItems/Pexambarman/page_view.dart';
import 'package:runaki_islam/Screens/HomeItems/Pexambarman/zhyan_namay_pexambarman.dart';
import 'package:runaki_islam/Screens/HomeItems/PrsyarWakamAyne/prsyar_walam_ayne.dart';
import 'package:runaki_islam/Screens/HomeItems/PrsyarWalamRozheDway/prsyar_walam_rozhe_dway.dart';
import 'package:runaki_islam/Screens/HomeItems/PuxtaySaheheMuslim/puxtay_sahehe_muslim.dart';
import 'package:runaki_islam/Screens/HomeItems/QiblaFinder/qibla_finder_page.dart';
import 'package:runaki_islam/Screens/HomeItems/Qurani%20Piroz/quran_page.dart';
import 'package:runaki_islam/Screens/HomeItems/Sunatakan/sunatakan.dart';
import 'package:runaki_islam/Screens/HomeItems/Taqekrdnawa/welcome/welcome_screen.dart';
import 'package:runaki_islam/Screens/HomeItems/Tasbeeh/check_database.dart';
import 'package:runaki_islam/Screens/HomeItems/TawanaGawrakan/tawana_gawrakan_page.dart';
import 'package:runaki_islam/Screens/HomeItems/WtawAmozhgary/wtaw_amozhgare.dart';
import 'package:runaki_islam/Screens/HomeItems/ZanyareQuran/zanyare_quran_page.dart';
import 'package:runaki_islam/Screens/HomeItems/ZakatCalculator/zakat_calculator_page.dart';
import 'package:runaki_islam/Screens/HomeItems/Zekrakan/zekrakan.dart';
import 'package:runaki_islam/Screens/HomeItems/ZhyanNamayPexambaran/zh_pexambaran.dart';
import 'package:runaki_islam/Screens/HomeItems/nawakany_xuday_gawra/allah_names.dart';
import 'package:runaki_islam/Screens/mainScreens/all_items.dart';
import 'package:runaki_islam/Screens/mainScreens/widget/about_me_widget.dart';
import 'package:runaki_islam/Screens/mainScreens/widget/prayer_times_screen.dart';
import 'package:runaki_islam/database/database_helper.dart';
import 'package:runaki_islam/models/cherok_model.dart';
import 'package:runaki_islam/models/dua_model.dart';
import 'package:runaki_islam/models/farmuda_model.dart';
import 'package:runaki_islam/models/global_search_item.dart';
import 'package:runaki_islam/models/muhjizakan.dart';
import 'package:runaki_islam/models/prsyarakan_model.dart';
import 'package:runaki_islam/models/puxtay_sahehe_muslim_model.dart';
import 'package:runaki_islam/models/qyamat_model.dart';
import 'package:runaki_islam/models/tawanakan_model.dart';
import 'package:runaki_islam/models/wtaw_amozhgare.dart';
import 'package:runaki_islam/models/zekr_model.dart';
import 'package:runaki_islam/models/zhayanama_model.dart';
import 'package:runaki_islam/util/animation_helper.dart';

class GlobalSearchService {
  GlobalSearchService._();

  static final GlobalSearchService instance = GlobalSearchService._();

  static const String _recentSearchesKey = 'global_search_recent_queries_v1';
  static const int _maxRecentSearches = 10;

  Future<List<GlobalSearchItem>>? _indexFuture;
  List<GlobalSearchItem>? _cachedItems;
  SharedPreferences? _prefs;

  Future<List<GlobalSearchItem>> ensureIndex() {
    if (_cachedItems != null) {
      return Future<List<GlobalSearchItem>>.value(_cachedItems);
    }

    _indexFuture ??= _buildIndex();
    return _indexFuture!;
  }

  Future<void> warmUp() async {
    await ensureIndex();
  }

  Future<List<String>> loadRecentSearches() async {
    final prefs = await _preferences();
    final searches =
        prefs.getStringList(_recentSearchesKey) ?? const <String>[];
    return searches
        .where((query) => query.trim().isNotEmpty)
        .toList(growable: false);
  }

  Future<void> saveRecentSearch(String query) async {
    final trimmed = query.trim();
    if (trimmed.isEmpty) {
      return;
    }

    final prefs = await _preferences();
    final current = prefs.getStringList(_recentSearchesKey) ?? const <String>[];
    final normalized = normalizeSearchText(trimmed);

    final next = <String>[trimmed];
    for (final entry in current) {
      if (normalizeSearchText(entry) == normalized) {
        continue;
      }
      next.add(entry);
      if (next.length == _maxRecentSearches) {
        break;
      }
    }

    await prefs.setStringList(_recentSearchesKey, next);
  }

  Future<void> clearRecentSearches() async {
    final prefs = await _preferences();
    await prefs.remove(_recentSearchesKey);
  }

  List<GlobalSearchItem> featuredSections(List<GlobalSearchItem> items) {
    const featuredIds = <String>[
      'section-quran',
      'section-zekr',
      'section-dua',
      'section-prayer',
      'section-allah-names',
      'section-farmuda',
      'section-qibla',
      'section-books',
      'section-ramadan',
      'section-ai',
    ];

    final byId = <String, GlobalSearchItem>{
      for (final item in items) item.id: item,
    };

    return featuredIds
        .map((id) => byId[id])
        .whereType<GlobalSearchItem>()
        .toList(growable: false);
  }

  List<GlobalSearchItem> search(
    String query,
    List<GlobalSearchItem> items, {
    int limit = 60,
  }) {
    final normalizedQuery = normalizeSearchText(query);
    if (normalizedQuery.isEmpty) {
      return const <GlobalSearchItem>[];
    }

    final terms = normalizedQuery
        .split(' ')
        .where((term) => term.trim().isNotEmpty)
        .toList(growable: false);

    final matches = <_ScoredSearchItem>[];
    for (final item in items) {
      if (!_matchesItem(item, normalizedQuery, terms)) {
        continue;
      }

      matches.add(
        _ScoredSearchItem(
          item: item,
          score: _scoreItem(item, normalizedQuery, terms),
        ),
      );
    }

    matches.sort((left, right) {
      final byScore = right.score.compareTo(left.score);
      if (byScore != 0) {
        return byScore;
      }

      final byKind = left.item.kind.index.compareTo(right.item.kind.index);
      if (byKind != 0) {
        return byKind;
      }

      return left.item.title.compareTo(right.item.title);
    });

    return matches
        .take(limit)
        .map((entry) => entry.item)
        .toList(growable: false);
  }

  Future<SharedPreferences> _preferences() async {
    return _prefs ??= await SharedPreferences.getInstance();
  }

  Future<List<GlobalSearchItem>> _buildIndex() async {
    final items = <GlobalSearchItem>[..._buildSectionItems()];

    final contentGroups = await Future.wait<List<GlobalSearchItem>>(
      <Future<List<GlobalSearchItem>>>[
        _safeLoad(_loadZekrItems),
        _safeLoad(_loadDuaItems),
        _safeLoad(_loadFarmudaItems),
        _safeLoad(_loadCherokItems),
        _safeLoad(_loadAllahNamesItems),
        _safeLoad(_loadHaramItems),
        _safeLoad(_loadHawalItems),
        _safeLoad(_loadZanyareQuranItems),
        _safeLoad(_loadPrsyarAyneItems),
        _safeLoad(_loadZhyanNamayPexambaranItems),
        _safeLoad(_loadTawanaItems),
        _safeLoad(_loadSunnaItems),
        _safeLoad(_loadPuxtayMuslimItems),
        _safeLoad(_loadRozheQyamatItems),
        _safeLoad(_loadQuoteItems),
        _safeLoad(_loadProphetBiographyItems),
        _safeLoad(_loadProphetMiracleItems),
      ],
    );

    for (final group in contentGroups) {
      items.addAll(group);
    }

    _cachedItems = items;
    return items;
  }

  Future<List<GlobalSearchItem>> _safeLoad(
    Future<List<GlobalSearchItem>> Function() loader,
  ) async {
    try {
      return await loader();
    } catch (error, stackTrace) {
      debugPrint('GlobalSearchService load error: $error');
      debugPrintStack(stackTrace: stackTrace);
      return const <GlobalSearchItem>[];
    }
  }

  List<GlobalSearchItem> _buildSectionItems() {
    return <GlobalSearchItem>[
      _sectionItem(
        id: 'section-all',
        title: 'هەموو بەشەکان',
        subtitle: 'هەموو بابەت و بەشەکان لە یەک شوێندا',
        icon: Icons.grid_view_rounded,
        keywords: const <String>['all sections', 'categories', 'home'],
        pageBuilder: () => const AllItemsList(),
      ),
      _sectionItem(
        id: 'section-quran',
        title: 'قورئانی پیرۆز',
        subtitle: 'سورە، گەڕان، خوێندنەوە و زانیاری',
        icon: Icons.menu_book_rounded,
        keywords: const <String>['quran', 'surah', 'ayah'],
        pageBuilder: () => const QuranPage(),
      ),
      _sectionItem(
        id: 'section-zekr',
        title: 'زیکرەکان',
        subtitle: 'ئەزکار و یادی خودا',
        icon: Icons.auto_stories_rounded,
        keywords: const <String>['zikr', 'azkar', 'athkar'],
        pageBuilder: () => const ZekrakanPage(),
      ),
      _sectionItem(
        id: 'section-dua',
        title: 'دوعاکان',
        subtitle: 'دوعا و خواپێداویستییەکان',
        icon: Icons.volunteer_activism_rounded,
        keywords: const <String>['dua', 'prayer', 'supplication'],
        pageBuilder: () => const DuakanPage(),
      ),
      _sectionItem(
        id: 'section-tasbih',
        title: 'تەسبیح',
        subtitle: 'تەسبیح و ژماردنی زیکر',
        icon: Icons.fingerprint_rounded,
        keywords: const <String>['tasbih', 'sebha', 'counter'],
        pageBuilder: () => const CheckDatabase(),
      ),
      _sectionItem(
        id: 'section-farmuda',
        title: 'فەرموودە',
        subtitle: 'فەرموودە و هەدیسەکان',
        icon: Icons.chrome_reader_mode_rounded,
        keywords: const <String>['hadith', 'farmuda'],
        pageBuilder: () => const FarmudaPage(),
      ),
      _sectionItem(
        id: 'section-cherok',
        title: 'چیرۆک',
        subtitle: 'چیرۆک و بەسەرهات',
        icon: Icons.library_books_rounded,
        keywords: const <String>['story', 'stories'],
        pageBuilder: () => const CherokPage(),
      ),
      _sectionItem(
        id: 'section-books',
        title: 'کتێب',
        subtitle: 'کتێب و پەرتوکە PDF ـەکان',
        icon: Icons.collections_bookmark_rounded,
        keywords: const <String>['book', 'books', 'pdf'],
        pageBuilder: () => const BookPage(),
      ),
      _sectionItem(
        id: 'section-prayer',
        title: 'نوێژ',
        subtitle: 'فێرکارییەکانی نوێژ',
        icon: Icons.mosque_rounded,
        keywords: const <String>['nwezh', 'prayer', 'salah'],
        pageBuilder: () => const NwezhPage(),
      ),
      _sectionItem(
        id: 'section-prayer-times',
        title: 'کاتەکانی بانگ',
        subtitle: 'کاتەکانی نوێژ و بانگ',
        icon: Icons.access_time_rounded,
        keywords: const <String>['adhan', 'prayer times', 'bang'],
        pageBuilder: () => const PrayerTimesScreen(),
      ),
      _sectionItem(
        id: 'section-zakat',
        title: 'ژمێریاری زەکات',
        subtitle: 'حیسابکردنی زەکات',
        icon: Icons.calculate_rounded,
        keywords: const <String>['zakat', 'calculator'],
        pageBuilder: () => const ZakatCalculatorPage(),
      ),
      _sectionItem(
        id: 'section-qibla',
        title: 'قیبلە نواندەر',
        subtitle: 'دۆزینەوەی ئاراستەی قیبلە',
        icon: Icons.explore_rounded,
        keywords: const <String>['qibla', 'compass', 'direction'],
        pageBuilder: () => const QiblaFinderPage(),
      ),
      _sectionItem(
        id: 'section-allah-names',
        title: 'ناوەکانی خودای گەورە',
        subtitle: 'ناو و ماناکانی ئەسمائی حوسنا',
        icon: Icons.stars_rounded,
        keywords: const <String>['asmaul husna', 'allah names'],
        pageBuilder: () => const AllahNames(sarder: 'ناوەکانی خودای گەورە'),
      ),
      _sectionItem(
        id: 'section-prsyar',
        title: 'پرسیار و وەڵامی ئاینی',
        subtitle: 'پرسیار و وەڵامی بەشی ئاینی',
        icon: Icons.quiz_outlined,
        keywords: const <String>['question', 'answer', 'faq'],
        pageBuilder: () => const PrsyarWalamAyne(),
      ),
      _sectionItem(
        id: 'section-ayat-kursi',
        title: 'ئایەتی کورسی',
        subtitle: 'خوێندنەوە و مانای ئایەتی کورسی',
        icon: Icons.auto_awesome_rounded,
        keywords: const <String>['ayat kursi'],
        pageBuilder: () => const AyatKursi(sarder: 'ئایەتی کورسی'),
      ),
      _sectionItem(
        id: 'section-quiz',
        title: 'تاقیکردنەوە',
        subtitle: 'تاقیکردنەوە و پرسیاری خوێندکارانە',
        icon: Icons.fact_check_rounded,
        keywords: const <String>['quiz', 'test'],
        pageBuilder: () => const WelcomeScreen(),
      ),
      _sectionItem(
        id: 'section-prophet',
        title: 'ژیاننامەی پێغەمبەر ﷺ',
        subtitle: 'ژیاننامە و معجیزەکانی پێغەمبەر ﷺ',
        icon: Icons.auto_awesome_motion_rounded,
        keywords: const <String>['prophet', 'seerah', 'sirah'],
        pageBuilder: () =>
            const ZhyanNamayPexambarman(sarder: 'ﷺژیاننامەی پێغەمبەر'),
      ),
      _sectionItem(
        id: 'section-prophets',
        title: 'ژیاننامەی پێغەمبەران',
        subtitle: 'باس و چیرۆکی پێغەمبەران',
        icon: Icons.groups_rounded,
        keywords: const <String>['prophets'],
        pageBuilder: () =>
            const ZyanNamayPexambaran(sarder: 'ژیاننامەی پێغەمبەران'),
      ),
      _sectionItem(
        id: 'section-major-sins',
        title: 'تاوانە گەورەکان',
        subtitle: 'تاوان و ئامۆژگارییەکانیان',
        icon: Icons.warning_amber_rounded,
        keywords: const <String>['sins'],
        pageBuilder: () => const TawanaGawrakan(sarder: 'تاوانە گەورەکان'),
      ),
      _sectionItem(
        id: 'section-companions',
        title: 'هاوەڵانی پێغەمبەر ﷺ',
        subtitle: 'ژیان و سیرەتی هاوەڵان',
        icon: Icons.people_alt_rounded,
        keywords: const <String>['companions', 'sahaba'],
        pageBuilder: () => const Hawalakan(sarder: 'ﷺهاوەڵانی پێغەمبەر'),
      ),
      _sectionItem(
        id: 'section-heaven-hell',
        title: 'بەهەشت و دۆزەخ',
        subtitle: 'باسەکانی بەهەشت و دۆزەخ',
        icon: Icons.wb_sunny_outlined,
        keywords: const <String>['jannah', 'jahannam'],
        pageBuilder: () => const BahashtDozaxPage(sarder: 'بەهەشت و دۆزەخ'),
      ),
      _sectionItem(
        id: 'section-ramadan',
        title: 'مانگی ڕەمەزان',
        subtitle: 'ڕەمەزان، ڕۆژوو و ئامرازەکانی',
        icon: Icons.nightlight_round,
        keywords: const <String>['ramadan', 'fasting'],
        pageBuilder: () => const MangeRamazanPage(sarder: 'مانگی ڕەمەزان'),
      ),
      _sectionItem(
        id: 'section-quran-info',
        title: 'زانیاری قورئان',
        subtitle: 'زانیاری و بابەتەکانی پەیوەندیدار بە قورئان',
        icon: Icons.info_outline_rounded,
        keywords: const <String>['quran info', 'tafsir'],
        pageBuilder: () => const ZanyareQuranPage(sarder: 'زانیاری قورئان'),
      ),
      _sectionItem(
        id: 'section-hijri',
        title: 'ڕۆژژمێری هیجری',
        subtitle: 'ڕێکەوت و ساڵی هیجری',
        icon: Icons.calendar_month_rounded,
        keywords: const <String>['hijri', 'calendar'],
        pageBuilder: () => const HijriCalendarPage(sarder: 'ڕۆژژمێری هیجری'),
      ),
      _sectionItem(
        id: 'section-last-day-signs',
        title: 'نیشانەکانی ڕۆژی دوایی',
        subtitle: 'نیشانە و باسەکانی قیامەت',
        icon: Icons.bolt_rounded,
        keywords: const <String>['day of judgement', 'qiyamah signs'],
        pageBuilder: () =>
            const NeshanakaneRozheDwayScreen(sarder: 'نیشانەکانی ڕۆژی دوایی'),
      ),
      _sectionItem(
        id: 'section-quotes',
        title: 'وتە و ئامۆژگاری',
        subtitle: 'وتەی کورت و ئامۆژگاری',
        icon: Icons.format_quote_rounded,
        keywords: const <String>['quote', 'advice'],
        pageBuilder: () => const WtawAmozhgare(sarder: 'وتە و ئامۆژگاری'),
      ),
      _sectionItem(
        id: 'section-sunna',
        title: 'سوونەتەکان',
        subtitle: 'سوونەت و فێرکارییەکانیان',
        icon: Icons.lightbulb_outline_rounded,
        keywords: const <String>['sunna', 'sunnah'],
        pageBuilder: () => const SunatakanPage(sarder: 'سوونەتەکان'),
      ),
      _sectionItem(
        id: 'section-kafarat',
        title: 'کەفارەتەکان',
        subtitle: 'باس و ڕێنمایی کەفارەتەکان',
        icon: Icons.gavel_rounded,
        keywords: const <String>['kafara', 'expiation'],
        pageBuilder: () => const Kafaratakan(sarder: 'کەفارەتەکان'),
      ),
      _sectionItem(
        id: 'section-haram',
        title: 'حەڕامکراوەکان',
        subtitle: 'شتە قەدەغەکراوەکان',
        icon: Icons.block_rounded,
        keywords: const <String>['haram', 'forbidden'],
        pageBuilder: () => const Haramkrawakan(sarder: 'حەڕامکراوەکان'),
      ),
      _sectionItem(
        id: 'section-pillars',
        title: 'پایەکانی ئیمان  ئیسلام',
        subtitle: 'پایەکانی ئیمان و ئیسلام',
        icon: Icons.account_balance_rounded,
        keywords: const <String>['iman', 'islam', 'pillars'],
        pageBuilder: () =>
            const PayakaneEmanuIskam(sarder: 'پایەکانی ئیمان  ئیسلام'),
      ),
      _sectionItem(
        id: 'section-muslim',
        title: 'پوختەی سەحیحی موسلیم',
        subtitle: 'بابەت و فەرموودەکانی سەحیحی موسلیم',
        icon: Icons.library_add_check_rounded,
        keywords: const <String>['sahih muslim', 'muslim'],
        pageBuilder: () =>
            const PuxtaySaheheMuslim(sarder: 'پوختەی سەحیحی موسلیم'),
      ),
      _sectionItem(
        id: 'section-afterlife-qa',
        title: 'پرسیار و وەڵامەکانی دواڕۆژ',
        subtitle: 'پرسیار و وەڵام لەسەر قیامەت و دواڕۆژ',
        icon: Icons.history_edu_rounded,
        keywords: const <String>['afterlife', 'qiyamah', 'day of judgement'],
        pageBuilder: () =>
            const RozheQyamat(sarder: 'پرسیار و وەڵامەکانی دواڕۆژ'),
      ),
      _sectionItem(
        id: 'section-ai',
        title: 'یارمەتی AI',
        subtitle: 'پرسیارکردن لە یارمەتی AI',
        icon: Icons.smart_toy_rounded,
        keywords: const <String>['ai', 'assistant', 'chat'],
        pageBuilder: () => const IslamicAiAssistantPage(),
      ),
      _sectionItem(
        id: 'section-about-me',
        title: 'دەربارەی من',
        subtitle: 'ناسنامە و زانیاری دروستکەر',
        icon: Icons.person_outline_rounded,
        keywords: const <String>['about me', 'profile'],
        pageBuilder: () => const AboutMe(),
      ),
      _sectionItem(
        id: 'section-about-app',
        title: 'دەربارەی بەرنامە',
        subtitle: 'زانیاری و ناساندنی بەرنامە',
        icon: Icons.info_outline_rounded,
        keywords: const <String>['about app', 'info'],
        pageBuilder: () => const AboutApp(sarder: 'دەربارەی بەرنامە'),
      ),
      _sectionItem(
        id: 'section-feedback',
        title: 'ڕەخنە و پێشنیار',
        subtitle: 'فیدباک و پێشنیارەکان',
        icon: Icons.feedback_outlined,
        keywords: const <String>['feedback', 'support'],
        pageBuilder: () => const FeedBack(sarder: 'ڕەخنە و پێشنیار'),
      ),
    ];
  }

  GlobalSearchItem _sectionItem({
    required String id,
    required String title,
    required String subtitle,
    required IconData icon,
    required Widget Function() pageBuilder,
    List<String> keywords = const <String>[],
  }) {
    return GlobalSearchItem(
      id: id,
      kind: GlobalSearchKind.section,
      title: title,
      sectionTitle: 'بەشەکان',
      subtitle: subtitle,
      preview: subtitle,
      icon: icon,
      keywords: keywords,
      onOpen: (context) => _pushPage(context, pageBuilder()),
    );
  }

  Future<List<GlobalSearchItem>> _loadZekrItems() {
    return _loadJsonTitleDescriptionItems(
      assetPath: 'assets/data/content/zekr.json',
      idPrefix: 'zekr',
      sectionTitle: 'زیکرەکان',
      icon: Icons.auto_stories_rounded,
      keywords: const <String>['zikr', 'azkar', 'athkar'],
      titleReader: (entry) => ZekrData.formJson(entry).title ?? '',
      descriptionReader: (entry) => ZekrData.formJson(entry).description ?? '',
      pageBuilder: (title, description) =>
          TextPageView(title: title, desc: description, sarder: 'زیکرەکان'),
    );
  }

  Future<List<GlobalSearchItem>> _loadDuaItems() {
    return _loadJsonTitleDescriptionItems(
      assetPath: 'assets/data/content/dua.json',
      idPrefix: 'dua',
      sectionTitle: 'دوعاکان',
      icon: Icons.volunteer_activism_rounded,
      keywords: const <String>['dua', 'supplication'],
      titleReader: (entry) => DuaData.formJson(entry).title ?? '',
      descriptionReader: (entry) => DuaData.formJson(entry).description ?? '',
      pageBuilder: (title, description) =>
          TextPageView(title: title, desc: description, sarder: 'دوعاکان'),
    );
  }

  Future<List<GlobalSearchItem>> _loadFarmudaItems() async {
    final rows = await DbHelper().allCourses();
    final items = <GlobalSearchItem>[];

    for (final row in rows) {
      final farmuda = FarmudaData.fromMap(
        Map<String, dynamic>.from(row as Map),
      );
      items.add(
        GlobalSearchItem(
          id: 'farmuda-${farmuda.id}',
          kind: GlobalSearchKind.content,
          title: farmuda.title,
          sectionTitle: 'فەرموودە',
          subtitle: 'فەرموودە / هەدیس',
          preview: farmuda.kuDescr,
          icon: Icons.chrome_reader_mode_rounded,
          keywords: const <String>['hadith', 'farmuda'],
          onOpen: (context) => _pushPage(
            context,
            TextPageView(
              title: farmuda.title,
              sarder: 'فەرموودەکان',
              arab: farmuda.arDescr,
              desc: farmuda.kuDescr,
              isFarmuda: true,
            ),
          ),
        ),
      );
    }

    return items;
  }

  Future<List<GlobalSearchItem>> _loadCherokItems() async {
    final rows = await DbHelper2().allCourses();
    final items = <GlobalSearchItem>[];

    for (final row in rows) {
      final cherok = CherokData.fromMap(Map<String, dynamic>.from(row as Map));
      items.add(
        GlobalSearchItem(
          id: 'cherok-${items.length}',
          kind: GlobalSearchKind.content,
          title: cherok.section,
          sectionTitle: 'چیرۆک',
          subtitle: 'چیرۆک',
          preview: cherok.text,
          icon: Icons.library_books_rounded,
          keywords: const <String>['story', 'stories'],
          onOpen: (context) => _pushPage(
            context,
            TextPageView(
              title: cherok.section,
              sarder: cherok.section,
              desc: cherok.text,
            ),
          ),
        ),
      );
    }

    return items;
  }

  Future<List<GlobalSearchItem>> _loadAllahNamesItems() async {
    final names = await QueryCtr().getAllFruits();
    return names
        .map(
          (name) => GlobalSearchItem(
            id: 'allah-name-${name.id}',
            kind: GlobalSearchKind.content,
            title: name.t1,
            sectionTitle: 'ناوەکانی خودای گەورە',
            subtitle: name.t2,
            preview: name.t2,
            icon: Icons.stars_rounded,
            keywords: const <String>['allah names', 'asmaul husna'],
            onOpen: (context) => _pushPage(
              context,
              AllahNames(
                sarder: 'ناوەکانی خودای گەورە',
                initialSearchTerm: name.t1,
              ),
            ),
          ),
        )
        .toList(growable: false);
  }

  Future<List<GlobalSearchItem>> _loadHaramItems() {
    return _loadJsonTitleDescriptionItems(
      assetPath: 'assets/data/content/haramkrawakan.json',
      idPrefix: 'haram',
      sectionTitle: 'حەڕامکراوەکان',
      icon: Icons.block_rounded,
      keywords: const <String>['haram', 'forbidden'],
      titleReader: (entry) => TawanakanData.formJson(entry).title ?? '',
      descriptionReader: (entry) => TawanakanData.formJson(entry).desc ?? '',
      pageBuilder: (title, description) => TextPageView(
        title: title,
        desc: description,
        sarder: 'حەڕامکراوەکان',
      ),
    );
  }

  Future<List<GlobalSearchItem>> _loadHawalItems() {
    return _loadJsonTitleDescriptionItems(
      assetPath: 'assets/data/content/hawalane_pexambar.json',
      idPrefix: 'hawal',
      sectionTitle: 'هاوەڵانی پێغەمبەر ﷺ',
      icon: Icons.people_alt_rounded,
      keywords: const <String>['companions', 'sahaba'],
      titleReader: (entry) => TawanakanData.formJson(entry).title ?? '',
      descriptionReader: (entry) => TawanakanData.formJson(entry).desc ?? '',
      pageBuilder: (title, description) => TextPageView(
        title: title,
        desc: description,
        sarder: 'ﷺهاوەڵانی پێغەمبەر',
      ),
    );
  }

  Future<List<GlobalSearchItem>> _loadZanyareQuranItems() {
    return _loadJsonTitleDescriptionItems(
      assetPath: 'assets/data/content/zanyare_quran.json',
      idPrefix: 'zanyare-quran',
      sectionTitle: 'زانیاری قورئان',
      icon: Icons.info_outline_rounded,
      keywords: const <String>['quran info', 'tafsir'],
      titleReader: (entry) => TawanakanData.formJson(entry).title ?? '',
      descriptionReader: (entry) => TawanakanData.formJson(entry).desc ?? '',
      pageBuilder: (title, description) => TextPageView(
        title: title,
        desc: description,
        sarder: 'زانیاری قورئان',
      ),
    );
  }

  Future<List<GlobalSearchItem>> _loadPrsyarAyneItems() {
    return _loadJsonTitleDescriptionItems(
      assetPath: 'assets/data/content/prsyar_ayne.json',
      idPrefix: 'prsyar-ayne',
      sectionTitle: 'پرسیار و وەڵامی ئاینی',
      icon: Icons.quiz_outlined,
      keywords: const <String>['question', 'answer', 'faq'],
      titleReader: (entry) => PrsyarData.formJson(entry).babat ?? '',
      descriptionReader: (entry) {
        final item = PrsyarData.formJson(entry);
        return '${item.prsyar ?? ''} ${item.walam ?? ''}'.trim();
      },
      itemBuilder: (entry, index) {
        final item = PrsyarData.formJson(entry);
        return GlobalSearchItem(
          id: 'prsyar-ayne-$index',
          kind: GlobalSearchKind.content,
          title: item.babat ?? '',
          sectionTitle: 'پرسیار و وەڵامی ئاینی',
          subtitle: item.prsyar ?? '',
          preview: item.walam ?? '',
          icon: Icons.quiz_outlined,
          keywords: const <String>['question', 'answer', 'faq'],
          onOpen: (context) => _pushPage(
            context,
            TextPageView(
              title: item.prsyar ?? item.babat ?? '',
              desc: item.walam ?? '',
              sarder: 'پرسیار و وەڵامی ئاینی',
            ),
          ),
        );
      },
    );
  }

  Future<List<GlobalSearchItem>> _loadZhyanNamayPexambaranItems() {
    return _loadJsonTitleDescriptionItems(
      assetPath: 'assets/data/content/zhyan_namay_pexambaran.json',
      idPrefix: 'prophets',
      sectionTitle: 'ژیاننامەی پێغەمبەران',
      icon: Icons.groups_rounded,
      keywords: const <String>['prophets'],
      titleReader: (entry) => ZhyanamaData.formJson(entry).title ?? '',
      descriptionReader: (entry) => ZhyanamaData.formJson(entry).desc ?? '',
      pageBuilder: (title, description) => TextPageView(
        title: title,
        desc: description,
        sarder: 'ژیاننامەی پێغەمبەران',
      ),
    );
  }

  Future<List<GlobalSearchItem>> _loadTawanaItems() {
    return _loadJsonTitleDescriptionItems(
      assetPath: 'assets/data/content/tawana_gawrakan.json',
      idPrefix: 'major-sins',
      sectionTitle: 'تاوانە گەورەکان',
      icon: Icons.warning_amber_rounded,
      keywords: const <String>['sins'],
      titleReader: (entry) => TawanakanData.formJson(entry).title ?? '',
      descriptionReader: (entry) => TawanakanData.formJson(entry).desc ?? '',
      pageBuilder: (title, description) => TextPageView(
        title: title,
        desc: description,
        sarder: 'تاوانە گەورەکان',
      ),
    );
  }

  Future<List<GlobalSearchItem>> _loadSunnaItems() {
    return _loadJsonTitleDescriptionItems(
      assetPath: 'assets/data/content/sunatakan.json',
      idPrefix: 'sunna',
      sectionTitle: 'سوونەتەکان',
      icon: Icons.lightbulb_outline_rounded,
      keywords: const <String>['sunna', 'sunnah'],
      titleReader: (entry) => ZhyanamaData.formJson(entry).title ?? '',
      descriptionReader: (entry) => ZhyanamaData.formJson(entry).desc ?? '',
      pageBuilder: (title, description) =>
          TextPageView(title: title, desc: description, sarder: 'سوونەتەکان'),
    );
  }

  Future<List<GlobalSearchItem>> _loadPuxtayMuslimItems() async {
    final entries = await _loadJsonEntries(
      'assets/data/content/puxtay_sahehe_muslim.json',
    );
    return <GlobalSearchItem>[
      for (int index = 0; index < entries.length; index++)
        () {
          final item = PSMModel.formJson(entries[index]);
          return GlobalSearchItem(
            id: 'psm-$index',
            kind: GlobalSearchKind.content,
            title: item.sarder ?? '',
            sectionTitle: 'پوختەی سەحیحی موسلیم',
            subtitle: item.pageNum == null ? '' : 'بەشی ${item.pageNum}',
            preview: item.drezha ?? '',
            icon: Icons.library_add_check_rounded,
            keywords: const <String>['sahih muslim', 'muslim'],
            onOpen: (context) => _pushPage(
              context,
              TextPageView(
                title: item.sarder ?? '',
                desc: item.drezha ?? '',
                sarder: 'پوختەی سەحیحی موسلیم',
              ),
            ),
          );
        }(),
    ];
  }

  Future<List<GlobalSearchItem>> _loadRozheQyamatItems() async {
    final entries = await _loadJsonEntries(
      'assets/data/content/prsyar_rozhe_dway.json',
    );
    return <GlobalSearchItem>[
      for (int index = 0; index < entries.length; index++)
        () {
          final item = QyamatModel.formJson(entries[index]);
          return GlobalSearchItem(
            id: 'rozhe-qyamat-$index',
            kind: GlobalSearchKind.content,
            title: item.sarder ?? '',
            sectionTitle: 'پرسیار و وەڵامەکانی دواڕۆژ',
            subtitle: item.bash ?? '',
            preview: item.drezha ?? '',
            icon: Icons.history_edu_rounded,
            keywords: const <String>['afterlife', 'qiyamah'],
            onOpen: (context) => _pushPage(
              context,
              TextPageView(
                title: item.sarder ?? '',
                desc: item.drezha ?? '',
                sarder: item.bash ?? 'پرسیار و وەڵامەکانی دواڕۆژ',
              ),
            ),
          );
        }(),
    ];
  }

  Future<List<GlobalSearchItem>> _loadQuoteItems() async {
    final entries = await _loadJsonEntries(
      'assets/data/content/wtaw_amozhgary.json',
    );
    return <GlobalSearchItem>[
      for (int index = 0; index < entries.length; index++)
        () {
          final item = WtawAmozhgareModel.formJson(entries[index]);
          final text = item.text ?? '';
          return GlobalSearchItem(
            id: 'quote-$index',
            kind: GlobalSearchKind.content,
            title: _compactTitle(text),
            sectionTitle: 'وتە و ئامۆژگاری',
            subtitle: 'وتە / ئامۆژگاری',
            preview: text,
            icon: Icons.format_quote_rounded,
            keywords: const <String>['quote', 'advice'],
            onOpen: (context) => _pushPage(
              context,
              TextPageView(
                title: 'وتە و ئامۆژگاری',
                desc: text,
                sarder: 'وتە و ئامۆژگاری',
              ),
            ),
          );
        }(),
    ];
  }

  Future<List<GlobalSearchItem>> _loadProphetBiographyItems() {
    return _loadJsonTitleDescriptionItems(
      assetPath: 'assets/data/content/prophet_biography.json',
      idPrefix: 'prophet-bio',
      sectionTitle: 'ژیاننامەی پێغەمبەر ﷺ',
      icon: Icons.auto_awesome_motion_rounded,
      keywords: const <String>['prophet', 'seerah', 'sirah'],
      titleReader: (entry) => ZhyanamaData.formJson(entry).title ?? '',
      descriptionReader: (entry) => ZhyanamaData.formJson(entry).desc ?? '',
      pageBuilder: (title, description) => TextPageView(
        title: title,
        desc: description,
        sarder: 'ﷺژیاننامەی پێغەمبەر',
      ),
    );
  }

  Future<List<GlobalSearchItem>> _loadProphetMiracleItems() {
    return _loadJsonTitleDescriptionItems(
      assetPath: 'assets/data/content/prophet_miracles.json',
      idPrefix: 'prophet-miracle',
      sectionTitle: 'ژیاننامەی پێغەمبەر ﷺ',
      icon: Icons.auto_awesome_motion_rounded,
      keywords: const <String>['prophet miracle', 'mujiza'],
      titleReader: (entry) => MuhjuzaData.formJson(entry).title ?? '',
      descriptionReader: (entry) => MuhjuzaData.formJson(entry).desc ?? '',
      pageBuilder: (title, description) => TextPageView(
        title: title,
        desc: description,
        sarder: 'ﷺژیاننامەی پێغەمبەر',
      ),
    );
  }

  Future<List<GlobalSearchItem>> _loadJsonTitleDescriptionItems({
    required String assetPath,
    required String idPrefix,
    required String sectionTitle,
    required IconData icon,
    required List<String> keywords,
    required String Function(Map<String, dynamic> entry) titleReader,
    required String Function(Map<String, dynamic> entry) descriptionReader,
    Widget Function(String title, String description)? pageBuilder,
    GlobalSearchItem Function(Map<String, dynamic> entry, int index)?
    itemBuilder,
  }) async {
    final entries = await _loadJsonEntries(assetPath);
    final items = <GlobalSearchItem>[];

    for (int index = 0; index < entries.length; index++) {
      final entry = entries[index];
      if (itemBuilder != null) {
        items.add(itemBuilder(entry, index));
        continue;
      }

      final title = titleReader(entry).trim();
      if (title.isEmpty || pageBuilder == null) {
        continue;
      }

      final description = descriptionReader(entry).trim();
      items.add(
        GlobalSearchItem(
          id: '$idPrefix-$index',
          kind: GlobalSearchKind.content,
          title: title,
          sectionTitle: sectionTitle,
          subtitle: sectionTitle,
          preview: description,
          icon: icon,
          keywords: keywords,
          onOpen: (context) =>
              _pushPage(context, pageBuilder(title, description)),
        ),
      );
    }

    return items;
  }

  Future<List<Map<String, dynamic>>> _loadJsonEntries(String assetPath) async {
    return DatabaseHelper().getContentItemsByAssetPath(assetPath);
  }

  bool _matchesItem(
    GlobalSearchItem item,
    String normalizedQuery,
    List<String> terms,
  ) {
    if (item.normalizedSearchText.contains(normalizedQuery)) {
      return true;
    }

    return terms.every(item.normalizedSearchText.contains);
  }

  int _scoreItem(
    GlobalSearchItem item,
    String normalizedQuery,
    List<String> terms,
  ) {
    var score = 0;

    if (item.normalizedTitle == normalizedQuery) {
      score += 1200;
    } else if (item.normalizedTitle.startsWith(normalizedQuery)) {
      score += 800;
    } else if (item.normalizedTitle.contains(normalizedQuery)) {
      score += 520;
    }

    if (item.normalizedSectionTitle == normalizedQuery) {
      score += 240;
    } else if (item.normalizedSectionTitle.startsWith(normalizedQuery)) {
      score += 160;
    } else if (item.normalizedSectionTitle.contains(normalizedQuery)) {
      score += 120;
    }

    if (item.normalizedSearchText.contains(normalizedQuery)) {
      score += 100;
    }

    for (final term in terms) {
      if (item.normalizedTitle.contains(term)) {
        score += 70;
      } else if (item.normalizedSectionTitle.contains(term)) {
        score += 35;
      } else if (item.normalizedSearchText.contains(term)) {
        score += 16;
      }
    }

    if (item.kind == GlobalSearchKind.section) {
      score += 18;
    }

    return score;
  }

  void _pushPage(BuildContext context, Widget page) {
    Navigator.of(context).push(AppMotion.fadeSlidePage(page: page));
  }

  String _compactTitle(String value, {int limit = 52}) {
    final compact = value.replaceAll(RegExp(r'\s+'), ' ').trim();
    if (compact.isEmpty) {
      return 'وتە و ئامۆژگاری';
    }
    if (compact.length <= limit) {
      return compact;
    }
    return '${compact.substring(0, limit).trim()}...';
  }
}

class _ScoredSearchItem {
  const _ScoredSearchItem({required this.item, required this.score});

  final GlobalSearchItem item;
  final int score;
}
