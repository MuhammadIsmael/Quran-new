import 'dart:async';
import 'dart:convert';

import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:runaki_islam/firebase_options.dart';
import 'package:runaki_islam/services/zikr_reminder_open_service.dart';
import 'package:runaki_islam/util/mojibake_fixer.dart';

const String _remoteNotificationChannelId = 'runaki_remote_notifications';
const String _legacyRemoteNotificationChannelId = 'runaki_general';
const String _remoteNotificationChannelName = 'Runaki Islam Notifications';
const String _remoteNotificationChannelDescription =
    'Dashboard and Firebase push notifications';
const List<String> _defaultNotificationTopics = <String>['all', 'active-users'];

@pragma('vm:entry-point')
Future<void> firebaseMessagingBackgroundHandler(RemoteMessage message) async {
  try {
    if (Firebase.apps.isEmpty) {
      await Firebase.initializeApp(
        options: DefaultFirebaseOptions.currentPlatform,
      );
    }
  } catch (error) {
    debugPrint('Background Firebase init failed: $error');
  }

  debugPrint('Background FCM message received: ${message.messageId}');
}

class PushNotificationService {
  static final FlutterLocalNotificationsPlugin _localNotifications =
      FlutterLocalNotificationsPlugin();

  static bool _initialized = false;
  static Timer? _retryTimer;
  static _PushMessage? _queuedMessage;

  static const String _fcmTokenKey = 'runaki_fcm_token_v1';

  static bool get _isSupportedPlatform {
    if (kIsWeb) {
      return false;
    }

    switch (defaultTargetPlatform) {
      case TargetPlatform.android:
      case TargetPlatform.iOS:
        return true;
      default:
        return false;
    }
  }

  static void registerBackgroundHandler() {
    if (!_isSupportedPlatform) {
      return;
    }
    FirebaseMessaging.onBackgroundMessage(firebaseMessagingBackgroundHandler);
  }

  static Future<void> initialize() async {
    if (_initialized || !_isSupportedPlatform) {
      return;
    }
    if (Firebase.apps.isEmpty) {
      debugPrint('Push notifications skipped: Firebase is not initialized.');
      return;
    }

    _initialized = true;
    await _initializeLocalNotifications();
    await _prepareFirebaseMessaging();

    final initialMessage = await FirebaseMessaging.instance.getInitialMessage();
    if (initialMessage != null) {
      _queuePresentation(_PushMessage.fromRemoteMessage(initialMessage));
    }
  }

  static Future<void> _initializeLocalNotifications() async {
    const android = AndroidInitializationSettings('launcher_icon');
    const darwin = DarwinInitializationSettings(
      requestAlertPermission: false,
      requestBadgePermission: false,
      requestSoundPermission: false,
    );
    const settings = InitializationSettings(
      android: android,
      iOS: darwin,
      macOS: darwin,
    );

    await _localNotifications.initialize(
      settings: settings,
      onDidReceiveNotificationResponse: _onLocalNotificationResponse,
    );

    final androidPlugin = _localNotifications
        .resolvePlatformSpecificImplementation<
          AndroidFlutterLocalNotificationsPlugin
        >();
    await androidPlugin?.createNotificationChannel(
      const AndroidNotificationChannel(
        _remoteNotificationChannelId,
        _remoteNotificationChannelName,
        description: _remoteNotificationChannelDescription,
        importance: Importance.max,
      ),
    );
    await androidPlugin?.createNotificationChannel(
      const AndroidNotificationChannel(
        _legacyRemoteNotificationChannelId,
        _remoteNotificationChannelName,
        description: _remoteNotificationChannelDescription,
        importance: Importance.max,
      ),
    );
  }

  static Future<void> _prepareFirebaseMessaging() async {
    final settings = await FirebaseMessaging.instance.requestPermission(
      alert: true,
      badge: true,
      sound: true,
    );
    debugPrint('FCM permission status: ${settings.authorizationStatus.name}');

    final androidPlugin = _localNotifications
        .resolvePlatformSpecificImplementation<
          AndroidFlutterLocalNotificationsPlugin
        >();
    await androidPlugin?.requestNotificationsPermission();

    await FirebaseMessaging.instance
        .setForegroundNotificationPresentationOptions(
          alert: true,
          badge: true,
          sound: true,
        );

    // Ensure APNs token is ready before proceeding on iOS
    final bool isApnsReady = await _ensureApnsTokenAvailable();
    if (defaultTargetPlatform == TargetPlatform.iOS && !isApnsReady) {
      debugPrint(
        'iOS APNs token is missing. Skipping FCM token retrieval and topic subscriptions. '
        'Check Push Notifications capability, Apple signing/profile setup, and APNs key in Firebase.',
      );
      // Set up listener for when the token becomes available dynamically
      FirebaseMessaging.instance.onTokenRefresh.listen((token) async {
        await _storeToken(token);
        await _subscribeToDefaultTopics();
      });
      return;
    }

    try {
      final token = await FirebaseMessaging.instance.getToken();
      if (token != null && token.isNotEmpty) {
        await _storeToken(token);
      }
      await _subscribeToDefaultTopics();
    } catch (error) {
      debugPrint('Failed to get FCM token or subscribe to topics: $error');
    }

    FirebaseMessaging.instance.onTokenRefresh.listen((token) async {
      await _storeToken(token);
      await _subscribeToDefaultTopics();
    });

    FirebaseMessaging.onMessage.listen((message) async {
      debugPrint(
        'Foreground FCM message received: ${message.messageId} on ${message.from}',
      );
      await _showForegroundNotification(message);
    });

    FirebaseMessaging.onMessageOpenedApp.listen((message) {
      _queuePresentation(_PushMessage.fromRemoteMessage(message));
    });
  }

  static Future<bool> _ensureApnsTokenAvailable() async {
    if (defaultTargetPlatform != TargetPlatform.iOS) {
      return true;
    }

    String? apnsToken;
    for (int attempt = 0; attempt < 10; attempt++) {
      apnsToken = await FirebaseMessaging.instance.getAPNSToken();
      if (apnsToken != null && apnsToken.isNotEmpty) {
        debugPrint('iOS APNs token is available.');
        return true;
      }
      await Future<void>.delayed(const Duration(milliseconds: 1000));
    }

    return false;
  }

  // static Future<void> _logApplePushState() async {
  //   if (defaultTargetPlatform != TargetPlatform.iOS) {
  //     return;
  //   }

  //   String? apnsToken;
  //   for (int attempt = 0; attempt < 6; attempt++) {
  //     apnsToken = await FirebaseMessaging.instance.getAPNSToken();
  //     if (apnsToken != null && apnsToken.isNotEmpty) {
  //       break;
  //     }
  //     await Future<void>.delayed(const Duration(milliseconds: 500));
  //   }

  //   if (apnsToken == null || apnsToken.isEmpty) {
  //     debugPrint(
  //       'iOS APNs token is missing. Check Push Notifications capability, '
  //       'Apple signing/profile setup, and APNs key in Firebase.',
  //     );
  //     return;
  //   }

  //   debugPrint('iOS APNs token is available.');
  // }

  static Future<void> _storeToken(String token) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_fcmTokenKey, token);
    debugPrint('FCM registration token updated.');
  }

  static Future<void> _subscribeToDefaultTopics() async {
    if (defaultTargetPlatform == TargetPlatform.iOS) {
      final apnsToken = await FirebaseMessaging.instance.getAPNSToken();
      if (apnsToken == null || apnsToken.isEmpty) {
        debugPrint('Skipping FCM topic subscription: APNs token is null.');
        return;
      }
    }

    for (final topic in _defaultNotificationTopics) {
      try {
        await FirebaseMessaging.instance.subscribeToTopic(topic);
        debugPrint('Subscribed to FCM topic: $topic');
      } catch (error) {
        debugPrint('FCM topic subscription failed for $topic: $error');
      }
    }
  }

  static Future<void> _showForegroundNotification(RemoteMessage message) async {
    final pushMessage = _PushMessage.fromRemoteMessage(message);
    if (!pushMessage.hasVisibleContent) {
      return;
    }

    await _localNotifications.show(
      id: pushMessage.id,
      title: pushMessage.title,
      body: pushMessage.body,
      notificationDetails: NotificationDetails(
        android: AndroidNotificationDetails(
          _remoteNotificationChannelId,
          _remoteNotificationChannelName,
          channelDescription: _remoteNotificationChannelDescription,
          importance: Importance.max,
          priority: Priority.high,
          icon: 'ic_notification',
        ),
        iOS: const DarwinNotificationDetails(
          presentAlert: true,
          presentBadge: true,
          presentSound: true,
        ),
      ),
      payload: pushMessage.toPayload(),
    );
  }

  static void _onLocalNotificationResponse(NotificationResponse response) {
    final payload = response.payload;
    if (payload == null || payload.isEmpty) {
      return;
    }

    final message = _PushMessage.fromPayload(payload);
    if (message != null) {
      _queuePresentation(message);
    }
  }

  static void _queuePresentation(_PushMessage message) {
    _queuedMessage = message;
    _retryTimer?.cancel();
    _presentWhenReady();
  }

  static void _presentWhenReady() {
    final message = _queuedMessage;
    final context = ZikrReminderOpenService.navigatorKey.currentContext;

    if (message == null) {
      return;
    }

    if (context == null) {
      _retryTimer = Timer(const Duration(milliseconds: 250), _presentWhenReady);
      return;
    }

    _queuedMessage = null;
    WidgetsBinding.instance.addPostFrameCallback((_) async {
      final activeContext = ZikrReminderOpenService.navigatorKey.currentContext;
      if (activeContext == null) {
        _queuePresentation(message);
        return;
      }

      await showDialog<void>(
        context: activeContext,
        builder: (dialogContext) {
          return AlertDialog(
            title: Text(
              message.title.isNotEmpty ? message.title : 'Runaki Islam',
              textAlign: TextAlign.right,
            ),
            content: Text(
              message.body.isNotEmpty
                  ? message.body
                  : 'ئاگادارکردنەوەیەکی نوێت هات.',
              textAlign: TextAlign.right,
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.of(dialogContext).pop(),
                child: const Text('باشە'),
              ),
            ],
          );
        },
      );
    });
  }
}

class _PushMessage {
  const _PushMessage({
    required this.id,
    required this.title,
    required this.body,
    required this.data,
  });

  factory _PushMessage.fromRemoteMessage(RemoteMessage message) {
    final notification = message.notification;
    final data = message.data.map<String, dynamic>(
      (key, value) =>
          MapEntry<String, dynamic>(key, MojibakeFixer.repairObject(value)),
    );

    return _PushMessage(
      id: message.messageId?.hashCode ?? DateTime.now().millisecondsSinceEpoch,
      title: MojibakeFixer.repairText(
        notification?.title?.trim() ??
            data['title']?.toString().trim() ??
            'Runaki Islam',
      ),
      body: MojibakeFixer.repairText(
        notification?.body?.trim() ??
            data['body']?.toString().trim() ??
            data['message']?.toString().trim() ??
            '',
      ),
      data: data,
    );
  }

  factory _PushMessage.fromMap(Map<String, dynamic> map) {
    return _PushMessage(
      id: (map['id'] as num?)?.toInt() ?? DateTime.now().millisecondsSinceEpoch,
      title: MojibakeFixer.repairText(
        map['title']?.toString().trim() ?? 'Runaki Islam',
      ),
      body: MojibakeFixer.repairText(map['body']?.toString().trim() ?? ''),
      data:
          (map['data'] as Map?)?.map<String, dynamic>(
            (key, value) => MapEntry<String, dynamic>(key.toString(), value),
          ) ??
          const <String, dynamic>{},
    );
  }

  final int id;
  final String title;
  final String body;
  final Map<String, dynamic> data;

  bool get hasVisibleContent => title.isNotEmpty || body.isNotEmpty;

  String toPayload() {
    return jsonEncode(<String, dynamic>{
      'id': id,
      'title': title,
      'body': body,
      'data': data,
    });
  }

  static _PushMessage? fromPayload(String payload) {
    try {
      final decoded = jsonDecode(payload);
      if (decoded is Map<String, dynamic>) {
        return _PushMessage.fromMap(decoded);
      }
      if (decoded is Map) {
        return _PushMessage.fromMap(
          decoded.map<String, dynamic>(
            (key, value) => MapEntry<String, dynamic>(key.toString(), value),
          ),
        );
      }
    } catch (error) {
      debugPrint('Failed to decode notification payload: $error');
    }
    return null;
  }
}
