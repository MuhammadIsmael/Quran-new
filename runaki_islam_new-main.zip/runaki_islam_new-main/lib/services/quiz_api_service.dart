import 'dart:convert';

import 'package:dio/dio.dart';
import 'package:runaki_islam/models/questions.dart';

const String _defaultQuizzesApiUrl = String.fromEnvironment(
  'QUIZZES_API_URL',
  defaultValue: 'https://dashboard.runakeislam.com/api/v1/quizzes/index.php',
);

const String _defaultQuizCategoriesApiUrl = String.fromEnvironment(
  'QUIZ_CATEGORIES_API_URL',
  defaultValue:
      'https://dashboard.runakeislam.com/api/v1/categories/index.php?scope=quiz',
);

class QuizApiException implements Exception {
  const QuizApiException(this.message);

  final String message;

  @override
  String toString() => message;
}

class QuizApiService {
  QuizApiService({
    Dio? dio,
    String? endpoint,
    String? categoriesEndpoint,
  }) : _dio = dio ?? Dio(),
       endpoint = endpoint ?? _defaultQuizzesApiUrl,
       categoriesEndpoint =
           categoriesEndpoint ?? _defaultQuizCategoriesApiUrl;

  final Dio _dio;
  final String endpoint;
  final String categoriesEndpoint;

  Future<List<QuizCategory>> fetchQuizCategories() async {
    final dynamic payload = await _getPayload(categoriesEndpoint);
    final List<dynamic> items = _extractList(
      payload,
      unsupportedMessage:
          'Quizzes categories API format is unsupported. Expected a list.',
    );

    return items
        .whereType<Map>()
        .map(
          (Map item) => QuizCategory.fromApi(Map<String, dynamic>.from(item)),
        )
        .where((QuizCategory item) => item.id > 0)
        .toList();
  }

  Future<List<QuizCollection>> fetchQuizCatalog() async {
    final dynamic payload = await _getPayload(endpoint);
    final List<dynamic> items = _extractList(
      payload,
      unsupportedMessage:
          'Quizzes API format is unsupported. Expected a list of quizzes.',
    );

    return items
        .whereType<Map>()
        .map(
          (Map item) =>
              QuizCollection.fromApiSummary(Map<String, dynamic>.from(item)),
        )
        .where((QuizCollection item) => item.id != null)
        .toList();
  }

  Future<QuizCollection> fetchQuizDetail(int quizId) async {
    final dynamic payload = await _getPayload(
      endpoint,
      queryParameters: <String, dynamic>{'id': quizId},
    );
    final Map<String, dynamic> data = _extractMap(
      payload,
      unsupportedMessage:
          'Quizzes API format is unsupported. Expected quiz details.',
    );
    return QuizCollection.fromApiDetail(data);
  }

  Future<dynamic> _getPayload(
    String url, {
    Map<String, dynamic>? queryParameters,
  }) async {
    if (url.trim().isEmpty) {
      throw const QuizApiException('Quizzes API endpoint is empty.');
    }

    Response<dynamic> response;
    try {
      response = await _dio.get<dynamic>(
        url,
        queryParameters: queryParameters,
        options: Options(
          sendTimeout: const Duration(seconds: 8),
          receiveTimeout: const Duration(seconds: 12),
          responseType: ResponseType.json,
        ),
      );
    } on DioException catch (error) {
      final int? status = error.response?.statusCode;
      throw QuizApiException(
        'Could not reach quizzes API (${status ?? 'network error'}).',
      );
    } catch (_) {
      throw const QuizApiException('Could not reach quizzes API.');
    }

    return _extractWrappedData(_normalizePayload(response.data));
  }

  dynamic _normalizePayload(dynamic data) {
    if (data is String) {
      final String text = data.trim();
      if (text.isEmpty) {
        throw const QuizApiException('Quizzes API returned an empty response.');
      }
      try {
        return jsonDecode(text);
      } catch (_) {
        throw const QuizApiException('Quizzes API returned invalid JSON.');
      }
    }
    return data;
  }

  dynamic _extractWrappedData(dynamic payload) {
    if (payload is! Map) {
      throw const QuizApiException(
        'Quizzes API format is unsupported. Expected an object wrapper.',
      );
    }

    final Map<String, dynamic> map = Map<String, dynamic>.from(payload);
    final dynamic status = map['status'];
    if (status is bool && !status) {
      final String message =
          (map['message'] ?? 'Quizzes API returned an error.')
              .toString()
              .trim();
      throw QuizApiException(
        message.isEmpty ? 'Quizzes API returned an error.' : message,
      );
    }

    if (!map.containsKey('data')) {
      throw const QuizApiException(
        'Quizzes API format is unsupported. Missing data field.',
      );
    }

    return map['data'];
  }

  List<dynamic> _extractList(
    dynamic payload, {
    required String unsupportedMessage,
  }) {
    if (payload is List) {
      return payload;
    }

    throw QuizApiException(unsupportedMessage);
  }

  Map<String, dynamic> _extractMap(
    dynamic payload, {
    required String unsupportedMessage,
  }) {
    if (payload is Map) {
      return Map<String, dynamic>.from(payload);
    }

    throw QuizApiException(unsupportedMessage);
  }
}
