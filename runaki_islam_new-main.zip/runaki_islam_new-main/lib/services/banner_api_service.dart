import 'dart:convert';
import 'dart:io';

import 'package:dio/dio.dart';
import 'package:path/path.dart' as path;
import 'package:path_provider/path_provider.dart';
import 'package:shared_preferences/shared_preferences.dart';

const String _bannersApiUrl =
    'https://dashboard.runakeislam.com/api/v1/banners/index.php';

class HomeBanner {
  const HomeBanner({
    required this.id,
    required this.title,
    required this.link,
    required this.imageUrl,
    required this.sortOrder,
    this.localImagePath,
  });

  final int id;
  final String title;
  final String link;
  final String imageUrl;
  final int sortOrder;
  final String? localImagePath;

  bool get hasLocalImage =>
      localImagePath != null && localImagePath!.trim().isNotEmpty;

  HomeBanner copyWith({
    int? id,
    String? title,
    String? link,
    String? imageUrl,
    int? sortOrder,
    String? localImagePath,
  }) {
    return HomeBanner(
      id: id ?? this.id,
      title: title ?? this.title,
      link: link ?? this.link,
      imageUrl: imageUrl ?? this.imageUrl,
      sortOrder: sortOrder ?? this.sortOrder,
      localImagePath: localImagePath ?? this.localImagePath,
    );
  }

  factory HomeBanner.fromApi(Map<String, dynamic> data) {
    return HomeBanner(
      id: _parseInt(data['id']) ?? 0,
      title: (data['title'] ?? '').toString().trim(),
      link: (data['link'] ?? '').toString().trim(),
      imageUrl: (data['image'] ?? '').toString().trim(),
      sortOrder: _parseInt(data['sort_order']) ?? 0,
    );
  }

  factory HomeBanner.fromJson(Map<String, dynamic> data) {
    return HomeBanner(
      id: _parseInt(data['id']) ?? 0,
      title: (data['title'] ?? '').toString().trim(),
      link: (data['link'] ?? '').toString().trim(),
      imageUrl: (data['image_url'] ?? '').toString().trim(),
      sortOrder: _parseInt(data['sort_order']) ?? 0,
      localImagePath: (data['local_image_path'] ?? '').toString().trim(),
    );
  }

  Map<String, dynamic> toJson() {
    return <String, dynamic>{
      'id': id,
      'title': title,
      'link': link,
      'image_url': imageUrl,
      'sort_order': sortOrder,
      'local_image_path': localImagePath,
    };
  }
}

class BannerApiException implements Exception {
  const BannerApiException(this.message);

  final String message;

  @override
  String toString() => message;
}

class BannerApiService {
  BannerApiService({Dio? dio}) : _dio = dio ?? Dio();

  static const String _bannerCachePrefsKey = 'home_banners_cache_v1';

  final Dio _dio;

  Future<List<HomeBanner>> loadCachedBanners() async {
    final SharedPreferences prefs = await SharedPreferences.getInstance();
    final String? raw = prefs.getString(_bannerCachePrefsKey);
    if (raw == null || raw.trim().isEmpty) {
      return const <HomeBanner>[];
    }

    try {
      final dynamic decoded = jsonDecode(raw);
      if (decoded is! List) {
        return const <HomeBanner>[];
      }

      final List<HomeBanner> banners = <HomeBanner>[];
      for (final dynamic item in decoded) {
        if (item is! Map) {
          continue;
        }
        final HomeBanner banner = HomeBanner.fromJson(
          Map<String, dynamic>.from(item),
        );
        if (await _hasUsableFile(banner.localImagePath)) {
          banners.add(banner);
        }
      }

      if (banners.length != decoded.length) {
        await _writeCachedBanners(banners);
      }

      return banners;
    } catch (_) {
      return const <HomeBanner>[];
    }
  }

  Future<List<HomeBanner>> fetchAndCacheBanners() async {
    final List<HomeBanner> cached = await loadCachedBanners();
    final List<HomeBanner> remote = await _fetchRemoteBanners();

    if (remote.isEmpty) {
      return cached;
    }

    final Map<int, HomeBanner> cachedById = <int, HomeBanner>{
      for (final HomeBanner item in cached) item.id: item,
    };

    final List<HomeBanner> prepared = <HomeBanner>[];
    for (final HomeBanner banner in remote) {
      final HomeBanner? hydrated = await _hydrateBanner(
        banner,
        previous: cachedById[banner.id],
      );
      if (hydrated != null) {
        prepared.add(hydrated);
      }
    }

    if (prepared.isNotEmpty) {
      await _writeCachedBanners(prepared);
      return prepared;
    }

    return cached;
  }

  Future<List<HomeBanner>> _fetchRemoteBanners() async {
    Response<dynamic> response;
    try {
      response = await _dio.get<dynamic>(
        _bannersApiUrl,
        options: Options(
          sendTimeout: const Duration(seconds: 8),
          receiveTimeout: const Duration(seconds: 12),
          responseType: ResponseType.json,
        ),
      );
    } on DioException catch (error) {
      final int? status = error.response?.statusCode;
      throw BannerApiException(
        'Could not reach banners API (${status ?? 'network error'}).',
      );
    } catch (_) {
      throw const BannerApiException('Could not reach banners API.');
    }

    final dynamic normalized = _normalizePayload(response.data);
    final dynamic data = _extractWrappedData(normalized);
    if (data is! List) {
      throw const BannerApiException('Banners API returned invalid data.');
    }

    return data
        .whereType<Map>()
        .map(
          (Map item) => HomeBanner.fromApi(Map<String, dynamic>.from(item)),
        )
        .where((HomeBanner item) => item.id > 0 && item.imageUrl.isNotEmpty)
        .toList()
      ..sort(
        (HomeBanner a, HomeBanner b) => a.sortOrder.compareTo(b.sortOrder),
      );
  }

  dynamic _normalizePayload(dynamic data) {
    if (data is String) {
      final String text = data.trim();
      if (text.isEmpty) {
        return const <dynamic>[];
      }
      return jsonDecode(text);
    }
    return data;
  }

  dynamic _extractWrappedData(dynamic payload) {
    if (payload is! Map) {
      throw const BannerApiException('Banners API wrapper is invalid.');
    }

    final Map<String, dynamic> map = Map<String, dynamic>.from(payload);
    final dynamic status = map['status'];
    if (status is bool && !status) {
      throw BannerApiException(
        (map['message'] ?? 'Banners API returned an error.')
            .toString()
            .trim(),
      );
    }

    return map['data'];
  }

  Future<HomeBanner?> _hydrateBanner(
    HomeBanner banner, {
    HomeBanner? previous,
  }) async {
    if (previous != null &&
        previous.imageUrl == banner.imageUrl &&
        await _hasUsableFile(previous.localImagePath)) {
      return banner.copyWith(localImagePath: previous.localImagePath);
    }

    final File? file = await _downloadBannerFile(banner);
    if (file == null) {
      if (previous != null && await _hasUsableFile(previous.localImagePath)) {
        return banner.copyWith(localImagePath: previous.localImagePath);
      }
      return null;
    }

    return banner.copyWith(localImagePath: file.path);
  }

  Future<File?> _downloadBannerFile(HomeBanner banner) async {
    final Uri? uri = Uri.tryParse(banner.imageUrl);
    if (uri == null || uri.host.isEmpty) {
      return null;
    }

    final Directory directory = await _bannerDirectory();
    final String extension = _safeExtension(uri.path);
    final File file = File(
      path.join(directory.path, 'banner_${banner.id}$extension'),
    );

    try {
      await _dio.download(
        banner.imageUrl,
        file.path,
        deleteOnError: true,
        options: Options(
          sendTimeout: const Duration(seconds: 10),
          receiveTimeout: const Duration(seconds: 30),
        ),
      );
    } catch (_) {
      return null;
    }

    if (!file.existsSync() || await file.length() <= 0) {
      return null;
    }

    return file;
  }

  Future<Directory> _bannerDirectory() async {
    final Directory directory = await getApplicationDocumentsDirectory();
    return Directory(
      path.join(directory.path, 'runaki_home_banners'),
    ).create(recursive: true);
  }

  Future<void> _writeCachedBanners(List<HomeBanner> banners) async {
    final SharedPreferences prefs = await SharedPreferences.getInstance();
    await prefs.setString(
      _bannerCachePrefsKey,
      jsonEncode(
        banners.map((HomeBanner item) => item.toJson()).toList(),
      ),
    );
  }

  Future<bool> _hasUsableFile(String? filePath) async {
    final String pathValue = (filePath ?? '').trim();
    if (pathValue.isEmpty) {
      return false;
    }

    final File file = File(pathValue);
    return file.existsSync() && await file.length() > 0;
  }

  String _safeExtension(String value) {
    final String extension = path.extension(value).toLowerCase();
    switch (extension) {
      case '.png':
      case '.jpg':
      case '.jpeg':
      case '.webp':
        return extension;
      default:
        return '.jpg';
    }
  }
}

int? _parseInt(dynamic value) {
  if (value is int) return value;
  if (value is num) return value.toInt();
  if (value is String) return int.tryParse(value.trim());
  return null;
}
