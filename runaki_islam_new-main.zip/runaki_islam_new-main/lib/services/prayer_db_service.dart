import 'dart:async';
import 'dart:io';
import 'dart:math' as math;

import 'package:flutter/services.dart';
import 'package:path_provider/path_provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:sqflite/sqflite.dart';

class PrayerDbService {
  static const String _assetPath = 'assets/db/adhan/adthan_db.db';
  static const String _assetPathLegacy = 'assets\\db\\adhan\\adthan_db.db';
  static const String _dbFileName = 'adthan_db.db';
  static const String _dbSignatureFileName = 'adthan_db.asset.sig';
  static const String _locationSelectionModeKey =
      'prayer_location_selection_mode_v1';
  static const String _locationSelectionModeManual = 'manual';
  static const String _locationSelectionModeAuto = 'auto';

  Database? _db;
  Future<Database>? _opening;
  int _activeOperations = 0;
  Completer<void>? _idleCompleter;
  bool _closeRequested = false;

  Future<void> close() async {
    _closeRequested = true;
    if (_activeOperations > 0) {
      final idle = _idleCompleter ??= Completer<void>();
      await idle.future;
      return;
    }
    await _closeDatabase();
  }

  Future<PrayerLookupResult> loadForDate(DateTime day) async {
    return _withDatabase((db) async {
      final normalizedDay = _normalizeDay(day);
      final city = await _resolveCurrentCity(db);
      final today = await _readDayMoments(db, city: city, date: normalizedDay);
      final tomorrow = await _readDayMoments(
        db,
        city: city,
        date: normalizedDay.add(const Duration(days: 1)),
      );
      final yesterday = await _readDayMoments(
        db,
        city: city,
        date: normalizedDay.subtract(const Duration(days: 1)),
      );

      return PrayerLookupResult(
        city: city,
        today: today,
        tomorrow: tomorrow,
        yesterday: yesterday,
      );
    });
  }

  Future<PrayerCity> resolveCurrentCity() {
    return _withDatabase(_resolveCurrentCity);
  }

  Future<List<PrayerMoment>> loadMomentsForDate(
    DateTime day, {
    PrayerCity? city,
  }) async {
    return _withDatabase((db) async {
      final resolvedCity = await _ensureUsableCity(db, city);
      return _readDayMoments(db, city: resolvedCity, date: _normalizeDay(day));
    });
  }

  Future<List<PrayerDayMoments>> loadMonthMoments({
    required int month,
    required int year,
    PrayerCity? city,
  }) async {
    return _withDatabase((db) async {
      final resolvedCity = await _ensureUsableCity(db, city);
      final lastDay = DateTime(year, month + 1, 0).day;
      final result = <PrayerDayMoments>[];

      for (int day = 1; day <= lastDay; day++) {
        final date = DateTime(year, month, day);
        try {
          final moments = await _readDayMoments(
            db,
            city: resolvedCity,
            date: date,
          );
          result.add(PrayerDayMoments(date: date, moments: moments));
        } catch (_) {
          continue;
        }
      }

      return result;
    });
  }

  Future<List<PrayerCity>> loadIraqiCities() async {
    return _withDatabase((db) async {
      final rows = await db.query(
        'cities',
        columns: <String>[
          'id',
          'city',
          'base',
          'ckb',
          'ar',
          'country_code',
          'latitude',
          'longitude',
        ],
        where: 'iraq = 1 AND base IS NOT NULL',
        orderBy: 'sort ASC, id ASC',
      );

      final cities = <PrayerCity>[];
      for (final row in rows) {
        final normalized = await _normalizeCity(db, PrayerCity.fromRow(row));
        if (normalized != null) {
          cities.add(normalized);
        }
      }
      return cities;
    });
  }

  Future<PrayerCity?> findNearestCity({
    required double latitude,
    required double longitude,
  }) async {
    return _withDatabase((db) async {
      final rows = await db.query(
        'cities',
        columns: <String>[
          'id',
          'city',
          'base',
          'ckb',
          'ar',
          'country_code',
          'latitude',
          'longitude',
        ],
        where:
            'iraq = 1 AND base IS NOT NULL AND latitude IS NOT NULL AND longitude IS NOT NULL',
        orderBy: 'sort ASC, id ASC',
      );

      PrayerCity? nearest;
      double? nearestDistance;

      for (final row in rows) {
        final city = await _normalizeCity(db, PrayerCity.fromRow(row));
        if (city == null || city.latitude == null || city.longitude == null) {
          continue;
        }

        final distance = _distanceMeters(
          latitude,
          longitude,
          city.latitude!,
          city.longitude!,
        );

        if (nearestDistance == null || distance < nearestDistance) {
          nearestDistance = distance;
          nearest = city;
        }
      }

      return nearest;
    });
  }

  Future<void> saveSelectedCity(int cityId) async {
    await _withDatabase((db) => _saveConfigLocation(db, cityId));
  }

  Future<bool> shouldAutoResolveLocation() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString(_locationSelectionModeKey) !=
        _locationSelectionModeManual;
  }

  Future<void> markLocationSelectionManual() async {
    await _saveLocationSelectionMode(_locationSelectionModeManual);
  }

  Future<void> markLocationSelectionAutomatic() async {
    await _saveLocationSelectionMode(_locationSelectionModeAuto);
  }

  Future<void> _saveLocationSelectionMode(String mode) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_locationSelectionModeKey, mode);
  }

  Future<T> _withDatabase<T>(Future<T> Function(Database db) action) async {
    _activeOperations++;
    try {
      final db = await _open();
      return await action(db);
    } finally {
      _activeOperations--;
      if (_activeOperations == 0) {
        if (_closeRequested) {
          await _closeDatabase();
        }
        _idleCompleter?.complete();
        _idleCompleter = null;
      }
    }
  }

  Future<void> _closeDatabase() async {
    final db = _db;
    _db = null;
    _opening = null;
    _closeRequested = false;
    if (db != null && db.isOpen) {
      await db.close();
    }
  }

  Future<Database> _open() async {
    final cachedDb = _db;
    if (cachedDb != null) {
      if (cachedDb.isOpen) {
        return cachedDb;
      }
      _db = null;
    }
    return _opening ??= _openInternal();
  }

  Future<Database> _openSqliteDatabase(String path, {bool readOnly = false}) {
    // Avoid sqflite's shared-path singleton so one screen/service closing its
    // database cannot invalidate another PrayerDbService instance.
    return openDatabase(path, readOnly: readOnly, singleInstance: false);
  }

  Future<Database> _openInternal() async {
    Database? openedDb;

    final dir = await getApplicationDocumentsDirectory();
    final path = '${dir.path}${Platform.pathSeparator}$_dbFileName';
    final signaturePath =
        '${dir.path}${Platform.pathSeparator}$_dbSignatureFileName';
    final bundledBytes = await _loadBundledDatabaseBytes();

    await _syncBundledDatabaseIfNeeded(
      path: path,
      signaturePath: signaturePath,
      bundledBytes: bundledBytes,
    );

    try {
      openedDb = await _openSqliteDatabase(path);
      if (!await _hasUsablePrayerCityData(openedDb)) {
        final preservedLocationId = await _readLocationIdFromDatabase(openedDb);
        await openedDb.close();
        openedDb = null;
        await _replaceDatabaseWithBundledCopy(
          path: path,
          signaturePath: signaturePath,
          bundledBytes: bundledBytes,
          preserveLocationId: preservedLocationId,
        );
        openedDb = await _openSqliteDatabase(path);
      }
    } catch (_) {
      await openedDb?.close();
      openedDb = null;
      await _replaceDatabaseWithBundledCopy(
        path: path,
        signaturePath: signaturePath,
        bundledBytes: bundledBytes,
        preserveLocationId: await _readLocationIdFromDatabasePath(path),
      );
      openedDb = await _openSqliteDatabase(path);
    } finally {
      _opening = null;
    }

    _db = openedDb;
    return openedDb;
  }

  Future<ByteData> _loadBundledDatabase() async {
    try {
      return await rootBundle.load(_assetPath);
    } catch (_) {
      return rootBundle.load(_assetPathLegacy);
    }
  }

  Future<Uint8List> _loadBundledDatabaseBytes() async {
    final data = await _loadBundledDatabase();
    return data.buffer.asUint8List(data.offsetInBytes, data.lengthInBytes);
  }

  Future<void> _syncBundledDatabaseIfNeeded({
    required String path,
    required String signaturePath,
    required Uint8List bundledBytes,
  }) async {
    final file = File(path);
    if (!await file.exists()) {
      await _replaceDatabaseWithBundledCopy(
        path: path,
        signaturePath: signaturePath,
        bundledBytes: bundledBytes,
      );
      return;
    }

    final currentSignature = await _readDatabaseSignature(signaturePath);
    final bundledSignature = _buildDatabaseSignature(bundledBytes);
    if (currentSignature == bundledSignature) {
      return;
    }

    await _replaceDatabaseWithBundledCopy(
      path: path,
      signaturePath: signaturePath,
      bundledBytes: bundledBytes,
      preserveLocationId: await _readLocationIdFromDatabasePath(path),
    );
  }

  Future<void> _replaceDatabaseWithBundledCopy({
    required String path,
    required String signaturePath,
    required Uint8List bundledBytes,
    int? preserveLocationId,
  }) async {
    final file = File(path);
    if (await file.exists()) {
      await file.delete();
    }
    await file.writeAsBytes(bundledBytes, flush: true);

    final db = await _openSqliteDatabase(path);
    try {
      if (preserveLocationId != null) {
        await _saveConfigLocation(db, preserveLocationId);
      }
    } finally {
      await db.close();
    }

    await File(
      signaturePath,
    ).writeAsString(_buildDatabaseSignature(bundledBytes), flush: true);
  }

  Future<int?> _readLocationIdFromDatabasePath(String path) async {
    final file = File(path);
    if (!await file.exists()) return null;

    Database? db;
    try {
      db = await _openSqliteDatabase(path, readOnly: true);
      final config = await db.query(
        'config',
        columns: <String>['location'],
        where: 'id = ?',
        whereArgs: <Object>[1],
        limit: 1,
      );
      if (config.isEmpty) return null;
      return int.tryParse(config.first['location']?.toString() ?? '');
    } catch (_) {
      return null;
    } finally {
      await db?.close();
    }
  }

  Future<int?> _readLocationIdFromDatabase(Database db) async {
    try {
      final config = await db.query(
        'config',
        columns: <String>['location'],
        where: 'id = ?',
        whereArgs: <Object>[1],
        limit: 1,
      );
      if (config.isEmpty) return null;
      return int.tryParse(config.first['location']?.toString() ?? '');
    } catch (_) {
      return null;
    }
  }

  Future<String?> _readDatabaseSignature(String signaturePath) async {
    final file = File(signaturePath);
    if (!await file.exists()) return null;
    try {
      return (await file.readAsString()).trim();
    } catch (_) {
      return null;
    }
  }

  String _buildDatabaseSignature(Uint8List bytes) {
    const int offsetBasis = 0xcbf29ce484222325;
    const int prime = 0x100000001b3;
    const int mask = 0xFFFFFFFFFFFFFFFF;
    int hash = offsetBasis;
    for (final byte in bytes) {
      hash ^= byte;
      hash = (hash * prime) & mask;
    }
    return '${bytes.length}:${hash.toRadixString(16)}';
  }

  Future<bool> _hasUsablePrayerCityData(Database db) async {
    try {
      final rows = await db.rawQuery(
        'SELECT 1 FROM cities '
        'WHERE iraq = 1 AND base IS NOT NULL '
        'AND latitude IS NOT NULL AND longitude IS NOT NULL '
        'LIMIT 1',
      );
      return rows.isNotEmpty;
    } catch (_) {
      return false;
    }
  }

  Future<PrayerCity> _ensureUsableCity(Database db, PrayerCity? city) async {
    if (city == null) {
      return _resolveCurrentCity(db);
    }

    final normalized = await _normalizeCity(db, city);
    if (normalized != null) {
      return normalized;
    }

    final byId = await _cityById(db, city.id);
    if (byId != null) {
      return byId;
    }

    throw Exception('No prayer city found');
  }

  Future<PrayerCity> _resolveCurrentCity(Database db) async {
    int? locationId;
    final config = await db.query(
      'config',
      columns: <String>['location'],
      where: 'id = ?',
      whereArgs: <Object>[1],
      limit: 1,
    );
    if (config.isNotEmpty) {
      locationId = int.tryParse(config.first['location']?.toString() ?? '');
    }

    PrayerCity? city;
    if (locationId != null) {
      city = await _cityById(db, locationId);
    }

    city ??= await _fallbackCity(db);
    if (city == null) {
      throw Exception('No prayer city found');
    }

    if (locationId != city.id) {
      await _saveConfigLocation(db, city.id);
    }

    return city;
  }

  Future<void> _saveConfigLocation(Database db, int locationId) async {
    final value = locationId.toString();
    final updated = await db.update(
      'config',
      <String, Object?>{'location': value},
      where: 'id = ?',
      whereArgs: <Object>[1],
    );
    if (updated == 0) {
      await db.insert('config', <String, Object?>{'id': 1, 'location': value});
    }
  }

  Future<PrayerCity?> _cityById(Database db, int id) async {
    final rows = await db.query(
      'cities',
      columns: <String>[
        'id',
        'city',
        'base',
        'ckb',
        'ar',
        'country_code',
        'latitude',
        'longitude',
      ],
      where: 'id = ? AND base IS NOT NULL',
      whereArgs: <Object>[id],
      limit: 1,
    );
    if (rows.isEmpty) return null;
    return _normalizeCity(db, PrayerCity.fromRow(rows.first));
  }

  Future<PrayerCity?> _fallbackCity(Database db) async {
    final preferred = await db.query(
      'cities',
      columns: <String>[
        'id',
        'city',
        'base',
        'ckb',
        'ar',
        'country_code',
        'latitude',
        'longitude',
      ],
      where:
          'iraq = 1 AND base IS NOT NULL AND ('
          'ckb = ? OR lower(city) = lower(?) OR lower(base) = lower(?))',
      whereArgs: <Object>[
        '\u0633\u0644\u06CE\u0645\u0627\u0646\u06CC',
        'Sulaymaniyah',
        'Sulaymaniyah',
      ],
      limit: 1,
    );
    if (preferred.isNotEmpty) {
      final city = await _normalizeCity(
        db,
        PrayerCity.fromRow(preferred.first),
      );
      if (city != null) return city;
    }

    final rows = await db.query(
      'cities',
      columns: <String>[
        'id',
        'city',
        'base',
        'ckb',
        'ar',
        'country_code',
        'latitude',
        'longitude',
      ],
      where: 'iraq = 1 AND base IS NOT NULL',
      orderBy: 'sort ASC, id ASC',
      limit: 1,
    );
    if (rows.isEmpty) return null;
    return _normalizeCity(db, PrayerCity.fromRow(rows.first));
  }

  Future<PrayerCity?> _normalizeCity(Database db, PrayerCity city) async {
    final resolvedTable =
        await _resolveTableName(db, city.baseTable) ??
        await _resolveTableName(db, city.cityName);
    if (resolvedTable == null) {
      return null;
    }

    return city.copyWith(baseTable: resolvedTable);
  }

  Future<String?> _resolveTableName(Database db, String tableCandidate) async {
    final trimmed = tableCandidate.trim();
    if (trimmed.isEmpty) return null;

    final rows = await db.rawQuery(
      'SELECT name FROM sqlite_master WHERE type = ? AND lower(name) = lower(?) LIMIT 1',
      <Object>['table', trimmed],
    );
    if (rows.isEmpty) {
      return null;
    }
    return rows.first['name']?.toString();
  }

  Future<List<PrayerMoment>> _readDayMoments(
    Database db, {
    required PrayerCity city,
    required DateTime date,
  }) async {
    final safeTableName = _sanitizeTableName(city.baseTable);
    final month = date.month.toString();
    final day = date.day.toString();

    final rows = await db.rawQuery(
      'SELECT time FROM "$safeTableName" WHERE month = ? AND day = ? LIMIT 1',
      <Object>[month, day],
    );
    if (rows.isEmpty) {
      throw Exception('No prayer rows for day');
    }

    final rawTimes = rows.first['time']?.toString() ?? '';
    final parts = rawTimes.split('|').map((e) => e.trim()).toList();
    if (parts.length < 6) {
      throw Exception('Invalid prayer row');
    }

    const labels = <String>[
      '\u0628\u06D5\u06CC\u0627\u0646\u06CC',
      '\u062E\u06C6\u0631\u0647\u06D5\u06B5\u0627\u062A\u0646',
      '\u0646\u06CC\u0648\u06D5\u0695\u06C6',
      '\u0639\u06D5\u0633\u0631',
      '\u0645\u06D5\u063A\u0631\u0628',
      '\u0639\u06CC\u0634\u0627',
    ];

    final moments = <PrayerMoment>[];
    for (int i = 0; i < labels.length; i++) {
      final timeLabel = parts[i];
      final dateTime = _parseClock(date, timeLabel);
      moments.add(
        PrayerMoment(
          label: labels[i],
          timeLabel: timeLabel,
          dateTime: dateTime,
        ),
      );
    }
    return moments;
  }

  DateTime _parseClock(DateTime date, String hhmm) {
    final split = hhmm.split(':');
    if (split.length != 2) return date;
    final hour = int.tryParse(split[0]) ?? 0;
    final minute = int.tryParse(split[1]) ?? 0;
    return DateTime(date.year, date.month, date.day, hour, minute);
  }

  DateTime _normalizeDay(DateTime date) {
    return DateTime(date.year, date.month, date.day);
  }

  double _distanceMeters(
    double latitude1,
    double longitude1,
    double latitude2,
    double longitude2,
  ) {
    const earthRadius = 6371000.0;
    final dLat = _toRadians(latitude2 - latitude1);
    final dLon = _toRadians(longitude2 - longitude1);
    final a =
        math.sin(dLat / 2) * math.sin(dLat / 2) +
        math.cos(_toRadians(latitude1)) *
            math.cos(_toRadians(latitude2)) *
            math.sin(dLon / 2) *
            math.sin(dLon / 2);
    final c = 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a));
    return earthRadius * c;
  }

  double _toRadians(double value) => value * math.pi / 180.0;

  String _sanitizeTableName(String value) {
    final safe = RegExp(r'^[A-Za-z0-9_]+$').hasMatch(value);
    if (!safe) {
      throw Exception('Unsafe table name');
    }
    return value;
  }
}

class PrayerLookupResult {
  const PrayerLookupResult({
    required this.city,
    required this.today,
    required this.tomorrow,
    required this.yesterday,
  });

  final PrayerCity city;
  final List<PrayerMoment> today;
  final List<PrayerMoment> tomorrow;
  final List<PrayerMoment> yesterday;
}

class PrayerDayMoments {
  const PrayerDayMoments({required this.date, required this.moments});

  final DateTime date;
  final List<PrayerMoment> moments;

  PrayerMoment? momentAt(int index) {
    if (index < 0 || index >= moments.length) return null;
    return moments[index];
  }

  PrayerMoment? get fajr => momentAt(0);
  PrayerMoment? get maghrib => momentAt(4);
}

class PrayerCity {
  const PrayerCity({
    required this.id,
    required this.cityName,
    required this.baseTable,
    required this.displayName,
    required this.kurdishName,
    required this.arabicName,
    required this.searchText,
    required this.latitude,
    required this.longitude,
  });

  final int id;
  final String cityName;
  final String baseTable;
  final String displayName;
  final String kurdishName;
  final String arabicName;
  final String searchText;
  final double? latitude;
  final double? longitude;

  static String normalizeSearchValue(String value) {
    var normalized = value.trim().toLowerCase();
    if (normalized.isEmpty) return '';

    normalized = normalized
        .replaceAll(RegExp(r'[\u200c\u200f\u0640]'), '')
        .replaceAll(RegExp(r'[_\-\s]+'), '')
        .replaceAll('\u0629', '\u0647')
        .replaceAll('\u0649', '\u064a')
        .replaceAll('\u0626', '\u064a')
        .replaceAll('\u06d5', '\u0647')
        .replaceAll('\u06c1', '\u0647')
        .replaceAll('\u06ce', '\u064a')
        .replaceAll('\u06cc', '\u064a')
        .replaceAll('\u06c6', '\u0648')
        .replaceAll('\u0623', '\u0627')
        .replaceAll('\u0625', '\u0627')
        .replaceAll('\u0622', '\u0627');
    return normalized.replaceAll(
      RegExp(r'[\u064b-\u065f\u0670\u06d6-\u06ed]'),
      '',
    );
  }

  static String _buildSearchText(Iterable<String> values) {
    final tokens = <String>{};
    for (final value in values) {
      final trimmed = value.trim();
      if (trimmed.isEmpty) continue;
      final lowered = trimmed.toLowerCase();
      tokens.add(lowered);
      final normalized = normalizeSearchValue(trimmed);
      if (normalized.isNotEmpty) {
        tokens.add(normalized);
      }
    }
    return tokens.join(' ');
  }

  factory PrayerCity.fromRow(Map<String, Object?> row) {
    final cityName = (row['city']?.toString() ?? '').trim();
    final ckb = (row['ckb']?.toString() ?? '').trim();
    final ar = (row['ar']?.toString() ?? '').trim();
    final displayName = ckb.isNotEmpty ? ckb : (ar.isNotEmpty ? ar : cityName);
    final searchable = _buildSearchText(<String>[
      displayName,
      cityName,
      ar,
      ckb,
    ]);

    return PrayerCity(
      id: int.tryParse(row['id']?.toString() ?? '') ?? 0,
      cityName: cityName,
      baseTable: (row['base']?.toString() ?? cityName).trim(),
      displayName: displayName,
      kurdishName: ckb,
      arabicName: ar,
      searchText: searchable,
      latitude: _toNullableDouble(row['latitude']),
      longitude: _toNullableDouble(row['longitude']),
    );
  }

  PrayerCity copyWith({String? baseTable}) {
    return PrayerCity(
      id: id,
      cityName: cityName,
      baseTable: baseTable ?? this.baseTable,
      displayName: displayName,
      kurdishName: kurdishName,
      arabicName: arabicName,
      searchText: searchText,
      latitude: latitude,
      longitude: longitude,
    );
  }

  String get manualPickerSubtitle {
    final values = <String>{
      if (kurdishName.isNotEmpty && kurdishName != displayName) kurdishName,
      if (arabicName.isNotEmpty && arabicName != displayName) arabicName,
      if (cityName.isNotEmpty && cityName != displayName) cityName,
    };
    return values.join(' • ');
  }

  static double? _toNullableDouble(Object? value) {
    if (value == null) return null;
    if (value is num) return value.toDouble();
    return double.tryParse(value.toString());
  }

  // ignore: unused_element
  static Iterable<String> _searchTokens(String value) sync* {
    final trimmed = value.trim();
    if (trimmed.isEmpty) return;
    final lowered = trimmed.toLowerCase();
    yield lowered;

    final normalized = lowered
        .replaceAll(RegExp(r'[_\-\s]+'), '')
        .replaceAll('ة', 'ه')
        .replaceAll('ى', 'ي')
        .replaceAll('أ', 'ا')
        .replaceAll('إ', 'ا')
        .replaceAll('آ', 'ا');
    if (normalized != lowered) {
      yield normalized;
    }
  }
}

class PrayerMoment {
  const PrayerMoment({
    required this.label,
    required this.timeLabel,
    required this.dateTime,
  });

  final String label;
  final String timeLabel;
  final DateTime dateTime;
}
