import 'package:runaki_islam/models/book_model.dart';
import 'package:runaki_islam/services/book_api_service.dart';

class BookRepository {
  BookRepository({BookApiService? apiService})
    : _apiService = apiService ?? BookApiService();

  final BookApiService _apiService;

  Future<List<Book>> fetchBooks() {
    return _apiService.fetchBooks();
  }
}
