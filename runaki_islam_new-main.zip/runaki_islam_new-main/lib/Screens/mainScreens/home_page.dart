import 'dart:async';

import 'package:flutter/material.dart';
import 'package:page_transition/page_transition.dart';
import 'package:runaki_islam/Screens/DrawerScreens/AboutApp/about_app.dart';
import 'package:runaki_islam/Screens/DrawerScreens/FeedBack/feed_back_page.dart';
import 'package:runaki_islam/Screens/HomeItems/Qurani%20Piroz/quran_page.dart';
import 'package:runaki_islam/Screens/mainScreens/all_items.dart';
import 'package:runaki_islam/Screens/mainScreens/widget/home_widget.dart';
import 'package:runaki_islam/Screens/mainScreens/widget/prayer_times_screen.dart';
import 'package:runaki_islam/Screens/mainScreens/widget/profile_screen.dart';
import 'package:runaki_islam/bottom_navigation_view/bottom_bar_view.dart';
import 'package:runaki_islam/bottom_navigation_view/tab_icon_data.dart';
import 'package:runaki_islam/services/app_review_service.dart';
import 'package:runaki_islam/util/animation_helper.dart';
import 'package:runaki_islam/util/constans.dart';
import 'package:runaki_islam/util/navigate_between_pages/size_route.dart';
import 'package:runaki_islam/widgets/premium_drawer.dart';

class Homepage extends StatefulWidget {
  const Homepage({super.key});

  @override
  State<Homepage> createState() => _HomepageState();
}

class _HomepageState extends State<Homepage> {
  final List<TabIconData> tabIconsList = TabIconData.tabIconsList;
  final List<bool> _visitedTabs = List<bool>.filled(4, false);

  int _selectedTab = 0;
  ProfileSection _profileSection = ProfileSection.about;

  @override
  void initState() {
    super.initState();
    for (final TabIconData tab in tabIconsList) {
      tab.isSelected = false;
    }
    tabIconsList[0].isSelected = true;
    _visitedTabs[0] = true;
    WidgetsBinding.instance.addPostFrameCallback((_) {
      unawaited(AppReviewService.maybePromptForReview(context));
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bgColor,
      endDrawer: PremiumIslamicDrawer(
        name: "ئەمین صمد حمد",
        subtitle: "ڕووناکی ئیسلام",
        avatar: const AssetImage('assets/images/my-picture.jpg'),
        items: [
          DrawerActionItem(
            title: "سەرەکی",
            icon: Icons.home_outlined,
            onTap: () => _switchTabFromDrawer(0),
          ),
          DrawerActionItem(
            title: "قورئانی پیرۆز",
            icon: Icons.menu_book_rounded,
            onTap: () => _switchTabFromDrawer(1),
          ),
          DrawerActionItem(
            title: "کاتەکانی بانگ",
            icon: Icons.access_time_rounded,
            onTap: () => _switchTabFromDrawer(2),
          ),
          DrawerActionItem(
            title: "هەموو بەشەکان",
            icon: Icons.grid_view_rounded,
            onTap: () => _openDrawerRoute(
              () => Navigator.push(
                context,
                PageTransition(
                  child: const AllItemsList(),
                  duration: AppMotion.page,
                  type: PageTransitionType.topToBottom,
                ),
              ),
            ),
          ),
          DrawerActionItem(
            title: "ڕێکخستنەکان",
            icon: Icons.settings_outlined,
            onTap: () => _switchTabFromDrawer(
              3,
              profileSection: ProfileSection.settings,
            ),
          ),
          DrawerActionItem(
            title: "دەربارەی من",
            icon: Icons.person_outline_rounded,
            onTap: () =>
                _switchTabFromDrawer(3, profileSection: ProfileSection.about),
          ),
          DrawerActionItem(
            title: "دەربارەی بەرنامە",
            icon: Icons.info_outline_rounded,
            onTap: () => _openDrawerRoute(
              () => Navigator.push(
                context,
                SizeRoute(
                  page: const AboutApp(sarder: "دەربارەی بەرنامە"),
                ),
              ),
            ),
          ),
        ],
        footer: _buildDrawerFeedbackAction(),
      ),
      body: Stack(
        children: <Widget>[
          Positioned.fill(child: _buildTabStack()),
          bottomBar(),
        ],
      ),
    );
  }

  Widget _buildTabStack() {
    return IndexedStack(
      index: _selectedTab,
      children: <Widget>[
        _buildTabSlot(0),
        _buildTabSlot(1),
        _buildTabSlot(2),
        _buildTabSlot(3),
      ],
    );
  }

  Widget _buildTabSlot(int index) {
    if (!_visitedTabs[index]) {
      return const SizedBox.shrink();
    }

    switch (index) {
      case 0:
        return const HomeWidget();
      case 1:
        return const QuranPage(isTabMode: true);
      case 2:
        return TickerMode(
          enabled: _selectedTab == 2,
          child: PrayerTimesScreen(active: _selectedTab == 2),
        );
      case 3:
        return ProfileScreen(initialSection: _profileSection);
      default:
        return const SizedBox.shrink();
    }
  }

  void _updateTab(int index, {ProfileSection? profileSection}) {
    if (!mounted) return;
    setState(() {
      _selectedTab = index;
      _visitedTabs[index] = true;
      for (int i = 0; i < tabIconsList.length; i++) {
        tabIconsList[i].isSelected = i == index;
      }

      if (index == 3 && profileSection != null) {
        _profileSection = profileSection;
      }
    });
  }

  void _switchTabFromDrawer(int index, {ProfileSection? profileSection}) {
    Navigator.of(context).pop();
    _updateTab(index, profileSection: profileSection);
  }

  void _openDrawerRoute(VoidCallback action) {
    Navigator.of(context).pop();
    Future<void>.delayed(const Duration(milliseconds: 220), action);
  }

  Widget bottomBar() {
    return Column(
      children: <Widget>[
        const Expanded(child: SizedBox()),
        BottomBarView(
          key: ValueKey<int>(_selectedTab),
          tabIconsList: tabIconsList,
          addClick: () {},
          changeIndex: (int index) {
            _updateTab(index);
          },
        ),
      ],
    );
  }

  Widget _buildDrawerFeedbackAction() {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        borderRadius: BorderRadius.circular(18),
        onTap: () => _openDrawerRoute(
          () => Navigator.push(
            context,
            SizeRoute(page: const FeedBack(sarder: "ڕەخنە و پێشنیار")),
          ),
        ),
        child: Ink(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 12),
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topRight,
              end: Alignment.bottomLeft,
              colors: [
                kActiveIconColor.withValues(alpha: 0.96),
                (Color.lerp(kActiveIconColor, secondColor, 0.36) ??
                        kActiveIconColor)
                    .withValues(alpha: 0.96),
              ],
            ),
            borderRadius: BorderRadius.circular(18),
            boxShadow: [
              BoxShadow(
                color: kActiveIconColor.withValues(alpha: 0.20),
                blurRadius: 18,
                offset: const Offset(0, 8),
              ),
            ],
          ),
          child: Row(
            children: [
              Container(
                width: 42,
                height: 42,
                decoration: BoxDecoration(
                  color: Colors.white.withValues(alpha: 0.16),
                  borderRadius: BorderRadius.circular(14),
                  border: Border.all(
                    color: Colors.white.withValues(alpha: 0.18),
                  ),
                ),
                child: const Icon(
                  Icons.feedback_outlined,
                  color: Colors.white,
                  size: 20,
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      "ڕەخنە و پێشنیار",
                      textAlign: TextAlign.right,
                      style: TextStyle(
                        fontFamily: '0',
                        color: Colors.white,
                        fontSize: 15,
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                    const SizedBox(height: 3),
                    Text(
                      "بۆ باشترکردنی بەرنامە، پەیامت لێرە بنێرە",
                      textAlign: TextAlign.right,
                      style: TextStyle(
                        fontFamily: '0',
                        color: Colors.white.withValues(alpha: 0.88),
                        fontSize: 12.2,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 10),
              Container(
                width: 32,
                height: 32,
                decoration: BoxDecoration(
                  color: Colors.white.withValues(alpha: 0.16),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: const Icon(
                  Icons.chevron_right_rounded,
                  color: Colors.white,
                  size: 18,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
