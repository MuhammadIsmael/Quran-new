import 'package:flutter/material.dart';

import '../../util/constans.dart';

class LoadingPage extends StatelessWidget {
  const LoadingPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bgColor,
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(140),
          child: CircularProgressIndicator(
            valueColor: AlwaysStoppedAnimation<Color>(kActiveIconColor),
            strokeWidth: 3,
          ),
        ),
      ),
    );
  }
}
