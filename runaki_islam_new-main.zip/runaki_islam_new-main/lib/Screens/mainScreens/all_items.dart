import 'package:background_app_bar/background_app_bar.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:get/route_manager.dart';
import 'package:runaki_islam/Screens/HomeItems/AyatKursi/ayat_kursi.dart';
import 'package:runaki_islam/Screens/HomeItems/Books/book_page.dart';
import 'package:runaki_islam/Screens/HomeItems/Cherok/cherok_page.dart';
import 'package:runaki_islam/Screens/HomeItems/Dua/dua_list.dart';
import 'package:runaki_islam/Screens/HomeItems/Farmuda/farmuda_page.dart';
import 'package:runaki_islam/Screens/HomeItems/Haramkrawakan/haramkrawan.dart';
import 'package:runaki_islam/Screens/HomeItems/HawalanePexambar/hawalane_pexambar_page.dart';
import 'package:runaki_islam/Screens/HomeItems/HijriCalendar/hijri_calendar_page.dart';
import 'package:runaki_islam/Screens/HomeItems/Kafaratakan/kafaratakan.dart';
import 'package:runaki_islam/Screens/HomeItems/MangeRamazan/mange_ramazan_page.dart';
import 'package:runaki_islam/Screens/HomeItems/NeshanakaneRozheDway/neshanakane_rozhe_dway.dart';
import 'package:runaki_islam/Screens/HomeItems/Nwezhkrdn/nwezh_page.dart';
import 'package:runaki_islam/Screens/HomeItems/PayakaneEmanIslam/payakane_eman_islam.dart';
import 'package:runaki_islam/Screens/HomeItems/PrsyarWakamAyne/prsyar_walam_ayne.dart';
import 'package:runaki_islam/Screens/HomeItems/PrsyarWalamRozheDway/prsyar_walam_rozhe_dway.dart';
import 'package:runaki_islam/Screens/HomeItems/PuxtaySaheheMuslim/puxtay_sahehe_muslim.dart';
import 'package:runaki_islam/Screens/HomeItems/QiblaFinder/qibla_finder_page.dart';
import 'package:runaki_islam/Screens/HomeItems/Qurani%20Piroz/quran_page.dart';
import 'package:runaki_islam/Screens/HomeItems/Sunatakan/sunatakan.dart';
import 'package:runaki_islam/Screens/HomeItems/Taqekrdnawa/welcome/welcome_screen.dart';
import 'package:runaki_islam/Screens/HomeItems/Tasbeeh/check_database.dart';
import 'package:runaki_islam/Screens/HomeItems/TawanaGawrakan/tawana_gawrakan_page.dart';
import 'package:runaki_islam/Screens/HomeItems/WtawAmozhgary/wtaw_amozhgare.dart';
import 'package:runaki_islam/Screens/HomeItems/ZakatCalculator/zakat_calculator_page.dart';

import 'package:runaki_islam/Screens/HomeItems/Zekrakan/zekrakan.dart';
import 'package:runaki_islam/Screens/HomeItems/ZhyanNamayPexambaran/zh_pexambaran.dart';
import 'package:runaki_islam/Screens/HomeItems/nawakany_xuday_gawra/allah_names.dart';
import 'package:runaki_islam/util/background.dart';
import 'package:runaki_islam/util/constans.dart';
import 'package:runaki_islam/util/item_list.dart';
import 'package:runaki_islam/util/navigate_between_pages/fade_route.dart';
import 'package:runaki_islam/util/navigate_between_pages/scale_route.dart';
import 'package:runaki_islam/util/navigate_between_pages/size_route.dart';
import 'package:page_transition/page_transition.dart';
import 'package:runaki_islam/Screens/HomeItems/Pexambarman/zhyan_namay_pexambarman.dart';
import 'package:runaki_islam/Screens/HomeItems/Bahasht_Dozax/bahasht_u_dozax_page.dart';
import 'package:runaki_islam/Screens/HomeItems/ZanyareQuran/zanyare_quran_page.dart';
import 'package:runaki_islam/providers/settings_provider.dart';
import 'package:provider/provider.dart';

const appBarSize = 250.0;

class AllItemsList extends StatefulWidget {
  const AllItemsList({super.key, this.title, this.counter});
  final String? title;
  final int? counter;
  @override
  State<StatefulWidget> createState() => _AllItemsListState();
}

class _AllItemsListState extends State<AllItemsList> {
  final List<AllModel> _listview = [];
  var pressed = true;

  int? fontType;

  @override
  void initState() {
    super.initState();

    fontType = Provider.of<SettingsProvider>(
      context,
      listen: false,
    ).getsettingField('font_family');

    _listview.add(
      AllModel(
        title: "قورئانی پیرۆز",
        image: "assets/icons/quran-icon.svg",
        color: const Color(0xff17d39f),
        onPress: () {
          Navigator.push(context, SizeRoute(page: const QuranPage()));
        },
      ),
    );
    _listview.add(
      AllModel(
        title: "زیکرەکان",
        image: "assets/icons/zikr.svg",
        color: const Color(0xff3aa8de),
        onPress: () {
          Navigator.push(
            context,
            PageTransition(
              child: const ZekrakanPage(),
              type: PageTransitionType.rightToLeft,
            ),
          );
        },
      ),
    );
    _listview.add(
      AllModel(
        title: "تەسبیح",
        image: "assets/icons/tasbih.svg",
        color: const Color(0xffebba53),
        onPress: () {
          Navigator.push(context, FadeRoute(page: const CheckDatabase()));
        },
      ),
    );
    _listview.add(
      AllModel(
        title: "فەرموودە",
        isImage: true,
        image: "assets/icons/hadith.png",
        color: const Color(0xFFB99AE7),
        onPress: () {
          Navigator.push(
            context,
            PageTransition(
              child: const FarmudaPage(),
              type: PageTransitionType.rightToLeft,
            ),
          );
        },
      ),
    );
    _listview.add(
      AllModel(
        title: "چیرۆک",
        image: "assets/icons/cherok.svg",
        color: const Color(0xFFBDDA92),
        onPress: () {
          Navigator.push(context, SizeRoute(page: const CherokPage()));
        },
      ),
    );
    _listview.add(
      AllModel(
        title: "کتێب",
        image: "assets/icons/books.svg",
        color: const Color(0xff3aa8de),
        onPress: () {
          Navigator.push(context, ScaleRoute(page: const BookPage()));
        },
      ),
    );
    _listview.add(
      AllModel(
        title: "نوێژ",
        image: "assets/icons/praying.svg",
        color: const Color(0xFF91D4C1),
        onPress: () {
          Navigator.push(context, SizeRoute(page: const NwezhPage()));
        },
      ),
    );
    _listview.add(
      AllModel(
        title: "ژمێریاری زەکات",
        image: "assets/icons/islam.svg",
        color: const Color(0xFF77BFA1),
        onPress: () {
          Navigator.push(context, SizeRoute(page: const ZakatCalculatorPage()));
        },
      ),
    );
    _listview.add(
      AllModel(
        title: "قیبلە نواندەر",
        image: "assets/icons/prayer-time.svg",
        color: const Color(0xFF6AA58F),
        onPress: () {
          Navigator.push(context, SizeRoute(page: const QiblaFinderPage()));
        },
      ),
    );
    _listview.add(
      AllModel(
        title: "ناوەکانی خودای گەورە",
        image: "assets/icons/allah-word.svg",
        color: const Color(0xFFE9A2B7),
        onPress: () {
          Navigator.push(
            context,
            SizeRoute(page: const AllahNames(sarder: "ناوەکانی خودای گەورە")),
          );
        },
      ),
    );
    _listview.add(
      AllModel(
        title: "پرسیار و وەڵامی ئاینی",
        image: "assets/icons/prsyar.svg",
        color: const Color(0xFFffc288),
        onPress: () {
          Navigator.push(context, ScaleRoute(page: const PrsyarWalamAyne()));
        },
      ),
    );
    // _listview.add(AllModel(
    //   title: "قیبلە",
    //   image: "assets/icons/qibla.svg",
    //   color :const  Color(0xFF609C4D),
    //   onPress: () {
    //     Navigator.push(context, SizeRoute(page: const  FirstLoading()));
    //   },
    // ));
    _listview.add(
      AllModel(
        title: "ئایەتی کورسی",
        image: "assets/icons/icon-png.png",
        color: const Color(0xFF9dbeb9),
        isImage: true,
        onPress: () {
          Navigator.push(
            context,
            PageTransition(
              child: const AyatKursi(sarder: "ئایەتی کورسی"),
              type: PageTransitionType.bottomToTop,
            ),
          );
        },
      ),
    );
    _listview.add(
      AllModel(
        title: "دوعایەکان",
        image: "assets/icons/dua.svg",
        color: const Color(0xFFa4ebf3),
        onPress: () {
          Navigator.push(context, SizeRoute(page: const DuakanPage()));
        },
      ),
    );
    _listview.add(
      AllModel(
        title: "تاقیکردنەوە",
        image: "assets/icons/prsyar.svg",
        color: const Color(0xFF8fd9a8),
        onPress: () {
          Get.to(const WelcomeScreen());
        },
      ),
    );
    _listview.add(
      AllModel(
        title: "ژیاننامەی پێغەمبەر ﷺ",
        isImage: true,
        image: "assets/icons/prophet-name.png",
        color: const Color(0xFF9f5f80),
        onPress: () {
          Navigator.push(
            context,
            SizeRoute(
              page: const ZhyanNamayPexambarman(sarder: "ﷺژیاننامەی پێغەمبەر"),
            ),
          );
        },
      ),
    );
    // _listview.add(AllModel(
    //   title: "خەونامە",
    //   image: "assets/icons/dream.svg",
    //   color: const Color(0xFFB3B2F1),
    //   onPress: () {
    //     Navigator.push(
    //         context, SizeRoute(page: const XawNama(sarder: "خەونامە")));
    //   },
    // ));
    _listview.add(
      AllModel(
        title: "ژیاننامەی پێغەمبەران",
        image: "assets/icons/icon-png.png",
        isImage: true,
        color: const Color(0xFFF8A8A8),
        onPress: () {
          Navigator.push(
            context,
            PageTransition(
              child: const ZyanNamayPexambaran(sarder: "ژیاننامەی پێغەمبەران"),
              type: PageTransitionType.bottomToTop,
            ),
          );
        },
      ),
    );
    _listview.add(
      AllModel(
        title: "تاوانە گەورەکان",
        image: "assets/icons/tawanakan.svg",
        color: const Color(0xFFA8F8B3),
        onPress: () {
          Navigator.push(
            context,
            SizeRoute(page: const TawanaGawrakan(sarder: "تاوانە گەورەکان")),
          );
        },
      ),
    );
    _listview.add(
      AllModel(
        title: "هاوەڵانی پێغەمبەر ﷺ",
        image: "assets/icons/hawal.svg",
        color: const Color(0xff3aa8de),
        onPress: () {
          Navigator.push(
            context,
            ScaleRoute(page: const Hawalakan(sarder: "ﷺهاوەڵانی پێغەمبەر")),
          );
        },
      ),
    );
    _listview.add(
      AllModel(
        title: "بەهەشت و دۆزەخ",
        image: "assets/icons/islam.svg",
        color: const Color(0xFFffc288),
        onPress: () {
          Navigator.push(
            context,
            SizeRoute(page: const BahashtDozaxPage(sarder: "بەهەشت و دۆزەخ")),
          );
        },
      ),
    );
    _listview.add(
      AllModel(
        title: "مانگی ڕەمەزان",
        image: "assets/icons/ramazan.svg",
        color: const Color(0xFF9A88FF),
        onPress: () {
          Navigator.push(
            context,
            SizeRoute(page: const MangeRamazanPage(sarder: "مانگی ڕەمەزان")),
          );
        },
      ),
    );

    _listview.add(
      AllModel(
        title: "زانیاری قورئان",
        image: "assets/icons/zanyare-quran.svg",
        color: const Color(0xFF91D4C1),
        onPress: () {
          Navigator.push(
            context,
            SizeRoute(page: const ZanyareQuranPage(sarder: "زانیاری قورئان")),
          );
        },
      ),
    );
    _listview.add(
      AllModel(
        title: "ڕۆژژمێری هیجری",
        image: "assets/icons/calendar.svg",
        color: const Color(0xFFA6D398),
        onPress: () {
          Navigator.push(
            context,
            ScaleRoute(page: const HijriCalendarPage(sarder: "ڕۆژژمێری هیجری")),
          );
        },
      ),
    );

    _listview.add(
      AllModel(
        title: "نیشانەکانی ڕۆژی دوایی",
        image: "assets/icons/tawanakan.svg",
        color: const Color(0xFFF8A8A8),
        onPress: () {
          Navigator.push(
            context,
            SizeRoute(
              page: const NeshanakaneRozheDwayScreen(
                sarder: "نیشانەکانی ڕۆژی دوایی",
              ),
            ),
          );
        },
      ),
    );
    _listview.add(
      AllModel(
        title: "وتە و ئامۆژگاری",
        image: "assets/icons/qoute.svg",
        color: const Color(0xFFB691D4),
        onPress: () {
          Navigator.push(
            context,
            SizeRoute(page: const WtawAmozhgare(sarder: "وتە و ئامۆژگاری")),
          );
        },
      ),
    );
    _listview.add(
      AllModel(
        title: "سوونەتەکان",
        image: "assets/icons/sunnah.svg",
        color: const Color(0xFFC5D491),
        onPress: () {
          Navigator.push(
            context,
            SizeRoute(page: const SunatakanPage(sarder: "سوونەتەکان")),
          );
        },
      ),
    );
    _listview.add(
      AllModel(
        title: "کەفارەتەکان",
        image: "assets/icons/tawanakan.svg",
        color: const Color(0xFFD4B991),
        onPress: () {
          Navigator.push(
            context,
            ScaleRoute(page: const Kafaratakan(sarder: "کەفارەتەکان")),
          );
        },
      ),
    );
    _listview.add(
      AllModel(
        title: "حەڕامکراوەکان",
        image: "assets/icons/haram.svg",
        color: const Color(0xFF919DD4),
        onPress: () {
          Navigator.push(
            context,
            ScaleRoute(page: const Haramkrawakan(sarder: "حەڕامکراوەکان")),
          );
        },
      ),
    );

    _listview.add(
      AllModel(
        title: "پایەکانی ئیمان  ئیسلام",
        image: "assets/icons/tajwed.svg",
        color: const Color(0xFFACD491),
        onPress: () {
          Navigator.push(
            context,
            ScaleRoute(
              page: const PayakaneEmanuIskam(sarder: "پایەکانی ئیمان  ئیسلام"),
            ),
          );
        },
      ),
    );
    _listview.add(
      AllModel(
        title: "پوختەی سەحیحی موسلیم",
        image: "assets/icons/hadith.png",
        isImage: true,
        color: const Color(0xFFD49191),
        onPress: () {
          Navigator.push(
            context,
            ScaleRoute(
              page: const PuxtaySaheheMuslim(sarder: "پوختەی سەحیحی موسلیم"),
            ),
          );
        },
      ),
    );
    _listview.add(
      AllModel(
        title: "پرسیار و وەڵامەکانی دواڕۆژ",
        image: "assets/icons/prsyar.svg",
        color: const Color(0xFF91D4C5),
        onPress: () {
          Navigator.push(
            context,
            ScaleRoute(
              page: const RozheQyamat(sarder: "پرسیار و وەڵامەکانی دواڕۆژ"),
            ),
          );
        },
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bgColor,
      body: NestedScrollView(
        physics: const BouncingScrollPhysics(),
        headerSliverBuilder: (context, innerBoxIsScrolled) => <Widget>[
          SliverAppBar(
            shape: const RoundedRectangleBorder(
              borderRadius: BorderRadius.vertical(bottom: Radius.circular(20)),
            ),
            leading: IconButton(
              icon: Icon(Icons.arrow_back_ios_rounded, color: iconColor),
              onPressed: () {
                Navigator.pop(context);
              },
            ),
            actions: [
              IconButton(
                icon: Icon(
                  pressed ? Icons.grid_view : Icons.menu,
                  color: iconColor,
                ),
                onPressed: () {
                  setState(() {
                    pressed = !pressed;
                  });
                },
              ),
            ],
            expandedHeight: appBarSize,
            floating: false,
            pinned: true,
            snap: false,
            elevation: 0.0,
            backgroundColor: Colors.transparent,
            flexibleSpace: BackgroundFlexibleSpaceBar(
              collapseMode: CollapseMode.parallax,
              centerTitle: true,
              title: Text(
                "هەموو  بەشەکان",
                style: bigTextStyle.copyWith(
                  color: Colors.white,
                  fontFamily: fontType.toString(),
                ),
              ),
              titlePadding: const EdgeInsets.all(50),
              background: ClipRect(
                child: Container(
                  decoration: const BoxDecoration(
                    image: DecorationImage(
                      image: AssetImage("assets/images/read-quran.jpg"),
                      fit: BoxFit.fill,
                    ),
                  ),
                  child: Container(
                    decoration: BoxDecoration(
                      color: thirdColor.withValues(alpha: 0.56),
                    ),
                  ),
                ),
              ),
            ),
          ),
        ],
        body: Stack(
          children: [
            const Background(),
            pressed
                ? ListView.builder(
                    padding: const EdgeInsets.only(bottom: 60),
                    physics: const BouncingScrollPhysics(
                      parent: AlwaysScrollableScrollPhysics(),
                    ),
                    cacheExtent: 900,
                    scrollDirection: Axis.vertical,
                    itemCount: _listview.length,
                    itemBuilder: (context, i) {
                      final a = _listview[i];
                      return ItemCard(
                        title: a.title,
                        color: a.color,
                        image: a.image,
                        isImage: a.isImage,
                        onPress: a.onPress,
                      );
                    },
                  )
                : GridView.builder(
                    itemCount: _listview.length,
                    physics: const BouncingScrollPhysics(
                      parent: AlwaysScrollableScrollPhysics(),
                    ),
                    cacheExtent: 900,
                    gridDelegate:
                        const SliverGridDelegateWithFixedCrossAxisCount(
                          crossAxisCount: 2,
                        ),
                    itemBuilder: (BuildContext context, i) {
                      final a = _listview[i];
                      return gridCard(
                        a.title,
                        a.image,
                        a.color,
                        a.onPress,
                        a.isImage,
                      );
                    },
                  ),
          ],
        ),
      ),
    );
  }

  Widget gridCard(
    String? title,
    String? image,
    Color? color,
    VoidCallback? onPress, [
    bool isImage = false,
  ]) {
    return Padding(
      padding: const EdgeInsets.only(left: 12, right: 12, bottom: 12),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(13),
        child: Container(
          width: double.infinity,
          // padding:const EdgeInsets.all(20),
          decoration: BoxDecoration(
            color: backgroundColor,
            borderRadius: BorderRadius.circular(13),
            boxShadow: [
              BoxShadow(
                offset: const Offset(0, 17),
                blurRadius: 17,
                spreadRadius: -23,
                color: kShadowColor,
              ),
            ],
          ),
          child: Material(
            color: Colors.transparent,
            child: InkWell(
              onTap: onPress!,
              child: Padding(
                padding: const EdgeInsets.only(left: 8, right: 8),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: <Widget>[
                    Container(
                      height: 60,
                      padding: const EdgeInsets.all(10),
                      margin: const EdgeInsets.only(
                        left: 10,
                        top: 6,
                        bottom: 6,
                      ),
                      width: 60,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(10),
                        color: color,
                      ),
                      child: isImage
                          ? Image.asset(image!, color: Colors.white)
                          : SvgPicture.asset(
                              image!,
                              colorFilter: const ColorFilter.mode(
                                Colors.white,
                                BlendMode.srcIn,
                              ),
                            ),
                    ),
                    const SizedBox(),
                    Text(
                      title!,
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        fontFamily: fontType.toString(),
                        fontSize: 18,
                        color: kTextColor.withValues(alpha: 0.5),
                      ),
                    ),
                    const SizedBox(),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  //Dark Mode
}

class AllModel {
  final String? title;
  final String? image;
  final Color? color;
  final VoidCallback? onPress;
  final bool isImage;

  AllModel({
    this.title,
    this.isImage = false,
    this.color,
    this.image,
    this.onPress,
  });
}
