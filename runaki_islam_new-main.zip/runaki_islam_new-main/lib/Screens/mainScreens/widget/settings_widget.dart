import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:runaki_islam/Screens/DrawerScreens/AboutApp/about_app.dart';
import 'package:runaki_islam/Screens/DrawerScreens/FeedBack/feed_back_page.dart';
import 'package:runaki_islam/providers/settings_provider.dart';
import 'package:runaki_islam/providers/theme_provider.dart';
import 'package:runaki_islam/util/animation_helper.dart';
import 'package:runaki_islam/util/constans.dart';
import 'package:runaki_islam/util/navigate_between_pages/size_route.dart';
import 'package:runaki_islam/util/quran_font_registry.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  int? fontType;
  double? fontSize;
  double? speedFactor;
  int? quranFontType;
  double? quranFontSize;

  final List<FontListItems> _fontListItems = const [
    FontListItems('فۆنتی ڕابەر', '0', 1),
    FontListItems('کەناڵی کوردستان 24', '1', 2),
    FontListItems('کەناڵی نێت تیڤی', '2', 3),
    FontListItems('کەناڵی ئێن ئار تی', '3', 4),
    FontListItems('کەناڵی ڕوداو', '4', 5),
    FontListItems('کەناڵی سپێدە', '5', 6),
    FontListItems('فۆنتی سیروان', '6', 7),
    FontListItems('یونیسروان نوور', '7', 8),
    FontListItems('یونیسروان ئێس تی سی', '8', 9),
    FontListItems('یونیسروان یوو ئار یوو', '9', 10),
    FontListItems('فۆنتی ماڵپەڕی خەندان', '10', 11),
    FontListItems('فۆنتی کەناڵی ئامۆژگاری', '11', 12),
    FontListItems('فۆنتی یونی قەیدەر', '12', 13),
  ];

  final List<FontListItems> _fontQuranListItems = kQuranFontOptions
      .map(
        (option) => FontListItems(
          option.label,
          option.family,
          option.order,
          preview: option.preview,
        ),
      )
      .toList(growable: false);

  @override
  void initState() {
    super.initState();
    final settings = Provider.of<SettingsProvider>(context, listen: false);
    fontSize = settings.getsettingField('font_size');
    speedFactor = settings.getsettingField('speed_factor');
    fontType = settings.getsettingField('font_family');
    quranFontType = normalizeQuranFontFamily(
      settings.getsettingField('quran_font_family'),
    );
    quranFontSize = settings.getsettingField('quran_font_size');
  }

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final settingsProvider = Provider.of<SettingsProvider>(
      context,
      listen: false,
    );

    return DecoratedBox(
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [
            scheme.surface,
            scheme.surfaceContainerHighest.withValues(
              alpha: isDark ? 0.38 : 0.22,
            ),
            bgColor,
          ],
        ),
      ),
      child: SingleChildScrollView(
        physics: const BouncingScrollPhysics(
          parent: AlwaysScrollableScrollPhysics(),
        ),
        child: SafeArea(
          bottom: false,
          child: Column(
            children: [
              const SizedBox(height: 12),
              FadeSlideIn(
                child: _settingsCard(
                  child: Column(
                    children: [
                      Container(
                        width: 106,
                        height: 106,
                        padding: const EdgeInsets.all(4),
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          border: Border.all(
                            color: kActiveIconColor.withValues(alpha: 0.35),
                            width: 2,
                          ),
                        ),
                        child: ClipRRect(
                          borderRadius: BorderRadius.circular(80),
                          child: Image.asset('assets/icons/icon-main.png'),
                        ),
                      ),
                      const SizedBox(height: 12),
                      Text(
                        "ڕووناکی ئیسلام",
                        style: TextStyle(
                          fontFamily: fontType.toString(),
                          color: kTextColor,
                          fontSize: 24,
                          fontWeight: FontWeight.w800,
                        ),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        "23/8/2020 دروستکرا لە",
                        style: TextStyle(
                          fontFamily: fontType.toString(),
                          color: titleTextColor,
                          fontSize: 13.5,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 12),
              FadeSlideIn(
                delay: const Duration(milliseconds: 50),
                child: _settingsCard(
                  child: Directionality(
                    textDirection: TextDirection.rtl,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        _sectionHeader("دۆخی تاریکی", Icons.dark_mode_outlined),
                        const SizedBox(height: 10),
                        Consumer<ThemeNotifier>(
                          builder: (context, notifier, child) {
                            return _toggleTile(
                              title: "گۆڕینی دۆخی بەرنامە بۆ تاریک و ڕووناک",
                              value: notifier.darkMode,
                              onChanged: (_) => notifier.toggleChangeTheme(),
                            );
                          },
                        ),
                      ],
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 12),
              FadeSlideIn(
                delay: const Duration(milliseconds: 80),
                child: _settingsCard(
                  child: Directionality(
                    textDirection: TextDirection.rtl,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        _sectionHeader(
                          "قەبارەی نووسین",
                          Icons.format_size_rounded,
                          trailing: _valueBadge("${fontSize?.toInt() ?? 18}"),
                        ),
                        const SizedBox(height: 6),
                        _themedSlider(
                          divisions: 26,
                          label: "${fontSize?.toInt() ?? 18}",
                          value: fontSize ?? 18,
                          onChanged: (value) {
                            setState(() {
                              fontSize = value;
                            });
                          },
                          onChangeEnd: (value) {
                            settingsProvider.updateSettings('font_size', value);
                          },
                          min: 14,
                          max: 40,
                        ),
                      ],
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 12),
              FadeSlideIn(
                delay: const Duration(milliseconds: 110),
                child: _fontExpansionCard(
                  title: "شێوازی فۆنت",
                  icon: Icons.text_fields_rounded,
                  currentValue: fontType.toString(),
                  items: _fontListItems,
                  onSelect: (item) async {
                    setState(() {
                      fontType = int.parse(item.value!);
                    });
                    await settingsProvider.updateSettings(
                      'font_family',
                      fontType,
                    );
                  },
                ),
              ),
              const SizedBox(height: 12),
              FadeSlideIn(
                delay: const Duration(milliseconds: 140),
                child: _settingsCard(
                  child: Directionality(
                    textDirection: TextDirection.rtl,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        _sectionHeader(
                          "قەبارەی نووسینی قورئان",
                          Icons.auto_stories_outlined,
                          trailing: _valueBadge(
                            "${(quranFontSize ?? 22).toInt()}",
                          ),
                        ),
                        const SizedBox(height: 6),
                        _themedSlider(
                          divisions: 46,
                          label: "${(quranFontSize ?? 22).toInt()}",
                          value: quranFontSize ?? 22,
                          onChanged: (value) {
                            setState(() {
                              quranFontSize = value;
                            });
                          },
                          onChangeEnd: (value) {
                            settingsProvider.updateSettings(
                              'quran_font_size',
                              value,
                            );
                          },
                          min: 14,
                          max: 60,
                        ),
                      ],
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 12),
              FadeSlideIn(
                delay: const Duration(milliseconds: 170),
                child: _fontExpansionCard(
                  title: "شێوازی فۆنتی قورئان",
                  icon: Icons.translate_rounded,
                  currentValue: quranFontType.toString(),
                  items: _fontQuranListItems,
                  onSelect: (item) async {
                    setState(() {
                      quranFontType = normalizeQuranFontFamily(item.value);
                    });
                    await settingsProvider.updateSettings(
                      'quran_font_family',
                      quranFontType,
                    );
                  },
                ),
              ),
              const SizedBox(height: 12),
              FadeSlideIn(
                delay: const Duration(milliseconds: 200),
                child: _settingsCard(
                  child: Directionality(
                    textDirection: TextDirection.rtl,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        _sectionHeader(
                          "خێرایی چوونەخوارەی قورئان",
                          Icons.speed_rounded,
                        ),
                        const SizedBox(height: 10),
                        Wrap(
                          spacing: 8,
                          runSpacing: 8,
                          children: [
                            _speedChip(
                              label: "زۆر خاو",
                              value: 2,
                              current: speedFactor ?? 10,
                              onTap: () => _setSpeed(settingsProvider, 2),
                            ),
                            _speedChip(
                              label: "خاو",
                              value: 5,
                              current: speedFactor ?? 10,
                              onTap: () => _setSpeed(settingsProvider, 5),
                            ),
                            _speedChip(
                              label: "ئاسایی",
                              value: 10,
                              current: speedFactor ?? 10,
                              onTap: () => _setSpeed(settingsProvider, 10),
                            ),
                            _speedChip(
                              label: "خێرا",
                              value: 20,
                              current: speedFactor ?? 10,
                              onTap: () => _setSpeed(settingsProvider, 20),
                            ),
                            _speedChip(
                              label: "زۆر خێرا",
                              value: 50,
                              current: speedFactor ?? 10,
                              onTap: () => _setSpeed(settingsProvider, 50),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 12),
              FadeSlideIn(
                delay: const Duration(milliseconds: 230),
                child: _settingsCard(
                  child: Directionality(
                    textDirection: TextDirection.rtl,
                    child: Column(
                      children: [
                        _navigationTile(
                          title: "دەربارەی بەرنامە",
                          icon: Icons.info_outline_rounded,
                          onTap: () => Navigator.push(
                            context,
                            SizeRoute(
                              page: const AboutApp(sarder: "دەربارەی بەرنامە"),
                            ),
                          ),
                        ),
                        const SizedBox(height: 8),
                        _navigationTile(
                          title: "ڕەخنە و پێشنیار",
                          icon: Icons.rate_review_outlined,
                          onTap: () => Navigator.push(
                            context,
                            SizeRoute(
                              page: const FeedBack(sarder: "ڕەخنە و پێشنیار"),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 120),
            ],
          ),
        ),
      ),
    );
  }

  void _setSpeed(SettingsProvider provider, double value) {
    setState(() => speedFactor = value);
    provider.updateSettings('speed_factor', value);
  }

  Widget _settingsCard({required Widget child}) {
    final scheme = Theme.of(context).colorScheme;
    final isDark = Theme.of(context).brightness == Brightness.dark;
    return Container(
      width: double.infinity,
      margin: const EdgeInsets.symmetric(horizontal: 14),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: scheme.surface.withValues(alpha: isDark ? 0.78 : 0.92),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(
          color: scheme.outline.withValues(alpha: isDark ? 0.30 : 0.16),
        ),
        boxShadow: [
          BoxShadow(
            color: scheme.shadow.withValues(alpha: isDark ? 0.42 : 0.10),
            blurRadius: 20,
            offset: Offset(0, 8),
          ),
        ],
      ),
      child: child,
    );
  }

  Widget _sectionHeader(String title, IconData icon, {Widget? trailing}) {
    final scheme = Theme.of(context).colorScheme;
    return Row(
      children: [
        if (trailing != null) ...[trailing, const SizedBox(width: 10)],
        Expanded(
          child: Text(
            title,
            textAlign: TextAlign.right,
            style: TextStyle(
              fontFamily: fontType.toString(),
              color: scheme.onSurface,
              fontWeight: FontWeight.w800,
              fontSize: 16.5,
            ),
          ),
        ),
        const SizedBox(width: 10),
        Container(
          width: 36,
          height: 36,
          decoration: BoxDecoration(
            color: kActiveIconColor.withValues(alpha: 0.12),
            borderRadius: BorderRadius.circular(11),
          ),
          child: Icon(icon, color: kActiveIconColor, size: 20),
        ),
      ],
    );
  }

  Widget _valueBadge(String value) {
    final scheme = Theme.of(context).colorScheme;
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
      decoration: BoxDecoration(
        color: scheme.primary.withValues(alpha: 0.10),
        borderRadius: BorderRadius.circular(10),
      ),
      child: Text(
        value,
        style: TextStyle(
          fontFamily: 'english',
          color: scheme.primary,
          fontWeight: FontWeight.w700,
        ),
      ),
    );
  }

  Widget _themedSlider({
    required double value,
    required double min,
    required double max,
    required int divisions,
    required String label,
    required ValueChanged<double> onChanged,
    required ValueChanged<double> onChangeEnd,
  }) {
    return SliderTheme(
      data: Theme.of(context).sliderTheme.copyWith(
        trackHeight: 4.5,
        thumbShape: const RoundSliderThumbShape(enabledThumbRadius: 8),
        overlayShape: const RoundSliderOverlayShape(overlayRadius: 16),
      ),
      child: Slider(
        divisions: divisions,
        label: label,
        value: value,
        activeColor: kActiveIconColor,
        onChanged: onChanged,
        onChangeEnd: onChangeEnd,
        min: min,
        max: max,
      ),
    );
  }

  Widget _toggleTile({
    required String title,
    required bool value,
    required ValueChanged<bool> onChanged,
  }) {
    final scheme = Theme.of(context).colorScheme;
    final isDark = Theme.of(context).brightness == Brightness.dark;
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
      decoration: BoxDecoration(
        color: scheme.surfaceContainerHighest.withValues(
          alpha: isDark ? 0.5 : 0.36,
        ),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: scheme.outline.withValues(alpha: isDark ? 0.32 : 0.18),
        ),
      ),
      child: Row(
        children: [
          Transform.scale(
            scale: 0.93,
            child: Switch(
              value: value,
              onChanged: onChanged,
              activeThumbColor: Colors.white,
              activeTrackColor: kActiveIconColor,
              inactiveThumbColor: scheme.onSurfaceVariant,
              inactiveTrackColor: scheme.outline.withValues(alpha: 0.35),
            ),
          ),
          const SizedBox(width: 8),
          Container(
            width: 34,
            height: 34,
            decoration: BoxDecoration(
              color: kActiveIconColor.withValues(alpha: 0.12),
              borderRadius: BorderRadius.circular(10),
            ),
            child: Icon(
              value ? Icons.dark_mode_rounded : Icons.light_mode_rounded,
              color: kActiveIconColor,
              size: 18,
            ),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Text(
              title,
              textAlign: TextAlign.right,
              style: TextStyle(
                fontFamily: fontType.toString(),
                color: scheme.onSurface,
                fontSize: 14.2,
                fontWeight: FontWeight.w600,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _fontExpansionCard({
    required String title,
    required IconData icon,
    required String currentValue,
    required List<FontListItems> items,
    required Future<void> Function(FontListItems item) onSelect,
  }) {
    return _settingsCard(
      child: Theme(
        data: Theme.of(context).copyWith(dividerColor: Colors.transparent),
        child: ExpansionTile(
          tilePadding: EdgeInsets.zero,
          childrenPadding: const EdgeInsets.only(top: 8),
          title: _sectionHeader(title, icon),
          iconColor: kActiveIconColor,
          collapsedIconColor: kActiveIconColor,
          children: items.map((item) {
            final selected = item.value == currentValue;
            final scheme = Theme.of(context).colorScheme;
            final isDark = Theme.of(context).brightness == Brightness.dark;
            return Container(
              margin: const EdgeInsets.only(bottom: 8),
              decoration: BoxDecoration(
                color: selected
                    ? kActiveIconColor.withValues(alpha: 0.90)
                    : scheme.surfaceContainerHighest.withValues(
                        alpha: isDark ? 0.45 : 0.35,
                      ),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(
                  color: selected
                      ? Colors.transparent
                      : scheme.outline.withValues(alpha: isDark ? 0.32 : 0.18),
                ),
              ),
              child: ListTile(
                onTap: () => onSelect(item),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
                leading: Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 8,
                    vertical: 4,
                  ),
                  decoration: BoxDecoration(
                    color: selected
                        ? Colors.white.withValues(alpha: 0.25)
                        : kActiveIconColor.withValues(alpha: 0.12),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Text(
                    item.id.toString(),
                    style: TextStyle(
                      fontFamily: 'english',
                      color: selected ? Colors.white : kActiveIconColor,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                ),
                title: Text(
                  item.title!,
                  textAlign: TextAlign.right,
                  style: TextStyle(
                    fontFamily: item.preview == null
                        ? item.value
                        : fontType.toString(),
                    color: selected ? Colors.white : scheme.onSurface,
                    fontWeight: FontWeight.w600,
                  ),
                ),
                subtitle: item.preview == null
                    ? null
                    : Text(
                        item.preview!,
                        textAlign: TextAlign.right,
                        textDirection: TextDirection.rtl,
                        style: TextStyle(
                          fontFamily: item.value,
                          color: selected
                              ? Colors.white.withValues(alpha: 0.94)
                              : scheme.onSurfaceVariant,
                          fontSize: 20,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                trailing: selected
                    ? const Icon(
                        Icons.check_circle_rounded,
                        color: Colors.white,
                      )
                    : const SizedBox.shrink(),
              ),
            );
          }).toList(),
        ),
      ),
    );
  }

  Widget _speedChip({
    required String label,
    required double value,
    required double current,
    required VoidCallback onTap,
  }) {
    final selected = current == value;
    final scheme = Theme.of(context).colorScheme;
    final isDark = Theme.of(context).brightness == Brightness.dark;
    return AnimatedContainer(
      duration: AppMotion.fast,
      curve: AppMotion.curve,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(11),
        boxShadow: selected
            ? [
                BoxShadow(
                  color: kActiveIconColor.withValues(alpha: 0.22),
                  blurRadius: 12,
                  offset: const Offset(0, 5),
                ),
              ]
            : const [],
      ),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          borderRadius: BorderRadius.circular(11),
          onTap: onTap,
          child: Ink(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 9),
            decoration: BoxDecoration(
              color: selected
                  ? kActiveIconColor
                  : scheme.surfaceContainerHighest.withValues(
                      alpha: isDark ? 0.50 : 0.35,
                    ),
              borderRadius: BorderRadius.circular(11),
              border: Border.all(
                color: selected
                    ? Colors.transparent
                    : scheme.outline.withValues(alpha: isDark ? 0.30 : 0.18),
              ),
            ),
            child: Text(
              label,
              style: TextStyle(
                fontFamily: fontType.toString(),
                fontWeight: FontWeight.w700,
                color: selected ? Colors.white : scheme.onSurfaceVariant,
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _navigationTile({
    required String title,
    required IconData icon,
    required VoidCallback onTap,
  }) {
    final scheme = Theme.of(context).colorScheme;
    final isDark = Theme.of(context).brightness == Brightness.dark;
    return Material(
      color: Colors.transparent,
      child: InkWell(
        borderRadius: BorderRadius.circular(12),
        onTap: onTap,
        child: Ink(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 12),
          decoration: BoxDecoration(
            color: scheme.surfaceContainerHighest.withValues(
              alpha: isDark ? 0.48 : 0.36,
            ),
            borderRadius: BorderRadius.circular(12),
            border: Border.all(
              color: scheme.outline.withValues(alpha: isDark ? 0.30 : 0.18),
            ),
          ),
          child: Row(
            children: [
              CircleAvatar(
                radius: 16,
                backgroundColor: kActiveIconColor.withValues(alpha: 0.12),
                child: Icon(icon, size: 16, color: kActiveIconColor),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Text(
                  title,
                  textAlign: TextAlign.right,
                  style: TextStyle(
                    fontFamily: fontType.toString(),
                    color: scheme.onSurface,
                    fontWeight: FontWeight.w700,
                    fontSize: 14.5,
                  ),
                ),
              ),
              const SizedBox(width: 8),
              Icon(
                Icons.arrow_forward_ios_rounded,
                size: 14,
                color: scheme.onSurfaceVariant,
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class FontListItems {
  final String? title;
  final String? value;
  final int? id;
  final String? preview;

  const FontListItems(this.title, this.value, this.id, {this.preview});
}
