import 'package:flutter/material.dart';
import 'package:runaki_islam/Screens/mainScreens/widget/about_me_widget.dart';
import 'package:runaki_islam/Screens/mainScreens/widget/settings_widget.dart';
import 'package:runaki_islam/util/animation_helper.dart';

enum ProfileSection { about, settings }

class ProfileScreen extends StatefulWidget {
  const ProfileScreen({super.key, this.initialSection = ProfileSection.about});

  final ProfileSection initialSection;

  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  late ProfileSection _section;

  @override
  void initState() {
    super.initState();
    _section = widget.initialSection;
  }

  @override
  void didUpdateWidget(covariant ProfileScreen oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.initialSection != widget.initialSection) {
      _section = widget.initialSection;
    }
  }

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return Column(
      children: [
        SafeArea(
          bottom: false,
          child: Padding(
            padding: const EdgeInsets.fromLTRB(14, 8, 14, 6),
            child: Container(
              height: 52,
              padding: const EdgeInsets.all(4),
              decoration: BoxDecoration(
                color: scheme.surface.withValues(alpha: 0.92),
                borderRadius: BorderRadius.circular(16),
                border: Border.all(
                  color: scheme.outline.withValues(alpha: 0.2),
                ),
              ),
              child: Row(
                children: [
                  Expanded(
                    child: _sectionButton(
                      label: 'پرۆفایل',
                      selected: _section == ProfileSection.about,
                      onTap: () {
                        setState(() => _section = ProfileSection.about);
                      },
                    ),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: _sectionButton(
                      label: 'ڕێکخستن',
                      selected: _section == ProfileSection.settings,
                      onTap: () {
                        setState(() => _section = ProfileSection.settings);
                      },
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
        Expanded(
          child: MediaQuery.removePadding(
            context: context,
            removeTop: true,
            child: AnimatedSwitcher(
              duration: AppMotion.fast,
              switchInCurve: AppMotion.curve,
              switchOutCurve: AppMotion.curve,
              child: KeyedSubtree(
                key: ValueKey<ProfileSection>(_section),
                child: _section == ProfileSection.about
                    ? const AboutMe()
                    : const SettingsScreen(),
              ),
            ),
          ),
        ),
      ],
    );
  }

  Widget _sectionButton({
    required String label,
    required bool selected,
    required VoidCallback onTap,
  }) {
    final scheme = Theme.of(context).colorScheme;
    return Material(
      color: Colors.transparent,
      child: InkWell(
        borderRadius: BorderRadius.circular(12),
        onTap: onTap,
        child: AnimatedContainer(
          duration: AppMotion.fast,
          curve: AppMotion.curve,
          decoration: BoxDecoration(
            color: selected
                ? scheme.primary.withValues(alpha: 0.16)
                : Colors.transparent,
            borderRadius: BorderRadius.circular(12),
          ),
          alignment: Alignment.center,
          child: Text(
            label,
            style: TextStyle(
              color: selected ? scheme.primary : scheme.onSurfaceVariant,
              fontWeight: selected ? FontWeight.w700 : FontWeight.w600,
              fontSize: 13.8,
            ),
          ),
        ),
      ),
    );
  }
}
