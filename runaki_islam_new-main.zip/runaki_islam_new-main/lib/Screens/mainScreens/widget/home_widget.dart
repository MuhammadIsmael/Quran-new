import 'dart:async';
import 'dart:io';

import 'package:carousel_slider/carousel_slider.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:geolocator/geolocator.dart';
import 'package:page_transition/page_transition.dart';
import 'package:provider/provider.dart';
import 'package:runaki_islam/Screens/HomeItems/Books/book_page.dart';
import 'package:runaki_islam/Screens/HomeItems/Cherok/cherok_page.dart';
import 'package:runaki_islam/Screens/HomeItems/Farmuda/farmuda_page.dart';
import 'package:runaki_islam/Screens/HomeItems/IslamicAI/islamic_ai_assistant_page.dart';
import 'package:runaki_islam/Screens/HomeItems/MangeRamazan/mange_ramazan_page.dart';
import 'package:runaki_islam/Screens/HomeItems/MangeRamazan/ramadan_tools_pages.dart';
import 'package:runaki_islam/Screens/HomeItems/Nwezhkrdn/nwezh_page.dart';
import 'package:runaki_islam/Screens/HomeItems/PayakaneEmanIslam/ArkakaneIslam/pages/haj.dart';
import 'package:runaki_islam/Screens/HomeItems/QiblaFinder/qibla_finder_page.dart';
import 'package:runaki_islam/Screens/HomeItems/Qurani%20Piroz/quran_page.dart';
import 'package:runaki_islam/Screens/HomeItems/ZakatCalculator/zakat_calculator_page.dart';
import 'package:runaki_islam/Screens/HomeItems/Tasbeeh/check_database.dart';
import 'package:runaki_islam/Screens/HomeItems/Zekrakan/zekrakan.dart';
import 'package:runaki_islam/Screens/HomeItems/nawakany_xuday_gawra/allah_names.dart';
import 'package:runaki_islam/Screens/mainScreens/all_items.dart';
import 'package:runaki_islam/providers/settings_provider.dart';
import 'package:runaki_islam/services/banner_api_service.dart';
import 'package:runaki_islam/util/animation_helper.dart';
import 'package:runaki_islam/util/constans.dart';
import 'package:runaki_islam/util/navigate_between_pages/fade_route.dart';
import 'package:runaki_islam/util/navigate_between_pages/scale_route.dart';
import 'package:runaki_islam/util/navigate_between_pages/size_route.dart';
import 'package:runaki_islam/widgets/carousel_slider_widget.dart';
import 'package:runaki_islam/widgets/general_search_delegate.dart';
import 'package:url_launcher/url_launcher.dart';

class HomeWidget extends StatefulWidget {
  const HomeWidget({super.key});

  @override
  State<HomeWidget> createState() => _HomeWidgetState();
}

class _HomeWidgetState extends State<HomeWidget> {
  int? fontType;
  final BannerApiService _bannerService = BannerApiService();

  final List<Widget> _sliderList = [
    MyContainer(
      title: "تەواوی قورئانی پیرۆز",
      desc: "114/114",
      img: Image.asset("assets/images/quran.png", height: 100),
    ),
    MyContainer(
      title: " ژیاننامەی پێغەمبەر ﷺ",
      desc: "ژیاننامەی پێغەمبەر و موعجیزەکانی ",
      img: Padding(
        padding: const EdgeInsets.only(left: 20),
        child: SvgPicture.asset(
          "assets/icons/tajwed.svg",
          height: 70,
          width: 70,
          colorFilter: const ColorFilter.mode(Colors.white, BlendMode.srcIn),
        ),
      ),
    ),
    MyContainer(
      title: "خەونامە",
      desc: "زیاد لە 2000 وشە",
      img: Padding(
        padding: const EdgeInsets.only(left: 20),
        child: SvgPicture.asset(
          "assets/icons/dream.svg",
          height: 70,
          width: 70,
          colorFilter: const ColorFilter.mode(Colors.white, BlendMode.srcIn),
        ),
      ),
    ),
    MyContainer(
      title: "مانگی ڕەمەزان",
      desc: "تەواوی زانیاریەکانی مانگی ڕەمەزان",
      img: Padding(
        padding: const EdgeInsets.only(left: 20),
        child: SvgPicture.asset(
          "assets/icons/ramazan.svg",
          height: 70,
          width: 70,
          colorFilter: const ColorFilter.mode(Colors.white, BlendMode.srcIn),
        ),
      ),
    ),
  ];

  List<HomeBanner> _networkBanners = <HomeBanner>[];
  bool _isBannerSyncing = false;
  int currentIndex = 0;

  @override
  void initState() {
    super.initState();
    fontType = Provider.of<SettingsProvider>(
      context,
      listen: false,
    ).getsettingField('font_family');
    unawaited(_loadHomeBanners());
  }

  Future<void> _openMosqueSearch() async {
    await _launchMapSearch('mosque');
  }

  Future<void> _openNearbyMosque() async {
    try {
      final serviceEnabled = await Geolocator.isLocationServiceEnabled();
      if (!serviceEnabled) {
        _showHomeSnack('تکایە GPS چالاک بکە، پاشان دووبارە هەوڵ بدە.');
        return;
      }

      var permission = await Geolocator.checkPermission();
      if (permission == LocationPermission.denied) {
        permission = await Geolocator.requestPermission();
      }

      if (permission == LocationPermission.denied) {
        _showHomeSnack('ڕێگەی دەستپێگەیشتن بە شوێن نەدرا. تکایە ڕێگە بدە.');
        return;
      }

      if (permission == LocationPermission.deniedForever) {
        _showHomeSnack(
          'ڕێگەی شوێن هەمیشە بڵۆک کراوە. تکایە لە Settings چالاکی بکە.',
        );
        return;
      }

      final position = await Geolocator.getCurrentPosition(
        desiredAccuracy: LocationAccuracy.high,
        timeLimit: const Duration(seconds: 14),
      );
      await _launchMapSearch(
        'mosque near ${position.latitude},${position.longitude}',
      );
    } catch (_) {
      _showHomeSnack('نەتوانرا شوێنی ئێستا بدۆزرێتەوە.');
    }
  }

  Future<void> _openMosqueMap() async {
    await _launchMapSearch('mosque map');
  }

  Future<void> _openRamadanTimetable() async {
    await Navigator.push(
      context,
      SizeRoute(page: const RamadanTimetablePage()),
    );
  }

  Future<void> _openKhatmPlan() async {
    await Navigator.push(context, SizeRoute(page: const KhatmPlanPage()));
  }

  Future<void> _openDailyHadith() async {
    await Navigator.push(context, SizeRoute(page: const DailyHadithPage()));
  }

  Future<void> _openLaylatQadrGuide() async {
    await Navigator.push(
      context,
      SizeRoute(page: const MangeRamazanPage(sarder: "مانگی ڕەمەزان")),
    );
  }

  Future<void> _openHajjUmrahGuide() async {
    await Navigator.push(
      context,
      SizeRoute(page: const Hakjkrdn(sarder: "حەج و عوومرە")),
    );
  }

  Future<void> _launchMapSearch(String query) async {
    final uri = Uri.https('www.google.com', '/maps/search/', {
      'api': '1',
      'query': query,
    });
    final launched = await launchUrl(uri, mode: LaunchMode.externalApplication);
    if (!launched) {
      _showHomeSnack('نەتوانرا نەخشە بکرێتەوە. تکایە دواتر هەوڵ بدە.');
    }
  }

  void _showHomeSnack(String message) {
    if (!mounted) return;
    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(
        SnackBar(
          behavior: SnackBarBehavior.floating,
          duration: const Duration(seconds: 2),
          content: Text(
            message,
            textDirection: TextDirection.rtl,
            style: TextStyle(fontFamily: fontType.toString()),
          ),
        ),
      );
  }

  void _openAiAssistantScreen() {
    Navigator.push(context, SizeRoute(page: const IslamicAiAssistantPage()));
  }

  Widget _buildAiFab() {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        borderRadius: BorderRadius.circular(99),
        onTap: _openAiAssistantScreen,
        child: Ink(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
          decoration: BoxDecoration(
            gradient: const LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: [Color(0xFFEAF8F2), Color(0xFFD9F0E7)],
            ),
            borderRadius: BorderRadius.circular(99),
            border: Border.all(color: const Color(0x4D17A377)),
            boxShadow: const [
              BoxShadow(
                color: Color(0x2117A377),
                blurRadius: 18,
                offset: Offset(0, 8),
              ),
            ],
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Icon(
                Icons.smart_toy_rounded,
                color: Color(0xFF0E7A5B),
                size: 22,
              ),
              const SizedBox(width: 8),
              Text(
                'یارمەتی AI',
                style: TextStyle(
                  fontFamily: fontType.toString(),
                  color: const Color(0xFF0E7054),
                  fontWeight: FontWeight.w800,
                  fontSize: 13.2,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildMosqueSection() {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 14),
      padding: const EdgeInsets.fromLTRB(10, 10, 10, 8),
      decoration: BoxDecoration(
        color: Colors.white.withValues(alpha: 0.92),
        borderRadius: BorderRadius.circular(22),
        border: Border.all(color: const Color(0x1FB9893C)),
        boxShadow: const [
          BoxShadow(
            color: Color(0x12000000),
            blurRadius: 18,
            offset: Offset(0, 8),
          ),
        ],
      ),
      child: Directionality(
        textDirection: TextDirection.rtl,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(6, 4, 6, 10),
              child: Text(
                'گەڕان بۆ مزگەوتەکان',
                textAlign: TextAlign.right,
                style: TextStyle(
                  fontFamily: fontType.toString(),
                  color: const Color(0xFF2D2419),
                  fontWeight: FontWeight.w800,
                  fontSize: 18,
                ),
              ),
            ),
            _MosqueActionTile(
              title: 'گەڕان بۆ مزگەوتەکان',
              icon: Icons.mosque_rounded,
              color: const Color(0xFF15A775),
              fontType: fontType,
              onTap: _openMosqueSearch,
            ),
            const SizedBox(height: 8),
            _MosqueActionTile(
              title: 'مزگەوتی نزیک',
              icon: Icons.location_on_rounded,
              color: const Color(0xFF2F8FCC),
              fontType: fontType,
              onTap: _openNearbyMosque,
            ),
            const SizedBox(height: 8),
            _MosqueActionTile(
              title: 'نەخشەی مزگەوت',
              icon: Icons.map_rounded,
              color: const Color(0xFFB9893C),
              fontType: fontType,
              onTap: _openMosqueMap,
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildRamadanSeasonSection() {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 14),
      padding: const EdgeInsets.fromLTRB(10, 10, 10, 8),
      decoration: BoxDecoration(
        color: Colors.white.withValues(alpha: 0.92),
        borderRadius: BorderRadius.circular(22),
        border: Border.all(color: const Color(0x1FA884B7)),
        boxShadow: const [
          BoxShadow(
            color: Color(0x12000000),
            blurRadius: 18,
            offset: Offset(0, 8),
          ),
        ],
      ),
      child: Directionality(
        textDirection: TextDirection.rtl,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(6, 4, 6, 10),
              child: Text(
                'بەشەکانی مانگی ڕەمەزان',
                textAlign: TextAlign.right,
                style: TextStyle(
                  fontFamily: fontType.toString(),
                  color: const Color(0xFF2D2419),
                  fontWeight: FontWeight.w800,
                  fontSize: 18,
                ),
              ),
            ),
            _MosqueActionTile(
              title: 'کاتی ئیفطار/سحوور',
              icon: Icons.schedule_rounded,
              color: const Color(0xFF8B7CE6),
              fontType: fontType,
              onTap: _openRamadanTimetable,
            ),
            const SizedBox(height: 8),
            _MosqueActionTile(
              title: 'پلانی خەتم',
              icon: Icons.auto_stories_rounded,
              color: const Color(0xFF6EA3E2),
              fontType: fontType,
              onTap: _openKhatmPlan,
            ),
            const SizedBox(height: 8),
            _MosqueActionTile(
              title: 'فەرموودەی ڕۆژانە',
              icon: Icons.menu_book_rounded,
              color: const Color(0xFFD0A341),
              fontType: fontType,
              onTap: _openDailyHadith,
            ),
            const SizedBox(height: 8),
            _MosqueActionTile(
              title: 'ڕێنمایی شەوی قەدر',
              icon: Icons.nights_stay_rounded,
              color: const Color(0xFF9A86D3),
              fontType: fontType,
              onTap: _openLaylatQadrGuide,
            ),

            const SizedBox(height: 8),
            _MosqueActionTile(
              title: 'ڕێنمایی حەج/عوومرە',
              icon: Icons.assured_workload_rounded,
              color: const Color(0xFF6DB496),
              fontType: fontType,
              onTap: _openHajjUmrahGuide,
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _loadHomeBanners() async {
    final List<HomeBanner> cached = await _bannerService.loadCachedBanners();
    if (!mounted) return;

    if (cached.isNotEmpty) {
      setState(() {
        _networkBanners = cached;
        _syncBannerIndex();
      });
    }

    setState(() {
      _isBannerSyncing = true;
    });

    try {
      final List<HomeBanner> fresh = await _bannerService
          .fetchAndCacheBanners();
      if (!mounted) return;

      if (fresh.isNotEmpty) {
        setState(() {
          _networkBanners = fresh;
          _syncBannerIndex();
        });
      }
    } catch (_) {
      if (!mounted) return;
    } finally {
      if (mounted) {
        setState(() {
          _isBannerSyncing = false;
        });
      }
    }
  }

  void _syncBannerIndex() {
    final int count = _activeSliderItems.length;
    if (count == 0) {
      currentIndex = 0;
      return;
    }
    if (currentIndex >= count) {
      currentIndex = 0;
    }
  }

  List<Widget> get _activeSliderItems {
    if (_networkBanners.isEmpty) {
      return _sliderList;
    }
    return _networkBanners
        .map((HomeBanner banner) => _buildNetworkBannerCard(banner))
        .toList();
  }

  Widget _buildNetworkBannerCard(HomeBanner banner) {
    final String filePath = (banner.localImagePath ?? '').trim();
    final bool hasLocalImage =
        filePath.isNotEmpty && File(filePath).existsSync();
    final bool hasLink = banner.link.trim().isNotEmpty;

    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTap: hasLink ? () => _openBannerLink(banner) : null,
      child: Container(
        margin: const EdgeInsets.symmetric(horizontal: 14),
        decoration: BoxDecoration(borderRadius: BorderRadius.circular(22)),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(22),
          child: Stack(
            fit: StackFit.expand,
            children: [
              if (hasLocalImage)
                Image.file(
                  File(filePath),
                  fit: BoxFit.cover,
                  errorBuilder:
                      (
                        BuildContext context,
                        Object error,
                        StackTrace? stackTrace,
                      ) => _buildBannerFallback(),
                )
              else
                Image.network(
                  banner.imageUrl,
                  fit: BoxFit.cover,
                  loadingBuilder:
                      (
                        BuildContext context,
                        Widget child,
                        ImageChunkEvent? loadingProgress,
                      ) {
                        if (loadingProgress == null) {
                          return child;
                        }
                        return _buildBannerLoading(
                          loadingProgress.expectedTotalBytes,
                          loadingProgress.cumulativeBytesLoaded,
                        );
                      },
                  errorBuilder:
                      (
                        BuildContext context,
                        Object error,
                        StackTrace? stackTrace,
                      ) => _buildBannerFallback(),
                ),
              if (hasLink)
                Positioned(
                  top: 12,
                  left: 12,
                  child: Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 10,
                      vertical: 6,
                    ),
                    decoration: BoxDecoration(
                      color: Colors.white.withValues(alpha: 0.16),
                      borderRadius: BorderRadius.circular(100),
                      border: Border.all(color: const Color(0x30FFFFFF)),
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        const Icon(
                          Icons.open_in_new_rounded,
                          color: Colors.white,
                          size: 14,
                        ),
                        const SizedBox(width: 4),
                        Text(
                          banner.link.trim().isEmpty ? 'بانەر' : 'بینین',
                          style: TextStyle(
                            fontFamily: fontType.toString(),
                            color: Colors.white,
                            fontWeight: FontWeight.w700,
                            fontSize: 11.5,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              /* Positioned(
                  right: 16,
                  left: 16,
                  bottom: 16,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: [
                      Text(
                        banner.title.trim().isEmpty
                            ? 'Runaki Islam'
                            : banner.title,
                        textAlign: TextAlign.right,
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(
                          fontFamily: fontType.toString(),
                          color: Colors.white,
                          fontSize: 20,
                          fontWeight: FontWeight.w800,
                          shadows: const [
                            Shadow(
                              color: Color(0x40000000),
                              offset: Offset(0, 2),
                              blurRadius: 8,
                            ),
                          ],
                        ),
                      ),
                      const SizedBox.shrink(),
                      Text(
                        hasLocalImage
                            ? 'بانەری پاشەکەوتکراو'
                            : 'بارکردنی وێنەی بانەر',
                        textAlign: TextAlign.right,
                        style: TextStyle(
                          fontFamily: fontType.toString(),
                          color: Colors.transparent,
                          fontSize: 0,
                          height: 0,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ],
                  ),
                ), */
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildBannerLoading(int? totalBytes, int loadedBytes) {
    final double progress = totalBytes == null || totalBytes <= 0
        ? 0
        : (loadedBytes / totalBytes).clamp(0, 1);

    return DecoratedBox(
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [Color(0xFFF6E2B8), Color(0xFFE8BA67)],
        ),
      ),
      child: Center(
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
          decoration: BoxDecoration(
            color: Colors.white.withValues(alpha: 0.18),
            borderRadius: BorderRadius.circular(18),
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              SizedBox(
                width: 28,
                height: 28,
                child: CircularProgressIndicator(
                  strokeWidth: 2.6,
                  value: progress > 0 ? progress : null,
                  color: Colors.white,
                ),
              ),
              const SizedBox(height: 10),
              Text(
                'بارکردنی بانەر...',
                style: TextStyle(
                  fontFamily: fontType.toString(),
                  color: Colors.white,
                  fontWeight: FontWeight.w700,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildBannerFallback() {
    return DecoratedBox(
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [Color(0xFFFCCF75), Color(0xFFECA73E)],
        ),
      ),
      child: Center(
        child: Icon(
          Icons.image_not_supported_outlined,
          color: Colors.white.withValues(alpha: 0.85),
          size: 42,
        ),
      ),
    );
  }

  Future<void> _openBannerLink(HomeBanner banner) async {
    final Uri? uri = Uri.tryParse(banner.link.trim());
    if (uri == null || !uri.hasScheme) {
      return;
    }

    final bool launched = await launchUrl(
      uri,
      mode: LaunchMode.externalApplication,
    );
    if (!launched) {
      _showHomeSnack('نەتوانرا بەستەرەکە بکرێتەوە.');
    }
  }

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final List<Widget> sliderItems = _activeSliderItems;
    return DecoratedBox(
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [const Color(0xFFFDF8EE), scheme.surface, bgColor],
        ),
      ),
      child: Stack(
        children: [
          SingleChildScrollView(
            physics: const BouncingScrollPhysics(
              parent: AlwaysScrollableScrollPhysics(),
            ),
            child: Column(
              children: [
                SafeArea(
                  bottom: false,
                  child: FadeSlideIn(
                    offsetY: 8,
                    child: Padding(
                      padding: const EdgeInsets.fromLTRB(14, 6, 14, 0),
                      child: Container(
                        height: 56,
                        padding: const EdgeInsets.symmetric(horizontal: 8),
                        decoration: BoxDecoration(
                          color: Colors.white.withValues(alpha: 0.9),
                          borderRadius: BorderRadius.circular(16),
                          border: Border.all(color: const Color(0x1FB9893C)),
                          boxShadow: const [
                            BoxShadow(
                              color: Color(0x12000000),
                              blurRadius: 14,
                              offset: Offset(0, 6),
                            ),
                          ],
                        ),
                        child: Row(
                          children: [
                            _iconBubble(
                              icon: Icons.search_rounded,
                              onTap: () {
                                showGeneralSearchPage(
                                  context: context,
                                  fontFamily: fontType,
                                );
                              },
                            ),
                            Expanded(
                              child: Text(
                                "\u0695\u0648\u0646\u0627\u06a9\u06cc \u0626\u06cc\u0633\u0644\u0627\u0645",
                                textAlign: TextAlign.center,
                                style: TextStyle(
                                  fontFamily: fontType.toString(),
                                  fontSize: 19,
                                  fontWeight: FontWeight.w800,
                                  color: const Color(0xFF3A2D1E),
                                ),
                              ),
                            ),
                            _iconBubble(
                              icon: Icons.menu_rounded,
                              onTap: () {
                                Scaffold.maybeOf(context)?.openEndDrawer();
                              },
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
                const SizedBox(height: 10),
                FadeSlideIn(
                  offsetY: 10,
                  child: Container(
                    margin: const EdgeInsets.symmetric(horizontal: 14),
                    padding: const EdgeInsets.fromLTRB(16, 14, 16, 14),
                    decoration: BoxDecoration(
                      color: Colors.white.withValues(alpha: 0.9),
                      borderRadius: BorderRadius.circular(22),
                      border: Border.all(color: const Color(0x1EB08E58)),
                      boxShadow: const [
                        BoxShadow(
                          color: Color(0x12000000),
                          blurRadius: 18,
                          offset: Offset(0, 8),
                        ),
                      ],
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.end,
                      children: [
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.end,
                          children: [
                            Text(
                              "السلام عليكم ورحمة الله وبركاته",
                              style: TextStyle(
                                fontFamily: fontType.toString(),
                                color: titleTextColor,
                                fontSize: 13.5,
                              ),
                            ),
                            const SizedBox(height: 4),
                            Text(
                              "بەخێربێی بۆ ڕوناکی ئیسلام",
                              style: TextStyle(
                                fontFamily: fontType.toString(),
                                color: kTextColor,
                                fontSize: 23,
                                fontWeight: FontWeight.w700,
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: 14),
                FadeSlideIn(
                  delay: const Duration(milliseconds: 70),
                  offsetY: 12,
                  child: Stack(
                    children: [
                      CarouselSlider(
                        items: sliderItems,
                        options: CarouselOptions(
                          reverse: false,
                          autoPlayAnimationDuration: AppMotion.page,
                          autoPlay: !AppMotion.reduceMotion,
                          height: MediaQuery.of(context).size.height / 5.2,
                          viewportFraction: 1,
                          scrollPhysics: const BouncingScrollPhysics(),
                          onPageChanged: (index, reason) {
                            setState(() {
                              currentIndex = index;
                              _syncBannerIndex();
                            });
                          },
                        ),
                      ),
                      if (_isBannerSyncing && _networkBanners.isEmpty)
                        Positioned(
                          top: 22,
                          right: 28,
                          child: Container(
                            padding: const EdgeInsets.symmetric(
                              horizontal: 10,
                              vertical: 6,
                            ),
                            decoration: BoxDecoration(
                              color: Colors.white.withValues(alpha: 0.88),
                              borderRadius: BorderRadius.circular(100),
                            ),
                            child: Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                const SizedBox(
                                  width: 12,
                                  height: 12,
                                  child: CircularProgressIndicator(
                                    strokeWidth: 2,
                                    color: Color(0xFFB9893C),
                                  ),
                                ),
                                const SizedBox(width: 6),
                                Text(
                                  'بارکردن',
                                  style: TextStyle(
                                    fontFamily: fontType.toString(),
                                    color: const Color(0xFF8C6832),
                                    fontWeight: FontWeight.w700,
                                    fontSize: 11.5,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                    ],
                  ),
                ),
                const SizedBox(height: 12),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: List<Widget>.generate(sliderItems.length, (index) {
                    final selected = currentIndex == index;
                    return AnimatedContainer(
                      duration: AppMotion.fast,
                      curve: AppMotion.curve,
                      width: selected ? 20 : 8,
                      height: 8,
                      margin: const EdgeInsets.symmetric(horizontal: 4),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(100),
                        color: selected
                            ? const Color(0xFFB9893C)
                            : const Color(0x2AB9893C),
                      ),
                    );
                  }),
                ),
                const SizedBox(height: 16),
                FadeSlideIn(
                  delay: const Duration(milliseconds: 100),
                  offsetY: 10,
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 14),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        TextButton(
                          onPressed: () {
                            Navigator.push(
                              context,
                              PageTransition(
                                child: const AllItemsList(),
                                duration: AppMotion.page,
                                type: PageTransitionType.topToBottom,
                              ),
                            );
                          },
                          style: TextButton.styleFrom(
                            foregroundColor: const Color(0xFF8C6832),
                            backgroundColor: const Color(0xFFFFF3DD),
                            padding: const EdgeInsets.symmetric(
                              horizontal: 14,
                              vertical: 10,
                            ),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(12),
                              side: const BorderSide(color: Color(0x1FB9893C)),
                            ),
                          ),
                          child: Text(
                            "کردنەوەی هەموو بەشەکان",
                            style: TextStyle(
                              fontFamily: fontType.toString(),
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ),
                        Text(
                          "بەشەکان",
                          style: TextStyle(
                            fontFamily: fontType.toString(),
                            fontSize: 22,
                            color: const Color(0xFF2D2419),
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: 8),
                FadeSlideIn(
                  delay: const Duration(milliseconds: 130),
                  offsetY: 10,
                  child: Container(
                    margin: const EdgeInsets.symmetric(horizontal: 14),
                    padding: const EdgeInsets.all(10),
                    decoration: BoxDecoration(
                      color: Colors.white.withValues(alpha: 0.92),
                      borderRadius: BorderRadius.circular(22),
                      border: Border.all(color: const Color(0x1FB9893C)),
                      boxShadow: const [
                        BoxShadow(
                          color: Color(0x12000000),
                          blurRadius: 18,
                          offset: Offset(0, 8),
                        ),
                      ],
                    ),
                    child: GridView.count(
                      crossAxisCount: 2,
                      childAspectRatio: 1.5,
                      shrinkWrap: true,
                      physics: const NeverScrollableScrollPhysics(),
                      mainAxisSpacing: 10,
                      crossAxisSpacing: 10,
                      children: [
                        _HomeEntryCard(
                          title: "قورئانی پیرۆز",
                          color: const Color(0xff17d39f),
                          image: "assets/icons/quran-icon.svg",
                          isImage: false,
                          fontType: fontType,
                          onTap: () {
                            Navigator.push(
                              context,
                              SizeRoute(page: const QuranPage()),
                            );
                          },
                        ),
                        _HomeEntryCard(
                          title: "زیکرەکان",
                          color: const Color(0xff3aa8de),
                          image: "assets/icons/zikr.svg",
                          isImage: false,
                          fontType: fontType,
                          onTap: () {
                            Navigator.push(
                              context,
                              PageTransition(
                                child: const ZekrakanPage(),
                                duration: AppMotion.page,
                                type: PageTransitionType.rightToLeft,
                              ),
                            );
                          },
                        ),
                        _HomeEntryCard(
                          title: "تەسبیح",
                          color: const Color(0xffebba53),
                          image: "assets/icons/tasbih.svg",
                          isImage: false,
                          fontType: fontType,
                          onTap: () {
                            Navigator.push(
                              context,
                              FadeRoute(page: const CheckDatabase()),
                            );
                          },
                        ),
                        _HomeEntryCard(
                          title: "فەرموودە",
                          color: const Color(0xFFB99AE7),
                          image: "assets/icons/hadith.png",
                          isImage: true,
                          fontType: fontType,
                          onTap: () {
                            Navigator.push(
                              context,
                              PageTransition(
                                child: const FarmudaPage(),
                                duration: AppMotion.page,
                                type: PageTransitionType.rightToLeft,
                              ),
                            );
                          },
                        ),
                        _HomeEntryCard(
                          title: "چیرۆک",
                          color: const Color(0xFFBDDA92),
                          image: "assets/icons/cherok.svg",
                          isImage: false,
                          fontType: fontType,
                          onTap: () {
                            Navigator.push(
                              context,
                              ScaleRoute(page: const CherokPage()),
                            );
                          },
                        ),
                        _HomeEntryCard(
                          title: "کتێب",
                          color: const Color(0xff3aa8de),
                          image: "assets/icons/books.svg",
                          isImage: false,
                          fontType: fontType,
                          onTap: () {
                            Navigator.push(
                              context,
                              ScaleRoute(page: const BookPage()),
                            );
                          },
                        ),
                        _HomeEntryCard(
                          title: "نوێژکردن",
                          color: const Color(0xFF91D4C1),
                          image: "assets/icons/praying.svg",
                          isImage: false,
                          fontType: fontType,
                          onTap: () {
                            Navigator.push(
                              context,
                              SizeRoute(page: const NwezhPage()),
                            );
                          },
                        ),
                        _HomeEntryCard(
                          title: "ژمێریاری زەکات",
                          color: const Color(0xFF77BFA1),
                          image: "assets/icons/islam.svg",
                          isImage: false,
                          fontType: fontType,
                          onTap: () {
                            Navigator.push(
                              context,
                              SizeRoute(page: const ZakatCalculatorPage()),
                            );
                          },
                        ),
                        _HomeEntryCard(
                          title: "قیبلە نواندەر",
                          color: const Color(0xFF6AA58F),
                          image: "assets/icons/prayer-time.svg",
                          isImage: false,
                          fontType: fontType,
                          onTap: () {
                            Navigator.push(
                              context,
                              SizeRoute(page: const QiblaFinderPage()),
                            );
                          },
                        ),
                        _HomeEntryCard(
                          title: "ناوەکانی خودای گەورە",
                          color: const Color(0xFFE9A2B7),
                          image: "assets/icons/allah-word.svg",
                          isImage: false,
                          fontType: fontType,
                          onTap: () {
                            Navigator.push(
                              context,
                              SizeRoute(
                                page: const AllahNames(
                                  sarder: "ناوەکانی خودای گەورە",
                                ),
                              ),
                            );
                          },
                        ),
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: 12),
                FadeSlideIn(
                  delay: const Duration(milliseconds: 145),
                  offsetY: 8,
                  child: _buildMosqueSection(),
                ),
                const SizedBox(height: 12),
                FadeSlideIn(
                  delay: const Duration(milliseconds: 152),
                  offsetY: 8,
                  child: _buildRamadanSeasonSection(),
                ),
                const SizedBox(height: 14),
                FadeSlideIn(
                  delay: const Duration(milliseconds: 160),
                  offsetY: 8,
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 15),
                    child: SizedBox(
                      width: double.infinity,
                      child: ElevatedButton(
                        onPressed: () {
                          Navigator.push(
                            context,
                            PageTransition(
                              child: const AllItemsList(),
                              duration: AppMotion.page,
                              type: PageTransitionType.bottomToTop,
                            ),
                          );
                        },
                        style: ElevatedButton.styleFrom(
                          elevation: 0,
                          padding: const EdgeInsets.symmetric(vertical: 14),
                          backgroundColor: const Color(0xFFF7E4C3),
                          foregroundColor: const Color(0xFF8C6832),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(14),
                            side: const BorderSide(color: Color(0x2AB9893C)),
                          ),
                        ),
                        child: Text(
                          "کردنەوەی هەموو بەشەکان",
                          style: TextStyle(
                            fontFamily: fontType.toString(),
                            fontSize: 16,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
                const SizedBox(height: 136),
              ],
            ),
          ),
          Positioned(
            right: 14,
            bottom: 122,
            child: SafeArea(top: false, child: _buildAiFab()),
          ),
        ],
      ),
    );
  }

  Widget _iconBubble({required IconData icon, required VoidCallback onTap}) {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        borderRadius: BorderRadius.circular(12),
        onTap: onTap,
        child: Ink(
          width: 42,
          height: 42,
          decoration: BoxDecoration(
            color: Colors.white.withValues(alpha: 0.9),
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: const Color(0x1FB9893C)),
          ),
          child: Icon(icon, color: const Color(0xFF3F3121)),
        ),
      ),
    );
  }
}

class _HomeEntryCard extends StatelessWidget {
  const _HomeEntryCard({
    required this.title,
    required this.color,
    required this.image,
    required this.onTap,
    required this.fontType,
    this.isImage = false,
  });

  final String title;
  final Color color;
  final String image;
  final bool isImage;
  final int? fontType;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        borderRadius: BorderRadius.circular(16),
        onTap: onTap,
        child: Ink(
          padding: const EdgeInsets.all(10),
          decoration: BoxDecoration(
            color: const Color(0xFFFFFCF7),
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: const Color(0x15B9893C)),
          ),
          child: Row(
            children: [
              Container(
                width: 44,
                height: 44,
                padding: const EdgeInsets.all(9),
                decoration: BoxDecoration(
                  color: color.withValues(alpha: 0.92),
                  borderRadius: BorderRadius.circular(12),
                  boxShadow: [
                    BoxShadow(
                      color: color.withValues(alpha: 0.26),
                      blurRadius: 10,
                      offset: const Offset(0, 4),
                    ),
                  ],
                ),
                child: isImage
                    ? Image.asset(image, color: Colors.white)
                    : SvgPicture.asset(
                        image,
                        colorFilter: const ColorFilter.mode(
                          Colors.white,
                          BlendMode.srcIn,
                        ),
                      ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: Text(
                  title,
                  textAlign: TextAlign.right,
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                    fontFamily: fontType.toString(),
                    color: const Color(0xFF3A2D1E),
                    fontWeight: FontWeight.w700,
                    fontSize: 14.5,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _MosqueActionTile extends StatelessWidget {
  const _MosqueActionTile({
    required this.title,
    required this.icon,
    required this.color,
    required this.onTap,
    required this.fontType,
  });

  final String title;
  final IconData icon;
  final Color color;
  final Future<void> Function() onTap;
  final int? fontType;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        borderRadius: BorderRadius.circular(14),
        onTap: () {
          onTap();
        },
        child: Ink(
          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 10),
          decoration: BoxDecoration(
            color: const Color(0xFFFFFCF7),
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: const Color(0x15B9893C)),
          ),
          child: Row(
            children: [
              const Icon(
                Icons.arrow_back_ios_new_rounded,
                size: 16,
                color: Color(0xFF8C6832),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: Text(
                  title,
                  textAlign: TextAlign.right,
                  style: TextStyle(
                    fontFamily: fontType.toString(),
                    color: const Color(0xFF3A2D1E),
                    fontWeight: FontWeight.w700,
                    fontSize: 15,
                  ),
                ),
              ),
              const SizedBox(width: 10),
              Container(
                width: 42,
                height: 42,
                decoration: BoxDecoration(
                  color: color.withValues(alpha: 0.92),
                  borderRadius: BorderRadius.circular(12),
                  boxShadow: [
                    BoxShadow(
                      color: color.withValues(alpha: 0.25),
                      blurRadius: 10,
                      offset: const Offset(0, 4),
                    ),
                  ],
                ),
                child: Icon(icon, color: Colors.white, size: 22),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
