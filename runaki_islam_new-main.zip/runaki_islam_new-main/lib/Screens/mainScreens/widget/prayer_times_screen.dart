import 'dart:async';
import 'dart:io';

import 'package:analog_clock/analog_clock.dart';
import 'package:carousel_slider/carousel_slider.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:geolocator/geolocator.dart';
import 'package:hijri/hijri_calendar.dart';
import 'package:provider/provider.dart';
import 'package:runaki_islam/providers/settings_provider.dart';
import 'package:runaki_islam/services/prayer_db_service.dart';
import 'package:runaki_islam/services/prayer_home_widget_service.dart';
import 'package:runaki_islam/util/animation_helper.dart';
import 'package:runaki_islam/util/constans.dart';
import 'package:runaki_islam/util/platform_feature_flags.dart';
import 'package:slide_countdown/slide_countdown.dart';

class PrayerTimesScreen extends StatefulWidget {
  const PrayerTimesScreen({super.key, this.active = true});

  final bool active;

  @override
  State<PrayerTimesScreen> createState() => _PrayerTimesScreenState();
}

enum _CountdownMode { toNext, sincePrevious }

class _PrayerTimesScreenState extends State<PrayerTimesScreen>
    with SingleTickerProviderStateMixin {
  final PrayerDbService _service = PrayerDbService();
  Timer? _ticker;
  late final AnimationController _ambientController;
  late final Animation<double> _ambientCurve;

  int? _fontType;
  bool _isLoading = true;
  bool _isRefreshing = false;
  bool _didAutoPromptOnOpen = false;
  String? _errorText;
  int _locationRequestId = 0;

  PrayerCity? _city;
  List<PrayerMoment> _todayMoments = <PrayerMoment>[];
  List<PrayerMoment> _tomorrowMoments = <PrayerMoment>[];
  List<PrayerMoment> _yesterdayMoments = <PrayerMoment>[];

  DateTime _loadedDate = DateTime.now();
  DateTime _now = DateTime.now();
  int _headerIndex = 0;
  _CountdownMode _countdownMode = _CountdownMode.toNext;

  static const List<String> _gregorianWeekdays = <String>[
    '',
    '\u062F\u0648\u0634\u06D5\u0645\u0645\u06D5',
    '\u0633\u06CE\u0634\u06D5\u0645\u0645\u06D5',
    '\u0686\u0648\u0627\u0631\u0634\u06D5\u0645\u0645\u06D5',
    '\u067E\u06CE\u0646\u062C\u0634\u06D5\u0645\u0645\u06D5',
    '\u0647\u06D5\u06CC\u0646\u06CC',
    '\u0634\u06D5\u0645\u0645\u06D5',
    '\u06CC\u06D5\u06A9\u0634\u06D5\u0645\u0645\u06D5',
  ];

  @override
  void initState() {
    super.initState();
    _fontType = Provider.of<SettingsProvider>(
      context,
      listen: false,
    ).getsettingField('font_family');
    _ambientController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 14),
    );
    if (!AppMotion.reduceMotion) {
      _ambientController.repeat(reverse: true);
    }
    _ambientCurve = CurvedAnimation(
      parent: _ambientController,
      curve: Curves.easeInOutSine,
    );
    HijriCalendar.setLocal('ar');
    _loadPrayerTimes();
    if (widget.active) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        _requestLocationOnOpen();
      });
    }
    _setActiveState(widget.active, rebuild: false);
  }

  @override
  void didUpdateWidget(covariant PrayerTimesScreen oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.active == widget.active) return;
    _setActiveState(widget.active);
    if (widget.active && !_didAutoPromptOnOpen) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        _requestLocationOnOpen();
      });
    }
  }

  @override
  void dispose() {
    _stopTicker();
    _ambientController.dispose();
    _service.close();
    super.dispose();
  }

  void _setActiveState(bool active, {bool rebuild = true}) {
    if (active) {
      if (!AppMotion.reduceMotion && !_ambientController.isAnimating) {
        _ambientController.repeat(reverse: true);
      }
      _startTicker();
      final now = DateTime.now();
      if (rebuild && mounted) {
        setState(() => _now = now);
      } else {
        _now = now;
      }
      if (!_isRefreshing && !_isSameDay(_loadedDate, now)) {
        unawaited(_loadPrayerTimes(showLoader: false));
      }
      return;
    }

    _ambientController.stop();
    _stopTicker();
  }

  void _startTicker() {
    _ticker?.cancel();
    _ticker = Timer.periodic(const Duration(seconds: 1), (_) {
      if (!mounted) return;
      final now = DateTime.now();
      setState(() => _now = now);
      if (now.second == 0 && PlatformFeatureFlags.supportsPrayerWidgets) {
        unawaited(_syncHomeWidget());
      }
      if (!_isRefreshing && !_isSameDay(_loadedDate, now) && now.second == 0) {
        unawaited(_loadPrayerTimes(showLoader: false));
      }
    });
  }

  void _stopTicker() {
    _ticker?.cancel();
    _ticker = null;
  }

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final progress = _resolvePrayerProgress();

    return ColoredBox(
      color: bgColor,
      child: Stack(
        children: <Widget>[
          _animatedBackdrop(context),
          RefreshIndicator(
            onRefresh: () => _loadPrayerTimes(showLoader: false),
            color: scheme.primary,
            child: ListView(
              physics: const BouncingScrollPhysics(
                parent: AlwaysScrollableScrollPhysics(),
              ),
              padding: const EdgeInsets.fromLTRB(14, 8, 14, 118),
              children: <Widget>[
                FadeSlideIn(
                  delay: const Duration(milliseconds: 20),
                  child: SafeArea(bottom: false, child: _topBar(context)),
                ),
                const SizedBox(height: 10),
                if (_isLoading) ...<Widget>[
                  _loadingCard(context),
                ] else if (_errorText != null) ...<Widget>[
                  _errorCard(context),
                ] else ...<Widget>[
                  FadeSlideIn(
                    delay: const Duration(milliseconds: 50),
                    child: _headerCarousel(context, progress: progress),
                  ),
                  const SizedBox(height: 10),
                  FadeSlideIn(
                    delay: const Duration(milliseconds: 90),
                    child: _dateCard(context),
                  ),
                  const SizedBox(height: 10),
                  FadeSlideIn(
                    delay: const Duration(milliseconds: 130),
                    child: _prayerTableCard(context, progress: progress),
                  ),
                ],
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _animatedBackdrop(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    if (AppMotion.reduceMotion) {
      final colorA = scheme.primary.withValues(alpha: 0.08);
      final colorB = scheme.tertiary.withValues(alpha: 0.08);
      return IgnorePointer(
        child: Stack(
          children: <Widget>[
            Positioned(
              top: -140,
              left: -80,
              child: _ambientOrb(size: 240, color: colorA),
            ),
            Positioned(
              bottom: -120,
              right: -70,
              child: _ambientOrb(size: 220, color: colorB),
            ),
            Positioned(
              top: 260,
              right: 40,
              child: _ambientOrb(size: 84, color: colorA),
            ),
          ],
        ),
      );
    }
    return IgnorePointer(
      child: AnimatedBuilder(
        animation: _ambientCurve,
        builder: (context, child) {
          final value = _ambientCurve.value;
          final colorA = scheme.primary.withValues(alpha: 0.08);
          final colorB = scheme.tertiary.withValues(alpha: 0.08);
          return Stack(
            children: <Widget>[
              Positioned(
                top: -140 + (value * 24),
                left: -80 + (value * 12),
                child: _ambientOrb(size: 240, color: colorA),
              ),
              Positioned(
                bottom: -120 - (value * 18),
                right: -70 + (value * 24),
                child: _ambientOrb(size: 220, color: colorB),
              ),
              Positioned(
                top: 260 - (value * 20),
                right: 40 + (value * 16),
                child: _ambientOrb(size: 84, color: colorA),
              ),
            ],
          );
        },
      ),
    );
  }

  Widget _ambientOrb({required double size, required Color color}) {
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(color: color, shape: BoxShape.circle),
    );
  }

  Widget _topBar(BuildContext context) {
    return Container(
      height: 56,
      padding: const EdgeInsets.symmetric(horizontal: 8),
      decoration: BoxDecoration(
        color: Colors.white.withValues(alpha: 0.9),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: const Color(0x1FB9893C)),
        boxShadow: const <BoxShadow>[
          BoxShadow(
            color: Color(0x12000000),
            blurRadius: 14,
            offset: Offset(0, 6),
          ),
        ],
      ),
      child: Row(
        children: <Widget>[
          _iconBubble(
            context,
            icon: Icons.refresh_rounded,
            onTap: () => _loadPrayerTimes(showLoader: false),
          ),
          Expanded(
            child: Text(
              '\u06A9\u0627\u062A\u06CC \u0646\u0648\u06CE\u0698',
              textAlign: TextAlign.center,
              style: TextStyle(
                fontFamily: _fontType.toString(),
                color: const Color(0xFF3A2D1E),
                fontWeight: FontWeight.w800,
                fontSize: 19,
              ),
            ),
          ),
          _iconBubble(
            context,
            icon: Icons.my_location_rounded,
            onTap: _autoDetectAndSetCity,
            tooltip:
                '\u0634\u0648\u06CE\u0646\u06CC \u0626\u06CE\u0633\u062A\u0627',
          ),
          const SizedBox(width: 6),
          ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 150),
            child: _cityPickerPill(context),
          ),
        ],
      ),
    );
  }

  Widget _headerCarousel(
    BuildContext context, {
    required _PrayerProgress progress,
  }) {
    return AnimatedBuilder(
      animation: _ambientCurve,
      builder: (context, _) {
        final value = _ambientCurve.value;
        final carouselHeight = _resolveCarouselHeight(context);
        return Transform.translate(
          offset: Offset(0, 2 - (value * 4)),
          child: Transform.scale(
            scale: 0.985 + (value * 0.015),
            child: Column(
              children: <Widget>[
                CarouselSlider(
                  items: <Widget>[
                    _countdownCard(context, progress: progress),
                    _analogClockCard(context),
                  ],
                  options: CarouselOptions(
                    height: carouselHeight,
                    viewportFraction: 1,
                    enableInfiniteScroll: true,
                    autoPlay: false,
                    autoPlayInterval: const Duration(seconds: 8),
                    autoPlayAnimationDuration: const Duration(
                      milliseconds: 500,
                    ),
                    autoPlayCurve: Curves.easeInOutCubic,
                    onPageChanged: (index, _) {
                      if (!mounted) return;
                      setState(() => _headerIndex = index);
                    },
                  ),
                ),
                const SizedBox(height: 8),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: List<Widget>.generate(2, (index) {
                    final selected = index == _headerIndex;
                    return AnimatedContainer(
                      duration: AppMotion.fast,
                      curve: AppMotion.curve,
                      width: selected ? 18 : 8,
                      height: 8,
                      margin: const EdgeInsets.symmetric(horizontal: 4),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(99),
                        color: selected
                            ? const Color(0xFFB9893C)
                            : const Color(0x2AB9893C),
                      ),
                    );
                  }),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _countdownCard(
    BuildContext context, {
    required _PrayerProgress progress,
  }) {
    final scheme = Theme.of(context).colorScheme;
    final bool toNext = _countdownMode == _CountdownMode.toNext;
    final _NextPrayer next = progress.next;
    final _PreviousPrayer previous = progress.previous;

    String title;
    String prayerLabel;
    Duration duration;
    if (toNext) {
      title = next.isTomorrow
          ? '\u0645\u0627\u0648\u06D5 \u0628\u06C6 \u0646\u0648\u06CE\u0698\u06CC \u062F\u0627\u0647\u0627\u062A\u0648\u0648 (\u0633\u0628\u06D5\u06CC)'
          : '\u0645\u0627\u0648\u06D5 \u0628\u06C6 \u0646\u0648\u06CE\u0698\u06CC \u062F\u0627\u0647\u0627\u062A\u0648\u0648';
      prayerLabel = next.moment?.label ?? '---';
      duration = next.remaining;
    } else {
      title = previous.isYesterday
          ? '\u062A\u06CE\u067E\u06D5\u0695\u0628\u0648\u0648 \u0644\u06D5 \u0646\u0648\u06CE\u0698\u06CC \u067E\u06CE\u0634\u0648\u0648 (\u062F\u0648\u06CE\u0646\u06CE)'
          : '\u062A\u06CE\u067E\u06D5\u0695\u0628\u0648\u0648 \u0644\u06D5 \u0646\u0648\u06CE\u0698\u06CC \u067E\u06CE\u0634\u0648\u0648';
      prayerLabel = previous.moment?.label ?? '---';
      duration = previous.elapsed;
    }
    final safeDuration = duration.isNegative ? Duration.zero : duration;

    return Container(
      padding: const EdgeInsets.fromLTRB(14, 12, 14, 12),
      decoration: BoxDecoration(
        color: scheme.primary.withValues(alpha: 0.92),
        borderRadius: BorderRadius.circular(22),
        border: Border.all(color: scheme.primary.withValues(alpha: 0.35)),
        boxShadow: <BoxShadow>[
          BoxShadow(
            color: scheme.primary.withValues(alpha: 0.20),
            blurRadius: 18,
            offset: const Offset(0, 8),
          ),
        ],
      ),
      child: Stack(
        children: <Widget>[
          Positioned.fill(
            child: _cardPatternMarks(
              color: Colors.white.withValues(alpha: 0.2),
              mirror: false,
            ),
          ),
          Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: <Widget>[
              Row(
                children: <Widget>[
                  Material(
                    color: Colors.transparent,
                    child: InkWell(
                      borderRadius: BorderRadius.circular(12),
                      onTap: () {
                        setState(() {
                          _countdownMode = toNext
                              ? _CountdownMode.sincePrevious
                              : _CountdownMode.toNext;
                        });
                      },
                      child: Container(
                        width: 36,
                        height: 36,
                        decoration: BoxDecoration(
                          color: Colors.white.withValues(alpha: 0.16),
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(
                            color: Colors.white.withValues(alpha: 0.25),
                          ),
                        ),
                        child: AnimatedRotation(
                          duration: AppMotion.fast,
                          curve: AppMotion.curve,
                          turns: toNext ? 0 : 0.5,
                          child: const Icon(
                            Icons.swap_horiz_rounded,
                            color: Colors.white,
                            size: 20,
                          ),
                        ),
                      ),
                    ),
                  ),
                  const Spacer(),
                  Text(
                    _city?.displayName ?? '---',
                    textDirection: TextDirection.rtl,
                    style: TextStyle(
                      fontFamily: _fontType.toString(),
                      color: Colors.white.withValues(alpha: 0.9),
                      fontSize: 12.8,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 6),
              Text(
                title,
                textDirection: TextDirection.rtl,
                style: TextStyle(
                  fontFamily: _fontType.toString(),
                  color: Colors.white,
                  fontSize: 17,
                  fontWeight: FontWeight.w700,
                ),
              ),
              const SizedBox(height: 2),
              Text(
                prayerLabel,
                textDirection: TextDirection.rtl,
                style: TextStyle(
                  fontFamily: _fontType.toString(),
                  color: Colors.white.withValues(alpha: 0.95),
                  fontSize: 24,
                  fontWeight: FontWeight.w800,
                ),
              ),
              const SizedBox(height: 6),
              Align(
                alignment: Alignment.center,
                child: toNext
                    ? SlideCountdownSeparated(
                        duration: safeDuration,
                        separator: ':',
                        showZeroValue: true,
                        shouldShowDays: (_) => false,
                        shouldShowHours: (_) => true,
                        shouldShowMinutes: (_) => true,
                        shouldShowSeconds: (_) => true,
                        padding: const EdgeInsets.symmetric(horizontal: 1.5),
                        separatorPadding: const EdgeInsets.symmetric(
                          horizontal: 0.8,
                        ),
                        decoration: const BoxDecoration(
                          color: Colors.transparent,
                        ),
                        style: const TextStyle(
                          fontFamily: 'english',
                          color: Colors.white,
                          fontSize: 40,
                          fontWeight: FontWeight.w600,
                          height: 1.0,
                        ),
                        separatorStyle: const TextStyle(
                          fontFamily: 'english',
                          color: Colors.white,
                          fontSize: 40,
                          fontWeight: FontWeight.w600,
                          height: 1.0,
                        ),
                        slideAnimationDuration: const Duration(
                          milliseconds: 220,
                        ),
                        slideAnimationCurve: Curves.easeInOutCubic,
                      )
                    : Text(
                        _formatElapsedClock(safeDuration),
                        style: const TextStyle(
                          fontFamily: 'english',
                          color: Colors.white,
                          fontSize: 40,
                          fontWeight: FontWeight.w600,
                          height: 1.0,
                        ),
                      ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  String _formatElapsedClock(Duration duration) {
    final safe = duration.isNegative ? Duration.zero : duration;
    final hours = safe.inHours.toString().padLeft(2, '0');
    final minutes = (safe.inMinutes % 60).toString().padLeft(2, '0');
    final seconds = (safe.inSeconds % 60).toString().padLeft(2, '0');
    return '$hours:$minutes:$seconds';
  }

  Widget _analogClockCard(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return Container(
      padding: const EdgeInsets.fromLTRB(14, 12, 14, 10),
      decoration: BoxDecoration(
        color: Colors.white.withValues(alpha: 0.95),
        borderRadius: BorderRadius.circular(22),
        border: Border.all(color: const Color(0x1FB9893C)),
        boxShadow: const <BoxShadow>[
          BoxShadow(
            color: Color(0x12000000),
            blurRadius: 18,
            offset: Offset(0, 8),
          ),
        ],
      ),
      child: Stack(
        children: <Widget>[
          Positioned.fill(
            child: _cardPatternMarks(
              color: scheme.primary.withValues(alpha: 0.13),
              mirror: true,
            ),
          ),
          Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: <Widget>[
              Text(
                '\u06A9\u0627\u062A\u0698\u0645\u06CE\u0631\u06CC \u0626\u0627\u0646\u0627\u0644\u06C6\u06AF',
                textDirection: TextDirection.rtl,
                style: TextStyle(
                  fontFamily: _fontType.toString(),
                  color: scheme.onSurface,
                  fontSize: 16,
                  fontWeight: FontWeight.w800,
                ),
              ),
              const SizedBox(height: 8),
              Expanded(
                child: Center(
                  child: AnimatedBuilder(
                    animation: _ambientCurve,
                    builder: (context, _) {
                      final value = _ambientCurve.value;
                      return Transform.scale(
                        scale: 0.97 + (value * 0.06),
                        child: AnalogClock(
                          decoration: BoxDecoration(
                            border: Border.all(width: 2, color: scheme.primary),
                            color: Colors.transparent,
                            shape: BoxShape.circle,
                          ),
                          width: 145,
                          isLive: true,
                          hourHandColor: scheme.onSurface,
                          minuteHandColor: scheme.onSurface,
                          secondHandColor: scheme.primary,
                          numberColor: scheme.onSurfaceVariant,
                          showSecondHand: true,
                          showNumbers: true,
                          showAllNumbers: true,
                          textScaleFactor: 1.12,
                          datetime: _now,
                          showDigitalClock: false,
                        ),
                      );
                    },
                  ),
                ),
              ),
              const SizedBox(height: 4),
              Align(
                alignment: Alignment.center,
                child: Text(
                  '${_two(_now.hour)}:${_two(_now.minute)}:${_two(_now.second)}',
                  style: TextStyle(
                    fontFamily: 'english',
                    color: scheme.primary,
                    fontSize: 20,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  double _resolveCarouselHeight(BuildContext context) {
    final height = MediaQuery.sizeOf(context).height;
    if (height < 700) return 196;
    if (height < 830) return 210;
    return 220;
  }

  Widget _cardPatternMarks({required Color color, required bool mirror}) {
    return IgnorePointer(
      child: Stack(
        children: <Widget>[
          Positioned(
            top: 8,
            left: mirror ? null : 10,
            right: mirror ? 10 : null,
            child: Container(
              width: 72,
              height: 72,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                border: Border.all(color: color.withValues(alpha: 0.55)),
              ),
            ),
          ),
          Positioned(
            top: 22,
            left: mirror ? null : 24,
            right: mirror ? 24 : null,
            child: Container(
              width: 42,
              height: 42,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                border: Border.all(color: color.withValues(alpha: 0.4)),
              ),
            ),
          ),
          Positioned(
            top: 12,
            left: mirror ? 20 : null,
            right: mirror ? null : 20,
            child: Icon(
              Icons.auto_awesome_rounded,
              size: 13,
              color: color.withValues(alpha: 0.78),
            ),
          ),
          Positioned(
            bottom: 12,
            left: mirror ? 16 : null,
            right: mirror ? null : 16,
            child: Row(
              children: List<Widget>.generate(4, (index) {
                return Container(
                  width: 4,
                  height: 4,
                  margin: const EdgeInsets.symmetric(horizontal: 2),
                  decoration: BoxDecoration(
                    color: color.withValues(alpha: 0.82),
                    shape: BoxShape.circle,
                  ),
                );
              }),
            ),
          ),
          Positioned(
            bottom: 20,
            left: mirror ? null : 68,
            right: mirror ? 68 : null,
            child: Container(
              width: 56,
              height: 18,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(24),
                border: Border.all(color: color.withValues(alpha: 0.35)),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _dateCard(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final gregorian =
        '${_gregorianWeekdays[_loadedDate.weekday]}\u060C '
        '${_loadedDate.year}/${_two(_loadedDate.month)}/${_two(_loadedDate.day)}';
    final hijri = _hijriDateText(_loadedDate);

    return Container(
      padding: const EdgeInsets.fromLTRB(14, 12, 14, 12),
      decoration: BoxDecoration(
        color: Colors.white.withValues(alpha: 0.9),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: const Color(0x1FB9893C)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.end,
        children: <Widget>[
          Text(
            gregorian,
            textDirection: TextDirection.rtl,
            style: TextStyle(
              fontFamily: _fontType.toString(),
              color: scheme.onSurface,
              fontWeight: FontWeight.w700,
              fontSize: 15,
            ),
          ),
          const SizedBox(height: 3),
          Text(
            hijri,
            textDirection: TextDirection.rtl,
            style: TextStyle(
              fontFamily: _fontType.toString(),
              color: scheme.onSurfaceVariant,
              fontWeight: FontWeight.w600,
              fontSize: 13.8,
            ),
          ),
        ],
      ),
    );
  }

  Widget _prayerTableCard(
    BuildContext context, {
    required _PrayerProgress progress,
  }) {
    final scheme = Theme.of(context).colorScheme;
    final bool toNext = _countdownMode == _CountdownMode.toNext;
    final _NextPrayer next = progress.next;
    final _PreviousPrayer previous = progress.previous;
    final int activeIndex = toNext ? next.index : previous.index;
    final bool isFromOtherDay = toNext ? next.isTomorrow : previous.isYesterday;
    final String badgeLabel = toNext
        ? (next.isTomorrow
              ? '\u0633\u0628\u06d5\u06cc'
              : '\u062f\u0627\u0647\u0627\u062a\u0648\u0648')
        : (previous.isYesterday
              ? '\u062f\u0648\u06ce\u0646\u06ce'
              : '\u067e\u06ce\u0634\u0648\u0648');

    return Container(
      padding: const EdgeInsets.fromLTRB(12, 10, 12, 12),
      decoration: BoxDecoration(
        color: Colors.white.withValues(alpha: 0.9),
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: const Color(0x1FB9893C)),
        boxShadow: const <BoxShadow>[
          BoxShadow(
            color: Color(0x10000000),
            blurRadius: 16,
            offset: Offset(0, 7),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.end,
        children: <Widget>[
          Text(
            '\u06a9\u0627\u062a\u06d5\u06a9\u0627\u0646\u06cc \u0626\u06d5\u0645\u0695\u06c6',
            textDirection: TextDirection.rtl,
            style: TextStyle(
              fontFamily: _fontType.toString(),
              color: scheme.onSurface,
              fontWeight: FontWeight.w800,
              fontSize: 17,
            ),
          ),
          const SizedBox(height: 8),
          ...List<Widget>.generate(_todayMoments.length, (int index) {
            final moment = _todayMoments[index];
            final isActive = !isFromOtherDay && activeIndex == index;
            return AnimatedScale(
              duration: AppMotion.fast,
              curve: AppMotion.curve,
              scale: isActive ? 1.015 : 1,
              child: AnimatedContainer(
                duration: AppMotion.fast,
                curve: AppMotion.curve,
                margin: EdgeInsets.only(
                  bottom: index == _todayMoments.length - 1 ? 0 : 8,
                ),
                padding: const EdgeInsets.symmetric(
                  horizontal: 10,
                  vertical: 10,
                ),
                decoration: BoxDecoration(
                  color: isActive
                      ? scheme.primary.withValues(alpha: 0.12)
                      : scheme.surfaceContainerHighest.withValues(alpha: 0.28),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(
                    color: isActive
                        ? scheme.primary.withValues(alpha: 0.24)
                        : scheme.outline.withValues(alpha: 0.15),
                  ),
                ),
                child: Row(
                  children: <Widget>[
                    if (isActive)
                      Container(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 8,
                          vertical: 4,
                        ),
                        decoration: BoxDecoration(
                          color: scheme.primary.withValues(alpha: 0.18),
                          borderRadius: BorderRadius.circular(99),
                        ),
                        child: Text(
                          badgeLabel,
                          style: TextStyle(
                            fontFamily: _fontType.toString(),
                            color: scheme.primary,
                            fontSize: 11.5,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                      )
                    else
                      const SizedBox(width: 52),
                    const Spacer(),
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.end,
                      children: <Widget>[
                        Text(
                          moment.label,
                          textDirection: TextDirection.rtl,
                          style: TextStyle(
                            fontFamily: _fontType.toString(),
                            color: scheme.onSurface,
                            fontSize: 18.5,
                            fontWeight: isActive
                                ? FontWeight.w800
                                : FontWeight.w700,
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(width: 16),
                    Text(
                      _toTwelveHourClock(moment.timeLabel),
                      style: TextStyle(
                        fontFamily: 'english',
                        color: isActive
                            ? scheme.primary
                            : scheme.onSurfaceVariant,
                        fontSize: 28,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ],
                ),
              ),
            );
          }),
        ],
      ),
    );
  }

  Widget _loadingCard(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return Container(
      height: 210,
      decoration: BoxDecoration(
        color: Colors.white.withValues(alpha: 0.9),
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: const Color(0x1FB9893C)),
      ),
      alignment: Alignment.center,
      child: CircularProgressIndicator(
        strokeWidth: 3.2,
        valueColor: AlwaysStoppedAnimation<Color>(scheme.primary),
      ),
    );
  }

  Widget _errorCard(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return Container(
      padding: const EdgeInsets.fromLTRB(14, 18, 14, 14),
      decoration: BoxDecoration(
        color: Colors.white.withValues(alpha: 0.9),
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: const Color(0x1FB9893C)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.end,
        children: <Widget>[
          Text(
            _errorText ??
                '\u0647\u06D5\u06B5\u06D5\u06CC\u06D5\u06A9 \u0695\u0648\u0648\u06CC\u062F\u0627',
            textDirection: TextDirection.rtl,
            style: TextStyle(
              fontFamily: _fontType.toString(),
              color: scheme.error,
              fontWeight: FontWeight.w700,
              fontSize: 14.5,
            ),
          ),
          const SizedBox(height: 10),
          Align(
            alignment: Alignment.centerLeft,
            child: FilledButton.tonalIcon(
              onPressed: () => _loadPrayerTimes(showLoader: false),
              icon: const Icon(Icons.refresh_rounded),
              label: Text(
                '\u062F\u0648\u0648\u0628\u0627\u0631\u06D5 \u0647\u06D5\u0648\u06B5\u0628\u062F\u06D5\u0648\u06D5',
                style: TextStyle(fontFamily: _fontType.toString()),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _iconBubble(
    BuildContext context, {
    required IconData icon,
    required VoidCallback onTap,
    String? tooltip,
  }) {
    final scheme = Theme.of(context).colorScheme;
    final bubble = Material(
      color: Colors.transparent,
      child: InkWell(
        borderRadius: BorderRadius.circular(12),
        onTap: onTap,
        child: Ink(
          width: 40,
          height: 40,
          decoration: BoxDecoration(
            color: scheme.surfaceContainerHighest.withValues(alpha: 0.4),
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: scheme.outline.withValues(alpha: 0.2)),
          ),
          child: Icon(icon, color: scheme.onSurfaceVariant, size: 20),
        ),
      ),
    );
    if (tooltip == null || tooltip.trim().isEmpty) {
      return bubble;
    }
    return Tooltip(message: tooltip, child: bubble);
  }

  Widget _cityPickerPill(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final cityLabel =
        _city?.displayName ??
        '\u0647\u06D5\u06B5\u0628\u0698\u0627\u0631\u062F\u0646\u06CC \u0634\u0627\u0631';
    return Tooltip(
      message: '\u06AF\u06C6\u0695\u06CC\u0646\u06CC \u0634\u0627\u0631',
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          borderRadius: BorderRadius.circular(12),
          onTap: _openCityPicker,
          child: Ink(
            height: 40,
            padding: const EdgeInsets.symmetric(horizontal: 10),
            decoration: BoxDecoration(
              color: scheme.surfaceContainerHighest.withValues(alpha: 0.4),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: scheme.outline.withValues(alpha: 0.2)),
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: <Widget>[
                Icon(
                  Icons.keyboard_arrow_down_rounded,
                  color: scheme.onSurfaceVariant,
                  size: 18,
                ),
                const SizedBox(width: 4),
                Flexible(
                  child: Text(
                    cityLabel,
                    overflow: TextOverflow.ellipsis,
                    textDirection: TextDirection.rtl,
                    style: TextStyle(
                      fontFamily: _fontType.toString(),
                      color: scheme.onSurface,
                      fontSize: 13.2,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                ),
                const SizedBox(width: 6),
                Icon(
                  Icons.edit_location_alt_outlined,
                  color: scheme.onSurfaceVariant,
                  size: 18,
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Future<void> _openCityPicker() async {
    final cities = await _service.loadIraqiCities();
    if (!mounted || cities.isEmpty) return;

    String query = '';
    final selected = await showModalBottomSheet<PrayerCity>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (_) {
        final scheme = Theme.of(context).colorScheme;
        final maxHeight = MediaQuery.sizeOf(context).height * 0.76;
        return StatefulBuilder(
          builder: (context, modalSetState) {
            final filtered = cities
                .where((city) => _matchesCityQuery(city, query))
                .toList();

            return SafeArea(
              top: false,
              child: Container(
                margin: const EdgeInsets.fromLTRB(10, 0, 10, 10),
                padding: const EdgeInsets.fromLTRB(14, 12, 14, 14),
                decoration: BoxDecoration(
                  color: scheme.surface.withValues(alpha: 0.98),
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(
                    color: scheme.outline.withValues(alpha: 0.2),
                  ),
                ),
                child: ConstrainedBox(
                  constraints: BoxConstraints(maxHeight: maxHeight),
                  child: Column(
                    children: <Widget>[
                      Container(
                        width: 54,
                        height: 4,
                        decoration: BoxDecoration(
                          color: scheme.outline.withValues(alpha: 0.4),
                          borderRadius: BorderRadius.circular(99),
                        ),
                      ),
                      const SizedBox(height: 12),
                      Text(
                        '\u0647\u06D5\u06B5\u0628\u0698\u0627\u0631\u062F\u0646\u06CC \u0634\u0627\u0631',
                        textDirection: TextDirection.rtl,
                        style: TextStyle(
                          color: scheme.onSurface,
                          fontWeight: FontWeight.w800,
                          fontSize: 16,
                        ),
                      ),
                      const SizedBox(height: 10),
                      TextField(
                        textDirection: TextDirection.rtl,
                        decoration: const InputDecoration(
                          hintText:
                              '\u06AF\u06D5\u0695\u0627\u0646 \u0628\u06D5 \u0646\u0627\u0648\u06CC \u0634\u0627\u0631',
                          prefixIcon: Icon(Icons.search_rounded),
                        ),
                        onChanged: (value) {
                          modalSetState(() => query = value);
                        },
                      ),
                      const SizedBox(height: 10),
                      Expanded(
                        child: ListView.separated(
                          physics: const BouncingScrollPhysics(),
                          itemCount: filtered.length,
                          separatorBuilder: (_, _) => const SizedBox(height: 6),
                          itemBuilder: (context, index) {
                            final city = filtered[index];
                            final selected = city.id == _city?.id;
                            return Material(
                              color: Colors.transparent,
                              child: InkWell(
                                borderRadius: BorderRadius.circular(12),
                                onTap: () => Navigator.of(context).pop(city),
                                child: Ink(
                                  padding: const EdgeInsets.symmetric(
                                    horizontal: 12,
                                    vertical: 10,
                                  ),
                                  decoration: BoxDecoration(
                                    color: selected
                                        ? scheme.primary.withValues(alpha: 0.12)
                                        : scheme.surfaceContainerHighest
                                              .withValues(alpha: 0.32),
                                    borderRadius: BorderRadius.circular(12),
                                    border: Border.all(
                                      color: selected
                                          ? scheme.primary.withValues(
                                              alpha: 0.32,
                                            )
                                          : scheme.outline.withValues(
                                              alpha: 0.15,
                                            ),
                                    ),
                                  ),
                                  child: Row(
                                    children: <Widget>[
                                      Icon(
                                        selected
                                            ? Icons.check_circle_rounded
                                            : Icons.location_on_outlined,
                                        size: 20,
                                        color: selected
                                            ? scheme.primary
                                            : scheme.onSurfaceVariant,
                                      ),
                                      const SizedBox(width: 8),
                                      Expanded(
                                        child: Column(
                                          crossAxisAlignment:
                                              CrossAxisAlignment.end,
                                          children: <Widget>[
                                            Text(
                                              city.displayName,
                                              textDirection: TextDirection.rtl,
                                              textAlign: TextAlign.right,
                                              style: TextStyle(
                                                fontFamily: _fontType
                                                    .toString(),
                                                color: scheme.onSurface,
                                                fontSize: 14.2,
                                                fontWeight: selected
                                                    ? FontWeight.w800
                                                    : FontWeight.w600,
                                              ),
                                            ),
                                            if (city
                                                .manualPickerSubtitle
                                                .isNotEmpty) ...<Widget>[
                                              const SizedBox(height: 2),
                                              Text(
                                                city.manualPickerSubtitle,
                                                textDirection:
                                                    TextDirection.rtl,
                                                textAlign: TextAlign.right,
                                                maxLines: 1,
                                                overflow: TextOverflow.ellipsis,
                                                style: TextStyle(
                                                  fontFamily: _fontType
                                                      .toString(),
                                                  color:
                                                      scheme.onSurfaceVariant,
                                                  fontSize: 11.8,
                                                  fontWeight: FontWeight.w500,
                                                ),
                                              ),
                                            ],
                                          ],
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            );
                          },
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            );
          },
        );
      },
    );

    if (selected == null) return;
    _locationRequestId++;
    await _service.markLocationSelectionManual();
    if (selected.id == _city?.id) return;
    await _service.saveSelectedCity(selected.id);
    if (!mounted) return;
    await _loadPrayerTimes(showLoader: false);
  }

  bool _matchesCityQuery(PrayerCity city, String query) {
    final normalizedQuery = PrayerCity.normalizeSearchValue(query);
    if (normalizedQuery.isEmpty) return true;
    return city.searchText.contains(normalizedQuery);
  }

  // ignore: unused_element
  String _normalizeCitySearch(String value) {
    return value
        .trim()
        .toLowerCase()
        .replaceAll(RegExp(r'[_\-\s]+'), '')
        .replaceAll('ة', 'ه')
        .replaceAll('ى', 'ي')
        .replaceAll('أ', 'ا')
        .replaceAll('إ', 'ا')
        .replaceAll('آ', 'ا');
  }

  Future<void> _requestLocationOnOpen() async {
    if (_didAutoPromptOnOpen || !mounted) return;
    _didAutoPromptOnOpen = true;
    while (_isRefreshing && mounted) {
      await Future<void>.delayed(const Duration(milliseconds: 180));
    }
    if (!mounted) return;
    final shouldAutoResolve = await _service.shouldAutoResolveLocation();
    if (!mounted || !shouldAutoResolve) return;
    await _autoDetectAndSetCity(
      showSuccessSnack: false,
      showFailureSnack: false,
    );
  }

  Future<void> _autoDetectAndSetCity({
    bool showSuccessSnack = true,
    bool showFailureSnack = true,
  }) async {
    if (_isRefreshing) return;
    final requestId = ++_locationRequestId;

    try {
      final serviceEnabled = await Geolocator.isLocationServiceEnabled();
      if (!serviceEnabled) {
        if (showFailureSnack) {
          _snack('GPS ناچالاکە. دەتوانیت شار بە دەستی هەڵبژێریت.');
        }
        return;
      }

      LocationPermission permission = await Geolocator.checkPermission();
      if (permission == LocationPermission.denied ||
          permission == LocationPermission.unableToDetermine) {
        permission = await Geolocator.requestPermission();
      }

      if (permission == LocationPermission.denied) {
        if (showFailureSnack) {
          _snack('مۆڵەتی شوێن نەدرا. دەتوانیت شار بە دەستی هەڵبژێریت.');
        }
        return;
      }
      if (permission == LocationPermission.deniedForever) {
        if (showFailureSnack) {
          _snack(
            'مۆڵەتی شوێن لە Settings چالاک بکە یان شار بە دەستی هەڵبژێرە.',
          );
        }
        return;
      }

      final position = await _resolveDevicePosition();

      final nearest = await _service.findNearestCity(
        latitude: position.latitude,
        longitude: position.longitude,
      );

      if (nearest == null) {
        if (showFailureSnack) {
          _snack('شارێکی گونجاو نەدۆزرایەوە.');
        }
        return;
      }

      if (!mounted || requestId != _locationRequestId) return;
      await _service.markLocationSelectionAutomatic();
      await _service.saveSelectedCity(nearest.id);
      if (!mounted || requestId != _locationRequestId) return;
      await _loadPrayerTimes(showLoader: false);
      if (!mounted || requestId != _locationRequestId) return;
      if (showSuccessSnack) {
        _snack(
          '\u0634\u0648\u06CE\u0646 \u062F\u06CC\u0627\u0631\u06A9\u0631\u0627 \u0648 \u06A9\u0627\u062A\u06D5\u06A9\u0627\u0646 \u0646\u0648\u06CE\u06A9\u0631\u0627\u0646\u06D5\u0648\u06D5.',
        );
      }
    } on PermissionRequestInProgressException {
      if (!mounted || !showFailureSnack) return;
      _snack('داواکاری مۆڵەتی شوێن لە پێشدا کراوە. تکایە چاوەڕوان بە.');
    } on PermissionDefinitionsNotFoundException {
      if (!mounted || !showFailureSnack) return;
      _snack(
        'ڕێکخستنی مۆڵەتی شوێن تەواو نییە. دەتوانیت شار بە دەستی هەڵبژێریت.',
      );
    } on LocationServiceDisabledException {
      if (!mounted || !showFailureSnack) return;
      _snack('GPS ناچالاکە. دەتوانیت شار بە دەستی هەڵبژێریت.');
    } on TimeoutException {
      if (!mounted || !showFailureSnack) return;
      _snack('شوێن بە خێرایی نەدۆزرایەوە. دەتوانیت شار بە دەستی هەڵبژێریت.');
    } on StateError {
      if (!mounted || !showFailureSnack) return;
      _snack('شوێنی ئێستا نەدۆزرایەوە. لە شوێنێکی کراوەتر دووبارە هەوڵ بدەوە.');
    } on PlatformException catch (error, stackTrace) {
      debugPrint(
        'Prayer location platform error: ${error.code} ${error.message}',
      );
      debugPrintStack(stackTrace: stackTrace);
      if (!mounted || !showFailureSnack) return;
      _snack(
        '\u062F\u06C6\u0632\u06CC\u0646\u06D5\u0648\u06D5\u06CC \u0634\u0648\u06CE\u0646 \u0633\u06D5\u0631\u06A9\u06D5\u0648\u062A\u0648\u0648 \u0646\u06D5\u0628\u0648\u0648.',
      );
    } catch (error, stackTrace) {
      debugPrint('Prayer location detection failed: $error');
      debugPrintStack(stackTrace: stackTrace);
      if (!mounted || !showFailureSnack) return;
      _snack(
        '\u062F\u06C6\u0632\u06CC\u0646\u06D5\u0648\u06D5\u06CC \u0634\u0648\u06CE\u0646 \u0633\u06D5\u0631\u06A9\u06D5\u0648\u062A\u0648\u0648 \u0646\u06D5\u0628\u0648\u0648.',
      );
    }
  }

  Future<Position> _resolveDevicePosition() async {
    Position? cachedPosition;
    try {
      cachedPosition = await Geolocator.getLastKnownPosition();
    } catch (_) {}
    if (Platform.isAndroid && cachedPosition == null) {
      try {
        cachedPosition = await Geolocator.getLastKnownPosition(
          forceAndroidLocationManager: true,
        );
      } catch (_) {}
    }

    final attempts =
        <({LocationAccuracy accuracy, bool forceManager, Duration timeout})>[
          (
            accuracy: LocationAccuracy.best,
            forceManager: false,
            timeout: const Duration(seconds: 16),
          ),
          (
            accuracy: LocationAccuracy.high,
            forceManager: false,
            timeout: const Duration(seconds: 12),
          ),
          (
            accuracy: LocationAccuracy.medium,
            forceManager: false,
            timeout: const Duration(seconds: 10),
          ),
          if (Platform.isAndroid)
            (
              accuracy: LocationAccuracy.medium,
              forceManager: true,
              timeout: const Duration(seconds: 10),
            ),
        ];

    Object? lastError;
    for (final attempt in attempts) {
      try {
        final position = await Geolocator.getCurrentPosition(
          desiredAccuracy: attempt.accuracy,
          forceAndroidLocationManager: attempt.forceManager,
          timeLimit: attempt.timeout,
        );
        if (_isUsablePosition(position)) {
          return position;
        }
        cachedPosition ??= position;
      } on TimeoutException catch (error) {
        lastError = error;
      } on LocationServiceDisabledException {
        rethrow;
      } catch (error) {
        lastError = error;
      }
    }

    if (_isUsablePosition(cachedPosition)) {
      return cachedPosition!;
    }

    if (lastError is TimeoutException) {
      throw lastError;
    }

    final servicesEnabled = await Geolocator.isLocationServiceEnabled();
    if (!servicesEnabled) {
      throw const LocationServiceDisabledException();
    }

    throw StateError('Unable to resolve current position.');
  }

  bool _isUsablePosition(Position? position) {
    if (position == null) return false;
    if (position.latitude.abs() < 0.0001 && position.longitude.abs() < 0.0001) {
      return false;
    }
    return true;
  }

  Future<void> _loadPrayerTimes({bool showLoader = true}) async {
    if (_isRefreshing) return;
    _isRefreshing = true;
    if (showLoader) {
      setState(() {
        _isLoading = true;
        _errorText = null;
      });
    }

    try {
      final now = DateTime.now();
      final todayDate = DateTime(now.year, now.month, now.day);
      final data = await _service.loadForDate(todayDate);
      if (!mounted) return;
      setState(() {
        _city = data.city;
        _todayMoments = data.today;
        _tomorrowMoments = data.tomorrow;
        _yesterdayMoments = data.yesterday;
        _loadedDate = todayDate;
        _now = now;
        _errorText = null;
        _isLoading = false;
      });
      if (PlatformFeatureFlags.supportsPrayerWidgets) {
        unawaited(_syncHomeWidget());
      }
    } catch (_) {
      if (!mounted) return;
      setState(() {
        _isLoading = false;
        _errorText =
            '\u0647\u06CE\u0646\u0627\u0646\u06CC \u06A9\u0627\u062A\u06D5\u06A9\u0627\u0646\u06CC \u0646\u0648\u06CE\u0698 \u0633\u06D5\u0631\u06A9\u06D5\u0648\u062A\u0648\u0648 \u0646\u06D5\u0628\u0648\u0648.';
      });
    } finally {
      _isRefreshing = false;
    }
  }

  _PrayerProgress _resolvePrayerProgress() {
    return _PrayerProgress(
      next: _resolveNextPrayer(),
      previous: _resolvePreviousPrayer(),
    );
  }

  Future<void> _syncHomeWidget() async {
    if (!PlatformFeatureFlags.supportsPrayerWidgets) return;
    if (_city == null) return;
    final next = _resolveNextPrayer();
    final nextPrayer = next.moment;
    final rows = _buildWidgetRows();
    await PrayerHomeWidgetService.update(
      city: _city!.displayName,
      nextLine:
          '\u0628\u0627\u0646\u06AF\u06CC ${nextPrayer?.label ?? '---'} \u067E\u0627\u0634',
      nextTime: nextPrayer != null
          ? _toTwelveHourClock(nextPrayer.timeLabel)
          : '--:--',
      remaining: _formatWidgetRemaining(next.remaining),
      dateText: '${_two(_loadedDate.day)}/${_two(_loadedDate.month)}',
      rowNames: rows.map((e) => e.label).toList(),
      rowTimes: rows.map((e) => _toTwelveHourClock(e.timeLabel)).toList(),
    );
  }

  List<PrayerMoment> _buildWidgetRows() {
    if (_todayMoments.length >= 6) {
      return <PrayerMoment>[
        _todayMoments[0],
        _todayMoments[2],
        _todayMoments[3],
        _todayMoments[4],
        _todayMoments[5],
      ];
    }
    if (_todayMoments.length <= 5) {
      return List<PrayerMoment>.from(_todayMoments);
    }
    return _todayMoments.take(5).toList();
  }

  String _formatWidgetRemaining(Duration duration) {
    final safe = duration.isNegative ? Duration.zero : duration;
    final hours = safe.inHours;
    final minutes = safe.inMinutes % 60;
    if (hours > 0) {
      return '$hours hr, $minutes min';
    }
    return '$minutes min';
  }

  _NextPrayer _resolveNextPrayer() {
    for (int i = 0; i < _todayMoments.length; i++) {
      final moment = _todayMoments[i];
      if (!moment.dateTime.isBefore(_now)) {
        return _NextPrayer(
          moment: moment,
          index: i,
          isTomorrow: false,
          remaining: moment.dateTime.difference(_now),
        );
      }
    }

    if (_tomorrowMoments.isNotEmpty) {
      final tomorrow = _tomorrowMoments.first;
      return _NextPrayer(
        moment: tomorrow,
        index: 0,
        isTomorrow: true,
        remaining: tomorrow.dateTime.difference(_now),
      );
    }

    return const _NextPrayer.empty();
  }

  _PreviousPrayer _resolvePreviousPrayer() {
    for (int i = _todayMoments.length - 1; i >= 0; i--) {
      final moment = _todayMoments[i];
      if (!moment.dateTime.isAfter(_now)) {
        return _PreviousPrayer(
          moment: moment,
          index: i,
          isYesterday: false,
          elapsed: _now.difference(moment.dateTime),
        );
      }
    }

    if (_yesterdayMoments.isNotEmpty) {
      final index = _yesterdayMoments.length - 1;
      final moment = _yesterdayMoments[index];
      return _PreviousPrayer(
        moment: moment,
        index: index,
        isYesterday: true,
        elapsed: _now.difference(moment.dateTime),
      );
    }

    return const _PreviousPrayer.empty();
  }

  void _snack(String message) {
    if (!mounted) return;
    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(
        SnackBar(
          behavior: SnackBarBehavior.floating,
          duration: const Duration(seconds: 2),
          content: Text(
            message,
            textDirection: TextDirection.rtl,
            style: TextStyle(fontFamily: _fontType.toString()),
          ),
        ),
      );
  }

  String _hijriDateText(DateTime date) {
    final hijri = HijriCalendar.fromDate(date);
    final monthName = hijri.getLongMonthName();
    return '${hijri.hDay} $monthName ${hijri.hYear}';
  }

  String _two(int value) => value.toString().padLeft(2, '0');

  String _toTwelveHourClock(String hhmm) {
    final split = hhmm.split(':');
    if (split.length != 2) return hhmm;
    final hour24 = int.tryParse(split[0]);
    final minute = int.tryParse(split[1]);
    if (hour24 == null || minute == null) return hhmm;
    final hour12 = hour24 % 12 == 0 ? 12 : hour24 % 12;
    return '${_two(hour12)}:${_two(minute)}';
  }

  bool _isSameDay(DateTime a, DateTime b) {
    return a.year == b.year && a.month == b.month && a.day == b.day;
  }
}

class _PrayerProgress {
  const _PrayerProgress({required this.next, required this.previous});

  final _NextPrayer next;
  final _PreviousPrayer previous;
}

class _NextPrayer {
  const _NextPrayer({
    required this.moment,
    required this.index,
    required this.isTomorrow,
    required this.remaining,
  });

  const _NextPrayer.empty()
    : moment = null,
      index = -1,
      isTomorrow = false,
      remaining = Duration.zero;

  final PrayerMoment? moment;
  final int index;
  final bool isTomorrow;
  final Duration remaining;
}

class _PreviousPrayer {
  const _PreviousPrayer({
    required this.moment,
    required this.index,
    required this.isYesterday,
    required this.elapsed,
  });

  const _PreviousPrayer.empty()
    : moment = null,
      index = -1,
      isYesterday = false,
      elapsed = Duration.zero;

  final PrayerMoment? moment;
  final int index;
  final bool isYesterday;
  final Duration elapsed;
}
