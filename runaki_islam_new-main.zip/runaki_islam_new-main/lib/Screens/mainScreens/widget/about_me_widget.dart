import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:runaki_islam/providers/settings_provider.dart';
import 'package:runaki_islam/util/animation_helper.dart';
import 'package:runaki_islam/util/constans.dart';
import 'package:url_launcher/url_launcher.dart';

class AboutMe extends StatefulWidget {
  const AboutMe({super.key});

  @override
  State<AboutMe> createState() => _AboutMeState();
}

class _AboutMeState extends State<AboutMe> {
  int? fontType;
  static const String _partnerLogoAsset = 'assets/images/shauq.jpg';

  static const String _aboutText =
      "سڵاو! من ناوم ئەمین صمد. من گەشەپێدەری پێشەوەم و هەروەها دیزاینەری ڕووكارەكانم، و زۆر بەسۆز و تەرخانم بۆ کارەکانم بە هێمنی و سەركەوتووی كارەكانم ئەنجام دەدەم. بە ئەزموونی 6 ساڵ وەک Front End Developer ، ئەو لێهاتوویی و زانیارییەم بەدەستهێناوە کە پێویستن بۆ سەرخستنی پڕۆژەکەت. چێژ لە هەموو هەنگاوێکی پرۆسەی دیزاین و كۆدكردن وەردەگرم ەمیشە ئەو ڕێگایە دەگرمە بەر كە بەكارهێنەر تیایدا دڵخۆش و ئاسوودە دەبێت گرنگ نییە چەنێك ماندوو دەبین.";

  @override
  void initState() {
    super.initState();
    fontType = Provider.of<SettingsProvider>(
      context,
      listen: false,
    ).getsettingField('font_family');
  }

  Future<void> _openUrl(String url) async {
    final uri = Uri.parse(url);
    final launched = await launchUrl(uri, mode: LaunchMode.externalApplication);
    if (!launched) {
      debugPrint('Could not open: $url');
    }
  }

  @override
  Widget build(BuildContext context) {
    return DecoratedBox(
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [
            const Color(0xFFFDF8EE),
            Theme.of(context).colorScheme.surface,
            bgColor,
          ],
        ),
      ),
      child: SingleChildScrollView(
        physics: const BouncingScrollPhysics(
          parent: AlwaysScrollableScrollPhysics(),
        ),
        child: SafeArea(
          bottom: false,
          child: Column(
            children: [
              const SizedBox(height: 12),
              FadeSlideIn(
                child: _card(
                  child: Column(
                    children: [
                      Container(
                        width: 108,
                        height: 108,
                        padding: const EdgeInsets.all(3),
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          border: Border.all(
                            color: kActiveIconColor.withValues(alpha: 0.35),
                            width: 2,
                          ),
                        ),
                        child: const CircleAvatar(
                          backgroundImage: AssetImage(
                            'assets/images/my-picture.jpg',
                          ),
                        ),
                      ),
                      const SizedBox(height: 12),
                      Text(
                        "ئەمین صمد",
                        style: TextStyle(
                          fontFamily: fontType.toString(),
                          color: kTextColor,
                          fontSize: 26,
                          fontWeight: FontWeight.w800,
                        ),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        "گەشەپێدەری پێشەوە و دیزاینەری ڕووکار",
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          fontFamily: fontType.toString(),
                          color: titleTextColor,
                          fontSize: 14.5,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 12),
              FadeSlideIn(
                delay: const Duration(milliseconds: 70),
                child: _card(
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      _socialButton(
                        icon: Icons.camera_alt_outlined,
                        onTap: () =>
                            _openUrl("https://www.instagram.com/amin._.samad/"),
                      ),
                      _socialButton(
                        icon: Icons.facebook_rounded,
                        onTap: () => _openUrl(
                          "https://www.facebook.com/amin.samad.14418",
                        ),
                      ),
                      _socialButton(
                        icon: Icons.chat_bubble_outline_rounded,
                        onTap: () => _openUrl(
                          "https://www.snapchat.com/add/amin_samad2",
                        ),
                      ),
                      _socialButton(
                        icon: Icons.phone_rounded,
                        onTap: () => _openUrl("tel:+9647812560377"),
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 12),
              FadeSlideIn(
                delay: const Duration(milliseconds: 110),
                child: _card(
                  child: Directionality(
                    textDirection: TextDirection.rtl,
                    child: Text(
                      _aboutText,
                      textAlign: TextAlign.right,
                      style: TextStyle(
                        fontFamily: fontType.toString(),
                        color: const Color(0xFF3C2E20),
                        height: 1.8,
                        fontSize: 15.5,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 12),
              FadeSlideIn(
                delay: const Duration(milliseconds: 140),
                child: _card(child: _partnerCard()),
              ),
              const SizedBox(height: 12),
              FadeSlideIn(
                delay: const Duration(milliseconds: 170),
                child: _card(
                  child: Material(
                    color: Colors.transparent,
                    child: InkWell(
                      borderRadius: BorderRadius.circular(14),
                      onTap: () => _openUrl("https://aminsamad.com"),
                      child: Ink(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 12,
                          vertical: 12,
                        ),
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(14),
                          color: const Color(0xFFFFF3DD),
                          border: Border.all(color: const Color(0x2FB9893C)),
                        ),
                        child: Row(
                          children: [
                            const Icon(
                              Icons.open_in_new_rounded,
                              color: Color(0xFF8C6832),
                            ),
                            const SizedBox(width: 10),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    "Visit my website",
                                    style: TextStyle(
                                      fontFamily: fontType.toString(),
                                      color: const Color(0xFF8C6832),
                                      fontSize: 13,
                                      fontWeight: FontWeight.w600,
                                    ),
                                  ),
                                  const SizedBox(height: 2),
                                  Text(
                                    "aminsamad.com",
                                    style: TextStyle(
                                      fontFamily: fontType.toString(),
                                      color: const Color(0xFF3A2D1E),
                                      fontSize: 17,
                                      fontWeight: FontWeight.w800,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 120),
            ],
          ),
        ),
      ),
    );
  }

  Widget _card({required Widget child}) {
    return Container(
      width: double.infinity,
      margin: const EdgeInsets.symmetric(horizontal: 14),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Colors.white.withValues(alpha: 0.92),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: const Color(0x1FB9893C)),
        boxShadow: const [
          BoxShadow(
            color: Color(0x12000000),
            blurRadius: 18,
            offset: Offset(0, 8),
          ),
        ],
      ),
      child: child,
    );
  }

  Widget _socialButton({required IconData icon, required VoidCallback onTap}) {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        borderRadius: BorderRadius.circular(12),
        onTap: onTap,
        child: Ink(
          width: 48,
          height: 48,
          decoration: BoxDecoration(
            color: const Color(0xFFFFF3DD),
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: const Color(0x2FB9893C)),
          ),
          child: Icon(icon, color: const Color(0xFF8C6832)),
        ),
      ),
    );
  }

  Widget _partnerCard() {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            "هاوبەش",
            style: TextStyle(
              fontFamily: fontType.toString(),
              color: const Color(0xFF8C6832),
              fontSize: 13,
              fontWeight: FontWeight.w700,
            ),
          ),
          const SizedBox(height: 10),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(16),
              color: const Color(0xFFFFF8EC),
              border: Border.all(color: const Color(0x26B9893C)),
            ),
            child: Row(
              children: [
                Container(
                  width: 46,
                  height: 46,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: Colors.white,
                    border: Border.all(color: const Color(0x14000000)),
                  ),
                  clipBehavior: Clip.antiAlias,
                  child: Padding(
                    padding: const EdgeInsets.all(5),
                    child: Image.asset(
                      _partnerLogoAsset,
                      fit: BoxFit.contain,
                      errorBuilder: (context, error, stackTrace) {
                        return Container(
                          decoration: const BoxDecoration(
                            shape: BoxShape.circle,
                            gradient: LinearGradient(
                              begin: Alignment.topLeft,
                              end: Alignment.bottomRight,
                              colors: [Color(0xFFFF6A5E), Color(0xFFD91F11)],
                            ),
                          ),
                          alignment: Alignment.center,
                          child: const Icon(
                            Icons.wifi_rounded,
                            color: Colors.white,
                            size: 20,
                          ),
                        );
                      },
                    ),
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        "شوق الفجر",
                        style: TextStyle(
                          fontFamily: fontType.toString(),
                          color: kTextColor,
                          fontSize: 15.5,
                          fontWeight: FontWeight.w800,
                        ),
                      ),
                      const SizedBox(height: 2),
                      Text(
                        "هاوبەشی پشتگیری ئەم ئەپە",
                        style: TextStyle(
                          fontFamily: fontType.toString(),
                          color: titleTextColor,
                          fontSize: 12.5,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
