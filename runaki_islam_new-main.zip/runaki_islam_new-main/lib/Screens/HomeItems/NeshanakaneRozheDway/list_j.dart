import 'package:runaki_islam/Screens/HomeItems/Pexambarman/page_view.dart';
import 'package:flutter/material.dart';
import 'package:flutter_staggered_animations/flutter_staggered_animations.dart';
import 'package:runaki_islam/Screens/HomeItems/NeshanakaneRozheDway/list_a.dart';
import 'package:runaki_islam/util/background.dart';
import 'package:runaki_islam/util/constans.dart';
import 'package:page_transition/page_transition.dart';
import 'package:runaki_islam/providers/settings_provider.dart';
import 'package:provider/provider.dart';

class ListPageJ extends StatefulWidget {
  final String? sarder;

  const ListPageJ({super.key, this.sarder});
  @override
  State<StatefulWidget> createState() => _ListPageState();
}

class _ListPageState extends State<ListPageJ> {
  List<MyListViewitems> soranij = [];
  int? fontType;
  @override
  void initState() {
    super.initState();
    fontType = Provider.of<SettingsProvider>(context, listen: false)
        .getsettingField('font_family');
    soranij.add(MyListViewitems(
      drezha:
          "ئەکات و ڕایاندەکێشێت بۆ شوێنی حەشربوونیان!!\n\nلە نیشانەگەورەکانی هاتنی ڕۆژی دوایی کە کوتاییەکەتی ئاگرێک لە یەمەنەوە هەڵدەگیرسێت کە خەڵکی ڕاو ئەنێت بۆ شوێنی حەشربوونیان خاکی مەحشەریش خاکێکی سپییە و ڕاست و تەختە کەس نییە کە ڕێنیشاندەری خەڵکەکە بێت ڕێگا بە خەڵکەکە نیشان بدات!! (جگە لەو ئاگرە)\n\n٭سیفەتی ئەو ئاگرە چۆنە؟\n\n٭چۆن دەردەچێت؟\n\n٭لەکوێیەوە دەر ئەچێت؟\n\n٭چی ڕوو ئەدات لەدوای ئەوەوە؟\n\n",
      sarder: "ئاگرێک هەڵدەستێت کە خەڵکی پەلکێش",
    ));
    soranij.add(MyListViewitems(
      drezha:
          "پێغەمبەری خوا صلی الله علیە وسلم) دەفەرمووێت:\n\n ( إِنَّهَا لَنْ تَقُومَ حَتَّى تَرَوْنَ قَبْلَهَا عَشْرَ آيَاتٍ فَذَكَرَ الدُّخَانَ وَالدَّجَّالَ وَالدَّابَّةَ ، وَطُلُوعَ الشَّمْسِ مِنْ مَغْرِبِهَا ، وَنُزُولَ عِيسَى ابْنِ مَرْيَمَ وَيَأَجُوجَ وَمَأْجُوجَ ، وَثَلَاثَةَ خُسُوفٍ : خَسْفٌ بِالْمَشْرِقِ ، وَخَسْفٌ بِالْمَغْرِبِ ،  وَخَسْفٌ بِجَزِيرَةِ الْعَرَبِ ، وَآخِرُ ذَلـِكَ نَارٌ تَخْرُجُ مِنَ الْيَمَنِ تَطْرُدُ النَّاسَ إِلَى مَحْشَرِهِمْ )(صحيح مسلم (٥١٦٧) عَنْ أَبِي هُرَيْرَةَ (رَضيَ اللهُ عَنَهُ ).\n\nواتە: قیامەت هەڵناسێت تاکوو پێش ئەوە دە نیشانە نەبینن لەوانەی باسی کرد لە دوکەڵ و دەججال و ئاژەڵ وهەڵهاتنی خۆر لە خۆرئاواوە دابەزینی عیسای کوڕی مەریەم (سەلامی خوای لێ بێت)و یاجووج و مەجووج و سێ ڕۆچوون کە یەکیان لە ڕۆژهەڵات و یەکیان لە رۆژئاواو ئەوی تر لە دوورگەی عەڕەبی ڕووئەدەن دوایینیان دەرکەوتنی ئاگرێکی گەورەیە کە لەیەمەن هەڵدەستێت و خەڵکی ڕاو ئەنێت بۆ شوێنی حەشربوونیان!.)هەروەها دەفەرمووێت: \n \n( نَارٌ تَخْرُجُ مِنْ قُعْرَةِ عَدَنٍ تَرْحَلُ النَّاسَ )(رواه مسلم (٢٩٠١) عَنْ أَبِي سَرِيَحةَ حُذَيْفَةَ بْنَ أَسِيدٍ ( رَضيَ اللهُ عَنَهُ ).\n\nواتە: ئاگرێک لە چاڵایی عەدەنەوە (لەیەمەن) دەردەچێت خەڵکی پاڵ ئەنێت (بۆ شوێنی حەشربوونیان).هەروەها دەفەرمووێت:\n\n( سَتَخْرُجُ نَارٌ مِنْ حَضْرَمَوْتَ أَوْ مِنْ نَحْوِ بَحْرِ حَضْرَمَوْتَ قَبْلَ يَوْمِ الْقِيَامَةِ تَحْشُرُ النَّاسَ قَالُوا يَا رَسُولَ اللهِ فَمَا تَأْمُرُنَا؟ قَالَ عَلَيْكُمْ بِالشَّامِ )( رواه احمد صحيح عَنْ سَالِمِ بْنَ عَبْدِ اللهِ بْنَ عُمَرَ عَنْ أَبِيهِ (رَضيَ اللهُ عَنَهم) صحيح الجامع (٣٦٠٩) .\n\nواتە: لە حەزرەمەوت ئاگرێک هەڵدەستێت یاخود لەدەروبەری ڕوباری حەزوەمەوتەوە پێش هاتنی ڕۆژی دوایی هەڵدەستێت و پاڵ بەخەڵکی ئەنێت بۆ کۆبوونەوە کوتیان ئەی پێغەمبەری خوا (صلی اللە علیە وسلم ) فەرمانى چیمان پێ ئەکەیت؟ فەرمووی ڕاکەن بەرەو شام!!!\n\n",
      sarder: "قیامەت هەڵناسێت تاکوو پێش ئەو دە نیشانە نەبینن",
    ));
    soranij.add(MyListViewitems(
      drezha:
          "پێغەمبەری خوا(صی الله علیە وسلم) دەفەرمووێت:\n\nعَنْ أَنَسٍ رَضِيَ اللَّهُ عَنْهُ قَالَ بَلَغَ عَبْدَ اللَّهِ بْنَ سَلامٍ مَقْدَمُ رَسُولِ اللَّهِ صَلَّى اللَّهُ عَلَيْهِ وَسَلَّمَ الْمَدِينَةَ فَأَتَاهُ فَقَالَ إِنِّي سَائِلُكَ عَنْ ثَلاثٍ لا يَعْلَمُهُنَّ إِلا نَبِيٌّ ، قَالَ : مَا أَوَّلُ أَشْرَاطِ السَّاعَةِ وَمَا أَوَّلُ طَعَامٍ يَأْكُلُهُ أَهْلُ الْجَنَّةِ وَمِنْ أَيِّ شَيْءٍ يَنْزِعُ الْوَلَدُ إِلَى أَبِيهِ وَمِنْ أَيِّ شَيْءٍ يَنْزِعُ إِلَى أَخْوَالِهِ فَقَالَ رَسُولُ اللَّهِ صَلَّى اللَّهُ عَلَيْهِ وَسَلَّمَ خَبَّرَنِي بِهِنَّ آنِفًا جِبْرِيلُ قَالَ فَقَالَ عَبْدُ اللَّهِ ذَاكَ عَدُوُّ الْيَهُودِ مِنْ الْمَلائِكَةِ فَقَالَ رَسُولُ اللَّهِ صَلَّى اللَّهُ عَلَيْهِ وَسَلَّمَ أَمَّا أَوَّلُ أَشْرَاطِ السَّاعَةِ فَنَارٌ تَحْشُرُ النَّاسَ مِنْ الْمَشْرِقِ إِلَى الْمَغْرِبِ وَأَمَّا أَوَّلُ طَعَامٍ يَأْكُلُهُ أَهْلُ الْجَنَّةِ فَزِيَادَةُ كَبِدِ حُوتٍ وَأَمَّا الشَّبَهُ فِي الْوَلَدِ فَإِنَّ الرَّجُلَ إِذَا غَشِيَ الْمَرْأَةَ فَسَبَقَهَا مَاؤُهُ كَانَ الشَّبَهُ لَهُ وَإِذَا سَبَقَ مَاؤُهَا كَانَ الشَّبَهُ لَهَا قَالَ أَشْهَدُ أَنَّكَ رَسُولُ اللَّهِ )( صحيح البخاري (٣١٠٣).\n\nواتە: ئەنەسی کوڕی مالیک (خوا لێی ڕازی بێت) دەلێت: عەبدوڵڵای کوڕی سەلام پێی گەیشت کەوا پێغەمبەر(صی الله علیە وسلم) هاتۆتە مەدینە هاتە لای و پێی گوت من (30)سی پرسیارت لێ ئەکەم کە هیچ کەس وەڵامەکەی نازانێت پێغەمبەر نەبێت گوتی یەکەم نیشانەکانی قیامەت چییە؟ وە یەکەم خواردن کە بەهەشتییەکان ئەیخۆن لە بەهەشت چییە؟ وە منداڵ کەی شێوەی لە باوکی ئەچێت؟ وە لە چی شتێک بە خاڵوانی ئەچێت؟ پێغەمبەر(صلی الله علیە وسلم) فەرمووی تاوێ بەر لە ئیستا جوبریل پێی ڕاگەیاندم کەوا یەکەم نیشانەکانی قیامەت هەڵسانی ئاگرێکە خەڵکی لە خۆرهەڵاتەوە پاڵ ئەنێت بەرەو خۆرئاوا بەڵام لەبارەی یەکەم خۆراک کە  بەهەشتییەکان ئەیخۆن جگەری حووتە، وە کەی منداڵ لە باوکی ئەچێت ئەوە ئەوەیە گەر ئاوی پیاو پێش ئاوی ئافرەت کەوت ئەوە لە باوکی ئەچێت وە ئەگەر ئاوی ژن پێش ئاوی مێردەکەی کەوت ئەوە ئەو منداڵە بە دایکی ئەچێت (باوکی بەخاڵوانی ئەچێت) عەبدوڵڵای کوڕی سەلام کە ئەو وەڵامەی بیست یەکسەر شایەتی هێناو گوتی شایەتی ئەدەم کە تۆ پێغەمبەریت.\n\n",
      sarder: "جوبریل پێی ڕاگەیاندم یەکەم نیشانەکانی قیامەت هەڵسانی ئاگرێکە",
    ));
    soranij.add(MyListViewitems(
      drezha:
          "پێغەمبەری خوا (صلی الله علیە وسلم) دەفەرمووێت:\n\n(( يُحْشَرُ النَّاسُ عَلَى ثَلاثِ طَرَائِقَ رَاغِبِينَ رَاهِبِينَ، اثْنَانِ عَلَى بَعِيرٍ، وَثَلاثَةٌ عَلَى بَعِيرٍ، وَأَرْبَعَةٌ عَلَى بَعِيرٍ، وَعَشَرَةٌ عَلَى بَعِيرٍ، وَتَحْشُرُ بَقِيَّتَهُمُ النَّارُ، تَقِيلُ مَعَهُمْ حَيْثُ قَالُوا، وَتَبِيتُ مَعَهُمْ حَيْثُ بَاتُوا ، وَتُصْبِحُ مَعَهُمْ حَيْثُ أَصْبَحُوا، وَتُمْسِي مَعَهُمْ حَيْثُ أَمْسَوْا )( البخاری /الرقاق/٦۱٥۷٤)عن ٲبی هریرە (رضي الله عنه) .\n\nواتە: خەڵکی لەسەر سێ حاڵەت کۆدەکرێتەوە هەیانە دڵی خۆشە هەیانە لە ترس و لەرزدایە دووان لە سەر وشترێک و سێان لەسەر وشترێک و چوار لەسەر وشترێک و دە لەسەر وشترێک ئینجا ئەوانی تریان ئاگر کۆیاندەکاتەوە شەویان لەگەڵ دەکاتەوە لە هەر کوێ شەو بکەنەوەو نیوەڕۆ خەویان لەگەڵ دەکات لە هەرکوێ نیوەرۆ خەو بکەن و ڕۆژیان لەگەڵ دەکاتەوە لەهەر کوێ رۆژ بکەنەوە ئێوارەیان لەگەڵ دەکاتەوە لەهەر کوێ ئێوارە بکەنەوە).\n(مەبەست کۆکردنەوەی دونیایە پێش فووکردنی یەکەم بە کەڕەنادا)\n\nماناکەی ئەوەیە کە ئەو ئاگرە خەڵکی ناسووتێنێت بەڵکوو پاڵیان پێوەدەنێت بۆ حەشربوونیان لە شام! کاتێ خەڵکەکە لە ڕۆیشتن ماندوو ئەبن و توشی کەمە خەوێک (القیلولة) دێت هەرکە خەوتن ئاگرەکە ئەوەستێ !! کە بێداربوونەوە هەم دیسان ئاگرەکە پاڵیان پێوە ئەنێتەوە بەم شێوە بەردەوام ئەبن هەموویان لەشام کو ئەبنەوە.\n\n",
      sarder: "خەڵکی چۆن حەشر ئەبن؟",
    ));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bgColor,
      appBar: AppBar(
        toolbarHeight: 80,
        backgroundColor: thirdColor,
        title: Text(
          "${widget.sarder}",
          style: simpleTextStyle.copyWith(
            fontFamily: fontType.toString(),
          ),
        ),
        shape: const RoundedRectangleBorder(
            borderRadius: BorderRadius.vertical(bottom: Radius.circular(20))),
        centerTitle: true,
        elevation: 0,
        leading: IconButton(
          color: iconColor,
          onPressed: () => Navigator.pop(context),
          icon: const Icon(Icons.arrow_back_ios_rounded),
        ),
      ),
      body: Stack(
        children: [
          const Background(),
          Column(
            children: [
              Expanded(
                child: Padding(
                  padding: const EdgeInsets.only(
                      top: 20, right: 10, left: 10, bottom: 40),
                  child: AnimationLimiter(
                    child: ListView.builder(
                      physics: const BouncingScrollPhysics(),
                      scrollDirection: Axis.vertical,
                      itemCount: soranij.length,
                      itemBuilder: (context, i) {
                        final a = soranij[i];
                        return AnimationConfiguration.staggeredList(
                            position: i,
                            delay: const Duration(milliseconds: 100),
                            child: SlideAnimation(
                                duration: const Duration(milliseconds: 2500),
                                curve: Curves.fastLinearToSlowEaseIn,
                                horizontalOffset: 30,
                                verticalOffset: 300.0,
                                child: FlipAnimation(
                                  duration: const Duration(milliseconds: 3000),
                                  curve: Curves.fastLinearToSlowEaseIn,
                                  flipAxis: FlipAxis.y,
                                  child: homePageCardsGroup(
                                      kActiveIconColor,
                                      "assets/icons/prophet-name.png",
                                      '${a.sarder}', () {
                                    getItemNavigate(
                                        a.sarder!, a.drezha!, context);
                                  }, "${i + 1}"),
                                )));
                      },
                    ),
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget homePageCardsGroup(Color color, String icon, String title,
      VoidCallback onTap, String count) {
    double w = MediaQuery.of(context).size.width;
    return Padding(
      padding: EdgeInsets.only(bottom: w / 17),
      child: homePageCard(color, icon, title, onTap, count),
    );
  }

  Widget homePageCard(Color color, String icon, String title,
      VoidCallback onTap, String count) {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        splashColor: kActiveIconColor,
        customBorder:
            RoundedRectangleBorder(borderRadius: BorderRadius.circular(25)),
        onTap: onTap,
        child: Stack(
          children: [
            Container(
              padding: const EdgeInsets.all(15),
              width: double.infinity,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(25),
                color: backgroundColor.withValues(alpha: 0.8),
                boxShadow: [
                  BoxShadow(
                    color: const Color(0xFF282547).withValues(alpha: .15),
                    blurRadius: 20,
                  ),
                ],
              ),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  const SizedBox(),
                  Text(
                    title,
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(
                      fontFamily: fontType.toString(),
                      fontSize: 16,
                      color: titleTextColor,
                      fontWeight: FontWeight.w700,
                    ),
                    textAlign: TextAlign.center,
                  ),
                  const SizedBox(),
                ],
              ),
            ),
            Container(
              padding:
                  const EdgeInsets.symmetric(horizontal: 10.0, vertical: 5.0),
              decoration: const BoxDecoration(
                color: Color(0x83CEECE8),
                borderRadius: BorderRadius.only(
                    bottomRight: Radius.circular(10),
                    topLeft: Radius.circular(20)),
              ),
              child: Text(
                count,
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: kActiveIconColor,
                  fontWeight: FontWeight.w700,
                  fontSize: 12,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  void getItemNavigate(String title, String desc, BuildContext context) {
    Navigator.push(
        context,
        PageTransition(
            child: TextPageView(
              title: title,
              sarder: widget.sarder!,
              desc: desc,
            ),
            type: PageTransitionType.leftToRightWithFade));
  }
}
