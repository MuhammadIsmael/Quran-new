import 'package:runaki_islam/Screens/HomeItems/Pexambarman/page_view.dart';
import 'package:flutter/material.dart';
import 'package:flutter_staggered_animations/flutter_staggered_animations.dart';
import 'package:runaki_islam/Screens/HomeItems/NeshanakaneRozheDway/list_a.dart';
import 'package:runaki_islam/util/background.dart';
import 'package:runaki_islam/util/constans.dart';
import 'package:page_transition/page_transition.dart';
import 'package:runaki_islam/providers/settings_provider.dart';
import 'package:provider/provider.dart';

class ListPageG extends StatefulWidget {
  final String? sarder;

  const ListPageG({super.key, this.sarder});
  @override
  State<StatefulWidget> createState() => _ListPageState();
}

class _ListPageState extends State<ListPageG> {
  List<MyListViewitems> soranig = [];
  int? fontType;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bgColor,
      appBar: AppBar(
        toolbarHeight: 80,
        backgroundColor: thirdColor,
        title: Text(
          "${widget.sarder}",
          style: simpleTextStyle.copyWith(
            fontFamily: fontType.toString(),
          ),
        ),
        shape: const RoundedRectangleBorder(
            borderRadius: BorderRadius.vertical(bottom: Radius.circular(20))),
        centerTitle: true,
        elevation: 0,
        leading: IconButton(
          color: iconColor,
          onPressed: () => Navigator.pop(context),
          icon: const Icon(Icons.arrow_back_ios_rounded),
        ),
      ),
      body: Stack(
        children: [
          const Background(),
          Column(
            children: [
              Expanded(
                child: Padding(
                  padding: const EdgeInsets.only(
                      top: 20, right: 10, left: 10, bottom: 40),
                  child: AnimationLimiter(
                    child: ListView.builder(
                      physics: const BouncingScrollPhysics(),
                      scrollDirection: Axis.vertical,
                      itemCount: soranig.length,
                      itemBuilder: (context, i) {
                        final a = soranig[i];
                        return AnimationConfiguration.staggeredList(
                            position: i,
                            delay: const Duration(milliseconds: 100),
                            child: SlideAnimation(
                                duration: const Duration(milliseconds: 2500),
                                curve: Curves.fastLinearToSlowEaseIn,
                                horizontalOffset: 30,
                                verticalOffset: 300.0,
                                child: FlipAnimation(
                                  duration: const Duration(milliseconds: 3000),
                                  curve: Curves.fastLinearToSlowEaseIn,
                                  flipAxis: FlipAxis.y,
                                  child: homePageCardsGroup(
                                      kActiveIconColor,
                                      "assets/icons/prophet-name.png",
                                      '${a.sarder}', () {
                                    getItemNavigate(
                                        a.sarder!, a.drezha!, context);
                                  }, "${i + 1}"),
                                )));
                      },
                    ),
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget homePageCardsGroup(Color color, String icon, String title,
      VoidCallback onTap, String count) {
    double w = MediaQuery.of(context).size.width;
    return Padding(
      padding: EdgeInsets.only(bottom: w / 17),
      child: homePageCard(color, icon, title, onTap, count),
    );
  }

  Widget homePageCard(Color color, String icon, String title,
      VoidCallback onTap, String count) {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        splashColor: kActiveIconColor,
        customBorder:
            RoundedRectangleBorder(borderRadius: BorderRadius.circular(25)),
        onTap: onTap,
        child: Stack(
          children: [
            Container(
              padding: const EdgeInsets.all(15),
              width: double.infinity,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(25),
                color: backgroundColor.withValues(alpha: 0.8),
                boxShadow: [
                  BoxShadow(
                    color: const Color(0xFF282547).withValues(alpha: .15),
                    blurRadius: 20,
                  ),
                ],
              ),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  const SizedBox(),
                  Text(
                    title,
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(
                      fontFamily: fontType.toString(),
                      fontSize: 16,
                      color: titleTextColor,
                      fontWeight: FontWeight.w700,
                    ),
                    textAlign: TextAlign.center,
                  ),
                  const SizedBox(),
                ],
              ),
            ),
            Container(
              padding:
                  const EdgeInsets.symmetric(horizontal: 10.0, vertical: 5.0),
              decoration: const BoxDecoration(
                color: Color(0x83CEECE8),
                borderRadius: BorderRadius.only(
                    bottomRight: Radius.circular(10),
                    topLeft: Radius.circular(20)),
              ),
              child: Text(
                count,
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: kActiveIconColor,
                  fontWeight: FontWeight.w700,
                  fontSize: 12,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  void getItemNavigate(String title, String desc, BuildContext context) {
    Navigator.push(
        context,
        PageTransition(
            child: TextPageView(
              title: title,
              sarder: widget.sarder!,
              desc: desc,
            ),
            type: PageTransitionType.leftToRightWithFade));
  }

  @override
  void initState() {
    super.initState();
    fontType = Provider.of<SettingsProvider>(context, listen: false)
        .getsettingField('font_family');
    soranig.add(MyListViewitems(
      drezha:
          "نیشانەکانی هاتنی ڕوژی دوایی جۆرو هەمە چەشنی هەیە پەیوەندی بە زەوییەوە هەیە، هەمانە پەیوەندی بە خەڵکەوە هەیە، هەمانە پەیوەندی بە ئافرەتەوە هەیە، هەمانە پەیوەندی بە پیاوانەوە هەیە، هەیشە پەیوندی بەڕەوشت و ئاکارەکانەوە هەیە وەک بڵابوونەوەی زینا هەیشە  پەیوەندی بە بوونەوەرو دووکەڵەوەهەیە:\n\n٭مەبەست چییە لە دوکەڵ؟\n\n٭ئایا ئەو نیشانەیە تا ئیستا هاتووە؟\n\n٭حیکمەتی هەڵایسانی ئەم دووکەڵە چییە؟\nئەسڵ لەو نیشانە ئەم ئایەتەیە خوای گەورە دەفەرمووێت:\n\n(فَارْتَقِبْ يَوْمَ تَأْتِي السَّمَاءُ بِدُخَانٍ مُّبِينٍ ٭  يَغْشَى النَّاسَ هَٰذَا عَذَابٌ أَلِيمٌ ٭ رَّبَّنَا اكْشِفْ عَنَّا الْعَذَابَ إِنَّا مُؤْمِنُونَ٭ أَنَّىٰ لَهُمُ الذِّكْرَىٰ وَقَدْ جَاءَهُمْ رَسُولٌ مُّبِينٌ )(سورەتی الدخان(۱۰ ۱۱ ۱۲  13 ). \n\nواتە: (ئەوانه هەروا بەسەریانەوه ناچێت) چاوەڕێی ڕۆژێك بکه که دوکەڵێکی ئاشکرا بەری ئاسمان دەگرێت. هەموو خەڵکی دادەگرێته، بۆیه به ترسەوه دەڵێن: ئەمه سزاو ئازارێکی به ئێشه (وا ڕووی تێ کردووین). بەناچاری دان بەدەسەڵاتی خوادا دەنێن و دەڵێن: پەروەردگارا تۆ ئەم سزاو ئازارەمان له کۆڵ بکەرەوه، بێگومان ئێمه باوەڕدارین!! (تازه بەسەرچوو!! کەی بێداربوونەوه و ئیمان هێنانی ناچاری سوودی هەیه بۆیان)، چۆن و لەکوێ ئامۆژگاری وەردەگرن، لەکاتێکدا پێغەمبەرێکی ئاشکرایان بۆ ڕەوانه کرابوو.\n\n",
      sarder: "نیشانەی دەرکەوتنی دوکەڵ",
    ));
    soranig.add(MyListViewitems(
      drezha:
          "هەندێ پێیان وایە کە مەبەست لەو دووکەڵە ئەو ناڕەحەتی و نەهامەتی و برسێتییە بوو کە تووشی قورەیشییەکان هات ئەو کاتەی کە پێغەمبەری خوا دوعای لێکردن ئەویش ئەو کاتەی کە بە پیر بانگەزەکەیەوە نەهاتن  ئەوانیش دوای کە سەریان بەرەو ئاسمان بەرزئەکردەوە تەنها دووکەڵیان ئەبینی لەبەڕ بەڵاو نەهامەتییەک کە تووشی هاتبوون ئەوەی کە ئەم ڕایەشی هەیە عەبدوڵڵای کوڕی مەسعوود (ئیبن وجەریری طەبەری)ن. (خوا لێیان رازی بێت) فەرموودەکەش بەم شێوەیە کە دەفەرمووێت: \n\n عَنْ مَسْرُوقٍ قَالَ: كُنَّا عِنْدَ عَبْدِ اللَّهِ جُلُوسًا وَهُوَ مُضْطَجِعٌ بَيْنَنَا، فَأَتَاهُ رَجُلٌ فَقَالَ: يَا أَبَا عَبْدِ الرَّحْمَنِ إِنَّ قَاصًّا عِنْدَ أَبْوَابِ كِنْدَةَ يَقُصُّ، وَيَزْعُمُ أَنَّ آيَةَ الدُّخَانِ تَجِيءُ فَتَأْخُذُ بِأَنْفَاسِ الْكُفَّارِ، وَيَأْخُذُ الْمُؤْمِنِينَ مِنْهُ كَهَيْئَةِ الزُّكَامِ، فَقَالَ عَبْدُ اللَّهِ وَجَلَسَ وَهُوَ غَضْبَانُ: يَأَيَّهَا النَّاسُ اتَّقُوا اللَّهَ، مَنْ عَلِمَ مِنْكُمْ شَيْئًا فَلْيَقُلْ بِمَا يَعْلَمُ، وَمَنْ لَمْ يَعْلَمْ فَلْيَقُلْ: اللَّهُ أَعْلَمُ، فَإِنَّهُ أَعْلَمُ لِأَحَدِكُمْ أَنْ يَقُولَ لِمَا لَا يَعْلَمُ: اللَّهُ أَعْلَمُ؛ فَإِنَّ اللَّهَ عَزَّ وَجَلَّ قَالَ لِنَبِيِّهِ { قُلْ مَا أَسْأَلُكُمْ عَلَيْهِ مِنْ أَجْرٍ وَمَا أَنَا مِنْ الْمُتَكَلِّفِينَ } إِنَّ رَسُولَ اللَّهِ [ لَمَّا رَأَى مِنْ النَّاسِ إِدْبَارًا، فَقَالَ: « اللَّهُمَّ سَبْعٌ كَسَبْعِ يُوسُفَ » قَالَ: فَأَخَذَتْهُمْ سَنَةٌ حَصَّتْ كُلَّ شَيْءٍ، حَتَّى أَكَلُوا الْجُلُودَ وَالْمَيْتَةَ مِنْ الْجُوعِ، وَيَنْظُرُ إِلَى السَّمَاءِ أَحَدُهُمْ فَيَرَى كَهَيْئَةِ الدُّخَانِ ) (البخاری/ الاستسقاء (۹٦۲).\n\nواتە: مەسرووق دەڵێ ئێمە لای عەبدوڵڵا دانیشتبووین ئەو لەنێوانماندا ڕاکشابوو پیاوێک هات بۆلای وتی ئەی ئەبووعەبدولڕەحمان حیکایەتخوانێک لای دەروازەکانی شاری (کندە) مەبەست دەروازەی کووفەیە چیرۆک دەخوێنێتەوەو وا دەزانێت کە ئایەتی ڕووداوی دوکەڵەکە ڕوودەدات و هەناسە لە بێباوەڕان دەچنێ، بەڵام بڕواداران وەک هەڵامەت دەگۆرێتەوە عەبدوڵڵا دانیشت بەتووڕەییەوە گوتی ئەی خەڵکینە لە خوا بترسن هەرکەس لە ئێوە شتێکی زانی با بەپێی زانینەکەی خۆی قسە بکات هەرکەسیش نەیزانی بابڵێت خوا زاناترە، چونکە ئەوەیش زانستییەکی زیاترە گەر کەسێک نەزانێت و بڵێت خوا زاناترە ئەوەتا خوای باڵادەست بە پێغەمبەرەکەی فەرموو(قل ما أسألکم...) واتە: ئەی پێغەمبەر بەو خەڵکە بڵێ من هیچ پاداشت و خەڵاتێکم لە ئێوە ناوێت من لەو کاسانەیش نیم زۆر لە خۆم بکەم، چونکە پێغەمبەری خوا کاتێک بینی وا پشتی تێدەکەن فەرمووی: (خوایە گرانیەکی حەوت ساڵە وەک حەوتەکەی یووسف) دەڵێ ئەوانیش تووشی وشکە ساڵێ و قات و قڕییەک بوون کە هەموو شتێکی ڕیشەکێش کرد تا وایان لێهات لە برساندا پێستەی مردارۆ بوویان دەخوارد تا وای لێهات کەیەکێ لەوان سەیری ئاسمانی دەکرد شێوەی وەکو دووکەڵ وابوو!!.....هەروەها ئیبن ومەسعوود (خوای لێیان ڕازی بێت) دەڵێت:\n\n (( قَالَ خَمْسٌ قَدْ مَضَیْنَ الدُّخَانُ وَاللِّزَامُ وَالرُّومُ وَالْبَطْشَةُ وَالْقَمرُ ))(البخاري /التفسير/ ٤٥٤٨) عَنْ اللهِ رَضيَ اللهُ عَنَهُ ).\n\nواتە: پێنج شت تێپەریوون دوکەڵەکە و ڕۆژی بەدر و ڕۆم و کوشتاری بەدرو لەتبوانی مانگ.\n\n",
      sarder: "ناکۆکی زانایان لەبارەی ئەو دوکەڵەی کە لەئایتەکەدا هاتووە",
    ));
    soranig.add(MyListViewitems(
      drezha:
          "کە هێشتا نەهاتووە لەوانەی کە ئەو ڕایەشیان هەیە بریتین لە عەلی کوڕی ئەبووتاڵیب و ئەبووسەعیدی خودری خوای گەورە لێی ڕازی بێت ئیبن و کەسیریش ڕەحمەتی خوای لێ بێت هەر ئەم ڕایەی ئەوانی پی پەسندە.هەندێ لە زانایانی تریش ئەڵێن ئەو دووکەڵە دووجۆرە یەکیان ڕوویداوە وەک لە فەرموودەکەدا هاتووە ئاماژەی پێدابوو ڕای پەسندیش ئەوەیە کە ئەو دووکەڵە هیشتا نەهاتووە هەروەک لە قورئاندا خوای گەورە دەفەرمووێت: \n\n(( فَارْتَقِبْ يَوْمَ تَأْتِي السَّمَاءُ بِدُخَانٍ مُّبِينٍ )) الدخان ( 10 ).\n\nواتە: (ئەوانه هەروا بەسەریانەوه ناچێت) چاوەڕێی ڕۆژێك بکه که دوکەڵێکی ئاشکرا بەری ئاسمان دەگرێت.\n\n بەڵام ئەوەی کە ئیبن ومەسعوود باسی ئەکات ئەوە خەیاڵێک بوو خوا خستبوویە مێشکی قورەیشییەکانەوە کە لەبرسان و ماندووبوونانی وایان ئەزانی کە ئەوەی لە ئاسمان ئەیبنن دووکەڵە !!! هەروەک خوای گەورە فەرمووی (یَغْشَی النَّاس) یانی خوای گەورە ڕاستیەکەی لێ شاردبوونەوە هەروەها فەرمووی (هَذَا عَذَابْ ٲَلِیمْ) ئەمە سزایەکی بەسۆیە.\n\n",
      sarder:
          "زۆربەی زانایانی تر پێیان وایە کە دوکەڵ یەکێکە لەو نیشانانەی کە چاوەڕێ ئەکرێت بێت",
    ));
    soranig.add(MyListViewitems(
      drezha:
          "پێغەمبەری خوا (صلی الله علیە وسلم) دەفەرمووێت:\n\n(( إِنَّهَا لَنْ تَقُومَ حَتَّى تَرَوْنَ قَبْلَهَا عَشْرَ آيَاتٍ فَذَكَرَ الدُّخَانَ  وَيَأَجُوجَ وَمَأْجُوجَ ، وَثَلَاثَةَ خُسُوفٍ : خَسْفٌ بِالْمَشْرِقِ ، وَخَسْفٌ بِالْمَغْرِبِ ،  وَخَسْفٌ بِجَزِيرَةِ الْعَرَبِ ، وَآخِرُ ذَلـِكَ نَارٌ تَخْرُجُ مِنَ الْيَمَنِ تَطْرُدُ النَّاسَ إِلَى مَحْشَرِهِمْ )). أخرجه مسلم  برقم 2901 [ مسلم بشرح النووي ( 9/255) ].     هەروەها دەفەرموودێت:     ( بَادِرُوا بِالْأَعمَالِ سِتًا الدُّخَانَ وَالدَّجَّالَ وَدَابَّةَ الْأَرْضِ وَطُلُوعَ الشَّمْسِ مِنْ مَغْرِبِهَا وَأَمْرَ الْعَامَّةِ وَخُوَيْصَّةَ أَحَدِكُمْ ))،(صحيح مسلم (٨ / ٢٠٨/ أحمد( ٢/ ٢٣٤، ٤٠٧)عَنْ أَبِي هُرَيْرَةَ (رَضيَ اللهُ عَنَهُ ) السلسة الصحيحة)(٢/ ٣٩٨).\n\nواتە: پەلە بەکەن لەکردەوەی چاک پێش ئەوەی شەش شت دامێن گیرتان بێت دەججاڵ و دوکەڵ و جانەوەری زەوی و هەڵاتنی خۆر لە خۆر ئاواو کارەساتی گشتی (کەمەبەست قیامەتە) کارەساتی تایبەت بە هەریەکێک لە خۆتان (مەبەست مردنە)یاخود لە ئیبنوعەبباس(خوای لێیان ڕازی بێت)و دەیگوت بەوخوایە ئەمشەو خەوم لێ نەکەوتووە تا بەیانی ئەلێ وتم بۆچی؟ ئەڵێ وتی \n\n",
      sarder: "پەلە بەکەن لەکردەوەی چاک پێش ئەوەی شەش شت دامێن گیرتان بێت",
    ));
    soranig.add(MyListViewitems(
      drezha:
          "(( طَلَعَ الْكَوْكَبُ ذُو الذَّنَبِ فَخَشِيتُ الدُّخَانَ قَدْ طُرِقَ فَوَاللهِ مَا نِمْتُ حَتَّى أَصْبَحْتُ ) ( رواه ابن جرير وابن ابي حاتم قال ابن كثير إسناده صحيح الي عباس (رَضيَ اللهُ عَنَهُ ).\n\nئەستێرەی کلکدار دەرکەوت ترسام کە ئەوە دوکەڵەکە بێت دەرکەوتبێت بەوخوایە نەخوتووم تا بەیانی !!\n\n دیارە ترسانی (ئیبن وعەبباس)یش شایەتە لەسەر ئەوە کە دوکەڵەکە یەکێکە لە نیشانەکانی هاتنی ڕۆژی دوایی و هێشتاش دەرنەکەوتووە.     \n\n",
      sarder: "ئەم دوکەڵە یەکێکە لە نیشانەکانی هاتنی ڕۆژی دوای",
    ));
  }
}
