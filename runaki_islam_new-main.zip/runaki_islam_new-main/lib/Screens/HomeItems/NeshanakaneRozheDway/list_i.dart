import 'package:runaki_islam/Screens/HomeItems/Pexambarman/page_view.dart';
import 'package:flutter/material.dart';
import 'package:flutter_staggered_animations/flutter_staggered_animations.dart';
import 'package:runaki_islam/Screens/HomeItems/NeshanakaneRozheDway/list_a.dart';
import 'package:runaki_islam/util/background.dart';
import 'package:runaki_islam/util/constans.dart';
import 'package:page_transition/page_transition.dart';
import 'package:runaki_islam/providers/settings_provider.dart';
import 'package:provider/provider.dart';

class ListPageI extends StatefulWidget {
  final String? sarder;

  const ListPageI({super.key, this.sarder});
  @override
  State<StatefulWidget> createState() => _ListPageState();
}

class _ListPageState extends State<ListPageI> {
  List<MyListViewitems> soranii = [];

  int? fontType;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bgColor,
      appBar: AppBar(
        toolbarHeight: 80,
        backgroundColor: thirdColor,
        title: Text(
          "${widget.sarder}",
          style: simpleTextStyle.copyWith(
            fontFamily: fontType.toString(),
          ),
        ),
        shape: const RoundedRectangleBorder(
            borderRadius: BorderRadius.vertical(bottom: Radius.circular(20))),
        centerTitle: true,
        elevation: 0,
        leading: IconButton(
          color: iconColor,
          onPressed: () => Navigator.pop(context),
          icon: const Icon(Icons.arrow_back_ios_rounded),
        ),
      ),
      body: Stack(
        children: [
          const Background(),
          Column(
            children: [
              Expanded(
                child: Padding(
                  padding: const EdgeInsets.only(
                      top: 20, right: 10, left: 10, bottom: 40),
                  child: AnimationLimiter(
                    child: ListView.builder(
                      physics: const BouncingScrollPhysics(),
                      scrollDirection: Axis.vertical,
                      itemCount: soranii.length,
                      itemBuilder: (context, i) {
                        final a = soranii[i];
                        return AnimationConfiguration.staggeredList(
                            position: i,
                            delay: const Duration(milliseconds: 100),
                            child: SlideAnimation(
                                duration: const Duration(milliseconds: 2500),
                                curve: Curves.fastLinearToSlowEaseIn,
                                horizontalOffset: 30,
                                verticalOffset: 300.0,
                                child: FlipAnimation(
                                  duration: const Duration(milliseconds: 3000),
                                  curve: Curves.fastLinearToSlowEaseIn,
                                  flipAxis: FlipAxis.y,
                                  child: homePageCardsGroup(
                                      kActiveIconColor,
                                      "assets/icons/prophet-name.png",
                                      '${a.sarder}', () {
                                    getItemNavigate(
                                        a.sarder!, a.drezha!, context);
                                  }, "${i + 1}"),
                                )));
                      },
                    ),
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget homePageCardsGroup(Color color, String icon, String title,
      VoidCallback onTap, String count) {
    double w = MediaQuery.of(context).size.width;
    return Padding(
      padding: EdgeInsets.only(bottom: w / 17),
      child: homePageCard(color, icon, title, onTap, count),
    );
  }

  Widget homePageCard(Color color, String icon, String title,
      VoidCallback onTap, String count) {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        splashColor: kActiveIconColor,
        customBorder:
            RoundedRectangleBorder(borderRadius: BorderRadius.circular(25)),
        onTap: onTap,
        child: Stack(
          children: [
            Container(
              padding: const EdgeInsets.all(15),
              width: double.infinity,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(25),
                color: backgroundColor.withValues(alpha: 0.8),
                boxShadow: [
                  BoxShadow(
                    color: const Color(0xFF282547).withValues(alpha: .15),
                    blurRadius: 20,
                  ),
                ],
              ),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  const SizedBox(),
                  Text(
                    title,
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(
                      fontFamily: fontType.toString(),
                      fontSize: 16,
                      color: titleTextColor,
                      fontWeight: FontWeight.w700,
                    ),
                    textAlign: TextAlign.center,
                  ),
                  const SizedBox(),
                ],
              ),
            ),
            Container(
              padding:
                  const EdgeInsets.symmetric(horizontal: 10.0, vertical: 5.0),
              decoration: const BoxDecoration(
                color: Color(0x83CEECE8),
                borderRadius: BorderRadius.only(
                    bottomRight: Radius.circular(10),
                    topLeft: Radius.circular(20)),
              ),
              child: Text(
                count,
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: kActiveIconColor,
                  fontWeight: FontWeight.w700,
                  fontSize: 12,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  void getItemNavigate(String title, String desc, BuildContext context) {
    Navigator.push(
        context,
        PageTransition(
            child: TextPageView(
              title: title,
              sarder: widget.sarder!,
              desc: desc,
            ),
            type: PageTransitionType.leftToRightWithFade));
  }

  @override
  void initState() {
    super.initState();
    fontType = Provider.of<SettingsProvider>(context, listen: false)
        .getsettingField('font_family');
    soranii.add(MyListViewitems(
      drezha:
          "نیشانە گەورەکانی ڕۆژی دوایی بە گەورەو بچووکەوە ئەبینرێ کە لە ناکاو سیستەمی بوونەوەر هەمووی تێک ئەچێت ئەو ڕۆژە تازە بەیانی خەڵکی چاوەڕێی دەرکەوتنی  خۆر ئەکەن لەو شوێنەی کە هەموو جار دەرئەکەوت کاتێ لە پڕ ئەبینن کە خۆر ئەجارە لە خۆرئاواوە دەردەکەوێت! ئا لەوکاتەدا دەرگای تۆبە دا ئەخرێت و کەس تۆبەی لێ وەرناگیرێت! (خودا پەنامان بدات) هەروەک خوای گەورە دەفەرمووێت:\n\n(( هَلْ يَنظُرُونَ إِلَّا أَن تَأْتِيَهُمُ الْمَلَائِكَةُ أَوْ يَأْتِيَ رَبُّكَ أَوْ يَأْتِيَ بَعْضُ آيَاتِ رَبِّكَ يَوْمَ يَأْتِي بَعْضُ آيَاتِ رَبِّكَ لَا يَنفَعُ نَفْسًا إِيمَانُهَا لَمْ تَكُنْ آمَنَتْ مِن قَبْلُ أَوْ كَسَبَتْ فِي إِيمَانِهَا خَيْرًا قُلِ انتَظِرُوا إِنَّا مُنتَظِرُونَ )) (الأنعام 158 ) .\n\nواتە: ئایا ئەوانه چاوەڕێی هیچ شتێک دەکەن جگه لەوەی که فریشتەی گیان کێشانیان بۆ بێت؟ یان پەروەردگارت خۆی یەکسەر بێت بێ چەند و چوون؟ یان هەندێک له نیشانەکانی پەروەردگارت دەربکەوێت (که بەڵگەیه لەسەر بەرپا بوونی قیامەت)؟ له ڕۆژی هاتنی هەندێک له نیشانەکانی پەروەردگارت (وەکو هەڵهاتنی ڕۆژ له خۆرئاوا...)، ئەو کەسەی ئەو ڕۆژه ئیمان و بڕوا دەهێنێت، ئەو ئیمان و بڕوايەی سوودی بۆی نابێت ئەگەر پێشتر ئیمانی نەهێنابێت، یان کردەوەی چاکی هاوڕێ لەگەڵ ئیمانەکەیدا ئەنجام نەدابێت، پێیان بڵێ: چاوەڕێ بکەن (بزانین خوا چیتان بەسەر دەهێنێت) ئێمەش چاوەڕوانین.\n\n",
      sarder: "هەڵهاتنی خۆر لە خۆرئاواوە",
    ));
    soranii.add(MyListViewitems(
      drezha:
          "یەكێكی تر لە نیشانە گەورەكانی هاتنی قیامەت هەڵهاتنی خۆرە لە رۆژئاواوە لەو كاتەوە خودای گەورە ئەم گەردوونەی دروست كردوە تاكو ئێستا خۆر لە رۆژهەڵاتەوە هەڵدێ و لە رۆژئاوا ئاوادەبێ و هەرگیز دوا ناكەوێ, لە حسابێكی زۆر ورد بەڵام لەو رۆژەدا لە رۆژئاواوە هەڵدێ,  لە ئەبو هورەیرە رەزای خودای لێ بێ فەرمووی: پێغەمبەری خودا صلی الله علیه وسلم فەرموویەتی:\n\n(( لَا تَقُومُ السَّاعَةُ حَتَّى تَطْلُعَ الشَّمْسُ مِنْ مَغْرِبِهَا ، فَإِذَا رَآهَا النَّاسُ آمَنَ مَنْ عَلَيْهَا ، فَذَاكَ حِينَ )) رواه احمد: 5/268 وصححه الالباني في صحيح الجامع برقم: 2927. ((لا يَنفَعُ نَفْسًا إِيمَانُهَا لَمْ تَكُنْ آمَنَتْ مِنْ قَبْلُ أَوْ كَسَبَتْ فِي إِيمَانِهَا خَيْرًا قُلِ انتَظِرُوا إِنَّا مُنتَظِرُونَ )) اخرجه البخاري: 11/352 ومسلم: 2/194س\n\nواتە: قیامەت نایەت هەتا خۆر لە رۆژئاواوە هەڵدێت, كە لەوێوە هەڵهات و خەڵك بینیان ئیتر هەموویان بروا دەهێنن ئەو كاتەش ئەو كاتەيە كە  تیایدا بروا هێنان كەڵكی نی یە و خێری تێدا نی یە ئەگەر پێشتر بروایان نەهێنا بێت.\n\n",
      sarder: "یەكێك لە نیشانەكانی رۆژی دوایی هەڵهاتنی خۆرە لە رۆژئاواوە",
    ));
    soranii.add(MyListViewitems(
      drezha:
          "پێغەمبەری خوا(صلی الله علیە وسلم) دەفەرمووێت:\n\n(( ثَلَاثٌ إِذَا خَرَجْنَ لَا يَنْفَعُ نَفْسًا إِيمَانُهَا لَمْ تَكُنْ آمَنَتْ مِنْ قَبْلَ أَوْ كَسَبَتْ فِي إِيمَانُهَا خَيْرًا: طُلُوعُ  الشَّمْسِ مِنْ مَغْرِبِهَا وَالدَّجَّالُ وَدَابَّةُ الْأَرْضِ ))(البخاري / التفسير/ (٤٣٥٩) عَنْ أَبِي هُرَيْرَةَ (رَضي اللهُ عَنْهُ ).\n\nواتە: هەرکەس لەو رۆژەدا ئیمان بهێنێت سوودی بۆی نابێت ئەگەر پێشتر ئیمانی نەبووبێت یان کردەوەی چاکی هاوڕێ لەگەڵ ئیمان نەبووبێت. \n\nهەڵاتنی خۆر لە خۆر ئاواوە و هاتنی دەججاڵ و جانەوەرەکەی زەوی، حیکمەتی داخستنی دەرگای تۆبە لەوەیە ئیمان لە زۆر لایەنەوە ئیمانە بە غەیبیاتەکان کاتێ کە ئەو نیشانەیەش دەرئەکەوێت ئیتر غەیبیاتەکە ئەبێتە ئاشکرا و هەمووکەس بەچاوی خۆی ئەیبینێت، بۆیە ئەوکەسەی ئیمان بێنێت لەوکاتەدا ئیمانەکەی ئەبێتە ئیمانەکەی فیرعەون کاتێ بەڕاستی بۆی دەرکەوت کە نقوومی ئاوەکە ئەبێت.\n\n",
      sarder: "هەرکەس لەو رۆژەدا ئیمان بهێنێت سوودی بۆی نابێت",
    ));
    soranii.add(MyListViewitems(
      drezha:
          "پێغەمبەری خوا(صلی الله علیە وسلم) فەرمووێت\n\n عَنْ أَبِي ذَرٍّ، رَضِيَ اللَّهُ عَنْهُ أَنَّ رَسُولَ اللَّهِ , صَلَّى اللَّهُ عَلَيْهِ وَسَلَّمَ قَالَ يَوْمًا: «أَتَدْرُونَ أَيْنَ تَذْهَبُ هَذِهِ الشَّمْسُ؟» قَالُوا: اللَّهُ وَرَسُولُهُ أَعْلَمُ قَالَ: \" إِنَّ هَذِهِ تَجْرِي حِينَ تَنْتَهِي إِلَى مُسْتَقَرِّهَا تَحْتَ الْعَرْشِ فَتَخِرُّ سَاجِدَةً، فَلَا تَزَالُ كَذَلِكَ حَتَّى يُقَالَ لَهَا: ارْتَفِعِي ارْجِعِي مِنْ حَيْثُ جِئْتِ , فَتَرْجِعُ فَتُصْبِحُ طَالِعَةً مِنْ مَطْلَعِهَا , ثُمَّ تَجْرِي حِينَ تَنْتَهِي إِلَى مُسْتَقَرِّهَا ذَلِكَ تَحْتَ الْعَرْشِ , فَتَخِرُّ سَاجِدَةً , فَلَا تَزَالُ كَذَلِكَ حَتَّى يُقَالَ لَهَا: ارْجِعِي مِنْ حَيْثُ جِئْتِ , فَتُصْبِحُ طَالِعَةً مِنْ مَطْلَعِهَا , ثُمَّ تَجْرِي , لَا يُنْكِرُ النَّاسُ مِنْهَا شَيْئًا حَتَّى تَنْتَهِي إِلَى مُسْتَقَرِّهَا ذَلِكَ تَحْتَ الْعَرْشِ فَيُقَالُ لَهَا: ارْتَفِعِي , أَصْبِحِي طَالِعَةً مِنْ مَغْرِبِكِ , فَتُصْبِحُ طَالِعَةً مِنْ مَغْرِبِهَا \". قَالَ رَسُولُ اللَّهِ , صَلَّى اللَّهُ عَلَيْهِ وَسَلَّمَ: «أَتَدْرُونَ مَتَى ذَلِكُمْ؟» حِينَ {لَا يَنْفَعُ نَفْسًا إِيمَانُهَا لَمْ تَكُنْ آمَنَتْ مِنْ قَبْلُ أَوْ كَسَبَتْ فِي إِيمَانِهَا خَيْرًا )( صحیح مسلم صحیح الجامع(۸٤).\n\nواتە: ئەبووزەر(خوای لێ رازی بێت) دەڵێ ڕۆژێکیان پێغەمبەر(صلی الله علیە وسلم) فەرمووی (ئایا دەزانن ئەم خۆرە بەرەو کوێ دەڕوات) گوتیان خوا و پێغەمبەری خوا باشتر دەزانن فەرمووی ئەم خۆرە دەڕوات تا دەگاتە ئارامگەی خۆی لە ژێر عەرشدا. ئەوسا دەکەوێت بە کڕنووشدا.هەروا دەبێت تاپێی دەوترێت بەرزبەرەوە. لە کوێوە هاتووی بگەڕێرەوە ئەویش دەگەڕێتەوە لەشوێنی هەڵاتنیەوە هەڵدێتەوە پاشان دەڕوات تا دەگاتەوە ئارامگەی خۆی لەژیر عەرشدا.دەکەوێتەوە بەکڕنوشدا بەردەوام هەروا دەبێت تاپێی دەوترێت بەرز بەرەوە لە کوێوە هاتووی بگەڕێرەوە دەگەڕتەوە و سەرلەنوێ لە جێگەی خۆیەوە هەڵدێتەوە پاشان دەڕوات بەشێوەیەکی ئاسایی ڕۆژانی پێشوو بێ ئەوەی خەڵکی هیچ شتێکی وەی لێوە ببینن کەنائاسایی بێت تا دەگاتەوە ژێر عەرش پێی دەوترێت بەرز بەرەوە ئەمجارە لە خۆرئاواوە هەڵدەێت لە ژێر عەرشدا ئینجا لە خۆر ئاواوە هەڵدێت پێغەمبە (صلی الله علیە وسلم) فەرمووی (دەزانن ئەوە کەی دەبێت؟) ئەوە کاتێکە ئیتر هەر کەسێک بەرلەوە بڕواى نەهێنابێ و ئەوڕوژە بڕوا بهێنێ هیچ قازانجێکی لێناکات.\n\n",
      sarder: "ئایا دەزانن ئەم خۆرە بەرەو کوێ دەڕوات",
    ));
    soranii.add(MyListViewitems(
      drezha:
          "پێغەمبەرەوە(صلی الله علیە وسلم) فەمووێت;\n\nعَنْ عَبْدِ اللَّهِ بْنِ عَمْرٍو قَالَ حَفِظْتُ مِنْ رَسُولِ اللَّهِ -صلى الله عليه وسلم- حَدِيثًا لَمْ أَنْسَهُ بَعْدُ سَمِعْتُ رَسُولَ اللَّهِ -صلى الله عليه وسلم- يَقُولُ « إِنَّ أَوَّلَ الآيَاتِ خُرُوجًا طُلُوعُ الشَّمْسِ مِنْ مَغْرِبِهَا وَخُرُوجُ الدَّابَّةِ عَلَى النَّاسِ ضُحًى وَأَيُّهُمَا مَا كَانَتْ قَبْلَ صَاحِبَتِهَا فَالأُخْرَى عَلَى إِثْرِهَا قَرِيبًا )( صحيح مسلم صحيح الجامع)(٢٠١٣).\n\nواتە: عەبدوڵڵای کوڕی عەمەر (خوا لێیان ڕازی بێت) دەڵێ لە پێغەمبەرەوە(صلی الله علیە وسلم) فەموودەیەکم لەبەر کردووە هێشتا لەبیرم نەچوتەوە بیستم پێغەمبەر (صلی الله علیە وسلم ) دەیفەرموو یەکەمین نیشانەیەک کە دەردەچێت هەڵاتنی خۆرە لە خۆر ئاواوە و دەرچوونی دەعباکەیە بۆ سەر خەڵکی لە چێشتەنگاودا هەرکامیان پێش ئەویان بوو ئەوی تریش بە شوێنیدا نزیکە.\n\n",
      sarder: "یەکەمین نیشانەیەک کە دەردەچێت هەڵاتنی خۆرە لە خۆر ئاواوە",
    ));
    soranii.add(MyListViewitems(
      drezha:
          "پێغەمبەری خوا(صلی الله علیە وسلم)دەفەرمووێت:\n\n(( بَادِرُوا بِالْأَعْمَالِ سِتًّا: الدَّجَّالَ وَالدُّخَانَ وَدَابَّةَ الْأَرْضِ وَطُلُوعَ الشَّمْسِ مِنْ مَغْرِبِهَا وَأَمْرَ الْعَامَّةِ وَخُوَيْصَّةَ أَحَدِكُمْ )( صحيح مسلم (٥٢٤٦) عَنْ أَبِي هُرَيْرَةَ (رَضيَ اللهُ عَنَهُ ).\n\nواتە: پەلە بکەن لە کردەوەی چاک پێش ئەوەی شەش شت دامێن گیرتان بێت دەججاڵ و دوکەڵ و جانەوەری و زەوی و هەڵاتنی خۆر لە خۆر ئاواو کارەساتی گشتی (کەمەبەست قیامەتە) کارەساتی تایبەت بە هەریەکێک لە خۆتان (مەبەست مردنە).\n\n",
      sarder: "فەرمانکراوە بە دەستپێشخەری لە کاری خیردا",
    ));
  }
}
