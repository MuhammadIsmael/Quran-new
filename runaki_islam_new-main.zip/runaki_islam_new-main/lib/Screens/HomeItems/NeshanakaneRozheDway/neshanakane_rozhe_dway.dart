import 'dart:ui';

import 'package:background_app_bar/background_app_bar.dart';
import 'package:flutter/material.dart';
import 'package:flutter_staggered_animations/flutter_staggered_animations.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:runaki_islam/Screens/HomeItems/NeshanakaneRozheDway/list_a.dart';
import 'package:runaki_islam/Screens/HomeItems/NeshanakaneRozheDway/list_b.dart';
import 'package:runaki_islam/Screens/HomeItems/NeshanakaneRozheDway/list_c.dart';
import 'package:runaki_islam/Screens/HomeItems/NeshanakaneRozheDway/list_d.dart';
import 'package:runaki_islam/Screens/HomeItems/NeshanakaneRozheDway/list_e.dart';
import 'package:runaki_islam/Screens/HomeItems/NeshanakaneRozheDway/list_f.dart';
import 'package:runaki_islam/Screens/HomeItems/NeshanakaneRozheDway/list_g.dart';
import 'package:runaki_islam/Screens/HomeItems/NeshanakaneRozheDway/list_h.dart';
import 'package:runaki_islam/Screens/HomeItems/NeshanakaneRozheDway/list_i.dart';
import 'package:runaki_islam/Screens/HomeItems/NeshanakaneRozheDway/list_j.dart';
import 'package:runaki_islam/util/background.dart';
import 'package:runaki_islam/util/constans.dart';
import 'package:runaki_islam/util/navigate_between_pages/size_route.dart';
import 'package:runaki_islam/providers/settings_provider.dart';
import 'package:provider/provider.dart';

class NeshanakaneRozheDwayScreen extends StatefulWidget {
  final String? sarder;
  const NeshanakaneRozheDwayScreen({super.key, this.sarder});

  @override
  State<StatefulWidget> createState() =>
      _NeshanakaneRozheDwayScreenState();
}

class _NeshanakaneRozheDwayScreenState
    extends State<NeshanakaneRozheDwayScreen> {
  final List<String> _list = [
    "نيشانە بچوكەكانى هاتنى ڕۆژى دوايى",
    "شەڕە گەورەکەی نێوان موسڵمانان ڕۆمەکان و فەتحی قوستەنتینییە.",
    "دەرکەوتنی مەهدی مەهدی کێیە ؟",
    "نیشانەی مەسیحی دەججال مەسیحی دەججاڵ کێیە.؟",
    "دەرکەوتنى یەئجووج ومەئجووج",
    "نيشانەگەورەکانی ڕۆژیی دوایی کە بریتییە لە رۆچوونی زەوی",
    "نیشانەی دەرکەوتنی دوکەڵ کە بەری ئاسمان دادەگرێت.",
    "دەرکەوتنی ئەو ئاژەڵەی کە دێتە قسە",
    "نیشانەی گەورە و بچووکەوە ئەبینرێ هەڵهاتنی خۆر لەخۆرئاواوە",
    "ئاگرێک هەڵدەستێت خەڵکی ڕایاندەکێشێت بۆ شوێنی حەشربوونیان",
  ];

  int? fontType;
  @override
  void initState() {
    fontType = Provider.of<SettingsProvider>(context, listen: false)
        .getsettingField('font_family');
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
      backgroundColor: bgColor,
      body: NestedScrollView(
        physics: const BouncingScrollPhysics(),
        headerSliverBuilder: (_, _) => <Widget>[
          SliverAppBar(
            leading: IconButton(
              icon: Icon(
                Icons.arrow_back_ios_rounded,
                color: iconColor,
              ),
              onPressed: () {
                Navigator.pop(context);
              },
            ),
            expandedHeight: 200,
            floating: false,
            pinned: true,
            snap: false,
            elevation: 0.0,
            backgroundColor: Colors.transparent,
            flexibleSpace: BackgroundFlexibleSpaceBar(
              collapseMode: CollapseMode.parallax,
              centerTitle: true,
              title: Text(
                widget.sarder!,
                style: bigTextStyle.copyWith(
                    fontFamily: fontType.toString(), color: Colors.white),
              ),
              titlePadding: const EdgeInsets.all(50),
              background: ClipRect(
                child: Container(
                  decoration: const BoxDecoration(
                      image: DecorationImage(
                    image: AssetImage(
                      "assets/images/read-quran.jpg",
                    ),
                    fit: BoxFit.fill,
                  )),
                  child: BackdropFilter(
                    filter: ImageFilter.blur(sigmaX: 5.0, sigmaY: 5.0),
                    child: Container(
                      decoration: BoxDecoration(
                        color: thirdColor.withValues(alpha: 0.5),
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ),
        ],
        body: Stack(
          children: [
            const Background2(),
            Padding(
              padding: const EdgeInsets.all(15.0),
              child: AnimationLimiter(
                child: ListView.builder(
                  physics: const BouncingScrollPhysics(),
                  scrollDirection: Axis.vertical,
                  itemCount: _list.length,
                  itemBuilder: (context, i) {
                    final a = _list[i];
                    return AnimationConfiguration.staggeredList(
                        position: i,
                        delay: const Duration(milliseconds: 100),
                        child: SlideAnimation(
                            duration: const Duration(milliseconds: 2500),
                            curve: Curves.fastLinearToSlowEaseIn,
                            horizontalOffset: 30,
                            verticalOffset: 300.0,
                            child: FlipAnimation(
                                duration: const Duration(milliseconds: 3000),
                                curve: Curves.fastLinearToSlowEaseIn,
                                flipAxis: FlipAxis.y,
                                child: homePageCardsGroup(a, () {
                                  if (i == 0) {
                                    Navigator.push(
                                        context,
                                        SizeRoute(
                                            page: ListPageA(
                                          sarder: a,
                                        )));
                                  }
                                  if (i == 1) {
                                    Navigator.push(
                                        context,
                                        SizeRoute(
                                            page: ListPageB(
                                          sarder: a,
                                        )));
                                  }
                                  if (i == 2) {
                                    Navigator.push(
                                        context,
                                        SizeRoute(
                                            page: ListPageC(
                                          sarder: a,
                                        )));
                                  }
                                  if (i == 3) {
                                    Navigator.push(
                                        context,
                                        SizeRoute(
                                            page: ListPageD(
                                          sarder: a,
                                        )));
                                  }
                                  if (i == 4) {
                                    Navigator.push(
                                        context,
                                        SizeRoute(
                                            page: ListPageE(
                                          sarder: a,
                                        )));
                                  }
                                  if (i == 5) {
                                    Navigator.push(
                                        context,
                                        SizeRoute(
                                            page: ListPageF(
                                          sarder: a,
                                        )));
                                  }
                                  if (i == 6) {
                                    Navigator.push(
                                        context,
                                        SizeRoute(
                                            page: ListPageG(
                                          sarder: a,
                                        )));
                                  }
                                  if (i == 7) {
                                    Navigator.push(
                                        context,
                                        SizeRoute(
                                            page: ListPageH(
                                          sarder: a,
                                        )));
                                  }
                                  if (i == 8) {
                                    Navigator.push(
                                        context,
                                        SizeRoute(
                                            page: ListPageI(
                                          sarder: a,
                                        )));
                                  }
                                  if (i == 9) {
                                    Navigator.push(
                                        context,
                                        SizeRoute(
                                            page: ListPageJ(
                                          sarder: a,
                                        )));
                                  }
                                }, "${i + 1}"))));
                  },
                ),
              ),
            ),
          ],
        ),
      ),
    ));
  }

  Widget homePageCardsGroup(String title, VoidCallback onTap, String count) {
    double w = MediaQuery.of(context).size.width;
    return Padding(
      padding: EdgeInsets.only(bottom: w / 17),
      child: homePageCard(title, onTap, count),
    );
  }

  Widget homePageCard(String title, VoidCallback onTap, String count) {
    return InkWell(
      splashColor: kActiveIconColor,
      customBorder:
          RoundedRectangleBorder(borderRadius: BorderRadius.circular(25)),
      onTap: onTap,
      child: Stack(
        children: [
          Container(
            padding: const EdgeInsets.all(15),
            width: double.infinity,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(25),
              color: backgroundColor.withValues(alpha: 0.6),
              boxShadow: [
                BoxShadow(
                  color: const Color(0xFF282547).withValues(alpha: .15),
                  blurRadius: 20,
                ),
              ],
            ),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                const SizedBox(),
                Container(
                  padding: const EdgeInsets.all(10),
                  decoration: BoxDecoration(
                    color: kActiveIconColor.withValues(alpha: .1),
                    shape: BoxShape.circle,
                  ),
                  child: SvgPicture.asset(
                    "assets/icons/prsyar.svg",
                    height: 40,
                    width: 40,
                    colorFilter: ColorFilter.mode(
                      kActiveIconColor.withValues(alpha: .6),
                      BlendMode.srcIn,
                    ),
                  ),
                ),
                Text(
                  title,
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                    fontFamily: fontType.toString(),
                    fontSize: 18,
                    color: titleTextColor,
                    fontWeight: FontWeight.w700,
                  ),
                  textAlign: TextAlign.center,
                ),
                const SizedBox(),
              ],
            ),
          ),
          Container(
            padding:
                const EdgeInsets.symmetric(horizontal: 10.0, vertical: 5.0),
            decoration: const BoxDecoration(
              color: Color(0x83CEECE8),
              borderRadius: BorderRadius.only(
                  bottomRight: Radius.circular(10),
                  topLeft: Radius.circular(20)),
            ),
            child: Text(
              count,
              textAlign: TextAlign.center,
              style: TextStyle(
                color: kActiveIconColor,
                fontWeight: FontWeight.w700,
                fontSize: 12,
              ),
            ),
          ),
        ],
      ),
    );
  }
}
