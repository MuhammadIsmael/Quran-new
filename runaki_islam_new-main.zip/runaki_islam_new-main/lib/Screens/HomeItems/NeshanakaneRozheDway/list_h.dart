import 'package:runaki_islam/Screens/HomeItems/Pexambarman/page_view.dart';
import 'package:flutter/material.dart';
import 'package:flutter_staggered_animations/flutter_staggered_animations.dart';
import 'package:runaki_islam/Screens/HomeItems/NeshanakaneRozheDway/list_a.dart';
import 'package:runaki_islam/util/background.dart';
import 'package:runaki_islam/util/constans.dart';
import 'package:page_transition/page_transition.dart';
import 'package:runaki_islam/providers/settings_provider.dart';
import 'package:provider/provider.dart';

class ListPageH extends StatefulWidget {
  final String? sarder;

  const ListPageH({super.key, this.sarder});
  @override
  State<StatefulWidget> createState() => _ListPageState();
}

class _ListPageState extends State<ListPageH> {
  List<MyListViewitems> soranih = [];

  int? fontType;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bgColor,
      appBar: AppBar(
        toolbarHeight: 80,
        backgroundColor: thirdColor,
        title: Text(
          "${widget.sarder}",
          style: simpleTextStyle.copyWith(
            fontFamily: fontType.toString(),
          ),
        ),
        shape: const RoundedRectangleBorder(
            borderRadius: BorderRadius.vertical(bottom: Radius.circular(20))),
        centerTitle: true,
        elevation: 0,
        leading: IconButton(
          color: iconColor,
          onPressed: () => Navigator.pop(context),
          icon: const Icon(Icons.arrow_back_ios_rounded),
        ),
      ),
      body: Stack(
        children: [
          const Background(),
          Column(
            children: [
              Expanded(
                child: Padding(
                  padding: const EdgeInsets.only(
                      top: 20, right: 10, left: 10, bottom: 40),
                  child: AnimationLimiter(
                    child: ListView.builder(
                      physics: const BouncingScrollPhysics(),
                      scrollDirection: Axis.vertical,
                      itemCount: soranih.length,
                      itemBuilder: (context, i) {
                        final a = soranih[i];
                        return AnimationConfiguration.staggeredList(
                            position: i,
                            delay: const Duration(milliseconds: 100),
                            child: SlideAnimation(
                                duration: const Duration(milliseconds: 2500),
                                curve: Curves.fastLinearToSlowEaseIn,
                                horizontalOffset: 30,
                                verticalOffset: 300.0,
                                child: FlipAnimation(
                                  duration: const Duration(milliseconds: 3000),
                                  curve: Curves.fastLinearToSlowEaseIn,
                                  flipAxis: FlipAxis.y,
                                  child: homePageCardsGroup(
                                      kActiveIconColor,
                                      "assets/icons/prophet-name.png",
                                      '${a.sarder}', () {
                                    getItemNavigate(
                                        a.sarder!, a.drezha!, context);
                                  }, "${i + 1}"),
                                )));
                      },
                    ),
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget homePageCardsGroup(Color color, String icon, String title,
      VoidCallback onTap, String count) {
    double w = MediaQuery.of(context).size.width;
    return Padding(
      padding: EdgeInsets.only(bottom: w / 17),
      child: homePageCard(color, icon, title, onTap, count),
    );
  }

  Widget homePageCard(Color color, String icon, String title,
      VoidCallback onTap, String count) {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        splashColor: kActiveIconColor,
        customBorder:
            RoundedRectangleBorder(borderRadius: BorderRadius.circular(25)),
        onTap: onTap,
        child: Stack(
          children: [
            Container(
              padding: const EdgeInsets.all(15),
              width: double.infinity,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(25),
                color: backgroundColor.withValues(alpha: 0.8),
                boxShadow: [
                  BoxShadow(
                    color: const Color(0xFF282547).withValues(alpha: .15),
                    blurRadius: 20,
                  ),
                ],
              ),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  const SizedBox(),
                  Text(
                    title,
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(
                      fontFamily: fontType.toString(),
                      fontSize: 16,
                      color: titleTextColor,
                      fontWeight: FontWeight.w700,
                    ),
                    textAlign: TextAlign.center,
                  ),
                  const SizedBox(),
                ],
              ),
            ),
            Container(
              padding:
                  const EdgeInsets.symmetric(horizontal: 10.0, vertical: 5.0),
              decoration: const BoxDecoration(
                color: Color(0x83CEECE8),
                borderRadius: BorderRadius.only(
                    bottomRight: Radius.circular(10),
                    topLeft: Radius.circular(20)),
              ),
              child: Text(
                count,
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: kActiveIconColor,
                  fontWeight: FontWeight.w700,
                  fontSize: 12,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  void getItemNavigate(String title, String desc, BuildContext context) {
    Navigator.push(
        context,
        PageTransition(
            child: TextPageView(
              title: title,
              sarder: widget.sarder!,
              desc: desc,
            ),
            type: PageTransitionType.leftToRightWithFade));
  }

  @override
  void initState() {
    super.initState();
    fontType = Provider.of<SettingsProvider>(context, listen: false)
        .getsettingField('font_family');
    soranih.add(MyListViewitems(
      drezha:
          "لەئاخری زەمان لەگەڵ زۆربوونی فەسادو خراپەکاری و دەرکەوتنی چەندین تاوان و سەرپێچی و لەگەڵ ڕاهاتنی خەڵکەکە چاک و خراپ لەگەڵ یەک تێکەڵ دەبن باوەڕدارو دووڕوو تێکەڵ دەبن بەڵکوو موسڵمان و کافر تێکەڵ ئەبن ناسینەوەیان زۆر زەحمەت ئەبێت! ئەلەوکاتەدا خوای گەورە ئیزن ئەفەرمووێت کە ئەو ئاژەڵە دەرکەوێت!\n\n٭ئەو ئاژەڵە چ ئاژەڵێکە؟\n\n٭لەکوێ وە، کەی دەر ئەکەوێت؟\n\n٭کارەکانی چین؟\n\n",
      sarder: "دەرکەوتنی ئەو ئاژەڵەی کە دێتە قسە",
    ));
    soranih.add(MyListViewitems(
      drezha:
          "خوای گەورە دەفەرمووێت:\n\n(( وَإِذَا وَقَعَ الْقَوْلُ عَلَيْهِمْ أَخْرَجْنَا لَهُمْ دَابَّةً مِّنَ الْأَرْضِ تُكَلِّمُهُمْ أَنَّ النَّاسَ كَانُوا بِآيَاتِنَا لَا يُوقِنُونَ )) النمل ( 82 ) \n\nواتە:کاتێک بڕیاری بەرپابوونی (قیامەت درا، یاخود نزیک بۆوه)، زیندەوەرێک له زەوی دەردەهێنین بۆیان که قسەیان بۆ دەکات که: بەڕاستی زۆربەی خەڵکی باوەڕیان به ئایەت و فەرمانەکانی ئێمه نەبووه.\n\nشایەنی باسە ماوەردی سەعلەبی چەند سیفەتێکی ئەو ئاژەڵە باسی ئەکەن کە گوایە سەری گوێرەکەیەو گوێچکەکانی گوێچەی فیلە هەموو ئەوانە هیچ بەڵگەیەکی درووستیان لەسەر نییە ئەوەی کە دەزانرێت ئەو شتە بەهەقیقەت ئاژەڵە وە لەگەڵ خەڵکی ئەدوێت لە زەویشدا سەر دەرئەکات.\n\n",
      sarder: "ئەوئایەتانەی کە باس  لەو ئاژەڵە ئەکەن",
    ));
    soranih.add(MyListViewitems(
      drezha:
          "٭دەڵێن لە شاخی سەفا لە مەککە دەردەکەوێت.\n\n٭دەڵێن لە ژێر کەعبەوە سەردەرئەکات.\n\n٭دەڵێن لە دەشتێک لە بیابان دەرئەکەوێت.\n\n بەڵام هیچ فەرموودەیەکی دروست نەهاتووە لەسەر ئەوە کە ئەو شوێنە کوێیە کە لێی دەرئەچێت بۆیە ئەڵێین باوەرمان هەیە کە دەردەچێت هەروەک خوای گەورە پێی ڕاگەیاندوین.\n\n",
      sarder: "لەکوێوە پەیدا ئەبێت؟",
    ));
    soranih.add(MyListViewitems(
      drezha:
          "٭دەڵێن پیاوێکە لەگەڵ خەڵکی ئەدوێت دیارە ئەمە ڕاست نییە.\n\n٭دەڵێن حوشترەکەی ساڵحە (سەلامی خوای لێ بێت).\n\n٭دەڵێن بەچکەی وشترەکەی ساڵحە (سەلامی خوای لێ بێت).",
      sarder: "ئەو ئاژەڵە چ ئاژەڵێکە؟",
    ));
    soranih.add(MyListViewitems(
      drezha:
          "بەخەڵکی ئەڵێن:.....(أَنَّ النَّاسَ كَانُوا بِآيَاتِنَا لَايُوقِنُونَ) \n\nهەروەها لە ئایەتەکەدا هاتووە. دەعبایەکە مۆر دەنێت بە لووتی خەڵکەوە هەروەک دەفەرمووێت:\n\n( تَخْرُجُ الدَّابَّةُ فَتَسِمُ النَّاسَ عَلَى خَرَاطِيمِهِمْ ثُمَّ يَغْمُرُونَ فِيكُمْ حَتَّى يَشْتَرِيَ الرَّجُلُ الْبَعِيرَ فَيَقُولُ مِمَّنْ اشْتَرَيْتَةُ ؟ فَيَقُولُ اشْتَرَيْتُةُ مِنْ أَحَدِ الْمُخَطَّمِينَ ) (أخرجه أحمد (٥/ ٢٦٨) و البخاري في التاريخ الكبير(٣/ ٢/ ١٧٢) السلسة الصحيحة (١/ ٥٧٦) عَنْ أَبِي أُمَامَةَ (رَضيَ اللهُ عَنَهُ). \n\nواتە: دەعباکە دەردەچێت و مۆر ئەنێت بە لووتی خەڵکەکەوە پاشان لەناوتاندا هاتوچۆ ئەکات هەتا پیاو وشترێک ئەکڕێت ئەڵێت ئەو وشترەت لەکێ کڕی؟ ئەڵێت لەکەسێکم کڕی کە لووتی کترابوو!\n\n٭ئەو نیشانە (وسم) چۆنە ئایا بەردەوام ئەبێت؟\n\n٭ئایا نەوەیەک لەدوای یەکەکان ئەو خەڵکە ئەو وەسمەیان هەیە؟\n\n٭دوای ئەوە دەعباکە لووتی خەڵک ئەکوتێت هەق و ناهەق و باوەڕو بێباوەڕ جیا ئەبنەوە؟\n\n٭خەڵکی لەو زەمانە بەم حاڵەتەوە بەردەوام ئەبن تا پیاو هاوار لە پیاوی تر ئەکات و ئەڵێت ئەی بڕوادار ..ئەی کافر!!\n\n",
      sarder: "ئەو ئاژەڵە چی ئەکات؟",
    ));
    soranih.add(MyListViewitems(
      drezha:
          "ئەودەمەی کە خوا ویستی ڕۆژی دوایی هەڵسێت نەرمە بایەک هەڵدەکات و ڕۆحی بڕواداران دەر ئەکات، چونکە ئەو قیامەتە لەسەر خراپەکاران هەڵدەستێت بڕوادار تووشی ئەو ڕاچڵەکینه گەورەیە نابن).....هەرەوەک پێغەمبەری خوا(صلی الله علیە وسلم) دەفەرمووێت: \n\n(( فَبَيْنَمَا هُمْ كَذَلِكَ إِذْ بَعَثَ اللَّهُ رِيحًا طَيِّبَةً تَأْخُذُهُمْ تَحْتَ آبَاطِهِمْ ، وَفَتَقْبِضُ رُوحَ كُلِّ مُسْلِمٍ ، وَيَبْقَى سَائِرُ النَّاسِ يَتَهَارَجُونَ كَمَا تَهَارُجَ الْحُمُرِ ، فَعَلَيْهِمْ تَقُومُ السَّاعَةُ )( أخرجه أحمد (٤ / ١٨١ – ١٨٢)و مسلم(٨/ ١٩٧ – ١٩٨ ) و الحاكم(٤ / ٤٩٢) و صحيح الجامع (٤١٦٦).\n\nواتە: لە کاتێکدا ئەوان لەم باروگوزەرانەدا دەبن خواى تعالى شنەبایەکی خۆش هەڵدەکات بن هەنگڵیان دەگرێتەوە گیانی هەموو بڕوادارو موسڵمانێک دەکێشێت و خراپانی خەڵکی دەمێننەوە لەیەکتری دەپەڕن وەک چۆن کەرگەڵ لەیەکتری دەپەڕن لەسەر ئەوان قیامەت هەڵدەسێت.\n\n",
      sarder: "قیامەتە لەسەر خراپەکاران هەڵدەستێت",
    ));
    soranih.add(MyListViewitems(
      drezha:
          "هەروەک پێغەمبەری خوا(صلی الله علیە وسلم)دەفەرمووێت:\n\nعَنْ النُّعْمَانِ بْنِ سَالِمٍ قَالَ سَمِعْتُ يَعْقُوبَ بْنَ عَاصِمِ بْنِ عُرْوَةَ بْنِ مَسْعُودٍ الثَّقَفِيَّ يَقُولُ: سَمِعْتُ عَبْدَ اللَّهِ بْنَ عَمْرٍو وَجَاءَهُ رَجُلٌ فَقَالَ مَا هَذَا الْحَدِيثُ الَّذِي تُحَدِّثُ بِهِ تَقُولُ إِنَّ السَّاعَةَ تَقُومُ إِلَى كَذَا وَكَذَا فَقَالَ سُبْحَانَ اللَّهِ أَوْ لَا إِلَهَ إِلَّا اللَّهُ أَوْ كَلِمَةً نَحْوَهُمَا لَقَدْ هَمَمْتُ أَنْ لَا أُحَدِّثَ أَحَدًا شَيْئًا أَبَدًا إِنَّمَا قُلْتُ إِنَّكُمْ سَتَرَوْنَ بَعْدَ قَلِيلٍ أَمْرًا عَظِيمًا يُحَرَّقُ الْبَيْتُ وَيَكُونُ وَيَكُونُ ثُمَّ قَالَ قَالَ رَسُولُ اللَّهِ صَلَّى اللَّهُ عَلَيْهِ وَسَلَّمَ يَخْرُجُ الدَّجَّالُ فِي أُمَّتِي فَيَمْكُثُ أَرْبَعِينَ لَا أَدْرِي أَرْبَعِينَ يَوْمًا أَوْ أَرْبَعِينَ شَهْرًا أَوْ أَرْبَعِينَ عَامًا فَيَبْعَثُ اللَّهُ عِيسَى ابْنَ مَرْيَمَ كَأَنَّهُ عُرْوَةُ بْنُ مَسْعُودٍ فَيَطْلُبُهُ فَيُهْلِكُهُ [ثُمَّ يَمْكُثُ النَّاسُ سَبْعَ سِنِينَ لَيْسَ بَيْنَ اثْنَيْنِ عَدَاوَةٌ] ثُمَّ يُرْسِلُ اللَّهُ رِيحًا بَارِدَةً مِنْ قِبَلِ الشَّأْمِ فَلَا يَبْقَى عَلَى وَجْهِ الْأَرْضِ أَحَدٌ فِي قَلْبِهِ مِثْقَالُ ذَرَّةٍ مِنْ خَيْرٍ أَوْ إِيمَانٍ إِلَّا قَبَضَتْهُ حَتَّى لَوْ أَنَّ أَحَدَكُمْ دَخَلَ فِي كَبَدِ جَبَلٍ لَدَخَلَتْهُ عَلَيْهِ حَتَّى تَقْبِضَهُ قَالَ سَمِعْتُهَا مِنْ رَسُولِ اللَّهِ صَلَّى اللَّهُ عَلَيْهِ وَسَلَّمَ قَالَ فَيَبْقَى شِرَارُ النَّاسِ فِي خِفَّةِ الطَّيْرِ وَأَحْلَامِ السِّبَاعِ لَا يَعْرِفُونَ مَعْرُوفًا وَلَا يُنْكِرُونَ مُنْكَرًا فَيَتَمَثَّلُ لَهُمْ الشَّيْطَانُ فَيَقُولُ أَلَا تَسْتَجِيبُونَ فَيَقُولُونَ فَمَا تَأْمُرُنَا فَيَأْمُرُهُمْ بِعِبَادَةِ الْأَوْثَانِ وَهُمْ فِي ذَلِكَ دَارٌّ رِزْقُهُمْ حَسَنٌ عَيْشُهُمْ ثُمَّ يُنْفَخُ فِي الصُّورِ فَلَا يَسْمَعُهُ أَحَدٌ إِلَّا أَصْغَى لِيتًا وَرَفَعَ لِيتًا قَالَ وَأَوَّلُ مَنْ يَسْمَعُهُ رَجُلٌ يَلُوطُ حَوْضَ إِبِلِهِ قَالَ فَيَصْعَقُ وَيَصْعَقُ النَّاسُ ثُمَّ يُرْسِلُ اللَّهُ أَوْ قَالَ يُنْزِلُ اللَّهُ مَطَرًا كَأَنَّهُ الطَّلُّ أَوْ الظِّلُّ نُعْمَانُ الشَّاكُّ فَتَنْبُتُ مِنْهُ أَجْسَادُ النَّاسِ (ثُمَّ يُنْفَخُ فِيهِ أُخْرَى فَإِذَا هُمْ قِيَامٌ يَنْظُرُونَ) ثُمَّ يُقَالُ يَا أَيُّهَا النَّاسُ هَلُمَّ إِلَى رَبِّكُمْ (وَقِفُوهُمْ إِنَّهُمْ مَسْئُولُونَ) : الصافات :٢٤_ قَالَ ثُمَّ يُقَالُ أَخْرِجُوا بَعْثَ النَّارِ فَيُقَالُ مِنْ كَمْ فَيُقَالُ مِنْ كُلِّ أَلْفٍ تِسْعَ مِائَةٍ وَتِسْعَةً وَتِسْعِينَ قَالَ فَذَاكَ يَوْمَ يَجْعَلُ الْوِلْدَانَ شِيبًا وَذَلِكَ يَوْمَ يُكْشَفُ عَنْ سَاقٍ: ٤٢) صحیح مسلم صحیح الجامع (۸۰٤۷).\n\nواتە: نوعمانی کوڕی سالم (خوای لێ ڕازی بێت) دەڵێ گوێم لێبوو یەعقووبی کوڕی عاسمی کوڕی عوروەی کوڕی سعودی سەقەفی دەیگوت گوێم لە عەبدوڵڵای کوڕی عومەر بوو کاتێ پیاوێک هات بۆلای وتی ئەو قسە و باسە چییە کە دەیکەیت ؟ دەڵێی قیامەت ئەمەندەو ئەمەندەی دیکە هەڵدەسێت؟ ئەویش وتی (سبحان الله) یا (لا الە الا الله) یا وشەیەکی لەو جۆرە هات بە دڵیدا هەرگیز هیچ شتێک بۆ هیچ کەسێک نەگێڕمەوە من هەر ئەوندەم  وتوە کە ئێوە لەمەلا پاش کەمێک ڕوداوێکی گەورە دەبینن ماڵی (خوا) دەسوتێنرێت ئەوەو ئەوە دەبێت پاشان وتی: پێغەمبەری خوا (صلی الله علیە وسلم) فەرموویەتی دەججال لەناو  ئومەتەکەمدا دەردەچێت چل دەمێنێتەوە نازانم چل ڕۆژ یا چل مانگ یا چل ساڵ  پاشان خوا عیسای کوڕی مەریەم (سەلامی خوای لێ بێت) دەنێرێت هەر ئەڵێی عوروەی کوڕی مەسعوودە شوێنی دەکەوێت و لەناوی دەبات دوای ئەوە خەڵکی حەوت ساڵ دەمێنێتەوە لە نێوان دوو کەسدا دوژمنایەتی نابێت بەدوایدا خواى تعالى بایەکی سارد لە ڕووی شامەوە دەنێرێت هیچ کەسێک ناهێڵێتەوە لەسەر ڕووی زەویدا بە ئەندازەی گەردیلەیەک خێر یا باوەڕ لە دڵیدا هەبێت مەگەر گیانی دەکێشێت هەتاوەکو ئەگەر یەکێ لە ئێوە بچێتە ناو کرۆکی شاخەوە با بۆی دەچێتە ژوورەوە تا گیانی دەكێشێت) لە پێغەمبەری خوام (صلی الله علیە وسلم) بیستووە فەرموویەتی (ئینجا خراپانی خەڵک دەمێنێتەوە لەسوکیدا وەک باڵندە وان و سروشت و ئارەزوویان وەک دڕندەیە نە چاک بە چاک دەزانن و نەخراپ بە خراپ، بەڕادەیەک شەیتان خۆیان لێدەگۆڕێت و دەڵێت ئایا شەرم ناکەن؟ ئەوانیش دەڵێن بەچی فەرمانمان پێدەکەیت؟ ئەویش فەرمانیان پی دەکات بە بتپەرستیی کاتی ئەوان لەسەر ئەو باروگوزەرانە دەبن ڕزق و ڕۆزیان زۆر دەبێت و ژیان و گوزەرانیان خۆش دەبێت لەپاشان فوو دەکرێت بە کەڕەناداو هیچ کەسێک نییە گوێی لێبێت ئیلا لاملی نەوی دەکات و لاملی بەرز دەکاتەوە دەڵێ یەکەمین کەسێکیش کە گوێی لێ دەبێت پیاویکە خەریکە حەوزی حوشترەکەی چاک دەکات و سواقی دەدات، بەڵام تێدا دەچێت و خەڵکیش تێدا دەچن، دوای ئەوە خوا بارانێک دەنێرێت (یا وتی دەبارێنێت) هەر دەڵێی بارانی پەڵەیە نەرم و لەسەرخۆ یان دەڵێی: سێبەرە، نوعمان دوودڵە، ئەوجا لەش و لاری خەڵکی لێ دەڕوێتەوە لە پاشان فوویەکی دیکەی پێدا دەکرێت ئیتر ئەوان کتوپڕ ڕاست دەبنەوە و تەماشا دەکەن دوای ئەوەی دەوترێت ئەی خەڵکینە وەرن بەرەو لای پەروەردگارتان...\n\n(وَقِفُوهُمْ إِنَّهُم مَّسْئُولُونَ )سورەتی الصافات: )( 24 ) \nواتە:لە کاتی ڕاپێچ کردنیاندا فەرمان دەدرێت: ئادەی بیان وەستێنن، بێگومان ئەوان پرسیار لێکراون واتە: بیان وەستێنن ئەوان بەرپرسیارن لە پاشان دەگوترێت دەستە و تاقمەکانی ئاگر دەرکەن دەوترێت لە چەند؟ دەوترێت لەهەموو هەزارێک نۆسەد نەوەد و نۆیان دەڵێت: ئەوە ئەو ڕۆژەیە کە منداڵانی پێ پیر دەبێت ئەو ڕۆژەیشە کە....\n\n(( يَوْمَ يُكْشَفُ عَن سَاقٍ وَيُدْعَوْنَ إِلَى السُّجُودِ فَلَا يَسْتَطِيعُونَ )) /سورەتی القلم( 42 )\n\nواتە:ڕۆژێك دێت پەرده لەسەر هەموو شتێك لادەدرێت و (ساق) دەردەکەوێت، خوا نەناسان بانگ دەکرێن بۆ سوژده بردن، بەڵام ناتوانن.    \n\n",
      sarder:
          "خواى تعالى بایەکی سارد لە ڕووی شامەوە دەنێرێت هیچ کەسێک ناهێڵێتەوە",
    ));
  }
}
