import 'package:runaki_islam/Screens/HomeItems/Pexambarman/page_view.dart';
import 'package:flutter/material.dart';
import 'package:flutter_staggered_animations/flutter_staggered_animations.dart';
import 'package:runaki_islam/Screens/HomeItems/NeshanakaneRozheDway/list_a.dart';
import 'package:runaki_islam/util/background.dart';
import 'package:runaki_islam/util/constans.dart';import 'package:runaki_islam/providers/settings_provider.dart';
import 'package:provider/provider.dart';
import 'package:page_transition/page_transition.dart';

class ListPageF extends StatefulWidget {
  final String? sarder;

  const ListPageF({super.key, this.sarder});
  @override
  State<StatefulWidget> createState() => _ListPageState();
}

class _ListPageState extends State<ListPageF> {
  List<MyListViewitems> soranif = [];
    int? fontType;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bgColor,
      appBar: AppBar(
        toolbarHeight: 80,
        backgroundColor: thirdColor,
        title: Text(
          "${widget.sarder}",
          style: simpleTextStyle.copyWith(
            fontFamily: fontType.toString(),
          ),
        ),
        shape: const RoundedRectangleBorder(
            borderRadius: BorderRadius.vertical(bottom: Radius.circular(20))),
        centerTitle: true,
        elevation: 0,
        leading: IconButton(
          color: iconColor,
          onPressed: () => Navigator.pop(context),
          icon: const Icon(Icons.arrow_back_ios_rounded),
        ),
      ),
      body: Stack(
        children: [
          const Background(),
          Column(
            children: [
              Expanded(
                child: Padding(
                  padding: const EdgeInsets.only(
                      top: 20, right: 10, left: 10, bottom: 40),
                  child: AnimationLimiter(
                    child: ListView.builder(
                      physics: const BouncingScrollPhysics(),
                      scrollDirection: Axis.vertical,
                      itemCount: soranif.length,
                      itemBuilder: (context, i) {
                        final a = soranif[i];
                        return AnimationConfiguration.staggeredList(
                            position: i,
                            delay: const Duration(milliseconds: 100),
                            child: SlideAnimation(
                                duration: const Duration(milliseconds: 2500),
                                curve: Curves.fastLinearToSlowEaseIn,
                                horizontalOffset: 30,
                                verticalOffset: 300.0,
                                child: FlipAnimation(
                                  duration: const Duration(milliseconds: 3000),
                                  curve: Curves.fastLinearToSlowEaseIn,
                                  flipAxis: FlipAxis.y,
                                  child: homePageCardsGroup(
                                      kActiveIconColor,
                                      "assets/icons/prophet-name.png",
                                      '${a.sarder}', () {
                                    getItemNavigate(
                                        a.sarder!, a.drezha!, context);
                                  }, "${i + 1}"),
                                )));
                      },
                    ),
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget homePageCardsGroup(Color color, String icon, String title,
      VoidCallback onTap, String count) {
    double w = MediaQuery.of(context).size.width;
    return Padding(
      padding: EdgeInsets.only(bottom: w / 17),
      child: homePageCard(color, icon, title, onTap, count),
    );
  }

  Widget homePageCard(Color color, String icon, String title,
      VoidCallback onTap, String count) {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        splashColor: kActiveIconColor,
        customBorder:
            RoundedRectangleBorder(borderRadius: BorderRadius.circular(25)),
        onTap: onTap,
        child: Stack(
          children: [
            Container(
              padding: const EdgeInsets.all(15),
              width: double.infinity,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(25),
                color: backgroundColor.withValues(alpha: 0.8),
                boxShadow: [
                  BoxShadow(
                    color: const Color(0xFF282547).withValues(alpha: .15),
                    blurRadius: 20,
                  ),
                ],
              ),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  const SizedBox(),
                  Text(
                    title,
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(
                      fontFamily: fontType.toString(),
                      fontSize: 16,
                      color: titleTextColor,
                      fontWeight: FontWeight.w700,
                    ),
                    textAlign: TextAlign.center,
                  ),
                  const SizedBox(),
                ],
              ),
            ),
            Container(
              padding:
                  const EdgeInsets.symmetric(horizontal: 10.0, vertical: 5.0),
              decoration: const BoxDecoration(
                color: Color(0x83CEECE8),
                borderRadius: BorderRadius.only(
                    bottomRight: Radius.circular(10),
                    topLeft: Radius.circular(20)),
              ),
              child: Text(
                count,
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: kActiveIconColor,
                  fontWeight: FontWeight.w700,
                  fontSize: 12,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  void getItemNavigate(String title, String desc, BuildContext context) {
    Navigator.push(
        context,
        PageTransition(
            child: TextPageView(
              title: title,
              sarder: widget.sarder!,
              desc: desc,
            ),
            type: PageTransitionType.leftToRightWithFade));
  }

  @override
  void initState() {
    super.initState();
    fontType = Provider.of<SettingsProvider>(context, listen: false)
        .getsettingField('font_family');
    soranif.add(MyListViewitems(
      drezha:
          "نیشانەیەکی تر نيشانەگەورەکانی ڕۆژیی دوای کە پێغەمبەری خوا(صلی الله علیە وسلم) پێی ڕاگەیاندووین بریتییە لە رۆچوونی زەوی کە تێيدا خەلکەکە ڕائەچڵەکێنێت و کاریگەری زۆر درووست دەکات.\n\nمانای(الخسف) \nبریتییە لە شەقبوونی زەوی لەناووچووان و هەڵوەشانی ئەوەی لەسەرییەتی. بێگومان لە ڕابردوو و ئێستا زۆر جۆر ڕۆچوون و زەمێنلەرزەو تەپین ڕوویانداوەو ڕوو ئەدەن هەرهەمووی ئەوەستێتەوە سەر بەهێزی بێهێزی ئەو ڕۆچوونەوە بەڵام ئەو ڕۆچوونەی کە پێغەمبەری خوا (صلی الله علیە وسلم) ئاماژەی پێ ئەدات کاریگەری زۆر پەیدا ئەکات کەهەموو دونیا باسی ئەکەن. \n\nڕۆچوونەکان سێ ڕووچوون ئەبن هەروەک لە فەرموودەکاندا باس کراوە بریتین لە نیشانەگەورەکانی هاتنی ڕۆژی دوایی.\n\n",
      sarder: "نيشانەی ڕۆچوونی زەوی",
    ));
    soranif.add(MyListViewitems(
      drezha:
          "پێغەمبەری خوا (صلی الله علیە وسلم) دەفەرموێت:\n\n( إِنَّهَا لَنْ تَقُومَ حَتَّى تَرَوْنَ قَبْلَهَا عَشْرَ آيَاتٍ فَذَكَرَ الدُّخَانَ وَالدَّجَّالَ وَالدَّابَّةَ وَطُلُوعَ الشَّمْسِ مِنْ مَغْرِبِهَا وَنُزُولَ عِيسَى ابْنِ مَرْيَمَ وَيَأَجُوجَ وَمَأْجُوجَ وَثَلاَثَةَ خُسُوفٍ خَسْفٌ بِالْمَشْرِقِ وَخَسْفٌ بِالْمَغْرِبِ وَخَسْفٌ بِجَزِيرَةِ الْعَرَبِ وَآخِرُ ذَلِكَ نَارٌ تَخْرُجُ مِنَ الْيَمَنِ تَطْرُدُ النَّاسَ إِلَى مَحْشَرِهِمْ )( مسلم(٥١٦٧) وابو داود والترمذي عَنْ أَبِي هَرَيْرَةَ (رَضيَ اللهُ عَنْهُ ).\n\nواتە: قیامەت هەڵناسێت تاکوو پێش ئەوە (۱۰دە)نیشانە نەبینن لەوانە باسی کرد لە دوکەڵ و دەججال و هەڵهاتنی خۆر لە خۆرئاواوە دابەزینی عیسای کوڕی مەریەم (سەلامی خوای لێ بێت) يەئجووج ومەئەجووج و سێ ڕۆچوون کە یەکیان لە ڕۆژهەڵات و یەکیان لە خۆرئاواو ئەوەی تر دووگەی عەرەبی ڕووئەدەن دوایینیان دەرکەوتنی ئاگرێکی گەورەیە کە لەیەمەن هەڵدەسێت و خەڵکی ڕاو ئەنێت بۆ شوێنی حەشربوونیان!\n\n",
      sarder: "قیامەت هەڵناسێت تاکوو پێش ئەوە دە. نیشانەنەبینن",
    ));
    soranif.add(MyListViewitems(
      drezha:
          "پێغەمبەری خوا(صلی الله علیە وسلم)دەفەرموێت:\n\n( كُونُ اخْتِلَافٌ عِنْدَ مَوْتِ خَلِيفَةٍ، فَيَخْرُجُ رَجُلٌ مِنْ أَهْلِ الْمَدِينَةِ هَارِبًا إِلَى مَكَّةَ، فَيَأْتِيهِ نَاسٌ مِنْ أَهْلِ مَكَّةَ فَيُخْرِجُونَهُ وَهُوَ كَارِهٌ. فَيُبَايِعُونَهُ بَيْنَ الرُّكْنِ وَالْمَقَامِ. وَيُبْعَثُ إِلَيْهِ بَعْثٌ مِنْ أَهْلِ الشَّامِ، فَيُخْسَفُ بِهِمْ بِالْبَيْدَاءِ بَيْنَ مَكَّةَ وَالْمَدِينَةِ. فَإِذَا رَأَى النَّاسُ ذَلِكَ أَتَاهُ أَبْدَالُ الشَّامِ وَعَصَائِبُ أَهْلِ الْعِرَاقِ فَيُبَايِعُونَهُ )(أخرجه وأبوداوود بسند لا بأس وتدغدعةدمه الكثبر من الأحاديث الصحيحة الأخري عَنْ أَمً سَلَمَةَ (رَضيَ اللهُ عَنْهُ ).\n\nواتە: لەدوای مردنی خەلیفە خیلاف و ناکۆکی دەکەوێتە نێوان خەڵکەوە پیاوێکی شاری لە مەدینە دەردەچی و ڕائەکات بەرەو مەککە خەڵکی مەککە دێن بۆلای و بەزۆر دەری دەهێنن و لەنێوان (روکن)و (مەقام) بەزۆر بەیعەتی پێ ئەدەن لەشکرێک لەشامەوە بۆی بەڕێ ئەکەوێت (یانی داگیرکردنى کەعبە) لە (بەیدا) کەبیابانێکە لەنێوان مەککەو مەدینەوە ئەم لەشکرە ڕۆ ئەچێت بە زەویدا کاتێ خەڵکی ئەوە ئەبینن خواناسان ئەهلی شام و پۆڵە موجاهیدەکانی ئەهلی عێراق دێن بەیعەتی پی ئەدەن.\n\n",
      sarder: "مردنی خەلیفە",
    ));
    soranif.add(MyListViewitems(
      drezha:
          "پێغەمبەری خوا (صلی الله علیە وسلم) دەفەرموێت:\n\n ( يُمْسَخُ قَوْمٌ مِنْ هَذِهِ الأُمَّةِ فِي آخِرِ الزَّمَانِ قِرَدَةً وَخَنَازِيرَ  ، قَالُوا : يَا رَسُولَ اللَّهِ , أَلَيْسَ يَشْهَدُونَ أَنْ لا إِلَهَ أَلا اللَّهُ , وَأَنَّكَ رَسُولُ اللَّهِ ؟ !نَعَمْ وَيُصَلُّونَ وَيَصُومُونَ, وَيَحُجُّونَ قَالُوا : فَمَا بَالُهُمْ يَا رَسُولَ اللَّهِ ,؟ قَالَ : اتَّخَذُوا الْمَعَازِفَ  وَالْقَيْنَاتِ ,وَالدُّفُوفَ وَيَشْرَبُونَ هَذِهِ الْأَشْرِبَةَ فَبَاتُوا عَلَىَ لَهْوِهِمْ وَشُرْبِهِمْ, فَأَصْبَحُوا قِرَدَةً وَخَنَازِيرَ.)( التذكرة للقرطبي الصفحة أو الرقم) (٦٤٥). \n \nواتە: خەڵکێک لەم ئوممەتە لە کۆتایی زەمان وەک مەیموون و بەرازایان لێ دێت! گوتیان ئەی پێغەمبەری خوا ئایا ئەوانە شایەتی بەوە نادەن کە غەیری خوا هیچ خوایەکی تر نییە و پێغەمبەریش پەیامبەری خوایە؟ ئەویش فەرمووی بەڵێ ڕۆژوو دەگرن و نوێژ دەکەن و حەجیش دەکەن گوتیان ئەی له چيدان؟ فەرمووی مۆسیقا دەژەنن و دەف دەکوتن و گۆرانی دەڵێن لەسەر خۆش ڕابواردنەکانیانەوە دەخەون تا وایان لێ دێت وەک مەیموون و بەرازیان لێ دێت!\n\n",
      sarder:
          "خەڵکێک لەم ئوممەتە لە کۆتایی زەمان وەک مەیموون و بەرازایان لێ دێت",
    ));
    soranif.add(MyListViewitems(
      drezha:
          "پێغەمبەری خوا (صلی الله علیە وسلم) دەفەرموێت:\n\nعَنْ عُمَيَرْ بْنِ حُصَيْنٍ أَنَّ رَسُولَ صَلّي اللهُ عَلَيْهِ وَعَلَى آلِهِ وسَلَّم قَالَ فِي هَذِهِ الْأُمَّةِ خَسْفٌ وَمَسْخٌ وَقَذْفٌ فَقَالَ رَجُلٌ مِنَ الُمُسْلِمِينَ يَا رَسُولَ اللهُ وَمَىَّ ذَاكَ؟ قَالَ إِذَاظَهَرَتِ الْقَيْنَاتُ وَالْمَعَازَفُ وَشُرِبَتَ الْخُمُورُ )(راوه والترمذي وصححه الألباني في صحيح الجامع )(٤٢٧٣).\n\nواتە: عیمرانی کوڕی حوصەین (خوا لێی ڕازی بێت) دەڵێت پێغەمبەر (صلی الله علیە وسلم) فەرمووی لەم ئوممەتە حەسف و مەسح و قەزاف ڕوو ئەدات پیاوێک لە مسوڵمانان گوتی ئەی پێغەمبەری خوا (صلی الله علیە وسلم) ئەمە کەی ڕوو ئەدات؟ فەرمووی ئەگەر زیناو ئامێری موسیقاو گۆرانی دەرکەوتن و دەست کرا بە خواردنەوەی  ئارەقەکان!!!\n\n",
      sarder: "ئەگەر زیناو ئامێری موسیقاو گۆرانی دەرکەوت",
    ));
    soranif.add(MyListViewitems(
      drezha:
          "پێغەمبەری خوا(صلی الله علیە وسل)دەفەرمووێت:\n\n( بَيْنَمَا رَجُلٌ يَتَبَخْتَرُ يَمْشِي بُرْدَنْهِ أَعْجَبَتْهُ نَفْسُهُ فَخَسَفَ اللهُ اِلْأَرْضَ فَهَوَ يَتَجَلْجَلُ فِيهَا إِلَي يَوْمِ الْقَوْمَةِ )( راوه البخاري عَنْ أَبِي هَرَيْرَةَ (رَضيَ اللهَ عَنْهُ) مشكاة المصابيح)(٤٧١١)\n\nواتە: پیاوێ کە عەبایەکی لەسەر شان بوو بە نازو فیزەوە ئەڕۆیشت و زۆر بەخۆی ئەنازی خوای گەورە لە زەویدا ڕۆى چوواند تا هاتنی ڕۆژی دواییش هەر لە زەوی دا مەلە ئەکات ئەمێنێتەوە.\n\n",
      sarder: "بە نازو فیزەوە لەسەر زەوی",
    ));
  }
}
