import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:runaki_islam/providers/settings_provider.dart';
import 'package:runaki_islam/util/constans.dart';

class ZakatCalculatorPage extends StatefulWidget {
  const ZakatCalculatorPage({super.key});

  @override
  State<ZakatCalculatorPage> createState() => _ZakatCalculatorPageState();
}

class _ZakatCalculatorPageState extends State<ZakatCalculatorPage> {
  static const double _nisabGoldGram = 85.0;
  static const double _zakatRate = 0.025;
  static const int _topicsStartIndex = 71;
  static const List<_ZakatTopic> _zakatTopics = <_ZakatTopic>[
    _ZakatTopic(title: 'ژمێریاری زکات', icon: Icons.calculate_rounded),
    _ZakatTopic(title: 'زکاتی ئاژەڵ', icon: Icons.pets_rounded),
    _ZakatTopic(title: 'زکاتی کشتوکاڵ', icon: Icons.grass_rounded),
    _ZakatTopic(title: 'زکاتی کاروبار', icon: Icons.storefront_rounded),
    _ZakatTopic(title: 'نِصاب', icon: Icons.balance_rounded),
    _ZakatTopic(title: 'حیسابکردنی زکات', icon: Icons.request_quote_rounded),
    _ZakatTopic(title: 'فیدیە', icon: Icons.receipt_long_rounded),
    _ZakatTopic(title: 'خێر و بەخشین', icon: Icons.volunteer_activism_rounded),
  ];

  int? _fontType;
  int _modeIndex = 0;

  final TextEditingController _goldOwnedController = TextEditingController();
  final TextEditingController _goldPriceUsdController = TextEditingController(
    text: '75',
  );
  final TextEditingController _usdToIqdController = TextEditingController(
    text: '1320',
  );
  final TextEditingController _usdCashController = TextEditingController();
  final TextEditingController _iqdCashController = TextEditingController();
  final TextEditingController _usdDebtController = TextEditingController(
    text: '0',
  );
  final TextEditingController _iqdDebtController = TextEditingController(
    text: '0',
  );

  bool _includeDebt = true;

  @override
  void initState() {
    super.initState();
    _fontType = Provider.of<SettingsProvider>(
      context,
      listen: false,
    ).getsettingField('font_family');

    _goldOwnedController.addListener(_rebuild);
    _goldPriceUsdController.addListener(_rebuild);
    _usdToIqdController.addListener(_rebuild);
    _usdCashController.addListener(_rebuild);
    _iqdCashController.addListener(_rebuild);
    _usdDebtController.addListener(_rebuild);
    _iqdDebtController.addListener(_rebuild);
  }

  @override
  void dispose() {
    _goldOwnedController.dispose();
    _goldPriceUsdController.dispose();
    _usdToIqdController.dispose();
    _usdCashController.dispose();
    _iqdCashController.dispose();
    _usdDebtController.dispose();
    _iqdDebtController.dispose();
    super.dispose();
  }

  void _rebuild() {
    if (mounted) {
      setState(() {});
    }
  }

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final shared = _computeShared();
    return Scaffold(
      backgroundColor: bgColor,
      appBar: AppBar(
        toolbarHeight: 76,
        backgroundColor: thirdColor,
        centerTitle: true,
        elevation: 0,
        shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(bottom: Radius.circular(20)),
        ),
        leading: IconButton(
          color: iconColor,
          onPressed: () => Navigator.pop(context),
          icon: const Icon(Icons.arrow_back_ios_rounded),
        ),
        title: Text(
          'زکات و ماڵیات',
          style: simpleTextStyle.copyWith(fontFamily: _fontType.toString()),
        ),
      ),
      body: SafeArea(
        top: false,
        child: SingleChildScrollView(
          physics: const BouncingScrollPhysics(),
          padding: const EdgeInsets.fromLTRB(14, 14, 14, 120),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              _sectionCard(
                child: Directionality(
                  textDirection: TextDirection.rtl,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      _titleRow(
                        icon: Icons.calculate_rounded,
                        title: 'زانیاری هاوبەش',
                      ),
                      const SizedBox(height: 10),
                      _numberField(
                        controller: _goldPriceUsdController,
                        label: 'نرخی 1 گرام زێڕ (دۆلار)',
                        suffix: '\$',
                      ),
                      const SizedBox(height: 10),
                      _numberField(
                        controller: _usdToIqdController,
                        label: '1 دۆلار = چەند دینار',
                        suffix: 'IQD',
                      ),
                      const SizedBox(height: 10),
                      _toggleTile(
                        title: 'قەرز لە ژمێرکردندا حساب بکرێت',
                        value: _includeDebt,
                        onChanged: (value) => setState(() {
                          _includeDebt = value;
                        }),
                      ),
                      const SizedBox(height: 10),
                      Wrap(
                        alignment: WrapAlignment.end,
                        spacing: 8,
                        runSpacing: 8,
                        children: [
                          _chipValue(
                            label:
                                'نصاب بە زێڕ: ${_formatCompact(_nisabGoldGram)} گرام',
                          ),
                          _chipValue(
                            label:
                                'نصاب بە \$: ${_formatCompact(shared.nisabUsd)}',
                          ),
                          _chipValue(
                            label:
                                'نصاب بە دینار: ${_formatCompact(shared.nisabIqd)}',
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 12),
              Directionality(
                textDirection: TextDirection.rtl,
                child: SegmentedButton<int>(
                  style: ButtonStyle(
                    backgroundColor: WidgetStateProperty.resolveWith<Color?>((
                      states,
                    ) {
                      if (states.contains(WidgetState.selected)) {
                        return kActiveIconColor.withValues(alpha: 0.16);
                      }
                      return scheme.surface;
                    }),
                  ),
                  segments: const [
                    ButtonSegment<int>(value: 0, label: Text('زێڕ')),
                    ButtonSegment<int>(value: 1, label: Text('دۆلار')),
                    ButtonSegment<int>(value: 2, label: Text('دینار')),
                  ],
                  selected: {_modeIndex},
                  onSelectionChanged: (value) {
                    setState(() {
                      _modeIndex = value.first;
                    });
                  },
                ),
              ),
              const SizedBox(height: 12),
              if (_modeIndex == 0) _buildGoldMode(shared),
              if (_modeIndex == 1) _buildDollarMode(shared),
              if (_modeIndex == 2) _buildDinarMode(shared),
              const SizedBox(height: 12),
              _buildTopicsCard(),
              const SizedBox(height: 12),
              _sectionCard(
                child: Directionality(
                  textDirection: TextDirection.rtl,
                  child: Text(
                    'تێبینی: ئەم ژمێریارییە یارمەتییە بۆ خێرا هەژماردن. باشترە بۆ حاڵەتە تایبەتەکان پرسیاری زانای شەرعی بکەیت.',
                    style: TextStyle(
                      fontFamily: _fontType.toString(),
                      color: titleTextColor,
                      fontSize: 13.5,
                      fontWeight: FontWeight.w600,
                      height: 1.5,
                    ),
                    textAlign: TextAlign.right,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildGoldMode(_SharedNumbers shared) {
    final ownedGram = _toDouble(_goldOwnedController.text);
    final reached = ownedGram >= _nisabGoldGram;
    final zakatGram = reached ? ownedGram * _zakatRate : 0.0;
    final zakatUsd = zakatGram * shared.goldPriceUsd;
    final zakatIqd = zakatUsd * shared.usdToIqd;

    return _sectionCard(
      child: Directionality(
        textDirection: TextDirection.rtl,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            _titleRow(
              icon: Icons.workspace_premium_rounded,
              title: 'زەکاتی زێڕ',
            ),
            const SizedBox(height: 10),
            _numberField(
              controller: _goldOwnedController,
              label: 'کێشی زێڕەکەت (گرام)',
              suffix: 'g',
            ),
            const SizedBox(height: 12),
            _resultCard(
              reached: reached,
              rows: [
                _ResultRow(
                  label: 'کۆی زێڕ',
                  value: '${_formatCompact(ownedGram)} گرام',
                ),
                _ResultRow(
                  label: 'زەکات بە گرام',
                  value: '${_formatCompact(zakatGram)} گرام',
                ),
                _ResultRow(
                  label: 'زەکات بە دۆلار',
                  value: '\$ ${_formatCompact(zakatUsd)}',
                ),
                _ResultRow(
                  label: 'زەکات بە دینار',
                  value: '${_formatCompact(zakatIqd)} IQD',
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildDollarMode(_SharedNumbers shared) {
    final cash = _toDouble(_usdCashController.text);
    final debt = _includeDebt ? _toDouble(_usdDebtController.text) : 0.0;
    final net = math.max(0.0, cash - debt);
    final reached = net >= shared.nisabUsd;
    final zakatUsd = reached ? net * _zakatRate : 0.0;
    final zakatIqd = zakatUsd * shared.usdToIqd;

    return _sectionCard(
      child: Directionality(
        textDirection: TextDirection.rtl,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            _titleRow(icon: Icons.attach_money_rounded, title: 'زەکاتی دۆلار'),
            const SizedBox(height: 10),
            _numberField(
              controller: _usdCashController,
              label: 'کۆی پارەی دۆلار',
              suffix: '\$',
            ),
            const SizedBox(height: 10),
            _numberField(
              controller: _usdDebtController,
              label: 'قەرز (دۆلار)',
              suffix: '\$',
              enabled: _includeDebt,
            ),
            const SizedBox(height: 12),
            _resultCard(
              reached: reached,
              rows: [
                _ResultRow(
                  label: 'کۆی پاک (دوای قەرز)',
                  value: '\$ ${_formatCompact(net)}',
                ),
                _ResultRow(
                  label: 'نصاب',
                  value: '\$ ${_formatCompact(shared.nisabUsd)}',
                ),
                _ResultRow(
                  label: 'زەکات بە دۆلار',
                  value: '\$ ${_formatCompact(zakatUsd)}',
                ),
                _ResultRow(
                  label: 'زەکات بە دینار',
                  value: '${_formatCompact(zakatIqd)} IQD',
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildDinarMode(_SharedNumbers shared) {
    final cash = _toDouble(_iqdCashController.text);
    final debt = _includeDebt ? _toDouble(_iqdDebtController.text) : 0.0;
    final net = math.max(0.0, cash - debt);
    final reached = net >= shared.nisabIqd;
    final zakatIqd = reached ? net * _zakatRate : 0.0;
    final zakatUsd = shared.usdToIqd == 0 ? 0.0 : (zakatIqd / shared.usdToIqd);

    return _sectionCard(
      child: Directionality(
        textDirection: TextDirection.rtl,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            _titleRow(icon: Icons.payments_rounded, title: 'زەکاتی دینار'),
            const SizedBox(height: 10),
            _numberField(
              controller: _iqdCashController,
              label: 'کۆی پارەی دینار',
              suffix: 'IQD',
            ),
            const SizedBox(height: 10),
            _numberField(
              controller: _iqdDebtController,
              label: 'قەرز (دینار)',
              suffix: 'IQD',
              enabled: _includeDebt,
            ),
            const SizedBox(height: 12),
            _resultCard(
              reached: reached,
              rows: [
                _ResultRow(
                  label: 'کۆی پاک (دوای قەرز)',
                  value: '${_formatCompact(net)} IQD',
                ),
                _ResultRow(
                  label: 'نصاب',
                  value: '${_formatCompact(shared.nisabIqd)} IQD',
                ),
                _ResultRow(
                  label: 'زەکات بە دینار',
                  value: '${_formatCompact(zakatIqd)} IQD',
                ),
                _ResultRow(
                  label: 'زەکات بە دۆلار',
                  value: '\$ ${_formatCompact(zakatUsd)}',
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildTopicsCard() {
    return _sectionCard(
      child: Directionality(
        textDirection: TextDirection.rtl,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            _titleRow(
              icon: Icons.menu_book_rounded,
              title: 'VI. زکات و ماڵیات (71–78)',
            ),
            const SizedBox(height: 10),
            ...List<Widget>.generate(_zakatTopics.length, (index) {
              final topic = _zakatTopics[index];
              final number = _topicsStartIndex + index;
              return Padding(
                padding: const EdgeInsets.only(bottom: 8),
                child: Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 10,
                    vertical: 9,
                  ),
                  decoration: BoxDecoration(
                    color: myColor.withValues(alpha: 0.32),
                    borderRadius: BorderRadius.circular(11),
                    border: Border.all(color: strokeColor),
                  ),
                  child: Row(
                    children: [
                      Container(
                        width: 28,
                        height: 28,
                        decoration: BoxDecoration(
                          color: kActiveIconColor.withValues(alpha: 0.14),
                          borderRadius: BorderRadius.circular(9),
                        ),
                        child: Icon(
                          topic.icon,
                          size: 16,
                          color: kActiveIconColor,
                        ),
                      ),
                      const SizedBox(width: 8),
                      Expanded(
                        child: Text(
                          topic.title,
                          textAlign: TextAlign.right,
                          style: TextStyle(
                            fontFamily: _fontType.toString(),
                            fontWeight: FontWeight.w700,
                            color: kTextColor,
                            fontSize: 14.5,
                          ),
                        ),
                      ),
                      const SizedBox(width: 8),
                      Container(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 8,
                          vertical: 4,
                        ),
                        decoration: BoxDecoration(
                          color: Colors.white.withValues(alpha: 0.86),
                          borderRadius: BorderRadius.circular(8),
                          border: Border.all(color: strokeColor),
                        ),
                        child: Text(
                          '$number',
                          style: const TextStyle(
                            fontFamily: 'english',
                            fontWeight: FontWeight.w700,
                            fontSize: 12.5,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              );
            }),
          ],
        ),
      ),
    );
  }

  _SharedNumbers _computeShared() {
    final goldPriceUsd = _toDouble(_goldPriceUsdController.text);
    final usdToIqd = _toDouble(_usdToIqdController.text);
    final nisabUsd = _nisabGoldGram * goldPriceUsd;
    final nisabIqd = nisabUsd * usdToIqd;
    return _SharedNumbers(
      goldPriceUsd: goldPriceUsd,
      usdToIqd: usdToIqd,
      nisabUsd: nisabUsd,
      nisabIqd: nisabIqd,
    );
  }

  Widget _sectionCard({required Widget child}) {
    final scheme = Theme.of(context).colorScheme;
    final isDark = Theme.of(context).brightness == Brightness.dark;
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: scheme.surface.withValues(alpha: isDark ? 0.88 : 0.95),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: scheme.outline.withValues(alpha: isDark ? 0.3 : 0.18),
        ),
        boxShadow: [
          BoxShadow(
            color: scheme.shadow.withValues(alpha: isDark ? 0.22 : 0.08),
            blurRadius: 14,
            offset: const Offset(0, 7),
          ),
        ],
      ),
      child: child,
    );
  }

  Widget _titleRow({required IconData icon, required String title}) {
    return Row(
      children: [
        Container(
          width: 34,
          height: 34,
          decoration: BoxDecoration(
            color: kActiveIconColor.withValues(alpha: 0.12),
            borderRadius: BorderRadius.circular(10),
          ),
          child: Icon(icon, color: kActiveIconColor, size: 18),
        ),
        const SizedBox(width: 10),
        Expanded(
          child: Text(
            title,
            textAlign: TextAlign.right,
            style: TextStyle(
              fontFamily: _fontType.toString(),
              fontSize: 15.5,
              fontWeight: FontWeight.w800,
              color: kTextColor,
            ),
          ),
        ),
      ],
    );
  }

  Widget _chipValue({required String label}) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 7),
      decoration: BoxDecoration(
        color: kActiveIconColor.withValues(alpha: 0.10),
        borderRadius: BorderRadius.circular(10),
      ),
      child: Text(
        label,
        style: TextStyle(
          fontFamily: _fontType.toString(),
          fontSize: 13,
          fontWeight: FontWeight.w700,
          color: kActiveIconColor,
        ),
      ),
    );
  }

  Widget _numberField({
    required TextEditingController controller,
    required String label,
    required String suffix,
    bool enabled = true,
  }) {
    return TextField(
      controller: controller,
      enabled: enabled,
      textAlign: TextAlign.right,
      keyboardType: const TextInputType.numberWithOptions(decimal: true),
      style: TextStyle(
        fontFamily: _fontType.toString(),
        fontWeight: FontWeight.w700,
      ),
      decoration: InputDecoration(
        labelText: label,
        suffixText: suffix,
        filled: true,
        fillColor: enabled
            ? myColor.withValues(alpha: 0.38)
            : Colors.grey.shade200,
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: BorderSide(color: strokeColor),
        ),
      ),
    );
  }

  Widget _toggleTile({
    required String title,
    required bool value,
    required ValueChanged<bool> onChanged,
  }) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      decoration: BoxDecoration(
        color: myColor.withValues(alpha: 0.35),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: strokeColor),
      ),
      child: Row(
        children: [
          Transform.scale(
            scale: 0.90,
            child: Switch(
              value: value,
              onChanged: onChanged,
              activeTrackColor: kActiveIconColor,
            ),
          ),
          Expanded(
            child: Text(
              title,
              textAlign: TextAlign.right,
              style: TextStyle(
                fontFamily: _fontType.toString(),
                fontWeight: FontWeight.w700,
                color: kTextColor.withValues(alpha: 0.85),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _resultCard({required bool reached, required List<_ResultRow> rows}) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: reached
            ? const Color(0xFF18A874).withValues(alpha: 0.11)
            : const Color(0xFFD86A4A).withValues(alpha: 0.11),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: reached
              ? const Color(0xFF18A874).withValues(alpha: 0.35)
              : const Color(0xFFD86A4A).withValues(alpha: 0.35),
        ),
      ),
      child: Column(
        children: [
          Row(
            children: [
              Icon(
                reached ? Icons.check_circle_rounded : Icons.info_rounded,
                color: reached
                    ? const Color(0xFF0D8E61)
                    : const Color(0xFFB6573C),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: Text(
                  reached
                      ? 'گەیشتوویتە نصاب، زەکات دەکەوێت.'
                      : 'هێشتا نەگەیشتوویتە نصاب، زەکات ناکەوێت.',
                  textAlign: TextAlign.right,
                  style: TextStyle(
                    fontFamily: _fontType.toString(),
                    fontWeight: FontWeight.w700,
                    color: kTextColor.withValues(alpha: 0.88),
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),
          ...rows.map((row) => _resultRow(row.label, row.value)),
        ],
      ),
    );
  }

  Widget _resultRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        children: [
          Text(
            value,
            style: TextStyle(
              fontFamily: 'english',
              fontWeight: FontWeight.w700,
              color: kTextColor,
              fontSize: 13.5,
            ),
          ),
          const SizedBox(width: 8),
          Expanded(
            child: Text(
              label,
              textAlign: TextAlign.right,
              style: TextStyle(
                fontFamily: _fontType.toString(),
                fontWeight: FontWeight.w600,
                color: titleTextColor,
              ),
            ),
          ),
        ],
      ),
    );
  }

  double _toDouble(String raw) {
    final cleaned = raw.replaceAll(',', '').trim();
    return double.tryParse(cleaned) ?? 0.0;
  }

  String _formatCompact(double value) {
    if (!value.isFinite) return '0';
    final isWhole = (value - value.roundToDouble()).abs() < 0.0001;
    if (isWhole) {
      return value.round().toString();
    }
    return value.toStringAsFixed(2);
  }
}

class _SharedNumbers {
  const _SharedNumbers({
    required this.goldPriceUsd,
    required this.usdToIqd,
    required this.nisabUsd,
    required this.nisabIqd,
  });

  final double goldPriceUsd;
  final double usdToIqd;
  final double nisabUsd;
  final double nisabIqd;
}

class _ResultRow {
  const _ResultRow({required this.label, required this.value});

  final String label;
  final String value;
}

class _ZakatTopic {
  const _ZakatTopic({required this.title, required this.icon});

  final String title;
  final IconData icon;
}
