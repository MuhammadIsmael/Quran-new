import 'dart:async';
import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import 'package:runaki_islam/providers/settings_provider.dart';
import 'package:runaki_islam/services/ai_chat_history_service.dart';
import 'package:runaki_islam/services/gemini_ai_service.dart';

class IslamicAiSectionConfig {
  const IslamicAiSectionConfig({
    required this.id,
    required this.title,
    required this.subtitle,
    required this.icon,
    required this.welcomeMessage,
    required this.systemPrompt,
    required this.suggestedPrompts,
  });

  final String id;
  final String title;
  final String subtitle;
  final IconData icon;
  final String welcomeMessage;
  final String systemPrompt;
  final List<String> suggestedPrompts;
}

class IslamicAiChatPage extends StatefulWidget {
  const IslamicAiChatPage({super.key, required this.config}) : sections = null;
  const IslamicAiChatPage.unified({super.key, required this.sections})
    : config = null;

  final IslamicAiSectionConfig? config;
  final List<IslamicAiSectionConfig>? sections;

  @override
  State<IslamicAiChatPage> createState() => _IslamicAiChatPageState();
}

class _IslamicAiChatPageState extends State<IslamicAiChatPage> {
  static const String _fixedSystemPrompt = '''
You are Runaki Islam AI, the in-app Islamic assistant for the Runaki Islam mobile app.

Core behavior:
- Default language is Sorani Kurdish written in Arabic script.
- Switch language only when the user clearly asks for another language.
- Answer with calm, natural, practical wording.
- Be concise first, then add useful detail when needed.
- Use short sections or bullets when that improves clarity.
- Maintain context from the current conversation and answer the latest question directly.
- Do not repeat large parts of earlier answers unless the user asks.
- If you are uncertain, say so clearly.
- Do not invent Quran verses, hadith texts, scholar names, or references.
- Only mention references when reasonably confident.
- Never present yourself as a replacement for a qualified local scholar or mufti.
- For high-stakes rulings such as marriage, divorce, inheritance, finance, medical, or legal matters, advise consulting a trusted qualified scholar.
- Prefer balanced, non-sectarian explanations.
- End with one useful next step or follow-up suggestion only when it truly helps.
''';

  static const Color _bg = Color(0xFFF6F4EE);
  static const Color _card = Color(0xFFFFFDFC);
  static const Color _line = Color(0xFFE2DDD2);
  static const Color _text = Color(0xFF182127);
  static const Color _muted = Color(0xFF6F786F);
  static const Color _dark = Color(0xFF102A2B);
  static const Color _accent = Color(0xFF1F6F5F);
  static const Color _accentSoft = Color(0xFFE1F0EB);
  static const Color _gold = Color(0xFFD8B76A);

  final GeminiAiService _service = GeminiAiService();
  final AiChatHistoryService _historyService = AiChatHistoryService();
  final TextEditingController _inputController = TextEditingController();
  final TextEditingController _apiKeyController = TextEditingController();
  final ScrollController _scrollController = ScrollController();
  final FocusNode _inputFocusNode = FocusNode();
  final List<AiConversationMessage> _messages = <AiConversationMessage>[];

  late final List<IslamicAiSectionConfig> _sections;

  List<AiConversationRecord> _conversationHistory =
      const <AiConversationRecord>[];
  int _activeSectionIndex = 0;
  bool _initializing = true;
  bool _sending = false;
  bool _draftHasText = false;
  bool _autoScrollEnabled = true;
  bool _showTimestamps = true;
  bool _showQuickPrompts = true;
  String? _activeConversationId;
  String? _lastAuthMessage;

  IslamicAiSectionConfig get _activeSection => _sections[_activeSectionIndex];
  bool get _hasMultipleSections => _sections.length > 1;
  bool get _hasUserMessages => _messages.any((m) => m.isUser);
  bool get _isLanding => !_hasUserMessages;
  bool get _hasSavableConversation => _messages.any((m) => m.isUser);
  List<String> get _quickPrompts =>
      _activeSection.suggestedPrompts.take(4).toList(growable: false);

  @override
  void initState() {
    super.initState();
    _inputController.addListener(_handleDraftChanged);

    final singleSection = widget.config;
    final rawSections =
        widget.sections ??
        (singleSection == null
            ? <IslamicAiSectionConfig>[]
            : <IslamicAiSectionConfig>[singleSection]);
    _sections = rawSections
        .map(_normalizeSectionText)
        .where((section) => section.title.trim().isNotEmpty)
        .toList(growable: false);

    if (_sections.isEmpty) {
      throw StateError('IslamicAiChatPage needs at least one section.');
    }
    unawaited(_bootstrap());
  }

  @override
  void dispose() {
    _apiKeyController.dispose();
    _inputController.removeListener(_handleDraftChanged);
    _inputController.dispose();
    _scrollController.dispose();
    _inputFocusNode.dispose();
    super.dispose();
  }

  Future<void> _bootstrap() async {
    await _primeApiKey();
    await _restoreConversationState();
    if (!mounted) return;
    setState(() => _initializing = false);
    _scrollToBottom(jump: true);
  }

  IslamicAiSectionConfig _normalizeSectionText(IslamicAiSectionConfig section) {
    return IslamicAiSectionConfig(
      id: section.id,
      title: _repairText(section.title),
      subtitle: _repairText(section.subtitle),
      icon: section.icon,
      welcomeMessage: _repairText(section.welcomeMessage),
      systemPrompt: section.systemPrompt.trim(),
      suggestedPrompts: section.suggestedPrompts.map(_repairText).toList(),
    );
  }

  String _repairText(String text) {
    final value = text.trim();
    if (value.isEmpty || !_looksMojibake(value)) {
      return value.isEmpty ? text : value;
    }
    try {
      final decoded = utf8.decode(latin1.encode(value));
      return decoded.trim().isEmpty ? value : decoded.trim();
    } catch (_) {
      return value;
    }
  }

  bool _looksMojibake(String text) {
    if (RegExp(r'[\u0600-\u06FF]').hasMatch(text)) return false;
    return RegExp(r'[\u00D8\u00D9\u00DB\u00C3\u00D0\u00D1]').hasMatch(text);
  }

  void _handleDraftChanged() {
    final next = _inputController.text.trim().isNotEmpty;
    if (!mounted || next == _draftHasText) return;
    setState(() => _draftHasText = next);
  }

  Future<void> _primeApiKey() async {
    try {
      await _service.resolveApiKey();
    } catch (_) {}
  }

  Future<void> _restoreConversationState() async {
    final history = await _historyService.loadConversations();
    final activeId = await _historyService.loadActiveConversationId();
    AiConversationRecord? selected;
    if (activeId != null) {
      for (final item in history) {
        if (item.id == activeId) {
          selected = item;
          break;
        }
      }
    }
    selected ??= history.isNotEmpty ? history.first : null;

    if (!mounted) return;
    setState(() {
      _conversationHistory = history;
      if (selected == null) {
        _seedWelcomeConversation();
      } else {
        _applyConversation(selected);
      }
    });
  }

  Future<void> _showSnack(String message) async {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(_repairText(message), textAlign: TextAlign.right)),
    );
  }

  String _buildSystemPrompt() {
    return '''
$_fixedSystemPrompt

Section behavior:
${_activeSection.systemPrompt}
''';
  }

  void _seedWelcomeConversation() {
    _activeConversationId = null;
    _messages
      ..clear()
      ..add(
        AiConversationMessage(
          id: _newId(),
          role: AiConversationMessageRole.assistant,
          text: _activeSection.welcomeMessage,
          createdAt: DateTime.now(),
        ),
      );
  }

  void _applyConversation(AiConversationRecord record) {
    var index = _activeSectionIndex;
    for (var i = 0; i < _sections.length; i++) {
      if (_sections[i].id == record.sectionId) {
        index = i;
        break;
      }
    }
    _activeSectionIndex = index;
    _activeConversationId = record.id;
    _messages
      ..clear()
      ..addAll(
        record.messages
            .map((m) => m.copyWith(text: _repairText(m.text)))
            .toList(growable: false),
      );
    if (_messages.isEmpty) _seedWelcomeConversation();
  }

  String _newId() => DateTime.now().microsecondsSinceEpoch.toString();

  AiConversationRecord? _buildConversationRecord() {
    if (!_hasSavableConversation) return null;
    final firstMeaningful = _messages.firstWhere(
      (m) => m.isUser,
      orElse: () => _messages.first,
    );
    final lastMeaningful = _messages.lastWhere(
      (m) => !m.isMeta,
      orElse: () => _messages.last,
    );
    return AiConversationRecord(
      id: _activeConversationId ?? _newId(),
      sectionId: _activeSection.id,
      title: _truncateSingleLine(_repairText(firstMeaningful.text), 48),
      preview: _truncateSingleLine(_repairText(lastMeaningful.text), 90),
      createdAt: _messages.first.createdAt,
      updatedAt: _messages.last.createdAt,
      messages: List<AiConversationMessage>.from(_messages),
    );
  }

  String _truncateSingleLine(String value, int limit) {
    final normalized = value.replaceAll(RegExp(r'\s+'), ' ').trim();
    if (normalized.isEmpty) return _activeSection.title;
    if (normalized.length <= limit) return normalized;
    return '${normalized.substring(0, limit).trimRight()}...';
  }

  Future<void> _persistCurrentConversation() async {
    final record = _buildConversationRecord();
    if (record == null) {
      await _historyService.saveActiveConversationId(null);
      return;
    }
    _activeConversationId = record.id;
    await _historyService.saveConversation(record);
    await _historyService.saveActiveConversationId(record.id);
    final next = <AiConversationRecord>[
      record,
      ..._conversationHistory.where((item) => item.id != record.id),
    ]..sort((a, b) => b.updatedAt.compareTo(a.updatedAt));
    if (!mounted) return;
    setState(() {
      _conversationHistory = next.take(30).toList(growable: false);
    });
  }

  Future<void> _startNewConversation({int? sectionIndex}) async {
    if (!mounted) return;
    setState(() {
      if (sectionIndex != null) _activeSectionIndex = sectionIndex;
      _seedWelcomeConversation();
      _sending = false;
    });
    await _historyService.saveActiveConversationId(null);
    _inputController.clear();
    _scrollToBottom(jump: true);
    if (mounted) _inputFocusNode.requestFocus();
  }

  Future<void> _loadConversation(AiConversationRecord record) async {
    if (!mounted) return;
    setState(() => _applyConversation(record));
    await _historyService.saveActiveConversationId(record.id);
    _scrollToBottom(jump: true);
  }

  Future<void> _deleteConversation(AiConversationRecord record) async {
    await _historyService.deleteConversation(record.id);
    final next = _conversationHistory
        .where((item) => item.id != record.id)
        .toList(growable: false);
    if (!mounted) return;
    setState(() {
      _conversationHistory = next;
      if (_activeConversationId == record.id) _seedWelcomeConversation();
    });
    if (_activeConversationId == record.id) {
      await _historyService.saveActiveConversationId(null);
    }
  }

  Future<bool> _ensureApiKeyConfigured() async {
    final key = await _service.resolveApiKey();
    if (key != null && key.isNotEmpty) return true;
    if (!mounted) return false;
    return _showApiKeyDialog(
      message: 'بۆ چالاککردنی AI پێویستە ڕێکخستنەکە تەواو بکەیت.',
    );
  }

  Future<bool> _showApiKeyDialog({String? message}) async {
    final messenger = ScaffoldMessenger.of(context);
    final fontFamily = _fontFamily(context);
    final savedKey = await _service.loadSavedApiKey() ?? '';
    if (!mounted) return false;
    _apiKeyController.text = savedKey;
    var obscureText = true;

    final didSave = await showDialog<bool>(
      context: context,
      builder: (dialogContext) {
        return StatefulBuilder(
          builder: (context, setDialogState) {
            return AlertDialog(
              backgroundColor: const Color(0xFFF8F8F4),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(24),
              ),
              title: Text(
                'ڕێکخستنی AI',
                textAlign: TextAlign.right,
                style: TextStyle(fontFamily: fontFamily, color: _text),
              ),
              content: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.end,
                children: <Widget>[
                  Text(
                    message ?? 'زانیاریی پێویست لێرە داخل بکە.',
                    textAlign: TextAlign.right,
                    style: TextStyle(fontFamily: fontFamily, color: _muted),
                  ),
                  const SizedBox(height: 12),
                  TextField(
                    controller: _apiKeyController,
                    obscureText: obscureText,
                    enableSuggestions: false,
                    autocorrect: false,
                    textDirection: TextDirection.ltr,
                    decoration: InputDecoration(
                      hintText: 'AIza...',
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(18),
                      ),
                      suffixIcon: IconButton(
                        onPressed: () {
                          setDialogState(() => obscureText = !obscureText);
                        },
                        icon: Icon(
                          obscureText
                              ? Icons.visibility_rounded
                              : Icons.visibility_off_rounded,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
              actions: <Widget>[
                if (savedKey.isNotEmpty)
                  TextButton(
                    onPressed: () async {
                      final navigator = Navigator.of(dialogContext);
                      await _service.saveApiKey('');
                      if (!mounted) return;
                      navigator.pop(false);
                      messenger.showSnackBar(
                        const SnackBar(content: Text('ڕێکخستنەکە سڕایەوە.')),
                      );
                    },
                    child: Text(
                      'سڕینەوە',
                      style: TextStyle(fontFamily: fontFamily),
                    ),
                  ),
                TextButton(
                  onPressed: () => Navigator.of(dialogContext).pop(false),
                  child: Text(
                    'داخستن',
                    style: TextStyle(fontFamily: fontFamily),
                  ),
                ),
                FilledButton(
                  onPressed: () async {
                    final navigator = Navigator.of(dialogContext);
                    final value = _apiKeyController.text.trim();
                    if (value.isEmpty) {
                      messenger.showSnackBar(
                        const SnackBar(
                          content: Text(
                            'تکایە سەرەتا زانیاریی پێویست داخل بکە.',
                          ),
                        ),
                      );
                      return;
                    }
                    await _service.saveApiKey(value);
                    if (!mounted) return;
                    navigator.pop(true);
                    messenger.showSnackBar(
                      const SnackBar(content: Text('ڕێکخستنەکە پاشەکەوت کرا.')),
                    );
                  },
                  style: FilledButton.styleFrom(
                    backgroundColor: _dark,
                    foregroundColor: Colors.white,
                  ),
                  child: Text(
                    'پاشەکەوت',
                    style: TextStyle(fontFamily: fontFamily),
                  ),
                ),
              ],
            );
          },
        );
      },
    );

    return didSave ?? false;
  }

  Future<void> _sendMessage([String? forcedPrompt]) async {
    if (_sending) return;

    final text = _repairText((forcedPrompt ?? _inputController.text).trim());
    if (text.isEmpty) return;
    if (!await _ensureApiKeyConfigured()) return;
    if (forcedPrompt == null) _inputController.clear();
    _inputFocusNode.unfocus();

    final userMessage = AiConversationMessage(
      id: _newId(),
      role: AiConversationMessageRole.user,
      text: text,
      createdAt: DateTime.now(),
    );

    setState(() {
      _messages.add(userMessage);
      _sending = true;
    });
    _scrollToBottom();
    await _persistCurrentConversation();

    try {
      final history = _messages
          .where((m) => !m.isMeta)
          .map((m) => AiChatTurn(isUser: m.isUser, text: _repairText(m.text)))
          .toList(growable: false);
      final reply = await _service.generateReply(
        systemPrompt: _buildSystemPrompt(),
        history: history,
      );

      if (!mounted) return;
      setState(() {
        _messages.add(
          AiConversationMessage(
            id: _newId(),
            role: AiConversationMessageRole.assistant,
            text: _repairText(reply),
            createdAt: DateTime.now(),
          ),
        );
        _sending = false;
      });
      _scrollToBottom();
      await _persistCurrentConversation();
    } on GeminiAuthException catch (error) {
      if (!mounted) return;
      _lastAuthMessage = _repairText(error.message);
      setState(() {
        _messages.add(
          AiConversationMessage(
            id: _newId(),
            role: AiConversationMessageRole.meta,
            text: _lastAuthMessage!,
            createdAt: DateTime.now(),
          ),
        );
        _sending = false;
      });
      await _persistCurrentConversation();
    } on GeminiApiException catch (error) {
      if (!mounted) return;
      setState(() {
        _messages.add(
          AiConversationMessage(
            id: _newId(),
            role: AiConversationMessageRole.meta,
            text: 'هەڵە: ${_repairText(error.message)}',
            createdAt: DateTime.now(),
          ),
        );
        _sending = false;
      });
      await _persistCurrentConversation();
    } catch (error) {
      if (!mounted) return;
      setState(() {
        _messages.add(
          AiConversationMessage(
            id: _newId(),
            role: AiConversationMessageRole.meta,
            text: 'هەڵەی نەنەسراو ڕوویدا. تکایە دووبارە هەوڵ بدەوە.',
            createdAt: DateTime.now(),
          ),
        );
        _sending = false;
      });
      await _persistCurrentConversation();
      unawaited(_showSnack(error.toString()));
    }
  }

  void _copyMessage(AiConversationMessage message) {
    Clipboard.setData(ClipboardData(text: _repairText(message.text)));
    HapticFeedback.selectionClick();
    unawaited(_showSnack('دەقەکە کۆپی کرا.'));
  }

  String _sectionTitleForId(String sectionId) {
    for (final section in _sections) {
      if (section.id == sectionId) return section.title;
    }
    return _activeSection.title;
  }

  String _fontFamily(BuildContext context) {
    return Provider.of<SettingsProvider>(
      context,
      listen: false,
    ).getsettingField('font_family').toString();
  }

  void _scrollToBottom({bool jump = false}) {
    if (!_autoScrollEnabled && !jump) return;
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!_scrollController.hasClients) return;
      final target = _scrollController.position.maxScrollExtent + 60;
      if (jump) {
        _scrollController.jumpTo(target);
      } else {
        _scrollController.animateTo(
          target,
          duration: const Duration(milliseconds: 220),
          curve: Curves.easeOutCubic,
        );
      }
    });
  }

  Future<void> _handleMenuAction(
    _AiChatMenuAction action,
    String fontFamily,
  ) async {
    switch (action) {
      case _AiChatMenuAction.newConversation:
        await _startNewConversation();
        break;
      case _AiChatMenuAction.featureSettings:
        await _openFeatureSettingsSheet(fontFamily);
        break;
    }
  }

  Future<void> _openFeatureSettingsSheet(String fontFamily) async {
    await showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (sheetContext) {
        return StatefulBuilder(
          builder: (context, setSheetState) {
            return SafeArea(
              top: false,
              child: Container(
                margin: const EdgeInsets.fromLTRB(12, 0, 12, 12),
                padding: const EdgeInsets.fromLTRB(16, 16, 16, 12),
                decoration: BoxDecoration(
                  color: const Color(0xFFF8F8F4),
                  borderRadius: BorderRadius.circular(28),
                  border: Border.all(color: _line),
                ),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: <Widget>[
                    Text(
                      'ڕێکخستنی تایبەتمەندی AI',
                      style: TextStyle(
                        fontFamily: fontFamily,
                        color: _text,
                        fontSize: 17,
                      ),
                    ),
                    const SizedBox(height: 14),
                    SwitchListTile.adaptive(
                      title: Text(
                        'خۆکار بەردەوام بکرێت کە ناوگەی نوێ بنووسێت',
                        textAlign: TextAlign.right,
                        style: TextStyle(fontFamily: fontFamily),
                      ),
                      value: _autoScrollEnabled,
                      onChanged: (value) {
                        setSheetState(() => _autoScrollEnabled = value);
                        setState(() {});
                      },
                    ),
                    SwitchListTile.adaptive(
                      title: Text(
                        'کاتی نامەکان لە دیالوگ پەردانەکان نیشان بدە',
                        textAlign: TextAlign.right,
                        style: TextStyle(fontFamily: fontFamily),
                      ),
                      value: _showTimestamps,
                      onChanged: (value) {
                        setSheetState(() => _showTimestamps = value);
                        setState(() {});
                      },
                    ),
                    SwitchListTile.adaptive(
                      title: Text(
                        'پێشنیارەکانی خێرا لە پەڕەی سەرەکی نیشان بدە',
                        textAlign: TextAlign.right,
                        style: TextStyle(fontFamily: fontFamily),
                      ),
                      value: _showQuickPrompts,
                      onChanged: (value) {
                        setSheetState(() => _showQuickPrompts = value);
                        setState(() {});
                      },
                    ),
                    const SizedBox(height: 8),
                    FilledButton(
                      onPressed: () => Navigator.of(sheetContext).pop(),
                      style: FilledButton.styleFrom(
                        backgroundColor: _dark,
                        foregroundColor: Colors.white,
                        minimumSize: const Size.fromHeight(48),
                      ),
                      child: Text(
                        'داخستن',
                        style: TextStyle(fontFamily: fontFamily),
                      ),
                    ),
                  ],
                ),
              ),
            );
          },
        );
      },
    );
  }

  Future<void> _openHistorySheet(String fontFamily) async {
    var items = List<AiConversationRecord>.from(_conversationHistory);
    await showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (sheetContext) {
        return StatefulBuilder(
          builder: (context, setSheetState) {
            return SafeArea(
              top: false,
              child: Container(
                margin: const EdgeInsets.fromLTRB(12, 0, 12, 12),
                padding: const EdgeInsets.fromLTRB(16, 16, 16, 12),
                decoration: BoxDecoration(
                  color: const Color(0xFFF8F8F4),
                  borderRadius: BorderRadius.circular(28),
                  border: Border.all(color: _line),
                ),
                child: ConstrainedBox(
                  constraints: BoxConstraints(
                    maxHeight: MediaQuery.sizeOf(context).height * 0.78,
                  ),
                  child: Column(
                    children: <Widget>[
                      Text(
                        'مێژووی گفتوگۆ',
                        style: TextStyle(fontFamily: fontFamily, color: _text),
                      ),
                      const SizedBox(height: 12),
                      if (items.isEmpty)
                        Expanded(
                          child: Center(
                            child: Text(
                              'هێشتا هیچ گفتوگۆیەک پاشەکەوت نەکراوە.',
                              textAlign: TextAlign.center,
                              style: TextStyle(
                                fontFamily: fontFamily,
                                color: _muted,
                              ),
                            ),
                          ),
                        )
                      else
                        Expanded(
                          child: ListView.separated(
                            itemCount: items.length,
                            separatorBuilder: (_, _) =>
                                const SizedBox(height: 8),
                            itemBuilder: (context, index) {
                              final item = items[index];
                              final isActive = item.id == _activeConversationId;
                              return ListTile(
                                tileColor: isActive
                                    ? const Color(0xFFF0F3F7)
                                    : Colors.white,
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(18),
                                  side: const BorderSide(color: _line),
                                ),
                                onTap: () {
                                  Navigator.of(sheetContext).pop();
                                  _loadConversation(item);
                                },
                                title: Text(
                                  item.title,
                                  textAlign: TextAlign.right,
                                  style: TextStyle(
                                    fontFamily: fontFamily,
                                    color: _text,
                                  ),
                                ),
                                subtitle: Text(
                                  '${_sectionTitleForId(item.sectionId)} • ${_formatDateTime(item.updatedAt)}',
                                  textAlign: TextAlign.right,
                                  style: TextStyle(
                                    fontFamily: fontFamily,
                                    color: _muted,
                                    fontSize: 11.5,
                                  ),
                                ),
                                trailing: IconButton(
                                  onPressed: () async {
                                    await _deleteConversation(item);
                                    items = List<AiConversationRecord>.from(
                                      _conversationHistory,
                                    );
                                    if (mounted) setSheetState(() {});
                                  },
                                  icon: const Icon(
                                    Icons.delete_outline_rounded,
                                  ),
                                ),
                              );
                            },
                          ),
                        ),
                    ],
                  ),
                ),
              ),
            );
          },
        );
      },
    );
  }

  Future<void> _openSectionSheet(String fontFamily) async {
    await showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (sheetContext) {
        return SafeArea(
          top: false,
          child: Container(
            margin: const EdgeInsets.fromLTRB(12, 0, 12, 12),
            padding: const EdgeInsets.fromLTRB(16, 16, 16, 12),
            decoration: BoxDecoration(
              color: const Color(0xFFF8F8F4),
              borderRadius: BorderRadius.circular(28),
              border: Border.all(color: _line),
            ),
            child: ConstrainedBox(
              constraints: BoxConstraints(
                maxHeight: MediaQuery.sizeOf(context).height * 0.78,
              ),
              child: ListView.separated(
                itemCount: _sections.length + 1,
                separatorBuilder: (_, _) => const SizedBox(height: 8),
                itemBuilder: (context, index) {
                  if (index == 0) {
                    return Text(
                      'بەشەکانی AI',
                      textAlign: TextAlign.right,
                      style: TextStyle(fontFamily: fontFamily, color: _text),
                    );
                  }
                  final section = _sections[index - 1];
                  final isActive = index - 1 == _activeSectionIndex;
                  return ListTile(
                    tileColor: isActive
                        ? const Color(0xFFF0F3F7)
                        : Colors.white,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(18),
                      side: const BorderSide(color: _line),
                    ),
                    leading: Icon(section.icon, color: _dark),
                    trailing: Icon(
                      isActive
                          ? Icons.check_circle_rounded
                          : Icons.arrow_back_ios_new_rounded,
                    ),
                    title: Text(
                      section.title,
                      textAlign: TextAlign.right,
                      style: TextStyle(fontFamily: fontFamily, color: _text),
                    ),
                    subtitle: Text(
                      section.subtitle,
                      textAlign: TextAlign.right,
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(
                        fontFamily: fontFamily,
                        color: _muted,
                        fontSize: 11.8,
                      ),
                    ),
                    onTap: _sending
                        ? null
                        : () {
                            Navigator.of(sheetContext).pop();
                            if (index - 1 != _activeSectionIndex) {
                              _startNewConversation(sectionIndex: index - 1);
                            }
                          },
                  );
                },
              ),
            ),
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    final fontFamily = _fontFamily(context);
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        backgroundColor: _bg,
        body: Container(
          decoration: const BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: <Color>[Color(0xFFF4F1E8), Color(0xFFF9F8F4)],
            ),
          ),
          child: Stack(
            children: <Widget>[
              const Positioned(
                top: -60,
                right: -20,
                child: _AmbientGlow(
                  size: 220,
                  colors: <Color>[Color(0x22D8B76A), Color(0x00D8B76A)],
                ),
              ),
              const Positioned(
                top: 140,
                left: -70,
                child: _AmbientGlow(
                  size: 260,
                  colors: <Color>[Color(0x181F6F5F), Color(0x001F6F5F)],
                ),
              ),
              SafeArea(
                child: Column(
                  children: <Widget>[
                    Padding(
                      padding: const EdgeInsets.fromLTRB(18, 14, 18, 8),
                      child: _compactTopBar(fontFamily),
                    ),
                    Expanded(
                      child: _initializing
                          ? _loadingBody(fontFamily)
                          : AnimatedSwitcher(
                              duration: const Duration(milliseconds: 260),
                              switchInCurve: Curves.easeOutCubic,
                              switchOutCurve: Curves.easeInCubic,
                              child: _isLanding
                                  ? _homeBody(fontFamily)
                                  : _chatBody(fontFamily),
                            ),
                    ),
                    if (!_initializing) _inputBar(fontFamily),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _loadingBody(String fontFamily) {
    return Center(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: <Widget>[
          Container(
            width: 68,
            height: 68,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: const LinearGradient(
                colors: <Color>[Color(0xFF1F6F5F), Color(0xFF102A2B)],
              ),
              boxShadow: <BoxShadow>[
                BoxShadow(
                  color: _accent.withValues(alpha: 0.18),
                  blurRadius: 28,
                  offset: const Offset(0, 16),
                ),
              ],
            ),
            child: const Padding(
              padding: EdgeInsets.all(18),
              child: CircularProgressIndicator(
                strokeWidth: 2.6,
                color: Colors.white,
              ),
            ),
          ),
          const SizedBox(height: 18),
          Text(
            'AI chat ئامادە دەکرێت...',
            style: TextStyle(
              fontFamily: fontFamily,
              color: _text,
              fontSize: 16,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            'تکایە چاوەڕێ بکە تا گفتوگۆکەت ئامادە بێت.',
            style: TextStyle(fontFamily: fontFamily, color: _muted),
          ),
        ],
      ),
    );
  }

  Widget _compactTopBar(String fontFamily) {
    final canGoBack = Navigator.canPop(context);
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
      decoration: BoxDecoration(
        color: const Color(0xFF152A2C),
        borderRadius: BorderRadius.circular(24),
        boxShadow: <BoxShadow>[
          BoxShadow(
            color: _dark.withValues(alpha: 0.14),
            blurRadius: 20,
            offset: const Offset(0, 10),
          ),
        ],
      ),
      child: Row(
        children: <Widget>[
          if (canGoBack) ...<Widget>[
            _headerActionButton(
              icon: Icons.arrow_back_ios_new_rounded,
              onPressed: () => Navigator.of(context).maybePop(),
            ),
            const SizedBox(width: 8),
          ],
          _headerActionButton(
            icon: Icons.more_horiz_rounded,
            onPressed: () => _openOverflowMenu(fontFamily),
          ),
          const SizedBox(width: 8),
          _headerActionButton(
            icon: Icons.history_rounded,
            onPressed: () => _openHistorySheet(fontFamily),
          ),
          const Spacer(),
          if (_sending)
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 7),
              decoration: BoxDecoration(
                color: Colors.white.withValues(alpha: 0.1),
                borderRadius: BorderRadius.circular(999),
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: <Widget>[
                  const SizedBox(
                    width: 14,
                    height: 14,
                    child: CircularProgressIndicator(
                      strokeWidth: 2,
                      color: Colors.white,
                    ),
                  ),
                  const SizedBox(width: 8),
                  Text(
                    'AI',
                    style: TextStyle(
                      fontFamily: fontFamily,
                      color: Colors.white,
                    ),
                  ),
                ],
              ),
            ),
          if (_sending) const SizedBox(width: 10),
          Flexible(child: _titlePill(fontFamily)),
        ],
      ),
    );
  }

  Widget _titlePill(String fontFamily) {
    final child = Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
      decoration: BoxDecoration(
        color: Colors.white.withValues(alpha: 0.12),
        borderRadius: BorderRadius.circular(999),
        border: Border.all(color: Colors.white.withValues(alpha: 0.14)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: <Widget>[
          if (_hasMultipleSections) ...<Widget>[
            Icon(
              Icons.keyboard_arrow_down_rounded,
              size: 18,
              color: Colors.white.withValues(alpha: 0.85),
            ),
            const SizedBox(width: 6),
          ],
          Flexible(
            child: Text(
              _activeSection.title,
              overflow: TextOverflow.ellipsis,
              style: TextStyle(fontFamily: fontFamily, color: Colors.white),
            ),
          ),
        ],
      ),
    );
    if (!_hasMultipleSections) return child;
    return InkWell(
      borderRadius: BorderRadius.circular(999),
      onTap: _sending ? null : () => _openSectionSheet(fontFamily),
      child: child,
    );
  }

  Widget _homeBody(String fontFamily) {
    final welcome = _messages.isEmpty
        ? _activeSection.welcomeMessage
        : _repairText(_messages.first.text);
    final recent = _conversationHistory.take(8).toList(growable: false);
    return ListView(
      key: const ValueKey<String>('ai-home'),
      padding: const EdgeInsets.fromLTRB(18, 4, 18, 12),
      children: <Widget>[
        Container(
          padding: const EdgeInsets.fromLTRB(18, 18, 18, 16),
          decoration: BoxDecoration(
            color: _card,
            borderRadius: BorderRadius.circular(28),
            border: Border.all(color: _line),
            boxShadow: _surfaceShadow,
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: <Widget>[
              Row(
                children: <Widget>[
                  const Spacer(),
                  _assistantOrb(icon: _activeSection.icon),
                ],
              ),
              const SizedBox(height: 14),
              Text(
                welcome,
                textAlign: TextAlign.right,
                style: TextStyle(
                  fontFamily: fontFamily,
                  color: _text,
                  height: 1.65,
                  fontSize: 16,
                ),
              ),
              const SizedBox(height: 14),
              if (_showQuickPrompts)
                Wrap(
                  spacing: 10,
                  runSpacing: 10,
                  alignment: WrapAlignment.end,
                  children: _quickPrompts
                      .map((prompt) => _promptChip(fontFamily, prompt))
                      .toList(growable: false),
                ),
            ],
          ),
        ),
        if (_hasMultipleSections) ...<Widget>[
          const SizedBox(height: 16),
          SizedBox(
            height: 110,
            child: ListView.separated(
              reverse: true,
              scrollDirection: Axis.horizontal,
              itemCount: _sections.length,
              separatorBuilder: (_, _) => const SizedBox(width: 10),
              itemBuilder: (context, index) {
                final section = _sections[index];
                final isActive = index == _activeSectionIndex;
                return InkWell(
                  borderRadius: BorderRadius.circular(24),
                  onTap: _sending
                      ? null
                      : () {
                          if (index != _activeSectionIndex) {
                            _startNewConversation(sectionIndex: index);
                          }
                        },
                  child: Container(
                    width: 170,
                    padding: const EdgeInsets.all(14),
                    decoration: BoxDecoration(
                      color: isActive ? _dark : Colors.white,
                      borderRadius: BorderRadius.circular(24),
                      border: Border.all(
                        color: isActive ? Colors.transparent : _line,
                      ),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.end,
                      children: <Widget>[
                        Icon(
                          section.icon,
                          color: isActive ? Colors.white : _accent,
                        ),
                        const Spacer(),
                        Text(
                          section.title,
                          textAlign: TextAlign.right,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: TextStyle(
                            fontFamily: fontFamily,
                            color: isActive ? Colors.white : _text,
                          ),
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
          ),
        ],
        const SizedBox(height: 16),
        _sectionPanel(
          fontFamily: fontFamily,
          title: 'گفتوگۆکان',
          subtitle: recent.isEmpty
              ? 'دەستپێبکە بە یەکەم نامە.'
              : 'دوایین چاتەکانت',
          trailing: recent.isEmpty
              ? null
              : TextButton(
                  onPressed: () => _openHistorySheet(fontFamily),
                  child: Text(
                    'هەمووی',
                    style: TextStyle(fontFamily: fontFamily, color: _accent),
                  ),
                ),
          child: recent.isEmpty
              ? _emptyPanelMessage(
                  fontFamily,
                  'هێشتا هیچ گفتوگۆیەکت نییە. یەکەم پرسیارت بنووسە.',
                )
              : Column(
                  children: recent
                      .map((item) => _historyTile(fontFamily, item))
                      .toList(growable: false),
                ),
        ),
        const SizedBox(height: 100),
      ],
    );
  }

  Widget _chatBody(String fontFamily) {
    return Container(
      key: const ValueKey<String>('ai-chat'),
      margin: const EdgeInsets.fromLTRB(18, 4, 18, 8),
      decoration: BoxDecoration(
        color: Colors.white.withValues(alpha: 0.88),
        borderRadius: BorderRadius.circular(32),
        border: Border.all(color: _line),
        boxShadow: _surfaceShadow,
      ),
      child: ListView.builder(
        controller: _scrollController,
        padding: const EdgeInsets.fromLTRB(16, 20, 16, 24),
        itemCount: _messages.length + (_sending ? 1 : 0),
        itemBuilder: (context, index) {
          if (_sending && index == _messages.length) {
            return _typingBubble(fontFamily);
          }
          return _messageBubble(_messages[index], fontFamily);
        },
      ),
    );
  }

  Widget _inputBar(String fontFamily) {
    return SafeArea(
      top: false,
      child: Padding(
        padding: const EdgeInsets.fromLTRB(18, 8, 18, 16),
        child: Container(
          padding: const EdgeInsets.fromLTRB(14, 10, 10, 10),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(30),
            border: Border.all(color: _line),
            boxShadow: <BoxShadow>[
              BoxShadow(
                color: _dark.withValues(alpha: 0.1),
                blurRadius: 26,
                offset: const Offset(0, 14),
              ),
            ],
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: <Widget>[
              Row(
                children: <Widget>[
                  Container(
                    width: 44,
                    height: 44,
                    decoration: BoxDecoration(
                      color: _accentSoft,
                      borderRadius: BorderRadius.circular(16),
                    ),
                    child: IconButton(
                      onPressed: _sending
                          ? null
                          : () => _startNewConversation(),
                      icon: const Icon(Icons.add_comment_rounded),
                      color: _accent,
                      tooltip: 'چاتی نوێ',
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.end,
                      children: <Widget>[
                        Text(
                          _isLanding
                              ? 'پرسیارەکەت بنووسە'
                              : 'دەتوانیت دوای وەڵامەکە پرسیاری دواتر زیاد بکەیت',
                          textAlign: TextAlign.right,
                          style: TextStyle(
                            fontFamily: fontFamily,
                            color: _muted,
                            fontSize: 12.2,
                            height: 1.35,
                          ),
                        ),
                        const SizedBox(height: 4),
                        Text(
                          _sending
                              ? 'AI ئێستا وەڵام ئامادە دەکات'
                              : 'گفتوگۆ بەردەوام دەبێت',
                          textAlign: TextAlign.right,
                          style: TextStyle(
                            fontFamily: fontFamily,
                            color: _text,
                            fontSize: 13.2,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 12),
              Row(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: <Widget>[
                  FilledButton(
                    onPressed: _sending || !_draftHasText ? null : _sendMessage,
                    style: FilledButton.styleFrom(
                      backgroundColor: _dark,
                      foregroundColor: Colors.white,
                      minimumSize: const Size(56, 56),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(22),
                      ),
                    ),
                    child: _sending
                        ? const SizedBox(
                            width: 20,
                            height: 20,
                            child: CircularProgressIndicator(
                              strokeWidth: 2.3,
                              color: Colors.white,
                            ),
                          )
                        : const Icon(Icons.arrow_upward_rounded),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 14),
                      decoration: BoxDecoration(
                        color: const Color(0xFFF8F6F1),
                        borderRadius: BorderRadius.circular(22),
                        border: Border.all(color: _line),
                      ),
                      child: TextField(
                        controller: _inputController,
                        focusNode: _inputFocusNode,
                        keyboardType: TextInputType.multiline,
                        textInputAction: TextInputAction.newline,
                        minLines: 1,
                        maxLines: 7,
                        style: TextStyle(fontFamily: fontFamily, color: _text),
                        decoration: InputDecoration(
                          hintText: 'پرسیارەکەت بنووسە...',
                          hintStyle: TextStyle(
                            fontFamily: fontFamily,
                            color: _muted,
                          ),
                          border: InputBorder.none,
                          contentPadding: const EdgeInsets.symmetric(
                            vertical: 14,
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _messageBubble(AiConversationMessage message, String fontFamily) {
    final isUser = message.isUser;
    final isMeta = message.isMeta;
    final bg = isMeta
        ? const Color(0xFFFFF1ED)
        : isUser
        ? _dark
        : const Color(0xFFF7F8F5);
    final fg = isMeta
        ? const Color(0xFF9B4A2A)
        : isUser
        ? Colors.white
        : _text;
    return Align(
      alignment: isUser ? Alignment.centerRight : Alignment.centerLeft,
      child: GestureDetector(
        onLongPress: () => _copyMessage(message),
        child: ConstrainedBox(
          constraints: BoxConstraints(
            maxWidth: MediaQuery.of(context).size.width * 0.87,
          ),
          child: Padding(
            padding: const EdgeInsets.only(bottom: 16),
            child: Row(
              mainAxisAlignment: isUser
                  ? MainAxisAlignment.end
                  : MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.end,
              children: <Widget>[
                if (!isUser) ...<Widget>[
                  _messageAvatar(isUser: false, icon: _activeSection.icon),
                  const SizedBox(width: 10),
                ],
                Flexible(
                  child: Container(
                    padding: const EdgeInsets.fromLTRB(15, 14, 15, 12),
                    decoration: BoxDecoration(
                      color: bg,
                      borderRadius: BorderRadius.only(
                        topLeft: const Radius.circular(24),
                        topRight: const Radius.circular(24),
                        bottomLeft: Radius.circular(isUser ? 24 : 8),
                        bottomRight: Radius.circular(isUser ? 8 : 24),
                      ),
                      border: Border.all(
                        color: isUser
                            ? Colors.white.withValues(alpha: 0.06)
                            : _line,
                      ),
                      boxShadow: <BoxShadow>[
                        BoxShadow(
                          color: Colors.black.withValues(alpha: 0.03),
                          blurRadius: 18,
                          offset: const Offset(0, 10),
                        ),
                      ],
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.end,
                      children: <Widget>[
                        Text(
                          isMeta
                              ? 'ئاگاداری'
                              : (isUser ? 'تۆ' : _activeSection.title),
                          style: TextStyle(
                            fontFamily: fontFamily,
                            color: fg.withValues(alpha: 0.78),
                            fontSize: 11.5,
                          ),
                        ),
                        const SizedBox(height: 8),
                        Text(
                          _repairText(message.text),
                          textAlign: TextAlign.right,
                          style: TextStyle(
                            fontFamily: fontFamily,
                            color: fg,
                            height: 1.65,
                            fontSize: 14.5,
                          ),
                        ),
                        const SizedBox(height: 10),
                        if (_showTimestamps)
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: <Widget>[
                              Icon(
                                Icons.content_copy_rounded,
                                size: 14,
                                color: fg.withValues(alpha: 0.46),
                              ),
                              Text(
                                _formatTime(message.createdAt),
                                style: TextStyle(
                                  fontFamily: fontFamily,
                                  color: fg.withValues(alpha: 0.68),
                                  fontSize: 10.8,
                                ),
                              ),
                            ],
                          ),
                        if (!_showTimestamps)
                          Icon(
                            Icons.content_copy_rounded,
                            size: 14,
                            color: fg.withValues(alpha: 0.46),
                          ),
                      ],
                    ),
                  ),
                ),
                if (isUser) ...<Widget>[
                  const SizedBox(width: 10),
                  _messageAvatar(isUser: true),
                ],
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _typingBubble(String fontFamily) {
    return Align(
      alignment: Alignment.centerLeft,
      child: Padding(
        padding: const EdgeInsets.only(bottom: 16),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.end,
          children: <Widget>[
            _messageAvatar(isUser: false, icon: _activeSection.icon),
            const SizedBox(width: 10),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
              decoration: BoxDecoration(
                color: const Color(0xFFF7F8F5),
                borderRadius: const BorderRadius.only(
                  topLeft: Radius.circular(24),
                  topRight: Radius.circular(24),
                  bottomLeft: Radius.circular(8),
                  bottomRight: Radius.circular(24),
                ),
                border: Border.all(color: _line),
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: <Widget>[
                  const SizedBox(
                    width: 16,
                    height: 16,
                    child: CircularProgressIndicator(
                      strokeWidth: 2,
                      color: _accent,
                    ),
                  ),
                  const SizedBox(width: 10),
                  Text(
                    'AI وەڵام ئامادە دەکات...',
                    style: TextStyle(fontFamily: fontFamily, color: _text),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _headerActionButton({
    required IconData icon,
    VoidCallback? onPressed,
  }) {
    return IconButton(
      onPressed: onPressed,
      style: IconButton.styleFrom(
        backgroundColor: Colors.white.withValues(alpha: 0.12),
        foregroundColor: Colors.white,
        fixedSize: const Size(46, 46),
        side: BorderSide(color: Colors.white.withValues(alpha: 0.12)),
      ),
      icon: Icon(icon),
    );
  }

  Future<void> _openOverflowMenu(String fontFamily) async {
    final selected = await showMenu<_AiChatMenuAction>(
      context: context,
      position: const RelativeRect.fromLTRB(24, 100, 24, 0),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
      color: Colors.white,
      items: <PopupMenuEntry<_AiChatMenuAction>>[
        PopupMenuItem<_AiChatMenuAction>(
          value: _AiChatMenuAction.newConversation,
          child: Text('چاتی نوێ', style: TextStyle(fontFamily: fontFamily)),
        ),
        PopupMenuItem<_AiChatMenuAction>(
          value: _AiChatMenuAction.featureSettings,
          child: Text(
            'ڕێکخستنی تایبەتمەندی',
            style: TextStyle(fontFamily: fontFamily),
          ),
        ),
      ],
    );
    if (selected != null) {
      await _handleMenuAction(selected, fontFamily);
    }
  }

  Widget _sectionPanel({
    required String fontFamily,
    required String title,
    required String subtitle,
    required Widget child,
    Widget? trailing,
  }) {
    return Container(
      padding: const EdgeInsets.fromLTRB(18, 18, 18, 16),
      decoration: BoxDecoration(
        color: _card,
        borderRadius: BorderRadius.circular(30),
        border: Border.all(color: _line),
        boxShadow: _surfaceShadow,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.end,
        children: <Widget>[
          Row(
            children: <Widget>[
              if (trailing != null) ...<Widget>[trailing, const Spacer()],
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: <Widget>[
                    Text(
                      title,
                      textAlign: TextAlign.right,
                      style: TextStyle(
                        fontFamily: fontFamily,
                        color: _text,
                        fontSize: 16,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      subtitle,
                      textAlign: TextAlign.right,
                      style: TextStyle(fontFamily: fontFamily, color: _muted),
                    ),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 14),
          child,
        ],
      ),
    );
  }

  Widget _promptChip(String fontFamily, String prompt) {
    return InkWell(
      borderRadius: BorderRadius.circular(22),
      onTap: _sending ? null : () => _sendMessage(prompt),
      child: Container(
        constraints: const BoxConstraints(minWidth: 120, maxWidth: 240),
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 13),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(22),
          border: Border.all(color: _line),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: <Widget>[
            const Icon(Icons.north_west_rounded, size: 16, color: _accent),
            const SizedBox(width: 10),
            Flexible(
              child: Text(
                prompt,
                textAlign: TextAlign.right,
                style: TextStyle(fontFamily: fontFamily, color: _text),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _historyTile(String fontFamily, AiConversationRecord item) {
    final isActive = item.id == _activeConversationId;
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: InkWell(
        borderRadius: BorderRadius.circular(22),
        onTap: () => _loadConversation(item),
        child: Container(
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            color: isActive ? _accentSoft : Colors.white,
            borderRadius: BorderRadius.circular(22),
            border: Border.all(color: isActive ? _accentSoft : _line),
          ),
          child: Row(
            children: <Widget>[
              Container(
                width: 42,
                height: 42,
                decoration: BoxDecoration(
                  color: isActive ? _accent : const Color(0xFFF5F2EA),
                  borderRadius: BorderRadius.circular(14),
                ),
                child: Icon(
                  Icons.chat_bubble_outline_rounded,
                  color: isActive ? Colors.white : _text,
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: <Widget>[
                    Text(
                      item.title,
                      textAlign: TextAlign.right,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(
                        fontFamily: fontFamily,
                        color: _text,
                        fontSize: 14.5,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      item.preview,
                      textAlign: TextAlign.right,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(fontFamily: fontFamily, color: _muted),
                    ),
                    const SizedBox(height: 6),
                    Text(
                      '${_sectionTitleForId(item.sectionId)} • ${_formatDateTime(item.updatedAt)}',
                      textAlign: TextAlign.right,
                      style: TextStyle(
                        fontFamily: fontFamily,
                        color: _muted,
                        fontSize: 11.6,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _messageAvatar({required bool isUser, IconData? icon}) {
    return Container(
      width: 34,
      height: 34,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        color: isUser ? _dark : _accentSoft,
      ),
      child: Icon(
        isUser ? Icons.person_rounded : (icon ?? Icons.auto_awesome_rounded),
        size: 18,
        color: isUser ? Colors.white : _accent,
      ),
    );
  }

  Widget _assistantOrb({required IconData icon}) {
    return Container(
      width: 60,
      height: 60,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        gradient: const LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: <Color>[Color(0xFFE8D39A), Color(0xFFB98E34)],
        ),
        boxShadow: <BoxShadow>[
          BoxShadow(
            color: _gold.withValues(alpha: 0.32),
            blurRadius: 22,
            offset: const Offset(0, 12),
          ),
        ],
      ),
      child: Icon(icon, color: _dark, size: 28),
    );
  }

  Widget _emptyPanelMessage(String fontFamily, String text) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: const Color(0xFFF8F6F1),
        borderRadius: BorderRadius.circular(22),
      ),
      child: Text(
        text,
        textAlign: TextAlign.right,
        style: TextStyle(fontFamily: fontFamily, color: _muted, height: 1.5),
      ),
    );
  }

  List<BoxShadow> get _surfaceShadow => <BoxShadow>[
    BoxShadow(
      color: _dark.withValues(alpha: 0.05),
      blurRadius: 24,
      offset: const Offset(0, 14),
    ),
  ];

  String _formatTime(DateTime value) {
    final hour = value.hour.toString().padLeft(2, '0');
    final minute = value.minute.toString().padLeft(2, '0');
    return '$hour:$minute';
  }

  String _formatDateTime(DateTime value) {
    final day = value.day.toString().padLeft(2, '0');
    final month = value.month.toString().padLeft(2, '0');
    final hour = value.hour.toString().padLeft(2, '0');
    final minute = value.minute.toString().padLeft(2, '0');
    return '$day/$month/${value.year} • $hour:$minute';
  }
}

enum _AiChatMenuAction { newConversation, featureSettings }

class _AmbientGlow extends StatelessWidget {
  const _AmbientGlow({required this.size, required this.colors});

  final double size;
  final List<Color> colors;

  @override
  Widget build(BuildContext context) {
    return IgnorePointer(
      child: Container(
        width: size,
        height: size,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          gradient: RadialGradient(colors: colors),
        ),
      ),
    );
  }
}
