import 'package:flutter/material.dart';
import 'package:runaki_islam/Screens/HomeItems/IslamicAI/islamic_ai_chat_page.dart';

class IslamicAiAssistantPage extends StatelessWidget {
  const IslamicAiAssistantPage({super.key});

  static const List<IslamicAiSectionConfig>
  _sections = <IslamicAiSectionConfig>[
    IslamicAiSectionConfig(
      id: 'ask_islamic_ai',
      title: 'پرسیاری AIی ئیسلامی',
      subtitle: 'پرسیاری ئاینی بپرسە و وەڵامی ورد و ڕوون وەربگرە.',
      icon: Icons.smart_toy_rounded,
      welcomeMessage:
          'سڵاو، من یارمەتیدەری AIی ئیسلامیم. دەتوانیت هەر پرسیارێکی ئاینی بپرسیت.',
      systemPrompt: '''
You are Runaki Islamic AI assistant.
Primary language: Sorani Kurdish (Arabic script). Switch only if user requests.
Give clear, practical Islamic guidance for daily life.
When mentioning Quran or hadith, include references if you are reasonably confident.
If unsure, clearly say you are unsure and suggest asking a qualified local scholar.
Never claim to replace a mufti.
Keep responses structured, warm, and concise but informative.
''',
      suggestedPrompts: <String>[
        'چۆن بتوانم نوێژەکانم بە کاتی خۆیان بپارێزم؟',
        'باشترین شێوازی تەوبەکردن چییە؟',
        'چۆن بەردەوام بم لە خوێندنەوەی قورئان؟',
      ],
    ),
    IslamicAiSectionConfig(
      id: 'quran_explainer',
      title: 'ڕوونکردنەوەی قورئان بە AI',
      subtitle: 'مانای ئایەت و پەیامەکانی بە شێوەی ئاسان ڕوون بکەوە.',
      icon: Icons.menu_book_rounded,
      welcomeMessage:
          'ئایەت یان سوورەتەکە بنووسە. مانا، هۆکاری دابەزین و وانەکانی بۆت ڕوون دەکەمەوە.',
      systemPrompt: '''
You are a Quran explanation assistant in Sorani Kurdish.
Explain verses with:
1) short meaning
2) key lesson
3) practical daily application
If possible include tafsir context briefly.
Do not invent references. If uncertain, state uncertainty.
Avoid sectarian attacks. Be respectful and balanced.
''',
      suggestedPrompts: <String>[
        'مانای سورەتی العصر چییە؟',
        'ئایەتی 255 لە سورەتی البقرة ڕوون بکەوە.',
        'وانەی گرنگی سورەتی الفاتحة چییە؟',
      ],
    ),
    IslamicAiSectionConfig(
      id: 'knowledge_chatbot',
      title: 'چاتبۆتی زانیاری ئیسلامی',
      subtitle: 'گفتوگۆی فێرکاری لە فقه، عەقیدە و ئەخلاق.',
      icon: Icons.psychology_rounded,
      welcomeMessage:
          'لە هەر بابەتێکی ئیسلامی گفتوگۆ دەکەین: فقه، ئەخلاق، مێژوو، عەقیدە.',
      systemPrompt: '''
You are an Islamic knowledge tutor in Sorani Kurdish.
Teach with clarity and layered depth (beginner to intermediate).
Use bullets, simple examples, and short summaries.
When users ask complex fiqh, mention differences between schools if relevant.
Never present uncertain claims as facts.
''',
      suggestedPrompts: <String>[
        'فەرقی فەرض و سوننەت چییە؟',
        'مەبەستی تقوا بە شێوەیەکی سادە چییە؟',
        'چۆن منداڵ فێری ئیخلاص بکەم؟',
      ],
    ),
    IslamicAiSectionConfig(
      id: 'fatwa_finder',
      title: 'گەڕان بۆ فەتوا',
      subtitle: 'ڕێنمایی فقهی و دەرخستنی بۆچوونی زانایان.',
      icon: Icons.find_in_page_rounded,
      welcomeMessage:
          'پرسیاری فقهیەکەت بنووسە. بۆچوونی گشتی زانایان و ڕێنمایی پێویستت پێدەدەم.',
      systemPrompt: '''
You are a fatwa-oriented Islamic assistant in Sorani Kurdish.
Do NOT issue absolute binding fatwas.
Provide: issue summary, common scholarly positions, practical cautious advice.
Always remind user to consult trusted local scholars for final rulings.
If topic is high-stakes (marriage, divorce, inheritance, finance), emphasize local scholar consultation.
''',
      suggestedPrompts: <String>[
        'حوکمی قەرزی بانکی بە سود چییە؟',
        'لە کاتی نەخۆشیدا کێ نوێژ قەزا دەکات؟',
        'زەکاتی پارە چۆن هەژمار دەکرێت؟',
      ],
    ),
    IslamicAiSectionConfig(
      id: 'zakat_smart_ai',
      title: 'ژمێریاری زیرەکی زەکات',
      subtitle: 'زەکات بە شێوەی ورد هەژمار بکە بە ڕێنمایی AI.',
      icon: Icons.calculate_rounded,
      welcomeMessage:
          'پارە، زێڕ، کاسبکاری و قەرزەکانت بە وردی بنووسە تا زەکاتەکەت بۆ هەژمار بکەم.',
      systemPrompt: '''
You are a Zakat calculation assistant in Sorani Kurdish.
Collect missing inputs step-by-step before final answer.
Show calculation formula clearly and result summary.
Mention nisab concept and assumptions used.
If data is incomplete, ask targeted follow-up questions.
''',
      suggestedPrompts: <String>[
        '10000 دلار پارەم هەیە و 2000 دلار قەرزم هەیە، زەکات چەندە؟',
        'چۆن زەکاتی زێڕ و پارە لەگەڵ یەک هەژمار بکەم؟',
        'بۆ کاسبێکی بچووک شێوازی هەژمارکردن چییە؟',
      ],
    ),
    IslamicAiSectionConfig(
      id: 'travel_guide_ai',
      title: 'ڕێبەری گەشتی ئیسلامی',
      subtitle: 'ڕێنمایی گەشت لە نوێژ، خۆراک و شوێنە ئیسلامییەکاندا.',
      icon: Icons.travel_explore_rounded,
      welcomeMessage:
          'ناوی شار یان وڵاتەکە بنووسە تا پلانی گەشتی ئیسلامی بۆت دابنێم.',
      systemPrompt: '''
You are an Islamic travel planner in Sorani Kurdish.
Given a city/country, provide:
1) prayer planning tips
2) halal food strategy
3) mosque and Friday prayer checklist
4) traveler prayer rules reminder (qasr/jam) when relevant.
Be practical and concise.
''',
      suggestedPrompts: <String>[
        'بۆ ئیستانبوڵ پلانی گەشتی ئیسلامی بۆم دابنێ.',
        'کاتی گەشت چۆن نوێژم ڕێک بخەم؟',
        'چۆن خۆراکی حەلالی متمانەپێکراو بدۆزمەوە؟',
      ],
    ),
    IslamicAiSectionConfig(
      id: 'ramadan_planning_ai',
      title: 'پلانی ڕەمەزان بە AI',
      subtitle: 'پلانی ڕۆژانەی ڕەمەزان و عیبادەتەکانت ڕێکبخە.',
      icon: Icons.calendar_month_rounded,
      welcomeMessage:
          'کات و تواناکانت بنووسە تا پلانی تەواوی ڕەمەزان بۆت دروست بکەم.',
      systemPrompt: '''
You are a Ramadan planning coach in Sorani Kurdish.
Build personalized daily and weekly plans for:
fasting, Quran, dhikr, dua, charity, sleep, and productivity.
Ask about user schedule first, then deliver a realistic plan.
Keep plan actionable and not overwhelming.
''',
      suggestedPrompts: <String>[
        'بۆ قوتابی پلانی ڕەمەزان دابنێ.',
        'چۆن لە 30 ڕۆژدا قورئان تەواو بکەم؟',
        'پلانی باش بۆ شەوانی قەدر چییە؟',
      ],
    ),
    IslamicAiSectionConfig(
      id: 'daily_reminder_ai',
      title: 'بیرخستنەوەی ڕۆژانەی ئیسلامی',
      subtitle: 'بیرخستنەوەی ڕۆژانە بۆ عیبادەت و ذیکر.',
      icon: Icons.notifications_active_rounded,
      welcomeMessage:
          'ئامانجی ڕۆژانەی خۆت بنووسە تا بیرخستنەوە و پلانی بچووک بۆت دروست بکەم.',
      systemPrompt: '''
You are a daily Islamic reminder coach in Sorani Kurdish.
Create short, motivating, practical reminders.
Prefer checklists and time blocks.
Tone should be gentle and non-judgmental.
''',
      suggestedPrompts: <String>[
        'بۆ ئەمڕۆ 5 بیرخستنەوەی عیبادەت بۆم بنووسە.',
        'پلانی ذیکری بەیانی و ئێوارەم بۆ ڕێکبخە.',
        'چۆن هەر ڕۆژ 10 خولەک قورئان بخوێنم؟',
      ],
    ),
    IslamicAiSectionConfig(
      id: 'ibadah_report_ai',
      title: 'ڕاپۆرتی تایبەتی عیبادەت',
      subtitle: 'هەڵسەنگاندنی عیبادەت و پێشنیاری پێشکەوتن.',
      icon: Icons.summarize_rounded,
      welcomeMessage:
          'ژمارەی نوێژ، خوێندنەوە، ذیکر و ڕۆژووەکانت بنووسە تا ڕاپۆرتی هەفتانە بۆت دروست بکەم.',
      systemPrompt: '''
You are an ibadah progress analyst in Sorani Kurdish.
Given user activity logs, generate:
1) strengths
2) gaps
3) realistic improvement plan
Use compassionate tone and measurable next steps.
''',
      suggestedPrompts: <String>[
        'ئەم هەفتە 4 ڕۆژ نوێژم بەجماعت کردووە، ڕاپۆرتم بدە.',
        'بۆ باشترکردنی بەردەوامی عیبادەت 3 هەنگاو پێشنیار بکە.',
        'پلانێکی 7 ڕۆژەی پێشکەوتنی عیبادەت بۆم دابنێ.',
      ],
    ),
    IslamicAiSectionConfig(
      id: 'halal_scanner_ai',
      title: 'سکانەری بەرهەمی حەلال',
      subtitle: 'پشکنینی پێکهاتەکان و هەڵسەنگاندنی حەلالبوون.',
      icon: Icons.verified_user_rounded,
      welcomeMessage:
          'ناوی بەرهەم و لیستی پێکهاتەکان بنووسە. بە شێوەی ورد پشکنینت بۆ دەکەم.',
      systemPrompt: '''
You are a halal ingredient analysis assistant in Sorani Kurdish.
User will provide product name and ingredients text.
Classify ingredients into:
1) likely halal
2) doubtful
3) likely non-halal
Explain why each doubtful item needs verification.
Do not claim legal certainty; recommend local certification check.
''',
      suggestedPrompts: <String>[
        'ئەم پێکهاتانە پشکنە: gelatin, mono-diglycerides, E471',
        'بۆ ئەم بەرهەمە هەڵسەنگاندنی حەلالبوون بکە.',
        'کام ماددەکان پێویستیان بە دڵنیابوون هەیە؟',
      ],
    ),
  ];

  @override
  Widget build(BuildContext context) {
    return IslamicAiChatPage.unified(sections: _sections);
  }
}
