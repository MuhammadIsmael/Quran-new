import 'dart:ui';

import 'package:background_app_bar/background_app_bar.dart';
import 'package:flutter/material.dart';
import 'package:flutter_staggered_animations/flutter_staggered_animations.dart';
import 'package:runaki_islam/Screens/HomeItems/Pexambarman/page_view.dart';
import 'package:runaki_islam/util/background.dart';
import 'package:runaki_islam/util/constans.dart';
import 'package:page_transition/page_transition.dart';
import 'package:runaki_islam/providers/settings_provider.dart';
import 'package:provider/provider.dart';

class Kafaratakan extends StatefulWidget {
  const Kafaratakan({super.key, this.sarder});
  final String? sarder;

  @override
  State<StatefulWidget> createState() => _WtawAmozhgareState();
}

class _WtawAmozhgareState extends State<Kafaratakan> {
  int? fontType;
  @override
  void initState() {
    fontType = Provider.of<SettingsProvider>(context, listen: false)
        .getsettingField('font_family');
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
            backgroundColor: bgColor,
            body: NestedScrollView(
              physics: const BouncingScrollPhysics(),
              headerSliverBuilder: (_, _) => <Widget>[
                SliverAppBar(
                  leading: IconButton(
                    icon: Icon(
                      Icons.arrow_back_ios_rounded,
                      color: iconColor,
                    ),
                    onPressed: () {
                      Navigator.pop(context);
                    },
                  ),
                  expandedHeight: 200,
                  floating: false,
                  pinned: true,
                  snap: false,
                  elevation: 0.0,
                  backgroundColor: Colors.transparent,
                  flexibleSpace: BackgroundFlexibleSpaceBar(
                    collapseMode: CollapseMode.parallax,
                    centerTitle: true,
                    title: Text(
                      widget.sarder!,
                      style: bigTextStyle.copyWith(
                          fontFamily: fontType.toString(), color: Colors.white),
                    ),
                    titlePadding: const EdgeInsets.all(50),
                    background: ClipRect(
                      child: Container(
                        decoration: const BoxDecoration(
                            image: DecorationImage(
                          image: AssetImage(
                            "assets/images/read-quran.jpg",
                          ),
                          fit: BoxFit.fill,
                        )),
                        child: BackdropFilter(
                          filter: ImageFilter.blur(sigmaX: 5.0, sigmaY: 5.0),
                          child: Container(
                            decoration: BoxDecoration(
                              color: thirdColor.withValues(alpha: 0.5),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
              ],
              body: Stack(
                children: [
                  const Background(),
                  ListView(
                    physics: const BouncingScrollPhysics(
                        parent: AlwaysScrollableScrollPhysics()),
                    shrinkWrap: true,
                    children: [
                      Padding(
                        padding: const EdgeInsets.only(top: 20),
                        child: AnimationLimiter(
                            child: AnimationConfiguration.synchronized(
                                child: SlideAnimation(
                                    duration:
                                        const Duration(milliseconds: 2500),
                                    curve: Curves.fastLinearToSlowEaseIn,
                                    horizontalOffset: 30,
                                    verticalOffset: 300.0,
                                    child: FlipAnimation(
                                      duration:
                                          const Duration(milliseconds: 3000),
                                      curve: Curves.fastLinearToSlowEaseIn,
                                      flipAxis: FlipAxis.y,
                                      child: Column(
                                        children: [
                                          //Ba Rozhu nabun
                                          ExpationTileWidgetUI(
                                            title:
                                                "کەفارەتەكان بە رۆژوو نەبوون",
                                            child: Column(
                                              children: [
                                                listTile(" سەفەر یان نەخۆشی",
                                                    () {
                                                  getItemNavigate(
                                                      " سەفەر یان نەخۆشی",
                                                      "-کەفارەتی بەرۆژوونەبوون بەهۆی سەفەر یان نەخۆشی \r\n\r\n -دەبێت دوای رەمەزان بیانگرێتەوە ؛ بەڵام ئەگەر بەهۆی نەخۆشیەکی درێژخایەنەوە نەیتوانی بیانگرێتەوە ئەوە بۆ هەر رۆژێک دەبێت یەک کیلۆ و نیو برینج بدرێت .\r\n",
                                                      context);
                                                }),
                                                listTile(
                                                    "ئافرەتی دووگیان یان شیردەر",
                                                    () {
                                                  getItemNavigate(
                                                      "ئافرەتی دووگیان یان شیردەر",
                                                      "-کەفارەتی بەرۆژوو نەبوونی ئافرەتی دووگیان یان شیردەر \r\n\r\n-ئەگەر بەرۆژوو بوون زیانی بۆی خۆی هەبوو یان بۆ منداڵەکەی , بۆ هەر رۆژێک یەک کیلۆ و نیو برینج دەدات و دەتوانێت نەیگرێتەوە و تەنها ئەو فیدیەی بدات .\r\n",
                                                      context);
                                                }),
                                                listTile(
                                                    "سەرجێی کردن لەگەڵ خێزان",
                                                    () {
                                                  getItemNavigate(
                                                      "سەرجێی کردن لەگەڵ خێزان",
                                                      "-کەفارەتی سەرجێی کردن لەگەڵ خێزان لەکاتی بەرۆژوو بوندا لەمانگی رەمەزاندا \r\n\r\n- ئەو کەسەی دەچێتە لای خێزانی لەکاتی بەرۆژوووندا لەمانگی رەمەزاندا ئەوە دەبێت داوای لێخۆشبون لەخوای گەورە بکات وە رۆژوەکەشیان بگرنەوە وە پیاوەکە دەبێت کۆیلەیەک ئازاد بکات ئەگەر هەبوو ؛ ئەگەرنا دەبێت دوو(٢) مانگ لەسەر یەک بەبێ پچڕان بەڕۆژوو بێت ؛ ئەگەر نەیتوانی دەبێت شێست(٦٠) فەقیر تێر بکات ؛ ئەم کەفارەتە بە تەرتیبە واتە ئەگەر توانای بەڕۆژوو بوونی دوو(٢) مانگی هەبوو دەبێت ئیلا بەڕۆژوو بێت ؛ ئەگەر نەی توانی ئینجا بۆی دروستە(60) فەقير تێر بکات ؛ وە ئافرەتەکەش ئەگەر بیزانیبێت کە ئەو کارە لەکاتی بەرۆژووبوونی مانگی ڕەمەزاندا حەڕامە ؛ وە پیاوەکەی بە زۆردی ئەوکارەی پێ نەکردبێت ئەویش دەبێت وەکو مێردەکەی کەفارەتەکەی جێ بەجێ بکات . انظر : \"مجموع فتاوى ابن باز\" (15/307) ، \"الشرح الممتع\" (6/402) .\r\n",
                                                      context);
                                                })
                                              ],
                                            ),
                                          ),

                                          //Lakate Sure Manganada
                                          ExpationTileWidgetUI(
                                            title: "لەکاتی سووری مانگانەدا",
                                            child: Column(
                                              children: [
                                                listTile(
                                                    "چوونە لای خێزانی لەکاتی سووری مانگانەدا",
                                                    () {
                                                  getItemNavigate(
                                                      "چوونە لای خێزانی لەکاتی سووری مانگانەدا",
                                                      "-کەفارەتی ئەو کەسەی دەچێتە لای خێزانی لەکاتی سووری مانگانەدا یان لەکاتی زەییستاندا\r\n\r\n- هەر کەسێک لەکاتی (سوری مانگانەدا) یان لەکاتی (نیفاس : زەییستان) بچیتە لای خێزانی ئەوە تاوانی ئەنجامداوە و دەبێت تەوبە بکات و پەشیان بێتەوەو جارێکی تر ئەوکارە دووبارە نەکاتەوە ؛ وە دەبێت کەفارەت بدات کە بریتیە لە بەخشینی پارە بە هەژاران بەئەندازەی نرخی (يەك مسقاڵ) زێر ئەگەر تونای هەبوو ؛ ئەگەرنا بە ئەندازەی نیو مسقاڵ دەبێت پارە ببەخشیت بە هەژاران ؛ بەڵام ئەگەر کەسێک بە نەزانین یان بە لەبیر چوون ئەوکارە بکات تاوان و کەفارەتی بۆ نیە . الشرح الممتع (1/255) و فتاوى اللجنة (6/93،112) .\r\n",
                                                      context);
                                                }),
                                              ],
                                            ),
                                          ),

                                          //Kafarate Swend
                                          ExpationTileWidgetUI(
                                            title: "کەفارەتی سوێند",
                                            child: Column(
                                              children: [
                                                listTile(
                                                    "کەفارەتی سوێند شکاندن ",
                                                    () {
                                                  getItemNavigate(
                                                      "کەفارەتی سوێند شکاندن ",
                                                      "-کەفارەتی سوێند شکاندن \r\n\r\n- هەر کاتیک سویندت خوارد لەسەر شتیک کە نەیکەیت یان بیکەیت پاشان پەشیمان ببیتەوە دەبیت کەفارەتی دەربکەیت کە بریتیە لە دروست کردنی خواردنی ١٠ کەسی هەژار یان دانی برینج بۆ هەر فەقیرێک (یەک کیلۆ و نیو) بدرێت کە بۆ ١٠ نەفەر دەکاتە ١٥ کیلۆ برينج ؛ ئەگەر نەیتوانی خواردن یان برینج بدات ئەوە دەبیت ٣ رۆژ بە رۆژوو بێت ؛ \r\n\r\n-خوای گەورە فەرمویەتی : لَا يُؤَاخِذُكُمُ اللَّهُ بِاللَّغْوِ فِي أَيْمَانِكُمْ وَلَٰكِنْ يُؤَاخِذُكُمْ بِمَا عَقَّدْتُمُ الْأَيْمَانَ ۖ فَكَفَّارَتُهُ إِطْعَامُ عَشَرَةِ مَسَاكِينَ مِنْ أَوْسَطِ مَا تُطْعِمُونَ أَهْلِيكُمْ أَوْ كِسْوَتُهُمْ أَوْ تَحْرِيرُ رَقَبَةٍ ۖ فَمَنْ لَمْ يَجِدْ فَصِيَامُ ثَلَاثَةِ أَيَّامٍ ۚ ذَٰلِكَ كَفَّارَةُ أَيْمَانِكُمْ إِذَا حَلَفْتُمْ ۚ وَاحْفَظُوا أَيْمَانَكُمْ ۚ كَذَٰلِكَ يُبَيِّنُ اللَّهُ لَكُمْ آيَاتِهِ لَعَلَّكُمْ تَشْكُرُونَ (المائدة :٨٩) .\r\nواتە : خوا لێتان ناگرێت کاتێک به‌ساده‌یی سوێند به‌ده‌متاندا دێت و (له‌سه‌ری ڕاهاتوون) به‌ڵکو له‌و سوێندانه‌تان ده‌پرسێته‌وه‌ که‌ بیرو هۆشتان لای هه‌بووه‌ و بۆ مه‌به‌ستێک وتووتانه‌، جا که‌فاره‌تی ئه‌و جۆره‌ سوێندانه‌: نان و خۆراک دانه‌ به‌ ده‌ که‌سی هه‌ژار به‌شێوه‌یه‌کی مامناوه‌ندی که‌ بۆ خاو و خێزانتان سه‌رفی ده‌که‌ن، یاخود پۆشته‌ کردنه‌وه‌یان یاخود ئازاد کردنی به‌نده‌یه‌ک (ئه‌گه‌ر بوو) وە ئه‌وه‌ی (توانای ئه‌و شتانه‌ی نه‌بوو) با سێ ڕۆژ به‌رۆژوو بێت، ئه‌وه‌ که‌فاره‌تی سوێنده‌کانتانه‌ کاتێک سوێند ده‌خۆن و نایبه‌نه‌ سه‌ر، جا تاده‌توانن سوێنده‌کانتان بپارێزن و مه‌یانشکێنن، ئا به‌و شێوه‌یه‌ خوا ئایه‌ته‌کانی خۆیتان بۆ ڕوون ده‌کاته‌وه‌ بۆ ئه‌وه‌ی سوپاسگوزاری بکه‌ن . \r\n",
                                                      context);
                                                }),
                                              ],
                                            ),
                                          ),

                                          //Kafarate Wtne Daykm Ba Xezant
                                          ExpationTileWidgetUI(
                                            title:
                                                "کەفارەتی وتنی دایکم  بەخێزانت",
                                            child: Column(
                                              children: [
                                                listTile(
                                                    "کەفارەتی ئەو کەسەی بەخێزانی دەڵێت تۆ وەک دایکم وای یان وەک خوشکم وای ",
                                                    () {
                                                  getItemNavigate(
                                                      "کەفارەتی ئەو کەسەی بەخێزانی دەڵێت تۆ وەک دایکم وای یان وەک خوشکم وای ",
                                                      "-کەفارەتی ئەو کەسەی بەخێزانی دەڵێت تۆ وەک دایکم وای یان وەک خوشکم وای \r\n\r\n- کە بریتیە لە ئازاد کردنی کۆیلەیەک ئەگەر نەبوو بەرۆژووبونی ٢ مانگ لەسەر یەک ئەگەر نەيتوانی ئەوە دەبێت ٦٠ فەقیر تێر بکات ؛ \r\n\r\n-خوای گەورە فەرمویەتی : وَالَّذِينَ يُظَاهِرُونَ مِنْ نِسَائِهِمْ ثُمَّ يَعُودُونَ لِمَا قَالُوا فَتَحْرِيرُ رَقَبَةٍ مِنْ قَبْلِ أَنْ يَتَمَاسَّا ذَلِكُمْ تُوعَظُونَ بِهِ وَاللَّهُ بِمَا تَعْمَلُونَ خَبِيرٌ * فَمَنْ لَمْ يَجِدْ فَصِيَامُ شَهْرَيْنِ مُتَتَابِعَيْنِ مِنْ قَبْلِ أَنْ يَتَمَاسَّا فَمَنْ لَمْ يَسْتَطِعْ فَإِطْعَامُ سِتِّينَ مِسْكِينًا ذَلِكَ لِتُؤْمِنُوا بِاللَّهِ وَرَسُولِهِ وَتِلْكَ حُدُودُ اللَّهِ وَلِلْكَافِرِينَ عَذَابٌ أَلِيمٌ. {المجادلة: 3-4} .\r\nوە ئەگەر ئافرەت بەپیاوەکەی وت تۆ وەک باوکم وای یان وەک دایکم وای ئەوە دەبێت = ئافرەتەکە کەفارەتی سوێند بدات پێش ئەوەی پیاوەکەی لێی نزیک بێت ؛ کەفارەتی ظهار نادات چونکە کەفارەتی ظهار تایبەتە بەپیاوان ..\r\n\r\n-شێخ محمد الصالح العثيمين فەرمویەتی : الظهار لا يكون من النساء لأزواجهن ، وإنما يكون من الرجال لأزواجهم ، ولهذا إذا ظاهرت المرأة من زوجها بأن قالت له \" أنتَ عليَّ كظهر أبي ، أو كظهر أخي \" أو ما أشبه ذلك : فإن ذلك لا يكون ظهاراً ، ولكن حكمه حكم اليمين ، بمعنى أنها لا يحل لها أن تمكنه من نفسها إلا بكفارة اليمين ، فإن شاءت دفعت الكفارة قبل أن يستمتع بها ، وإن شاءت دفعتها بعد ذلك \r\nوكفارة اليمين : إطعام عشرة مساكين ، أو كسوتهم ، أو عتق رقبة ، فإن لم يجد : فصيام ثلاثة أيام . فتاوى المرأة المسلمة \" ( 2 / 803 ) .\r\n",
                                                      context);
                                                }),
                                              ],
                                            ),
                                          ),

                                          //Kafarate Kushtn
                                          ExpationTileWidgetUI(
                                            title: "کەفارەتی کوشتن",
                                            child: Column(
                                              children: [
                                                listTile(" کوشتن بەهەڵە ", () {
                                                  getItemNavigate(
                                                      " کوشتن بەهەڵە ",
                                                      "-کەفارەتی کوشتنی بەهەڵە \r\n\r\n -بریتیە لە ئازاد کردنی کۆیلەیەک و دانی خوێن بەکەسو کاری کوژراوەکە بەئەندازەی سەد ووشتر وە ئەگەر بکوژەکە ئازاد کردنی کۆیلەیەکی دەست نەکەوت ئەوە دەبێت دوو مانگ بەسەریەکەوە بەرۆژوو ببێت ؛\r\n\r\n- خوای گەورە فەرمویەتی : \r\nوَمَا كَانَ لِمُؤْمِنٍ أَنْ يَقْتُلَ مُؤْمِنًا إِلَّا خَطَأً ۚ وَمَنْ قَتَلَ مُؤْمِنًا خَطَأً فَتَحْرِيرُ رَقَبَةٍ مُؤْمِنَةٍ وَدِيَةٌ مُسَلَّمَةٌ إِلَىٰ أَهْلِهِ إِلَّا أَنْ يَصَّدَّقُوا ۚ فَإِنْ كَانَ مِنْ قَوْمٍ عَدُوٍّ لَكُمْ وَهُوَ مُؤْمِنٌ فَتَحْرِيرُ رَقَبَةٍ مُؤْمِنَةٍ ۖ وَإِنْ كَانَ مِنْ قَوْمٍ بَيْنَكُمْ وَبَيْنَهُمْ مِيثَاقٌ فَدِيَةٌ مُسَلَّمَةٌ إِلَىٰ أَهْلِهِ وَتَحْرِيرُ رَقَبَةٍ مُؤْمِنَةٍ ۖ فَمَنْ لَمْ يَجِدْ فَصِيَامُ شَهْرَيْنِ مُتَتَابِعَيْنِ تَوْبَةً مِنَ اللَّهِ ۗ وَكَانَ اللَّهُ عَلِيمًا حَكِيمًا (النساء :٩٢)\r\n\r\n{وماكان لمؤمن أن يقتل مؤمنا} رێنه‌دراوه‌ هیچ باوه‌ڕدارێك باوه‌ڕدارێكی دیكه‌ بكوژێت, بۆیه‌ ئه‌و هه‌موو ورده‌كاریی و (ئیحتیات)ـه‌شكراوه‌ {إلا خطأ} به‌خه‌تاو به‌هه‌ڵه‌ نه‌بێت، ئه‌گینا كوشتنی موسڵمان-به‌ناهه‌ق- هه‌رگیز ڕه‌وانییه‌ {ومن قتل مؤمنا خطأ} و هه‌ركه‌سێك مرۆڤێكی باوه‌ڕداری به‌هه‌ڵه‌ كوشت، ده‌بێ له‌تۆڵه‌یدا دووشت ئه‌نجام بدات {فتحرير رقبة مؤمنة} یه‌كه‌م: ئازادكردنی كۆیله‌یه‌كی باوه‌ڕدار، چونكه‌ گوناهێكی گه‌وره‌ی كردووه‌ {ودية مسلمة إلى أهله} دووه‌م: خوێنێك به‌كه‌س و كاره‌كه‌ی بدرێ {إلا أن يصدقوا} مه‌گه‌ر بیكه‌نه‌ سه‌ده‌قه‌و بیبه‌خشن {فإن كان من قوم عدو لكم} خۆئه‌ر كوژراوه‌كه‌ له‌ تیره‌یه‌كی خوانه‌ناسی دوژمنتان بوون {وهو مؤمن} و موسڵمانیش بوو, ئه‌وا یه‌ك شتی ده‌كه‌وێته‌ سه‌ر، وه‌كو ده‌فه‌رموێ: {فتحرير رقبة مؤمنة} به‌نده‌یه‌كی باوه‌ڕدار ئازاد بكات، واته‌: خۆینی نادرێ {و إن كان من قوم بينكم وبينهم ميثاق} خۆئه‌گه‌ر ئه‌ومرۆڤه‌ ئیمانداره‌ كوژراوه‌ له‌تیره‌یه‌كی خوانه‌ناسی سوێندخۆر و هاوپه‌یمانتان بوو {فدية مسلمة إلى أهله} ئه‌بێ تۆڵه‌ی خوێنه‌كه‌ی به‌میراتبه‌ری كوژراوه‌كه‌ بدرێ {و تحرير رقبة مؤمنة} و به‌نده‌یه‌كی بڕواداریش ئازادبكا {فمن لم يجد} جا هه‌ركه‌سێك به‌نده‌ی ده‌ست نه‌كه‌وت، واته‌: توانای كڕینی نه‌بوو، یان هه‌ربه‌نده‌ نه‌مابوو، وه‌كو ئێستا {فصيام شهرين متتابعين} ئه‌وه‌ دوومانگی ره‌به‌ق له‌سه‌ر یه‌ك بێ وچان به‌رۆژوو ده‌بێ، مه‌گه‌ر نه‌خۆش بێت {توبة من الله} تاخوا په‌شیمانی له‌بكوژه‌كه‌ وه‌رگرێ {وكان الله عليما حكيما} و خواش زانای كار دروسته‌, ئه‌زانێ چ بڕیارێك چاكه‌ بۆ ئاده‌میزاد . (ته‌فسیری ڕامان) .\r\n",
                                                      context);
                                                }),
                                                listTile(
                                                    "کوشتنی بەئەنقەست و بەناحەق",
                                                    () {
                                                  getItemNavigate(
                                                      "کوشتنی بەئەنقەست و بەناحەق",
                                                      "-کەفارەتی کوشتنی بەئەنقەست و بەناحەق \r\n\r\n -بریتیە لەکوشتنەوەی بکوژەکە یان خوێن لێ وەرگرتنی کە بریتیە لە سەد وشتر یان لێ بوردنی ؛ \r\n\r\n-خوای گەورە فەرمویەتی : \r\nيَا أَيُّهَا الَّذِينَ آمَنُوا كُتِبَ عَلَيْكُمُ الْقِصَاصُ فِي الْقَتْلَى ۖ الْحُرُّ بِالْحُرِّ وَالْعَبْدُ بِالْعَبْدِ وَالْأُنْثَىٰ بِالْأُنْثَىٰ ۚ فَمَنْ عُفِيَ لَهُ مِنْ أَخِيهِ شَيْءٌ فَاتِّبَاعٌ بِالْمَعْرُوفِ وَأَدَاءٌ إِلَيْهِ بِإِحْسَانٍ ۗ ذَٰلِكَ تَخْفِيفٌ مِنْ رَبِّكُمْ وَرَحْمَةٌ ۗ فَمَنِ اعْتَدَىٰ بَعْدَ ذَٰلِكَ فَلَهُ عَذَابٌ أَلِيمٌ (البقرة :١٧٨) .\r\n\r\nواتە : ئه‌ی ئه‌وانه‌ی باوه‌ڕتان هێناوه‌، پێویست كراوه‌ له‌سه‌رتان: تۆڵه‌سه‌ندنه‌وه‌ بۆ كوژراوه‌كان، كه‌سێكی ئازاد به‌كه‌سێكی ئازاد و به‌نده‌ش له‌ جیاتی به‌نده‌ و ئافره‌ت له‌ جیاتی ئافره‌ت (واته‌ هه‌ر كه‌سێك به‌ تاوانی كوشتنی ناحه‌ق هه‌ستا ده‌بێت بكوژرێته‌وه‌)، جا ئه‌وه‌ی چاوپۆشی شتێكی لێكرا له‌لایه‌ن براكه‌یه‌وه‌، با حه‌قداری كوژراوه‌كه‌ چاك ڕه‌فتاربێت له‌گه‌ڵ بكوژه‌كه‌داو بكوژه‌كه‌ به‌جوانی خوێن به‌های كوژراوه‌كه‌ بدات و ئه‌وه‌ كار ئاسانكردن و سۆزو میهره‌بانیه‌كه‌ له‌لایه‌ن په‌روه‌ردگارتانه‌وه‌ (كه‌ له‌جیاتی كوشتنه‌وه‌ خوێنبایی وه‌ربگیرێت) ئه‌وسا ئیتر ئه‌وه‌ی له‌وه‌ودوا ده‌ستدرێژی بكات و له‌ سنوور بترازێت سزای به‌ئێشی بۆ ئاماده‌كراوه‌ .\r\n.",
                                                      context);
                                                }),
                                                listTile(
                                                    "ئەندازەی خوێنی پیاوی کوژراو",
                                                    () {
                                                  getItemNavigate(
                                                      "ئەندازەی خوێنی پیاوی کوژراو",
                                                      " -زانایان فەرمویانە ئەندازەی خوێنی پیاوی کوژراو سەد وشترە وە هی ئافرەت پەنجا وشترە وە هی منداڵی کوڕ وەکو پیاو سەد وشترە وە هی منداڵی کچ وەکو ئافرەت پەنجا وشترە ؛ سەد وشتر بەپارەی سعودی دەکاتە سەد هەزار ریال وە پەنجا وشتر دەکاتە ٥٠ هەزار ریال .\r\n",
                                                      context);
                                                })
                                              ],
                                            ),
                                          ),
                                        ],
                                      ),
                                    )))),
                      ),
                    ],
                  ),
                ],
              ),
            )));
  }

  Container listTile(String title, VoidCallback onPressed) {
    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(10),
        color: backgroundColor,
      ),
      margin: const EdgeInsets.all(8.0),
      child: ListTile(
        onTap: onPressed,
        title: Text(
          title,
          textAlign: TextAlign.right,
          style:
              TextStyle(fontFamily: fontType.toString(), color: titleTextColor),
        ),
      ),
    );
  }

  void getItemNavigate(String title, String desc, BuildContext context) {
    Navigator.push(
        context,
        PageTransition(
            child: TextPageView(
              sarder: widget.sarder!,
              title: title,
              desc: desc,
            ),
            type: PageTransitionType.leftToRightWithFade));
  }
}

class ExpationTileWidgetUI extends StatefulWidget {
  const ExpationTileWidgetUI({super.key, this.title, this.child});
  final String? title;
  final Widget? child;

  @override
  State<ExpationTileWidgetUI> createState() => _ExpationTileWidgetUIState();
}

class _ExpationTileWidgetUIState extends State<ExpationTileWidgetUI> {
  int? fontType;
  @override
  void initState() {
    fontType = Provider.of<SettingsProvider>(context, listen: false)
        .getsettingField('font_family');
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        ExpansionTile(
          collapsedIconColor: kActiveIconColor.withValues(alpha: 0.8),
          iconColor: iconColor,
          collapsedBackgroundColor: backgroundColor,
          backgroundColor: kActiveIconColor.withValues(alpha: 0.6),
          title: Text(
            widget.title!,
            textAlign: TextAlign.center,
            style: TextStyle(
              fontFamily: fontType.toString(),
              color: titleTextColor,
            ),
          ),
          children: [const Divider(), widget.child!],
        ),
        const Divider(
          color: Colors.transparent,
        )
      ],
    );
  }
}
