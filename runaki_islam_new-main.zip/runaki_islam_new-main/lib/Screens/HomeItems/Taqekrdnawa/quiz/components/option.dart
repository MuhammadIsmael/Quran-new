import 'package:flutter/material.dart';
import 'package:get/get_state_manager/get_state_manager.dart';
import 'package:runaki_islam/controller/question_controller.dart';
import 'package:runaki_islam/providers/settings_provider.dart';
import 'package:provider/provider.dart';

class Option extends StatefulWidget {
  const Option({super.key, this.text, this.index, this.press});
  final String? text;
  final int? index;
  final VoidCallback? press;

  @override
  State<Option> createState() => _OptionState();
}

class _OptionState extends State<Option> {
  int? fontType;
  @override
  void initState() {
    fontType = Provider.of<SettingsProvider>(
      context,
      listen: false,
    ).getsettingField('font_family');
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return GetBuilder<QuestionController>(
      builder: (qnController) {
        Color getTheRightColor() {
          if (qnController.isAnswered) {
            if (widget.index == qnController.correctAns) {
              return const Color(0xFF6AC259);
            } else if (widget.index == qnController.selectedAns &&
                qnController.selectedAns != qnController.correctAns) {
              return const Color(0xFFE92E30);
            }
          }
          return const Color(0xFFC1C1C1);
        }

        IconData getTheRightIcon() {
          return getTheRightColor() == const Color(0xFFE92E30)
              ? Icons.close
              : Icons.done;
        }

        return InkWell(
          onTap: widget.press,
          child: Container(
            margin: const EdgeInsets.only(top: 20),
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              border: Border.all(color: getTheRightColor()),
              borderRadius: BorderRadius.circular(15),
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.end,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Container(
                  height: 26,
                  width: 26,
                  decoration: BoxDecoration(
                    color: getTheRightColor() == const Color(0xFFC1C1C1)
                        ? Colors.transparent
                        : getTheRightColor(),
                    borderRadius: BorderRadius.circular(50),
                    border: Border.all(color: getTheRightColor()),
                  ),
                  child: getTheRightColor() == const Color(0xFFC1C1C1)
                      ? null
                      : Icon(getTheRightIcon(), size: 16, color: Colors.white),
                ),
                const Spacer(),
                Text(
                  widget.text!,
                  style: TextStyle(
                    fontFamily: fontType.toString(),
                    color: getTheRightColor(),
                    fontSize: 16,
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}
