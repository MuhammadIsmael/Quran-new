import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:runaki_islam/controller/question_controller.dart';
import 'package:runaki_islam/models/questions.dart';
import 'package:runaki_islam/util/constans.dart';
import 'option.dart';
import 'package:runaki_islam/providers/settings_provider.dart';
import 'package:provider/provider.dart';

class QuestionCard extends StatefulWidget {
  const QuestionCard({
    super.key,
    // it means we have to pass this
    required this.question,
  });

  final Question? question;

  @override
  State<QuestionCard> createState() => _QuestionCardState();
}

class _QuestionCardState extends State<QuestionCard> {
  int? fontType;
  @override
  void initState() {
    fontType = Provider.of<SettingsProvider>(
      context,
      listen: false,
    ).getsettingField('font_family');
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    final QuestionController controller =
        Get.isRegistered<QuestionController>()
            ? Get.find<QuestionController>()
            : Get.put(QuestionController());
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 20),
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: backgroundColor,
        borderRadius: BorderRadius.circular(25),
      ),
      child: SingleChildScrollView(
        child: Column(
          children: [
            Text(
              widget.question!.question!,
              textAlign: TextAlign.center,
              style: Theme.of(context).textTheme.titleLarge!.copyWith(
                fontFamily: fontType.toString(),
                color: titleTextColor,
              ),
            ),
            const SizedBox(height: 20 / 2),
            ...List.generate(
              widget.question!.options!.length,
              (index) => Option(
                index: index,
                text: widget.question!.options![index],
                press: () => controller.checkAns(widget.question!, index),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
