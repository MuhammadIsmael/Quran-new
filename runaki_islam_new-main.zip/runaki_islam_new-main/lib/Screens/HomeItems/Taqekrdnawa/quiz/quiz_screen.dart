import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:provider/provider.dart';
import 'package:runaki_islam/Screens/HomeItems/Taqekrdnawa/score/score_screen.dart';
import 'package:runaki_islam/controller/question_controller.dart';
import 'package:runaki_islam/models/questions.dart';
import 'package:runaki_islam/providers/settings_provider.dart';
import 'package:runaki_islam/util/background.dart';
import 'package:runaki_islam/util/constans.dart';

class QuizScreen extends StatefulWidget {
  const QuizScreen({super.key, this.startOptions, this.startFresh = true});

  final QuizStartOptions? startOptions;
  final bool startFresh;

  @override
  State<QuizScreen> createState() => _QuizScreenState();
}

class _QuizScreenState extends State<QuizScreen> {
  late final QuestionController _questionController;
  int? _fontType;

  String get _fontFamily => _fontType?.toString() ?? '0';
  String _t(String text) => QuestionController.repairText(text);

  @override
  void initState() {
    super.initState();
    _fontType = Provider.of<SettingsProvider>(
      context,
      listen: false,
    ).getsettingField('font_family');
    _questionController = _resolveController();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!mounted) return;
      if (widget.startFresh) {
        _questionController.startQuiz(options: widget.startOptions);
      } else {
        _questionController.continueQuiz();
      }
    });
  }

  @override
  void dispose() {
    _questionController.pauseTimer();
    super.dispose();
  }

  QuestionController _resolveController() {
    if (Get.isRegistered<QuestionController>()) {
      return Get.find<QuestionController>();
    }
    return Get.put(QuestionController());
  }

  Future<bool> _onWillPop() async {
    final bool shouldExit =
        await showDialog<bool>(
          context: context,
          builder: (BuildContext context) {
            return Directionality(
              textDirection: TextDirection.rtl,
              child: AlertDialog(
                title: Text(
                  _t('دەرچوون لە تاقیکردنەوە؟'),
                  style: TextStyle(
                    fontFamily: _fontFamily,
                    color: captionTextColor,
                  ),
                ),
                content: Text(
                  _t('پێشکەوتنی ئێستات لەدەست دەچێت.'),
                  style: TextStyle(
                    fontFamily: _fontFamily,
                    color: descriptionTectColor,
                  ),
                ),
                actions: <Widget>[
                  TextButton(
                    onPressed: () => Navigator.of(context).pop(false),
                    child: Text(_t('پاشگەزبوونەوە')),
                  ),
                  ElevatedButton(
                    onPressed: () => Navigator.of(context).pop(true),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color(0xFFD64545),
                      foregroundColor: Colors.white,
                    ),
                    child: Text(_t('دەرچوون')),
                  ),
                ],
              ),
            );
          },
        ) ??
        false;

    if (shouldExit) {
      _questionController.pauseTimer();
    }
    return shouldExit;
  }

  void _handleSystemPop() async {
    final bool shouldExit = await _onWillPop();
    if (!mounted || !shouldExit) return;
    Navigator.of(context).pop();
  }

  void _goNextQuestion() {
    if (!_questionController.isAnswered) {
      Get.snackbar(
        _t('ئاگاداری'),
        _t('تکایە یان وەڵام هەڵبژێرە یان بازبدە.'),
        snackPosition: SnackPosition.BOTTOM,
      );
      return;
    }

    _questionController.nextQuestion();
    if (_questionController.isFinished) {
      Get.off(() => const ScoreScreen());
    }
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: PopScope(
        canPop: false,
        onPopInvokedWithResult: (bool didPop, Object? result) {
          if (didPop) return;
          _handleSystemPop();
        },
        child: Scaffold(
          backgroundColor: bgColor,
          body: Stack(
            children: <Widget>[
              const Background(),
              SafeArea(
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(16, 10, 16, 20),
                  child: Obx(() {
                    if (_questionController.totalQuestions == 0) {
                      return Center(
                        child: Text(
                          _t('هیچ پرسیارێک نییە'),
                          style: TextStyle(
                            fontFamily: _fontFamily,
                            color: descriptionTectColor,
                          ),
                        ),
                      );
                    }

                    final Question question =
                        _questionController.currentQuestion;
                    final List<String> options =
                        question.options ?? const <String>[];
                    final bool isAnswered = _questionController.isAnswered;
                    final bool isLast = _questionController.isLastQuestion;

                    return Column(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: <Widget>[
                        Row(
                          children: <Widget>[
                            _TopBarButton(
                              icon: Icons.arrow_back_ios_new_rounded,
                              onTap: () async {
                                final bool shouldExit = await _onWillPop();
                                if (!context.mounted) return;
                                if (shouldExit) {
                                  Navigator.of(context).pop();
                                }
                              },
                            ),
                            const SizedBox(width: 10),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: <Widget>[
                                  Text(
                                    _t('تاقیکردنەوە'),
                                    style: TextStyle(
                                      fontFamily: _fontFamily,
                                      fontSize: 20,
                                      color: captionTextColor,
                                      fontWeight: FontWeight.w700,
                                    ),
                                  ),
                                  Text(
                                    _questionController.activeCategoryLabel,
                                    style: TextStyle(
                                      fontFamily: _fontFamily,
                                      fontSize: 12,
                                      color: descriptionTectColor,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            Container(
                              padding: const EdgeInsets.symmetric(
                                horizontal: 12,
                                vertical: 8,
                              ),
                              decoration: BoxDecoration(
                                color: Colors.white.withValues(alpha: 0.9),
                                borderRadius: BorderRadius.circular(14),
                              ),
                              child: Text(
                                '${_t('خاڵ')}: ${_questionController.totalPoints}',
                                style: const TextStyle(
                                  fontFamily: 'english',
                                  fontWeight: FontWeight.w700,
                                  color: Color(0xFF0F6B53),
                                ),
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 14),
                        Container(
                          width: double.infinity,
                          padding: const EdgeInsets.all(16),
                          decoration: BoxDecoration(
                            color: Colors.white.withValues(alpha: 0.92),
                            borderRadius: BorderRadius.circular(20),
                          ),
                          child: Row(
                            children: <Widget>[
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: <Widget>[
                                    Text(
                                      '${_t('پرسیار')} ${_questionController.questionNumber.value}/${_questionController.totalQuestions}',
                                      style: TextStyle(
                                        fontFamily: _fontFamily,
                                        fontSize: 17,
                                        fontWeight: FontWeight.w700,
                                        color: captionTextColor,
                                      ),
                                    ),
                                    const SizedBox(height: 6),
                                    LinearProgressIndicator(
                                      value:
                                          _questionController.questionProgress,
                                      minHeight: 7,
                                      borderRadius: BorderRadius.circular(100),
                                      backgroundColor: const Color(0xFFE3ECE8),
                                      valueColor:
                                          const AlwaysStoppedAnimation<Color>(
                                            Color(0xFF0F6B53),
                                          ),
                                    ),
                                  ],
                                ),
                              ),
                              const SizedBox(width: 14),
                              SizedBox(
                                width: 62,
                                height: 62,
                                child: Stack(
                                  alignment: Alignment.center,
                                  children: <Widget>[
                                    CircularProgressIndicator(
                                      value: _questionController.timerProgress,
                                      strokeWidth: 6,
                                      backgroundColor: const Color(0xFFE3ECE8),
                                      valueColor:
                                          const AlwaysStoppedAnimation<Color>(
                                            Color(0xFF1B9AAA),
                                          ),
                                    ),
                                    Text(
                                      '${_questionController.remainingSeconds}',
                                      style: const TextStyle(
                                        fontFamily: 'english',
                                        fontWeight: FontWeight.w700,
                                        color: Color(0xFF24433A),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),
                        if (isAnswered) ...<Widget>[
                          const SizedBox(height: 10),
                          _StatusBanner(
                            fontFamily: _fontFamily,
                            message: _questionController.selectedAns < 0
                                ? _t(
                                    'بەهۆی کات یاخود بازدان ئەم پرسیارە وەڵام نەدرا.',
                                  )
                                : _questionController.selectedAns ==
                                      _questionController.correctAns
                                ? _t('وەڵامی ڕاستە. زۆر باش.')
                                : _t('وەڵامی هەڵەیە. هەوڵێکی تر بدە.'),
                          ),
                        ],
                        const SizedBox(height: 12),
                        Expanded(
                          child: AnimatedSwitcher(
                            duration: const Duration(milliseconds: 220),
                            child: Container(
                              key: ValueKey<int>(
                                question.id ??
                                    _questionController.questionNumber.value,
                              ),
                              padding: const EdgeInsets.fromLTRB(
                                16,
                                16,
                                16,
                                12,
                              ),
                              decoration: BoxDecoration(
                                color: Colors.white,
                                borderRadius: BorderRadius.circular(22),
                                boxShadow: <BoxShadow>[
                                  BoxShadow(
                                    color: Colors.black.withValues(alpha: 0.05),
                                    blurRadius: 18,
                                    offset: const Offset(0, 10),
                                  ),
                                ],
                              ),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: <Widget>[
                                  Text(
                                    question.question ?? '',
                                    textDirection: TextDirection.rtl,
                                    style: TextStyle(
                                      fontFamily: _fontFamily,
                                      fontSize: 19,
                                      height: 1.5,
                                      fontWeight: FontWeight.w700,
                                      color: captionTextColor,
                                    ),
                                  ),
                                  const SizedBox(height: 14),
                                  Expanded(
                                    child: ListView.separated(
                                      itemCount: options.length,
                                      separatorBuilder:
                                          (BuildContext context, int index) =>
                                              const SizedBox(height: 10),
                                      itemBuilder:
                                          (BuildContext context, int index) {
                                            return _QuestionOptionTile(
                                              index: index,
                                              text: options[index],
                                              isAnswered: isAnswered,
                                              selectedIndex: _questionController
                                                  .selectedAns,
                                              correctIndex: _questionController
                                                  .correctAns,
                                              fontFamily: _fontFamily,
                                              onTap: () => _questionController
                                                  .selectAnswer(index),
                                            );
                                          },
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ),
                        const SizedBox(height: 14),
                        Row(
                          children: <Widget>[
                            Expanded(
                              child: OutlinedButton(
                                onPressed: isAnswered
                                    ? null
                                    : () => _questionController.skipQuestion(),
                                style: OutlinedButton.styleFrom(
                                  side: const BorderSide(
                                    color: Color(0xFF0F6B53),
                                  ),
                                  foregroundColor: const Color(0xFF0F6B53),
                                  padding: const EdgeInsets.symmetric(
                                    vertical: 14,
                                  ),
                                  shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(14),
                                  ),
                                ),
                                child: Text(
                                  _t('بازدان'),
                                  style: TextStyle(
                                    fontFamily: _fontFamily,
                                    fontSize: 15,
                                    fontWeight: FontWeight.w600,
                                  ),
                                ),
                              ),
                            ),
                            const SizedBox(width: 10),
                            Expanded(
                              flex: 2,
                              child: ElevatedButton(
                                onPressed: isAnswered ? _goNextQuestion : null,
                                style: ElevatedButton.styleFrom(
                                  backgroundColor: const Color(0xFF0F6B53),
                                  foregroundColor: Colors.white,
                                  disabledBackgroundColor: const Color(
                                    0xFFBFD8CF,
                                  ),
                                  padding: const EdgeInsets.symmetric(
                                    vertical: 14,
                                  ),
                                  shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(14),
                                  ),
                                ),
                                child: Text(
                                  isLast
                                      ? _t('تەواوکردنی تاقیکردنەوە')
                                      : _t('پرسیاری داهاتوو'),
                                  style: TextStyle(
                                    fontFamily: _fontFamily,
                                    fontSize: 16,
                                    fontWeight: FontWeight.w700,
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ],
                    );
                  }),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _TopBarButton extends StatelessWidget {
  const _TopBarButton({required this.icon, required this.onTap});

  final IconData icon;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.white.withValues(alpha: 0.88),
      borderRadius: BorderRadius.circular(14),
      child: InkWell(
        borderRadius: BorderRadius.circular(14),
        onTap: onTap,
        child: SizedBox(
          width: 44,
          height: 44,
          child: Icon(icon, color: captionTextColor),
        ),
      ),
    );
  }
}

class _StatusBanner extends StatelessWidget {
  const _StatusBanner({required this.message, required this.fontFamily});

  final String message;
  final String fontFamily;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
      decoration: BoxDecoration(
        color: const Color(0xFF0F6B53).withValues(alpha: 0.12),
        borderRadius: BorderRadius.circular(14),
      ),
      child: Text(
        message,
        style: TextStyle(
          fontFamily: fontFamily,
          color: const Color(0xFF275248),
          fontWeight: FontWeight.w600,
          fontSize: 13,
        ),
      ),
    );
  }
}

class _QuestionOptionTile extends StatelessWidget {
  const _QuestionOptionTile({
    required this.index,
    required this.text,
    required this.isAnswered,
    required this.selectedIndex,
    required this.correctIndex,
    required this.fontFamily,
    required this.onTap,
  });

  final int index;
  final String text;
  final bool isAnswered;
  final int selectedIndex;
  final int correctIndex;
  final String fontFamily;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final bool isSelected = selectedIndex == index;
    final bool isCorrect = index == correctIndex;
    final bool isWrongSelected = isAnswered && isSelected && !isCorrect;

    Color borderColor = const Color(0xFFC9D6D1);
    Color tileColor = Colors.white;
    Color iconColor = const Color(0xFF5D7A70);
    IconData? icon;

    if (isAnswered) {
      if (isCorrect) {
        borderColor = const Color(0xFF2F9C58);
        tileColor = const Color(0xFFEEF8F1);
        iconColor = const Color(0xFF2F9C58);
        icon = Icons.check_circle_rounded;
      } else if (isWrongSelected) {
        borderColor = const Color(0xFFD94A4A);
        tileColor = const Color(0xFFFFF1F1);
        iconColor = const Color(0xFFD94A4A);
        icon = Icons.cancel_rounded;
      }
    } else if (isSelected) {
      borderColor = const Color(0xFF1B9AAA);
      tileColor = const Color(0xFFEFF9FB);
      iconColor = const Color(0xFF1B9AAA);
      icon = Icons.radio_button_checked_rounded;
    }

    return Material(
      color: tileColor,
      borderRadius: BorderRadius.circular(14),
      child: InkWell(
        borderRadius: BorderRadius.circular(14),
        onTap: isAnswered ? null : onTap,
        child: Container(
          width: double.infinity,
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 12),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: borderColor),
          ),
          child: Row(
            children: <Widget>[
              Container(
                width: 28,
                height: 28,
                alignment: Alignment.center,
                decoration: BoxDecoration(
                  color: iconColor.withValues(alpha: 0.12),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: icon != null
                    ? Icon(icon, size: 17, color: iconColor)
                    : Text(
                        String.fromCharCode(65 + index),
                        style: TextStyle(
                          color: iconColor,
                          fontFamily: 'english',
                          fontWeight: FontWeight.w700,
                        ),
                      ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Text(
                  text,
                  textDirection: TextDirection.rtl,
                  style: TextStyle(
                    fontFamily: fontFamily,
                    fontSize: 16,
                    color: captionTextColor,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
