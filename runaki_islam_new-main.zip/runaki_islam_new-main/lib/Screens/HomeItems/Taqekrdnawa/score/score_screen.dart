import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:provider/provider.dart';
import 'package:runaki_islam/Screens/HomeItems/Taqekrdnawa/Walamakan/walamakan.dart';
import 'package:runaki_islam/Screens/HomeItems/Taqekrdnawa/quiz/quiz_screen.dart';
import 'package:runaki_islam/Screens/HomeItems/Taqekrdnawa/welcome/welcome_screen.dart';
import 'package:runaki_islam/controller/question_controller.dart';
import 'package:runaki_islam/providers/settings_provider.dart';
import 'package:runaki_islam/util/background.dart';
import 'package:runaki_islam/util/constans.dart';

class ScoreScreen extends StatefulWidget {
  const ScoreScreen({super.key});

  @override
  State<ScoreScreen> createState() => _ScoreScreenState();
}

class _ScoreScreenState extends State<ScoreScreen> {
  late final QuestionController _questionController;
  int? _fontType;

  String get _fontFamily => _fontType?.toString() ?? '0';
  String _t(String text) => QuestionController.repairText(text);

  @override
  void initState() {
    super.initState();
    _fontType = Provider.of<SettingsProvider>(
      context,
      listen: false,
    ).getsettingField('font_family');
    _questionController = _resolveController();
  }

  QuestionController _resolveController() {
    if (Get.isRegistered<QuestionController>()) {
      return Get.find<QuestionController>();
    }
    return Get.put(QuestionController());
  }

  void _playAgain() {
    Get.off(
      () => QuizScreen(
        startOptions: _questionController.startOptions,
        startFresh: true,
      ),
    );
  }

  void _backToQuizHome() {
    Get.off(() => const WelcomeScreen());
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        backgroundColor: bgColor,
        body: Stack(
          children: <Widget>[
            const Background(),
            SafeArea(
              child: Obx(() {
                final double progress = _questionController.scorePercent;
                final QuizStartOptions options =
                    _questionController.startOptions;

                return SingleChildScrollView(
                  physics: const BouncingScrollPhysics(),
                  padding: const EdgeInsets.fromLTRB(18, 18, 18, 24),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: <Widget>[
                      Text(
                        _t('ئەنجامی تاقیکردنەوە'),
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          fontFamily: _fontFamily,
                          fontSize: 28,
                          fontWeight: FontWeight.w800,
                          color: captionTextColor,
                        ),
                      ),
                      const SizedBox(height: 8),
                      Text(
                        _questionController.resultTitle,
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          fontFamily: _fontFamily,
                          fontSize: 21,
                          fontWeight: FontWeight.w700,
                          color: const Color(0xFF0F6B53),
                        ),
                      ),
                      const SizedBox(height: 6),
                      Text(
                        _questionController.resultSubtitle,
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          fontFamily: _fontFamily,
                          color: descriptionTectColor,
                          fontSize: 14,
                          height: 1.5,
                        ),
                      ),
                      const SizedBox(height: 20),
                      SizedBox(
                        height: 220,
                        child: Stack(
                          alignment: Alignment.center,
                          children: <Widget>[
                            SizedBox(
                              width: 220,
                              height: 220,
                              child: CircularProgressIndicator(
                                value: progress,
                                strokeWidth: 14,
                                backgroundColor: const Color(0xFFE2ECE7),
                                valueColor: const AlwaysStoppedAnimation<Color>(
                                  Color(0xFF0F6B53),
                                ),
                              ),
                            ),
                            Container(
                              width: 165,
                              height: 165,
                              decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                color: Colors.white.withValues(alpha: 0.94),
                              ),
                              alignment: Alignment.center,
                              child: Column(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: <Widget>[
                                  Text(
                                    '${_questionController.numOfCorrectAns}/${_questionController.totalQuestions}',
                                    style: const TextStyle(
                                      fontFamily: 'english',
                                      fontSize: 34,
                                      fontWeight: FontWeight.w700,
                                      color: Color(0xFF0F6B53),
                                    ),
                                  ),
                                  const SizedBox(height: 4),
                                  Text(
                                    '${_questionController.accuracyPercent.toStringAsFixed(1)}%',
                                    style: const TextStyle(
                                      fontFamily: 'english',
                                      fontSize: 14,
                                      fontWeight: FontWeight.w700,
                                      color: Color(0xFF4A645B),
                                    ),
                                  ),
                                  Text(
                                    _t('دروستی'),
                                    style: TextStyle(
                                      fontFamily: _fontFamily,
                                      fontSize: 12,
                                      color: descriptionTectColor,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(height: 18),
                      Row(
                        children: <Widget>[
                          Expanded(
                            child: _MetricCard(
                              title: _t('ڕاست'),
                              value: _questionController.numOfCorrectAns
                                  .toString(),
                              color: const Color(0xFF2F9C58),
                              icon: Icons.check_circle_rounded,
                              fontFamily: _fontFamily,
                            ),
                          ),
                          const SizedBox(width: 8),
                          Expanded(
                            child: _MetricCard(
                              title: _t('هەڵە'),
                              value: _questionController.wrongAnswers
                                  .toString(),
                              color: const Color(0xFFD94A4A),
                              icon: Icons.cancel_rounded,
                              fontFamily: _fontFamily,
                            ),
                          ),
                          const SizedBox(width: 8),
                          Expanded(
                            child: _MetricCard(
                              title: _t('بازدراو'),
                              value: _questionController.skippedAnswers
                                  .toString(),
                              color: const Color(0xFF1B9AAA),
                              icon: Icons.fast_forward_rounded,
                              fontFamily: _fontFamily,
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 12),
                      Container(
                        padding: const EdgeInsets.all(12),
                        decoration: BoxDecoration(
                          color: Colors.white.withValues(alpha: 0.9),
                          borderRadius: BorderRadius.circular(16),
                        ),
                        child: Column(
                          children: <Widget>[
                            _ConfigRow(
                              title: _t('بەش'),
                              value: _questionController.activeCategoryLabel,
                              fontFamily: _fontFamily,
                            ),
                            _ConfigRow(
                              title: _t('ژمارەی پرسیار'),
                              value: '${options.questionCount}',
                              fontFamily: _fontFamily,
                            ),
                            _ConfigRow(
                              title: _t('کاتی هەر پرسیار'),
                              value: '${options.timePerQuestion} ${_t('چرکە')}',
                              fontFamily: _fontFamily,
                            ),
                            _ConfigRow(
                              title: _t('خاڵ'),
                              value: '${_questionController.totalPoints}',
                              fontFamily: _fontFamily,
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(height: 14),
                      _ActionButton(
                        label: _t('پێداچوونەوەی وەڵامەکان'),
                        icon: Icons.fact_check_outlined,
                        fontFamily: _fontFamily,
                        color: const Color(0xFF1B9AAA),
                        onTap: () {
                          Get.to(
                            () =>
                                Walamakan(sarder: _t('پێداچوونەوەی وەڵامەکان')),
                          );
                        },
                      ),
                      const SizedBox(height: 10),
                      _ActionButton(
                        label: _t('دووبارە تاقیکردنەوە بکە'),
                        icon: Icons.replay_rounded,
                        fontFamily: _fontFamily,
                        color: const Color(0xFF0F6B53),
                        onTap: _playAgain,
                      ),
                      const SizedBox(height: 10),
                      _ActionButton(
                        label: _t('گەڕانەوە بۆ لاپەڕەی سەرەکی تاقیکردنەوە'),
                        icon: Icons.home_rounded,
                        fontFamily: _fontFamily,
                        color: const Color(0xFF6A7A74),
                        onTap: _backToQuizHome,
                      ),
                    ],
                  ),
                );
              }),
            ),
          ],
        ),
      ),
    );
  }
}

class _MetricCard extends StatelessWidget {
  const _MetricCard({
    required this.title,
    required this.value,
    required this.color,
    required this.icon,
    required this.fontFamily,
  });

  final String title;
  final String value;
  final Color color;
  final IconData icon;
  final String fontFamily;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 12),
      decoration: BoxDecoration(
        color: Colors.white.withValues(alpha: 0.9),
        borderRadius: BorderRadius.circular(16),
      ),
      child: Column(
        children: <Widget>[
          Icon(icon, color: color, size: 20),
          const SizedBox(height: 8),
          Text(
            value,
            style: const TextStyle(
              fontFamily: 'english',
              fontWeight: FontWeight.w700,
              fontSize: 20,
            ),
          ),
          const SizedBox(height: 2),
          Text(
            title,
            style: TextStyle(
              fontFamily: fontFamily,
              fontSize: 12,
              color: descriptionTectColor,
            ),
          ),
        ],
      ),
    );
  }
}

class _ConfigRow extends StatelessWidget {
  const _ConfigRow({
    required this.title,
    required this.value,
    required this.fontFamily,
  });

  final String title;
  final String value;
  final String fontFamily;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        children: <Widget>[
          Expanded(
            child: Text(
              title,
              style: TextStyle(
                fontFamily: fontFamily,
                color: descriptionTectColor,
              ),
            ),
          ),
          Text(
            value,
            style: TextStyle(
              fontFamily: fontFamily,
              color: captionTextColor,
              fontWeight: FontWeight.w700,
            ),
          ),
        ],
      ),
    );
  }
}

class _ActionButton extends StatelessWidget {
  const _ActionButton({
    required this.label,
    required this.icon,
    required this.fontFamily,
    required this.color,
    required this.onTap,
  });

  final String label;
  final IconData icon;
  final String fontFamily;
  final Color color;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: double.infinity,
      child: ElevatedButton.icon(
        onPressed: onTap,
        icon: Icon(icon, size: 20),
        label: Text(
          label,
          style: TextStyle(
            fontFamily: fontFamily,
            fontSize: 15,
            fontWeight: FontWeight.w700,
          ),
        ),
        style: ElevatedButton.styleFrom(
          backgroundColor: color,
          foregroundColor: Colors.white,
          padding: const EdgeInsets.symmetric(vertical: 14),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(14),
          ),
        ),
      ),
    );
  }
}
