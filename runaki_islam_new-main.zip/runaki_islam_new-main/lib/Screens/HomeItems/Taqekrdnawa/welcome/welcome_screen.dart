import 'dart:async';
import 'dart:math';

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:provider/provider.dart';
import 'package:runaki_islam/Screens/HomeItems/Taqekrdnawa/quiz/quiz_screen.dart';
import 'package:runaki_islam/controller/question_controller.dart';
import 'package:runaki_islam/models/questions.dart';
import 'package:runaki_islam/providers/settings_provider.dart';
import 'package:runaki_islam/util/animation_helper.dart';
import 'package:runaki_islam/util/background.dart';
import 'package:runaki_islam/util/constans.dart';

class FisrtQuizScreen extends StatelessWidget {
  const FisrtQuizScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return const WelcomeScreen();
  }
}

class WelcomeScreen extends StatefulWidget {
  const WelcomeScreen({super.key});

  @override
  State<WelcomeScreen> createState() => _WelcomeScreenState();
}

class _WelcomeScreenState extends State<WelcomeScreen> {
  late final QuestionController _questionController;
  int? _fontType;

  String _selectedCategoryId = 'all';
  String? _selectedQuizId;
  int _selectedQuestionCount = 10;
  int _selectedTimerSeconds = 25;
  bool _shuffleQuestions = true;
  bool _shuffleOptions = true;
  bool _isStartingQuiz = false;

  String get _fontFamily => _fontType?.toString() ?? '0';
  String get _effectiveSelectionId => _selectedQuizId ?? _selectedCategoryId;
  bool get _selectionHasQuizTarget => _selectedQuizId != null;

  int get _loadedQuestionCount =>
      _questionController.totalQuestionsForSelection(_effectiveSelectionId);

  int get _maxSelectableQuestions {
    if (_loadedQuestionCount > 0) {
      return _loadedQuestionCount;
    }
    return 20;
  }

  String _t(String text) => QuestionController.repairText(text);

  @override
  void initState() {
    super.initState();
    _fontType = Provider.of<SettingsProvider>(
      context,
      listen: false,
    ).getsettingField('font_family');
    _questionController = _resolveController();
    _questionController.ensureQuestionsLoaded(forceRefresh: true);
    _syncQuestionCount();
    Future<void>.delayed(const Duration(seconds: 16), () {
      if (!mounted) return;
      if (_questionController.isCatalogLoading &&
          !_questionController.hasQuizCatalog) {
        _questionController.recoverCatalogLoading();
      }
    });
  }

  QuestionController _resolveController() {
    if (Get.isRegistered<QuestionController>()) {
      return Get.find<QuestionController>();
    }
    return Get.put(QuestionController());
  }

  void _syncQuestionCount() {
    if (_selectedQuestionCount < 1) {
      _selectedQuestionCount = 1;
    }
    if (_selectedQuestionCount > _maxSelectableQuestions) {
      _selectedQuestionCount = _maxSelectableQuestions;
    }
  }

  void _ensureValidSelectionState() {
    final bool hasValidCategory = _questionController.hasSelection(
      _selectedCategoryId,
    );
    final List<QuizCollection> visibleQuizzes = _questionController
        .quizCollectionsForCategory(_selectedCategoryId);
    final bool hasValidQuiz =
        _selectedQuizId == null ||
        visibleQuizzes.any(
          (QuizCollection item) => item.selectionId == _selectedQuizId,
        );

    if (hasValidCategory && hasValidQuiz) {
      return;
    }

    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!mounted) return;
      setState(() {
        if (!hasValidCategory) {
          _selectedCategoryId = 'all';
        }
        if (!hasValidQuiz) {
          _selectedQuizId = null;
        }
        _syncQuestionCount();
      });
    });
  }

  Future<void> _prefetchSelection(String selectionId) async {
    unawaited(_questionController.prepareSelection(selectionId));
  }

  void _handleCategoryTap(String selectionId) {
    if (_selectedCategoryId == selectionId && _selectedQuizId == null) {
      return;
    }

    setState(() {
      _selectedCategoryId = selectionId;
      _selectedQuizId = null;
      _syncQuestionCount();
    });
    unawaited(_prefetchSelection(selectionId));
  }

  void _handleQuizTap(QuizCollection collection) {
    final String nextCategoryId = collection.categoryId == null
        ? 'all'
        : 'category:${collection.categoryId}';

    setState(() {
      _selectedCategoryId = nextCategoryId;
      _selectedQuizId = collection.selectionId;
      _syncQuestionCount();
    });
    unawaited(_prefetchSelection(collection.selectionId));
  }

  Future<void> _startQuiz() async {
    if (_isStartingQuiz) {
      return;
    }

    if (_questionController.isCatalogLoading &&
        !_questionController.hasQuizCatalog) {
      Get.snackbar(
        _t('ئاگاداری'),
        _t('تاقیکردنەوەکان هێشتا بار دەکرێن.'),
        snackPosition: SnackPosition.BOTTOM,
      );
      return;
    }

    if (!_questionController.canStartSelection(_effectiveSelectionId)) {
      Get.snackbar(
        _t('هەڵە'),
        _t('هیچ بەشێکی بەردەست بۆ هەڵبژاردن نەدۆزرایەوە.'),
        snackPosition: SnackPosition.BOTTOM,
      );
      return;
    }

    setState(() {
      _isStartingQuiz = true;
    });

    try {
      final int totalAvailable = await _questionController.prepareSelection(
        _effectiveSelectionId,
      );

      if (!mounted) {
        return;
      }

      if (totalAvailable <= 0) {
        Get.snackbar(
          _t('هەڵە'),
          _t('هیچ پرسیارێک بۆ ئەم هەڵبژاردنە نییە.'),
          snackPosition: SnackPosition.BOTTOM,
        );
        return;
      }

      final int safeCount = _selectedQuestionCount.clamp(1, totalAvailable);
      final QuizStartOptions options = QuizStartOptions(
        categoryId: _effectiveSelectionId,
        questionCount: safeCount,
        timePerQuestion: _selectedTimerSeconds,
        shuffleQuestions: _shuffleQuestions,
        shuffleOptions: _shuffleOptions,
      );

      Get.to(() => QuizScreen(startOptions: options));
    } finally {
      if (mounted) {
        setState(() {
          _isStartingQuiz = false;
        });
      }
    }
  }

  void _retryCatalogLoad() {
    unawaited(_questionController.loadQuizCatalog(forceRefresh: true));
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        backgroundColor: bgColor,
        body: Stack(
          children: <Widget>[
            const Background(),
            SafeArea(
              child: Obx(() {
                _ensureValidSelectionState();

                final List<QuizCollection> visibleQuizzes = _questionController
                    .quizCollectionsForCategory(_selectedCategoryId);
                final bool showCategoryShimmer =
                    _questionController.isCatalogLoading &&
                    _questionController.quizCategories.isEmpty;
                final bool showSectionsShimmer =
                    _questionController.isCatalogLoading &&
                    _questionController.quizCollections.isEmpty;
                final bool selectionLoaded = _questionController
                    .isSelectionLoaded(_effectiveSelectionId);
                final bool selectionBusy =
                    _isStartingQuiz ||
                    (_questionController.isSelectionPreparing &&
                        _questionController.preparingSelectionId ==
                            _effectiveSelectionId);

                return Stack(
                  children: <Widget>[
                    RefreshIndicator(
                      color: const Color(0xFF0F6B53),
                      onRefresh: () => _questionController.loadQuizCatalog(
                        forceRefresh: true,
                      ),
                      child: ListView(
                        physics: const BouncingScrollPhysics(
                          parent: AlwaysScrollableScrollPhysics(),
                        ),
                        padding: const EdgeInsets.fromLTRB(16, 12, 16, 24),
                        children: <Widget>[
                          Row(
                            children: <Widget>[
                              _CircleButton(
                                icon: Icons.arrow_back_ios_new_rounded,
                                onTap: () => Navigator.of(context).pop(),
                              ),
                              const Spacer(),
                              _ScoreBadge(
                                label: _t('باشترین'),
                                value: '${_questionController.bestScore}',
                              ),
                            ],
                          ),
                          const SizedBox(height: 18),
                          _HeroCard(
                            title: _t('تاقیکردنەوەی زانیاری'),
                            subtitle: _t(
                              'بەش هەڵبژێرە، ژمارەی پرسیار دیاری بکە، و بە خێرایی دەست پێبکە.',
                            ),
                            fontFamily: _fontFamily,
                          ),
                          if (_questionController.canResumeQuiz)
                            Padding(
                              padding: const EdgeInsets.only(top: 12),
                              child: _ResumeQuizCard(
                                fontFamily: _fontFamily,
                                currentQuestion:
                                    _questionController.currentQuestionNumber,
                                totalQuestions:
                                    _questionController.totalQuestions,
                                answeredQuestions:
                                    _questionController.answeredQuestions,
                                onContinue: () {
                                  Get.to(
                                    () => const QuizScreen(startFresh: false),
                                  );
                                },
                                onStartNew: _startQuiz,
                              ),
                            ),
                          const SizedBox(height: 18),
                          _SectionHeader(
                            title: _t('بەشەکان'),
                            actionIcon: Icons.refresh_rounded,
                            onAction: _questionController.isCatalogLoading
                                ? null
                                : _retryCatalogLoad,
                            fontFamily: _fontFamily,
                          ),
                          const SizedBox(height: 10),
                          if (showCategoryShimmer)
                            const _CategoryChipsShimmer()
                          else
                            Wrap(
                              spacing: 8,
                              runSpacing: 8,
                              children: <Widget>[
                                _CategoryChip(
                                  label: _t('هەموو'),
                                  selected: _selectedCategoryId == 'all',
                                  fontFamily: _fontFamily,
                                  onTap: () => _handleCategoryTap('all'),
                                ),
                                ..._questionController.quizCategories.map(
                                  (QuizCategory category) => _CategoryChip(
                                    label: category.title,
                                    selected:
                                        _selectedCategoryId ==
                                        category.selectionId,
                                    fontFamily: _fontFamily,
                                    onTap: () => _handleCategoryTap(
                                      category.selectionId,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          const SizedBox(height: 18),
                          _SectionHeader(
                            title: _t('تاقیکردنەوەکان'),
                            subtitle: _selectedCategoryId == 'all'
                                ? _t('هەموو بەشە بەردەستەکان')
                                : (_questionController.quizCategories
                                          .firstWhere(
                                            (QuizCategory item) =>
                                                item.selectionId ==
                                                _selectedCategoryId,
                                            orElse: () => const QuizCategory(
                                              id: 0,
                                              title: '',
                                              slug: '',
                                              description: '',
                                              scope: '',
                                              sortOrder: 0,
                                            ),
                                          )
                                          .title
                                          .trim()
                                          .isNotEmpty
                                      ? _questionController.quizCategories
                                            .firstWhere(
                                              (QuizCategory item) =>
                                                  item.selectionId ==
                                                  _selectedCategoryId,
                                              orElse: () => const QuizCategory(
                                                id: 0,
                                                title: '',
                                                slug: '',
                                                description: '',
                                                scope: '',
                                                sortOrder: 0,
                                              ),
                                            )
                                            .title
                                      : _t('بەشی هەڵبژێردراو')),
                            fontFamily: _fontFamily,
                          ),
                          const SizedBox(height: 10),
                          if (showSectionsShimmer)
                            const _QuizCardsShimmer()
                          else if (visibleQuizzes.isEmpty)
                            _EmptyStateCard(
                              fontFamily: _fontFamily,
                              title: _t('هیچ تاقیکردنەوەیەک نەدۆزرایەوە'),
                              subtitle:
                                  _questionController.catalogError
                                      .trim()
                                      .isNotEmpty
                                  ? _questionController.catalogError
                                  : _t(
                                      'ئەم بەشە هێشتا هیچ تاقیکردنەوەیەکی چالاکی نییە.',
                                    ),
                              onRetry: _questionController.isCatalogLoading
                                  ? null
                                  : _retryCatalogLoad,
                            )
                          else
                            Column(
                              children: visibleQuizzes
                                  .map(
                                    (QuizCollection collection) => Padding(
                                      padding: const EdgeInsets.only(
                                        bottom: 12,
                                      ),
                                      child: _QuizSectionCard(
                                        collection: collection,
                                        categoryLabel: _questionController
                                            .categoryTitleForQuiz(collection),
                                        selected:
                                            _selectedQuizId ==
                                            collection.selectionId,
                                        fontFamily: _fontFamily,
                                        onTap: () => _handleQuizTap(collection),
                                      ),
                                    ),
                                  )
                                  .toList(),
                            ),
                          if (_questionController.catalogError
                                  .trim()
                                  .isNotEmpty &&
                              visibleQuizzes.isNotEmpty) ...<Widget>[
                            const SizedBox(height: 6),
                            _InlineWarningCard(
                              fontFamily: _fontFamily,
                              message: _questionController.catalogError,
                            ),
                          ],
                          const SizedBox(height: 18),
                          _OptionsCard(
                            fontFamily: _fontFamily,
                            questionCount: _selectedQuestionCount,
                            maxQuestionCount: _maxSelectableQuestions,
                            availableQuestionCount: _loadedQuestionCount,
                            selectionLoaded: selectionLoaded,
                            timerSeconds: _selectedTimerSeconds,
                            shuffleQuestions: _shuffleQuestions,
                            shuffleOptions: _shuffleOptions,
                            currentSelectionLabel: _selectionHasQuizTarget
                                ? _t('بەشی هەڵبژێردراو')
                                : _t('هەڵبژاردنی ئێستا'),
                            onIncreaseQuestions: () {
                              setState(() {
                                if (_selectedQuestionCount <
                                    _maxSelectableQuestions) {
                                  _selectedQuestionCount += 1;
                                }
                              });
                            },
                            onDecreaseQuestions: () {
                              setState(() {
                                if (_selectedQuestionCount > 1) {
                                  _selectedQuestionCount -= 1;
                                }
                              });
                            },
                            onTimerChanged: (int? value) {
                              if (value == null) return;
                              setState(() {
                                _selectedTimerSeconds = value;
                              });
                            },
                            onShuffleQuestionsChanged: (bool value) {
                              setState(() {
                                _shuffleQuestions = value;
                              });
                            },
                            onShuffleOptionsChanged: (bool value) {
                              setState(() {
                                _shuffleOptions = value;
                              });
                            },
                          ),
                          const SizedBox(height: 16),
                          SizedBox(
                            height: 54,
                            child: ElevatedButton.icon(
                              onPressed:
                                  _questionController.canStartSelection(
                                        _effectiveSelectionId,
                                      ) &&
                                      !_isStartingQuiz
                                  ? _startQuiz
                                  : null,
                              icon: Icon(
                                selectionBusy
                                    ? Icons.hourglass_top_rounded
                                    : Icons.play_arrow_rounded,
                                size: 24,
                              ),
                              label: Text(
                                selectionBusy
                                    ? _t('ئامادەکردنی پرسیارەکان...')
                                    : _t('دەستپێکردنی تاقیکردنەوە'),
                                style: TextStyle(
                                  fontFamily: _fontFamily,
                                  fontSize: 16,
                                  fontWeight: FontWeight.w700,
                                ),
                              ),
                              style: ElevatedButton.styleFrom(
                                backgroundColor: const Color(0xFF0F6B53),
                                foregroundColor: Colors.white,
                                disabledBackgroundColor: const Color(
                                  0xFFBFD8CF,
                                ),
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(16),
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                    if (_isStartingQuiz)
                      const Positioned.fill(
                        child: ColoredBox(
                          color: Color(0x33000000),
                          child: Center(
                            child: CircularProgressIndicator(
                              color: Color(0xFF0F6B53),
                            ),
                          ),
                        ),
                      ),
                  ],
                );
              }),
            ),
          ],
        ),
      ),
    );
  }
}

class _HeroCard extends StatelessWidget {
  const _HeroCard({
    required this.title,
    required this.subtitle,
    required this.fontFamily,
  });

  final String title;
  final String subtitle;
  final String fontFamily;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: Colors.white.withValues(alpha: 0.94),
        borderRadius: BorderRadius.circular(24),
        border: Border.all(color: const Color(0xFFE3E9E6)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: <Widget>[
          Text(
            title,
            textAlign: TextAlign.right,
            style: TextStyle(
              fontFamily: fontFamily,
              color: captionTextColor,
              fontSize: 22,
              fontWeight: FontWeight.w800,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            subtitle,
            textAlign: TextAlign.right,
            style: TextStyle(
              fontFamily: fontFamily,
              color: descriptionTectColor,
              fontSize: 14,
              height: 1.6,
            ),
          ),
        ],
      ),
    );
  }
}

class _SectionHeader extends StatelessWidget {
  const _SectionHeader({
    required this.title,
    required this.fontFamily,
    this.subtitle,
    this.actionIcon,
    this.onAction,
  });

  final String title;
  final String? subtitle;
  final String fontFamily;
  final IconData? actionIcon;
  final VoidCallback? onAction;

  @override
  Widget build(BuildContext context) {
    return Row(
      children: <Widget>[
        if (actionIcon != null)
          IconButton(
            onPressed: onAction,
            icon: Icon(actionIcon, color: captionTextColor),
          ),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: <Widget>[
              Text(
                title,
                textAlign: TextAlign.right,
                style: TextStyle(
                  fontFamily: fontFamily,
                  fontSize: 18,
                  fontWeight: FontWeight.w800,
                  color: captionTextColor,
                ),
              ),
              if ((subtitle ?? '').trim().isNotEmpty)
                Padding(
                  padding: const EdgeInsets.only(top: 2),
                  child: Text(
                    subtitle!,
                    textAlign: TextAlign.right,
                    style: TextStyle(
                      fontFamily: fontFamily,
                      fontSize: 12,
                      color: descriptionTectColor,
                    ),
                  ),
                ),
            ],
          ),
        ),
      ],
    );
  }
}

class _ScoreBadge extends StatelessWidget {
  const _ScoreBadge({required this.label, required this.value});

  final String label;
  final String value;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      decoration: BoxDecoration(
        color: Colors.white.withValues(alpha: 0.9),
        borderRadius: BorderRadius.circular(16),
      ),
      child: Text(
        '$label: $value',
        style: const TextStyle(
          fontFamily: 'english',
          fontSize: 13,
          fontWeight: FontWeight.w700,
        ),
      ),
    );
  }
}

class _CategoryChip extends StatelessWidget {
  const _CategoryChip({
    required this.label,
    required this.selected,
    required this.fontFamily,
    required this.onTap,
  });

  final String label;
  final bool selected;
  final String fontFamily;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: selected ? const Color(0xFF0F6B53) : Colors.white,
      borderRadius: BorderRadius.circular(16),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(16),
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(16),
            border: Border.all(
              color: selected
                  ? const Color(0xFF0F6B53)
                  : const Color(0xFFE0E8E4),
            ),
          ),
          child: Text(
            label,
            style: TextStyle(
              fontFamily: fontFamily,
              fontSize: 13,
              fontWeight: FontWeight.w700,
              color: selected ? Colors.white : captionTextColor,
            ),
          ),
        ),
      ),
    );
  }
}

class _QuizSectionCard extends StatelessWidget {
  const _QuizSectionCard({
    required this.collection,
    required this.categoryLabel,
    required this.selected,
    required this.fontFamily,
    required this.onTap,
  });

  final QuizCollection collection;
  final String categoryLabel;
  final bool selected;
  final String fontFamily;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final Color borderColor = selected
        ? const Color(0xFF0F6B53)
        : const Color(0xFFE0E8E4);
    final Color tileColor = selected
        ? const Color(0xFFF2F8F5)
        : Colors.white.withValues(alpha: 0.95);

    return Material(
      color: tileColor,
      borderRadius: BorderRadius.circular(24),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(24),
        child: Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: tileColor,
            borderRadius: BorderRadius.circular(24),
            border: Border.all(color: borderColor, width: selected ? 1.5 : 1),
          ),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Container(
                width: 46,
                height: 46,
                decoration: BoxDecoration(
                  color: const Color(0xFF0F6B53).withValues(alpha: 0.1),
                  borderRadius: BorderRadius.circular(16),
                ),
                child: Icon(
                  selected ? Icons.check_circle_rounded : Icons.quiz_rounded,
                  color: const Color(0xFF0F6B53),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: <Widget>[
                    Row(
                      children: <Widget>[
                        if (categoryLabel.trim().isNotEmpty)
                          Container(
                            padding: const EdgeInsets.symmetric(
                              horizontal: 10,
                              vertical: 6,
                            ),
                            decoration: BoxDecoration(
                              color: const Color(0xFFEAF2EE),
                              borderRadius: BorderRadius.circular(100),
                            ),
                            child: Text(
                              categoryLabel,
                              style: TextStyle(
                                fontFamily: fontFamily,
                                fontSize: 11,
                                fontWeight: FontWeight.w700,
                                color: const Color(0xFF376053),
                              ),
                            ),
                          ),
                        const Spacer(),
                        if (collection.isLoaded)
                          Container(
                            padding: const EdgeInsets.symmetric(
                              horizontal: 10,
                              vertical: 6,
                            ),
                            decoration: BoxDecoration(
                              color: Colors.white,
                              borderRadius: BorderRadius.circular(100),
                              border: Border.all(
                                color: const Color(0xFFE0E8E4),
                              ),
                            ),
                            child: Text(
                              '${collection.questionCount} ${QuestionController.repairText('پرسیار')}',
                              style: const TextStyle(
                                fontFamily: 'english',
                                fontSize: 11,
                                fontWeight: FontWeight.w700,
                                color: Color(0xFF24433A),
                              ),
                            ),
                          )
                        else
                          const _CountShimmerPill(),
                      ],
                    ),
                    const SizedBox(height: 12),
                    Text(
                      collection.title,
                      textAlign: TextAlign.right,
                      style: TextStyle(
                        fontFamily: fontFamily,
                        fontSize: 18,
                        fontWeight: FontWeight.w800,
                        color: captionTextColor,
                      ),
                    ),
                    if (collection.description.trim().isNotEmpty) ...<Widget>[
                      const SizedBox(height: 6),
                      Text(
                        collection.description,
                        textAlign: TextAlign.right,
                        style: TextStyle(
                          fontFamily: fontFamily,
                          fontSize: 13,
                          height: 1.5,
                          color: descriptionTectColor,
                        ),
                      ),
                    ],
                    const SizedBox(height: 12),
                    Row(
                      children: <Widget>[
                        Icon(
                          selected
                              ? Icons.radio_button_checked_rounded
                              : Icons.touch_app_rounded,
                          size: 18,
                          color: const Color(0xFF0F6B53),
                        ),
                        const SizedBox(width: 6),
                        Expanded(
                          child: Text(
                            selected
                                ? QuestionController.repairText(
                                    'ئەم بەشە هەڵبژێردراوە',
                                  )
                                : QuestionController.repairText(
                                    'بۆ دەستپێکردن ئەم بەشە هەڵبژێرە',
                                  ),
                            textAlign: TextAlign.right,
                            style: TextStyle(
                              fontFamily: fontFamily,
                              fontSize: 12,
                              fontWeight: FontWeight.w700,
                              color: const Color(0xFF0F6B53),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _OptionsCard extends StatelessWidget {
  const _OptionsCard({
    required this.fontFamily,
    required this.questionCount,
    required this.maxQuestionCount,
    required this.availableQuestionCount,
    required this.selectionLoaded,
    required this.timerSeconds,
    required this.shuffleQuestions,
    required this.shuffleOptions,
    required this.currentSelectionLabel,
    required this.onIncreaseQuestions,
    required this.onDecreaseQuestions,
    required this.onTimerChanged,
    required this.onShuffleQuestionsChanged,
    required this.onShuffleOptionsChanged,
  });

  final String fontFamily;
  final int questionCount;
  final int maxQuestionCount;
  final int availableQuestionCount;
  final bool selectionLoaded;
  final int timerSeconds;
  final bool shuffleQuestions;
  final bool shuffleOptions;
  final String currentSelectionLabel;
  final VoidCallback onIncreaseQuestions;
  final VoidCallback onDecreaseQuestions;
  final ValueChanged<int?> onTimerChanged;
  final ValueChanged<bool> onShuffleQuestionsChanged;
  final ValueChanged<bool> onShuffleOptionsChanged;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Colors.white.withValues(alpha: 0.93),
        borderRadius: BorderRadius.circular(20),
      ),
      child: Column(
        children: <Widget>[
          Row(
            children: <Widget>[
              _SquareButton(
                icon: Icons.remove_rounded,
                onTap: onDecreaseQuestions,
              ),
              const SizedBox(width: 8),
              Text(
                '$questionCount',
                style: const TextStyle(
                  fontFamily: 'english',
                  fontSize: 18,
                  fontWeight: FontWeight.w800,
                ),
              ),
              const SizedBox(width: 8),
              _SquareButton(
                icon: Icons.add_rounded,
                onTap: onIncreaseQuestions,
              ),
              const Spacer(),
              Column(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: <Widget>[
                  Text(
                    QuestionController.repairText('ژمارەی پرسیار'),
                    style: TextStyle(
                      fontFamily: fontFamily,
                      fontSize: 16,
                      fontWeight: FontWeight.w800,
                      color: captionTextColor,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    selectionLoaded
                        ? '$currentSelectionLabel: $availableQuestionCount'
                        : QuestionController.repairText(
                            'ژمارەی پرسیارەکان بەردەست دەکرێت...',
                          ),
                    style: TextStyle(
                      fontFamily: fontFamily,
                      fontSize: 12,
                      color: descriptionTectColor,
                    ),
                    textAlign: TextAlign.right,
                  ),
                ],
              ),
            ],
          ),
          const Divider(height: 26),
          Row(
            children: <Widget>[
              DropdownButton<int>(
                value: timerSeconds,
                borderRadius: BorderRadius.circular(14),
                items: QuestionController.availableTimers
                    .map(
                      (int second) => DropdownMenuItem<int>(
                        value: second,
                        child: Text(
                          '$second ${QuestionController.repairText('چرکە')}',
                          style: const TextStyle(fontFamily: 'english'),
                        ),
                      ),
                    )
                    .toList(),
                onChanged: onTimerChanged,
              ),
              const Spacer(),
              Text(
                QuestionController.repairText('کاتی هەر پرسیار'),
                style: TextStyle(
                  fontFamily: fontFamily,
                  fontSize: 16,
                  fontWeight: FontWeight.w800,
                  color: captionTextColor,
                ),
              ),
            ],
          ),
          const Divider(height: 26),
          SwitchListTile(
            contentPadding: EdgeInsets.zero,
            value: shuffleQuestions,
            title: Text(
              QuestionController.repairText('تێکەڵکردنی پرسیارەکان'),
              textAlign: TextAlign.right,
              style: TextStyle(
                fontFamily: fontFamily,
                color: captionTextColor,
                fontWeight: FontWeight.w700,
              ),
            ),
            onChanged: onShuffleQuestionsChanged,
          ),
          SwitchListTile(
            contentPadding: EdgeInsets.zero,
            value: shuffleOptions,
            title: Text(
              QuestionController.repairText('تێکەڵکردنی هەڵبژاردەکان'),
              textAlign: TextAlign.right,
              style: TextStyle(
                fontFamily: fontFamily,
                color: captionTextColor,
                fontWeight: FontWeight.w700,
              ),
            ),
            onChanged: onShuffleOptionsChanged,
          ),
          if (availableQuestionCount > 0 && questionCount > maxQuestionCount)
            Padding(
              padding: const EdgeInsets.only(top: 4),
              child: Align(
                alignment: Alignment.centerRight,
                child: Text(
                  QuestionController.repairText(
                    'ژمارەی هەڵبژێردراو لە خشتەی بەردەست زیاترە و لە کاتی دەستپێکردن داڕێژراو دەبێت.',
                  ),
                  textAlign: TextAlign.right,
                  style: TextStyle(
                    fontFamily: fontFamily,
                    fontSize: 11,
                    color: const Color(0xFF7A6A3C),
                  ),
                ),
              ),
            ),
        ],
      ),
    );
  }
}

class _CategoryChipsShimmer extends StatelessWidget {
  const _CategoryChipsShimmer();

  @override
  Widget build(BuildContext context) {
    return Wrap(
      spacing: 8,
      runSpacing: 8,
      children: const <Widget>[
        _ShimmerChip(width: 78),
        _ShimmerChip(width: 96),
        _ShimmerChip(width: 88),
        _ShimmerChip(width: 92),
      ],
    );
  }
}

class _QuizCardsShimmer extends StatelessWidget {
  const _QuizCardsShimmer();

  @override
  Widget build(BuildContext context) {
    return const Column(
      children: <Widget>[
        _QuizCardSkeleton(),
        SizedBox(height: 12),
        _QuizCardSkeleton(),
        SizedBox(height: 12),
        _QuizCardSkeleton(),
      ],
    );
  }
}

class _QuizCardSkeleton extends StatelessWidget {
  const _QuizCardSkeleton();

  @override
  Widget build(BuildContext context) {
    return _Shimmer(
      child: Container(
        width: double.infinity,
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(24),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: const <Widget>[
            Row(
              children: <Widget>[
                Expanded(child: SizedBox()),
                _ShimmerBox(width: 88, height: 28, radius: 100),
                SizedBox(width: 8),
                _ShimmerBox(width: 68, height: 28, radius: 100),
              ],
            ),
            SizedBox(height: 14),
            _ShimmerBox(width: 170, height: 20, radius: 10),
            SizedBox(height: 10),
            _ShimmerBox(width: double.infinity, height: 12, radius: 8),
            SizedBox(height: 8),
            _ShimmerBox(width: 210, height: 12, radius: 8),
            SizedBox(height: 14),
            _ShimmerBox(width: 140, height: 12, radius: 8),
          ],
        ),
      ),
    );
  }
}

class _CountShimmerPill extends StatelessWidget {
  const _CountShimmerPill();

  @override
  Widget build(BuildContext context) {
    return const _ShimmerChip(width: 88, height: 28);
  }
}

class _ShimmerChip extends StatelessWidget {
  const _ShimmerChip({required this.width, this.height = 40});

  final double width;
  final double height;

  @override
  Widget build(BuildContext context) {
    return _Shimmer(
      child: _ShimmerBox(width: width, height: height, radius: 16),
    );
  }
}

class _ShimmerBox extends StatelessWidget {
  const _ShimmerBox({
    required this.width,
    required this.height,
    required this.radius,
  });

  final double width;
  final double height;
  final double radius;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: width,
      height: height,
      decoration: BoxDecoration(
        color: const Color(0xFFE3ECE8),
        borderRadius: BorderRadius.circular(radius),
      ),
    );
  }
}

class _Shimmer extends StatefulWidget {
  const _Shimmer({required this.child});

  final Widget child;

  @override
  State<_Shimmer> createState() => _ShimmerState();
}

class _ShimmerState extends State<_Shimmer>
    with SingleTickerProviderStateMixin {
  late final AnimationController _controller = AnimationController(
    vsync: this,
    duration: const Duration(milliseconds: 1100),
  );

  @override
  void initState() {
    super.initState();
    if (!AppMotion.reduceMotion) {
      _controller.repeat();
    }
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (AppMotion.reduceMotion) {
      return widget.child;
    }
    return AnimatedBuilder(
      animation: _controller,
      child: widget.child,
      builder: (BuildContext context, Widget? child) {
        final double value = _controller.value;
        return ShaderMask(
          blendMode: BlendMode.srcATop,
          shaderCallback: (Rect bounds) {
            return LinearGradient(
              begin: Alignment(-1.6 + (value * 2.6), 0),
              end: Alignment(-0.6 + (value * 2.6), 0),
              colors: const <Color>[
                Color(0xFFE3ECE8),
                Color(0xFFF7FBF9),
                Color(0xFFE3ECE8),
              ],
              stops: const <double>[0.1, 0.45, 0.9],
            ).createShader(bounds);
          },
          child: child,
        );
      },
    );
  }
}

class _InlineWarningCard extends StatelessWidget {
  const _InlineWarningCard({required this.fontFamily, required this.message});

  final String fontFamily;
  final String message;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Colors.white.withValues(alpha: 0.92),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: const Color(0xFFE4D8B5)),
      ),
      child: Text(
        message,
        textAlign: TextAlign.right,
        style: TextStyle(
          fontFamily: fontFamily,
          fontSize: 12,
          height: 1.5,
          color: const Color(0xFF6F5A2D),
        ),
      ),
    );
  }
}

class _EmptyStateCard extends StatelessWidget {
  const _EmptyStateCard({
    required this.fontFamily,
    required this.title,
    required this.subtitle,
    this.onRetry,
  });

  final String fontFamily;
  final String title;
  final String subtitle;
  final VoidCallback? onRetry;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: Colors.white.withValues(alpha: 0.93),
        borderRadius: BorderRadius.circular(22),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: <Widget>[
          Text(
            title,
            textAlign: TextAlign.right,
            style: TextStyle(
              fontFamily: fontFamily,
              fontSize: 17,
              fontWeight: FontWeight.w800,
              color: captionTextColor,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            subtitle,
            textAlign: TextAlign.right,
            style: TextStyle(
              fontFamily: fontFamily,
              fontSize: 13,
              height: 1.6,
              color: descriptionTectColor,
            ),
          ),
          if (onRetry != null) ...<Widget>[
            const SizedBox(height: 12),
            Align(
              alignment: Alignment.centerRight,
              child: OutlinedButton.icon(
                onPressed: onRetry,
                icon: const Icon(Icons.refresh_rounded, size: 18),
                label: Text(QuestionController.repairText('دووبارەهەوڵدان')),
                style: OutlinedButton.styleFrom(
                  foregroundColor: const Color(0xFF0F6B53),
                  side: const BorderSide(color: Color(0xFF0F6B53)),
                ),
              ),
            ),
          ],
        ],
      ),
    );
  }
}

class _CircleButton extends StatelessWidget {
  const _CircleButton({required this.icon, required this.onTap});

  final IconData icon;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.white.withValues(alpha: 0.9),
      borderRadius: BorderRadius.circular(14),
      child: InkWell(
        borderRadius: BorderRadius.circular(14),
        onTap: onTap,
        child: SizedBox(
          width: 44,
          height: 44,
          child: Icon(icon, color: captionTextColor),
        ),
      ),
    );
  }
}

class _ResumeQuizCard extends StatelessWidget {
  const _ResumeQuizCard({
    required this.fontFamily,
    required this.currentQuestion,
    required this.totalQuestions,
    required this.answeredQuestions,
    required this.onContinue,
    required this.onStartNew,
  });

  final String fontFamily;
  final int currentQuestion;
  final int totalQuestions;
  final int answeredQuestions;
  final VoidCallback onContinue;
  final VoidCallback onStartNew;

  @override
  Widget build(BuildContext context) {
    final int safeTotal = max(totalQuestions, 1);
    final double progress = (answeredQuestions / safeTotal).clamp(0.0, 1.0);

    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Colors.white.withValues(alpha: 0.9),
        borderRadius: BorderRadius.circular(18),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: <Widget>[
          Text(
            QuestionController.repairText('تاقیکردنەوەی هەڵگیراو'),
            textAlign: TextAlign.right,
            style: TextStyle(
              fontFamily: fontFamily,
              fontSize: 16,
              fontWeight: FontWeight.w800,
              color: captionTextColor,
            ),
          ),
          const SizedBox(height: 4),
          Text(
            QuestionController.repairText(
              'پرسیاری $currentQuestion لە $totalQuestions',
            ),
            textAlign: TextAlign.right,
            style: TextStyle(
              fontFamily: fontFamily,
              fontSize: 13,
              color: descriptionTectColor,
            ),
          ),
          const SizedBox(height: 8),
          ClipRRect(
            borderRadius: BorderRadius.circular(100),
            child: LinearProgressIndicator(
              value: progress,
              minHeight: 7,
              backgroundColor: const Color(0xFFE4EDEA),
              valueColor: const AlwaysStoppedAnimation<Color>(
                Color(0xFF0F6B53),
              ),
            ),
          ),
          const SizedBox(height: 10),
          Row(
            children: <Widget>[
              Expanded(
                child: OutlinedButton(
                  onPressed: onStartNew,
                  style: OutlinedButton.styleFrom(
                    side: const BorderSide(color: Color(0xFF0F6B53)),
                    foregroundColor: const Color(0xFF0F6B53),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                  ),
                  child: Text(
                    QuestionController.repairText('دەستپێکردنی نوێ'),
                    style: TextStyle(fontFamily: fontFamily),
                  ),
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: ElevatedButton(
                  onPressed: onContinue,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFF0F6B53),
                    foregroundColor: Colors.white,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                  ),
                  child: Text(
                    QuestionController.repairText('بەردەوامبوون'),
                    style: TextStyle(fontFamily: fontFamily),
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _SquareButton extends StatelessWidget {
  const _SquareButton({required this.icon, required this.onTap});

  final IconData icon;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(10),
      child: Container(
        width: 30,
        height: 30,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(10),
          color: const Color(0xFFE9F2EE),
        ),
        child: Icon(icon, size: 18, color: const Color(0xFF0F6B53)),
      ),
    );
  }
}
