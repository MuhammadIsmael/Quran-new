import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:provider/provider.dart';
import 'package:runaki_islam/controller/question_controller.dart';
import 'package:runaki_islam/providers/settings_provider.dart';
import 'package:runaki_islam/util/background.dart';
import 'package:runaki_islam/util/constans.dart';

class Walamakan extends StatefulWidget {
  final String? sarder;

  const Walamakan({super.key, this.sarder});

  @override
  State<Walamakan> createState() => _WalamakanState();
}

class _WalamakanState extends State<Walamakan> {
  late final QuestionController _questionController;
  int? _fontType;

  String get _fontFamily => _fontType?.toString() ?? '0';
  String _t(String text) => QuestionController.repairText(text);

  @override
  void initState() {
    super.initState();
    _fontType = Provider.of<SettingsProvider>(
      context,
      listen: false,
    ).getsettingField('font_family');
    _questionController = _resolveController();
  }

  QuestionController _resolveController() {
    if (Get.isRegistered<QuestionController>()) {
      return Get.find<QuestionController>();
    }
    return Get.put(QuestionController());
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        backgroundColor: bgColor,
        appBar: AppBar(
          centerTitle: true,
          title: Text(
            widget.sarder ?? _t('وەڵامەکان'),
            style: TextStyle(
              fontFamily: _fontFamily,
              color: titleTextColor,
              fontWeight: FontWeight.w700,
            ),
          ),
          backgroundColor: Colors.white,
          elevation: 0.5,
          leading: IconButton(
            icon: const Icon(Icons.arrow_back_ios_rounded),
            color: iconColor,
            onPressed: () => Navigator.pop(context),
          ),
        ),
        body: Stack(
          children: <Widget>[
            const CustomBackground(
              color: Colors.transparent,
              imageColor: Color(0x0A0F6B53),
            ),
            SafeArea(
              child: Obx(() {
                final List<QuizAnswerRecord> records =
                    _questionController.answerHistory;

                if (records.isEmpty) {
                  return Center(
                    child: Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 24),
                      child: Text(
                        _t('هێشتا هیچ مێژووی وەڵامێک نییە.'),
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          fontFamily: _fontFamily,
                          fontSize: 17,
                          color: descriptionTectColor,
                        ),
                      ),
                    ),
                  );
                }

                return ListView.separated(
                  padding: const EdgeInsets.fromLTRB(12, 12, 12, 20),
                  physics: const BouncingScrollPhysics(),
                  itemCount: records.length,
                  separatorBuilder: (BuildContext context, int index) =>
                      const SizedBox(height: 12),
                  itemBuilder: (BuildContext context, int index) {
                    return _AnswerCard(
                      record: records[index],
                      fontFamily: _fontFamily,
                    );
                  },
                );
              }),
            ),
          ],
        ),
      ),
    );
  }
}

class _AnswerCard extends StatelessWidget {
  const _AnswerCard({required this.record, required this.fontFamily});

  final QuizAnswerRecord record;
  final String fontFamily;

  String _t(String text) => QuestionController.repairText(text);

  @override
  Widget build(BuildContext context) {
    final List<String> options = record.question.options ?? const <String>[];

    Color statusColor;
    String statusText;
    IconData statusIcon;

    if (record.isCorrect) {
      statusColor = const Color(0xFF2F9C58);
      statusText = _t('ڕاست');
      statusIcon = Icons.check_circle_rounded;
    } else if (record.isSkipped) {
      statusColor = const Color(0xFF1B9AAA);
      statusText = record.timedOut ? _t('کات تەواو بوو') : _t('بازدراو');
      statusIcon = Icons.timer_off_rounded;
    } else {
      statusColor = const Color(0xFFD94A4A);
      statusText = _t('هەڵە');
      statusIcon = Icons.cancel_rounded;
    }

    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Colors.white.withValues(alpha: 0.93),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: statusColor.withValues(alpha: 0.25)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Row(
            children: <Widget>[
              Container(
                width: 30,
                height: 30,
                alignment: Alignment.center,
                decoration: BoxDecoration(
                  color: statusColor.withValues(alpha: 0.16),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Text(
                  '${record.questionNumber}',
                  style: TextStyle(
                    fontFamily: 'english',
                    color: statusColor,
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: Text(
                  '${_t('پرسیار')} ${record.questionNumber}',
                  style: TextStyle(
                    fontFamily: fontFamily,
                    color: captionTextColor,
                    fontWeight: FontWeight.w700,
                    fontSize: 15,
                  ),
                ),
              ),
              Container(
                padding: const EdgeInsets.symmetric(
                  horizontal: 10,
                  vertical: 6,
                ),
                decoration: BoxDecoration(
                  color: statusColor.withValues(alpha: 0.14),
                  borderRadius: BorderRadius.circular(14),
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: <Widget>[
                    Icon(statusIcon, size: 14, color: statusColor),
                    const SizedBox(width: 4),
                    Text(
                      statusText,
                      style: TextStyle(
                        fontFamily: fontFamily,
                        fontSize: 12,
                        fontWeight: FontWeight.w700,
                        color: statusColor,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          Text(
            record.question.question ?? '',
            textDirection: TextDirection.rtl,
            style: TextStyle(
              fontFamily: fontFamily,
              fontSize: 17,
              fontWeight: FontWeight.w700,
              color: captionTextColor,
              height: 1.5,
            ),
          ),
          const SizedBox(height: 12),
          ...List<Widget>.generate(
            options.length,
            (int index) => Padding(
              padding: const EdgeInsets.only(bottom: 8),
              child: _ReviewOptionRow(
                label: options[index],
                fontFamily: fontFamily,
                isCorrect: index == record.correctIndex,
                isSelected: index == record.selectedIndex,
                isWrongSelected:
                    index == record.selectedIndex && !record.isCorrect,
              ),
            ),
          ),
          if (record.isSkipped)
            Padding(
              padding: const EdgeInsets.only(top: 4),
              child: Text(
                record.timedOut
                    ? _t('پێش تەواوبوونی کات هیچ وەڵامێک هەڵنەبژێردرا.')
                    : _t('پرسیارەکە بە دەستی خۆت بازدرا.'),
                style: TextStyle(
                  fontFamily: fontFamily,
                  fontSize: 12,
                  color: const Color(0xFF58736A),
                ),
              ),
            ),
          if ((record.question.explanation ?? '').trim().isNotEmpty)
            Container(
              width: double.infinity,
              margin: const EdgeInsets.only(top: 10),
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: const Color(0xFFF7FAF9),
                borderRadius: BorderRadius.circular(14),
                border: Border.all(color: const Color(0xFFD6E3DE)),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  Text(
                    '\u0695\u0648\u0648\u0646\u06a9\u0631\u062f\u0646\u06d5\u0648\u06d5',
                    style: TextStyle(
                      fontFamily: fontFamily,
                      fontSize: 13,
                      fontWeight: FontWeight.w700,
                      color: captionTextColor,
                    ),
                  ),
                  const SizedBox(height: 6),
                  Text(
                    record.question.explanation!,
                    textDirection: TextDirection.rtl,
                    style: TextStyle(
                      fontFamily: fontFamily,
                      fontSize: 13,
                      height: 1.6,
                      color: const Color(0xFF58736A),
                    ),
                  ),
                ],
              ),
            ),
        ],
      ),
    );
  }
}

class _ReviewOptionRow extends StatelessWidget {
  const _ReviewOptionRow({
    required this.label,
    required this.fontFamily,
    required this.isCorrect,
    required this.isSelected,
    required this.isWrongSelected,
  });

  final String label;
  final String fontFamily;
  final bool isCorrect;
  final bool isSelected;
  final bool isWrongSelected;

  @override
  Widget build(BuildContext context) {
    Color borderColor = const Color(0xFFD4E0DB);
    Color tileColor = Colors.white;
    Color iconColor = const Color(0xFF66837A);
    IconData icon = Icons.circle_outlined;

    if (isCorrect) {
      borderColor = const Color(0xFF2F9C58);
      tileColor = const Color(0xFFEEF8F1);
      iconColor = const Color(0xFF2F9C58);
      icon = Icons.check_circle_rounded;
    } else if (isWrongSelected) {
      borderColor = const Color(0xFFD94A4A);
      tileColor = const Color(0xFFFFF1F1);
      iconColor = const Color(0xFFD94A4A);
      icon = Icons.cancel_rounded;
    } else if (isSelected) {
      borderColor = const Color(0xFF1B9AAA);
      tileColor = const Color(0xFFEFF9FB);
      iconColor = const Color(0xFF1B9AAA);
      icon = Icons.radio_button_checked_rounded;
    }

    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 10),
      decoration: BoxDecoration(
        color: tileColor,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: borderColor),
      ),
      child: Row(
        children: <Widget>[
          Icon(icon, size: 18, color: iconColor),
          const SizedBox(width: 8),
          Expanded(
            child: Text(
              label,
              textDirection: TextDirection.rtl,
              style: TextStyle(
                fontFamily: fontFamily,
                color: captionTextColor,
                fontSize: 14,
                fontWeight: FontWeight.w600,
              ),
            ),
          ),
        ],
      ),
    );
  }
}
