import 'dart:convert';
import 'dart:ui';
import 'package:background_app_bar/background_app_bar.dart';
import 'package:clipboard/clipboard.dart';
import 'package:flutter/material.dart';
import 'package:share_plus/share_plus.dart';
import 'package:get/get.dart';
import 'package:runaki_islam/models/wtaw_amozhgare.dart';
import 'package:runaki_islam/providers/sections_provider.dart';
import 'package:runaki_islam/util/background.dart';
import 'package:runaki_islam/util/constans.dart';
import 'package:loading_indicator/loading_indicator.dart';
import 'package:runaki_islam/providers/settings_provider.dart';
import 'package:provider/provider.dart';

class WtawAmozhgare extends StatefulWidget {
  const WtawAmozhgare({super.key, this.sarder});
  final String? sarder;

  @override
  State<StatefulWidget> createState() => _WtawAmozhgareState();
}

class _WtawAmozhgareState extends State<WtawAmozhgare> {
  final List<WtawAmozhgareModel> _list = [];
  var loading = false;
  Future<String> loadNoteAsset() async {
    return Provider.of<SectionsProvider>(
      context,
      listen: false,
    ).loadLegacyJsonAsset('assets/data/content/wtaw_amozhgary.json');
  }

  int? fontType;

  Future fetchData() async {
    setState(() {
      loading = true;
    });
    _list.clear();

    String response = await loadNoteAsset();

    final data = jsonDecode(response);
    setState(() {
      for (Map<String, dynamic> i in data) {
        _list.add(WtawAmozhgareModel.formJson(i));
        loading = false;
      }
    });
  }

  @override
  void initState() {
    super.initState();
    fontType = Provider.of<SettingsProvider>(
      context,
      listen: false,
    ).getsettingField('font_family');
    fetchData();
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        backgroundColor: bgColor,
        body: NestedScrollView(
          physics: const BouncingScrollPhysics(),
          headerSliverBuilder: (_, _) => <Widget>[
            SliverAppBar(
              leading: IconButton(
                icon: Icon(Icons.arrow_back_ios_rounded, color: iconColor),
                onPressed: () {
                  Navigator.pop(context);
                },
              ),
              expandedHeight: 200,
              floating: false,
              pinned: true,
              snap: false,
              elevation: 0.0,
              backgroundColor: Colors.transparent,
              flexibleSpace: BackgroundFlexibleSpaceBar(
                collapseMode: CollapseMode.parallax,
                centerTitle: true,
                title: Text(
                  widget.sarder!,
                  style: bigTextStyle.copyWith(
                    fontFamily: fontType.toString(),
                    color: Colors.white,
                  ),
                ),
                titlePadding: const EdgeInsets.all(50),
                background: ClipRect(
                  child: Container(
                    decoration: const BoxDecoration(
                      image: DecorationImage(
                        image: AssetImage("assets/images/read-quran.jpg"),
                        fit: BoxFit.fill,
                      ),
                    ),
                    child: BackdropFilter(
                      filter: ImageFilter.blur(sigmaX: 5.0, sigmaY: 5.0),
                      child: Container(
                        decoration: BoxDecoration(
                          color: thirdColor.withValues(alpha: 0.5),
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ],
          body: loading
              ? Center(
                  child: Padding(
                    padding: const EdgeInsets.all(120.0),
                    child: LoadingIndicator(
                      indicatorType: Indicator.ballSpinFadeLoader,
                      colors: [thirdColor],
                    ),
                  ),
                )
              : Stack(
                  children: [
                    const Background(),
                    Column(
                      children: [
                        Expanded(
                          child: Padding(
                            padding: const EdgeInsets.only(top: 20),
                            child: ListView.builder(
                              physics: const BouncingScrollPhysics(),
                              scrollDirection: Axis.vertical,
                              itemCount: _list.length,
                              itemBuilder: (context, i) {
                                final a = _list[i];

                                return Column(
                                  children: [
                                    ExpansionTile(
                                      collapsedIconColor: kActiveIconColor
                                          .withValues(alpha: 0.8),
                                      iconColor: iconColor,
                                      collapsedBackgroundColor: backgroundColor,
                                      backgroundColor: kActiveIconColor
                                          .withValues(alpha: 0.6),
                                      title: Text(
                                        a.text!,
                                        textAlign: TextAlign.center,
                                        style: TextStyle(
                                          fontFamily: fontType.toString(),
                                          color: titleTextColor,
                                        ),
                                      ),
                                      children: [
                                        const Divider(),
                                        Row(
                                          mainAxisAlignment:
                                              MainAxisAlignment.spaceEvenly,
                                          children: [
                                            IconButton(
                                              onPressed: () {
                                                snackBarUi("كۆپی بوو");
                                                FlutterClipboard.copy(
                                                  "${a.text} \n\n\n\n\nhttps://play.google.com/store/apps/details?id=com.amin.runakeislam",
                                                );
                                              },
                                              icon: Icon(
                                                Icons.copy,
                                                color: iconColor,
                                              ),
                                            ),
                                            IconButton(
                                              onPressed: () {
                                                SharePlus.instance.share(
                                                  ShareParams(
                                                    text:
                                                        "${a.text} \n\n\n\n\nhttps://play.google.com/store/apps/details?id=com.amin.runakeislam",
                                                    subject:
                                                        "${widget.sarder} \n \n ",
                                                  ),
                                                );
                                              },
                                              icon: Icon(
                                                Icons.share,
                                                color: iconColor,
                                              ),
                                            ),
                                          ],
                                        ),
                                      ],
                                    ),
                                    const Divider(color: Colors.transparent),
                                  ],
                                );
                              },
                            ),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
        ),
      ),
    );
  }

  void snackBarUi(String description) {
    Get.snackbar(
      '',
      '',
      boxShadows: [BoxShadow(blurRadius: 20, color: thirdColor)],
      icon: Icon(Icons.done, color: kActiveIconColor),
      duration: const Duration(milliseconds: 1000),
      overlayBlur: 4,
      shouldIconPulse: true,
      snackPosition: SnackPosition.BOTTOM,
      snackStyle: SnackStyle.FLOATING,
      titleText: Text(
        description,
        textAlign: TextAlign.right,
        textDirection: TextDirection.rtl,
        style: TextStyle(
          fontFamily: fontType.toString(),
          fontSize: 16,
          color: kTextColor,
        ),
      ),
      margin: const EdgeInsets.only(bottom: 25, left: 15, right: 15),
      padding: const EdgeInsets.only(bottom: 16, left: 16, right: 16, top: 16),
      borderRadius: 6,
      backgroundColor: bgColor,
    );
  }
}
