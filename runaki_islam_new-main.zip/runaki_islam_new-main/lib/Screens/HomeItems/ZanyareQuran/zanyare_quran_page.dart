import 'dart:convert';
import 'package:flutter/cupertino.dart';
import 'package:runaki_islam/Screens/HomeItems/Pexambarman/page_view.dart';
import 'package:flutter/material.dart';
import 'package:runaki_islam/util/background.dart';
import 'package:runaki_islam/util/constans.dart';
import 'package:runaki_islam/models/tawanakan_model.dart';
import 'package:loading_indicator/loading_indicator.dart';
import 'package:page_transition/page_transition.dart';
import 'package:runaki_islam/providers/sections_provider.dart';
import 'package:runaki_islam/providers/settings_provider.dart';
import 'package:provider/provider.dart';

class ZanyareQuranPage extends StatefulWidget {
  final String? sarder;

  const ZanyareQuranPage({super.key, this.sarder});
  @override
  State<StatefulWidget> createState() => _ZanyareQuranPageState();
}

class _ZanyareQuranPageState extends State<ZanyareQuranPage>
    with SingleTickerProviderStateMixin {
  final List<TawanakanData> _list = [];
  final List<TawanakanData> _search = [];
  var loading = false;
  var pressed = true;
  AnimationController? controller;
  Future<String> loadNoteAsset() async {
    return Provider.of<SectionsProvider>(
      context,
      listen: false,
    ).loadLegacyJsonAsset('assets/data/content/zanyare_quran.json');
  }

  int? fontType;

  Future fetchData() async {
    setState(() {
      loading = true;
    });
    _list.clear();

    String response = await loadNoteAsset();

    final data = jsonDecode(response);
    setState(() {
      for (Map<String, dynamic> i in data) {
        _list.add(TawanakanData.formJson(i));
        loading = false;
      }
    });
  } //second way

  TextEditingController textController = TextEditingController();

  Future<void> onSearch(String text) async {
    _search.clear();
    if (text.isEmpty) {
      setState(() {});
      return;
    }

    for (var f in _list) {
      if (f.title!.contains(text)) _search.add(f);
    }

    setState(() {});
  }

  @override
  void initState() {
    super.initState();
    fontType = Provider.of<SettingsProvider>(
      context,
      listen: false,
    ).getsettingField('font_family');
    controller = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 400),
      reverseDuration: const Duration(milliseconds: 400),
    );
    fetchData();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bgColor,
      appBar: AppBar(
        actions: [
          IconButton(
            icon: Icon(
              pressed ? CupertinoIcons.search : CupertinoIcons.clear,
              color: iconColor,
            ),
            onPressed: () {
              if (pressed == false) {
                setState(() {
                  pressed = true;
                });
              } else {
                if (pressed == true) {
                  setState(() {
                    pressed = false;
                  });
                }
              }
            },
          ),
        ],
        toolbarHeight: 80,
        backgroundColor: thirdColor,
        title: Text(
          "${widget.sarder}",
          style: simpleTextStyle.copyWith(fontFamily: fontType.toString()),
        ),
        shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(bottom: Radius.circular(20)),
        ),
        centerTitle: true,
        elevation: 0,
        leading: IconButton(
          color: iconColor,
          onPressed: () => Navigator.pop(context),
          icon: const Icon(Icons.arrow_back_ios_rounded),
        ),
      ),
      body: loading
          ? Center(
              child: Padding(
                padding: const EdgeInsets.all(120.0),
                child: LoadingIndicator(
                  indicatorType: Indicator.ballSpinFadeLoader,
                  colors: [thirdColor],
                ),
              ),
            )
          : Stack(
              children: [
                const Background(),
                Column(
                  children: [
                    if (pressed != true)
                      Padding(
                        padding: const EdgeInsets.only(top: 15),
                        child: Container(
                          margin: const EdgeInsets.only(left: 15, right: 15),
                          width: double.infinity,
                          padding: const EdgeInsets.only(left: 8, right: 8),
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(8),
                            color: backgroundColor,
                          ),
                          child: TextField(
                            controller: textController,
                            onChanged: onSearch,
                            keyboardType: TextInputType.text,
                            maxLines: 1,
                            scrollPhysics: const BouncingScrollPhysics(),
                            textAlign: TextAlign.right,
                            cursorColor: kActiveIconColor,
                            textDirection: TextDirection.rtl,
                            decoration: InputDecoration(
                              border: InputBorder.none,
                              hintText: "گەڕان",
                              hintStyle: TextStyle(
                                fontFamily: fontType.toString(),
                                color: const Color(0xff9e9e9e),
                              ),
                              icon: Icon(Icons.search, color: iconColor),
                            ),
                          ),
                        ),
                      ),
                    Expanded(
                      child: Padding(
                        padding: const EdgeInsets.only(
                          top: 20,
                          right: 10,
                          left: 10,
                          bottom: 40,
                        ),
                        child:
                            _search.isNotEmpty || textController.text.isNotEmpty
                            ? ListView.builder(
                                physics: const BouncingScrollPhysics(),
                                scrollDirection: Axis.vertical,
                                itemCount: _search.length,
                                itemBuilder: (context, i) {
                                  final b = _search[i];
                                  return homePageCardsGroup(
                                    kActiveIconColor,
                                    "assets/icons/prophet-name.png",
                                    '${b.title}',
                                    () {
                                      getItemNavigate(
                                        b.title!,
                                        b.desc!,
                                        context,
                                      );
                                    },
                                    "${i + 1}",
                                  );
                                },
                              )
                            : ListView.builder(
                                physics: const BouncingScrollPhysics(),
                                scrollDirection: Axis.vertical,
                                itemCount: _list.length,
                                itemBuilder: (context, i) {
                                  final a = _list[i];
                                  return homePageCardsGroup(
                                    kActiveIconColor,
                                    "assets/icons/prophet-name.png",
                                    a.title!,
                                    () {
                                      getItemNavigate(
                                        a.title!,
                                        a.desc!,
                                        context,
                                      );
                                    },
                                    "${i + 1}",
                                  );
                                },
                              ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
    );
  }

  Widget homePageCardsGroup(
    Color color,
    String icon,
    String title,
    VoidCallback onTap,
    String count,
  ) {
    double w = MediaQuery.of(context).size.width;
    return Padding(
      padding: EdgeInsets.only(bottom: w / 17),
      child: homePageCard(color, icon, title, onTap, count),
    );
  }

  Widget homePageCard(
    Color color,
    String icon,
    String title,
    VoidCallback onTap,
    String count,
  ) {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        splashColor: kActiveIconColor,
        customBorder: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(25),
        ),
        onTap: onTap,
        child: Stack(
          children: [
            Container(
              padding: const EdgeInsets.all(15),
              width: double.infinity,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(25),
                color: backgroundColor.withValues(alpha: 0.8),
                boxShadow: [
                  BoxShadow(
                    color: const Color(0xFF282547).withValues(alpha: .15),
                    blurRadius: 20,
                  ),
                ],
              ),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  const SizedBox(),
                  Text(
                    title,
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(
                      fontFamily: fontType.toString(),
                      fontSize: 16,
                      color: titleTextColor,
                      fontWeight: FontWeight.w700,
                    ),
                    textAlign: TextAlign.center,
                  ),
                  const SizedBox(),
                ],
              ),
            ),
            Container(
              padding: const EdgeInsets.symmetric(
                horizontal: 10.0,
                vertical: 5.0,
              ),
              decoration: const BoxDecoration(
                color: Color(0x83CEECE8),
                borderRadius: BorderRadius.only(
                  bottomRight: Radius.circular(10),
                  topLeft: Radius.circular(20),
                ),
              ),
              child: Text(
                count,
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: kActiveIconColor,
                  fontWeight: FontWeight.w700,
                  fontSize: 12,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  void getItemNavigate(String title, String desc, BuildContext context) {
    Navigator.push(
      context,
      PageTransition(
        child: TextPageView(title: title, sarder: "زانیاری قورئان", desc: desc),
        type: PageTransitionType.leftToRightWithFade,
      ),
    );
  }
}
