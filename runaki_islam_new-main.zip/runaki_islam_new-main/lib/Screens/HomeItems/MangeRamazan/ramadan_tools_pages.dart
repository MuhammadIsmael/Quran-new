import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:geolocator/geolocator.dart';
import 'package:hijri/hijri_calendar.dart';
import 'package:provider/provider.dart';
import 'package:runaki_islam/providers/settings_provider.dart';
import 'package:runaki_islam/services/prayer_db_service.dart';
import 'package:shared_preferences/shared_preferences.dart';

class RamadanTimetablePage extends StatefulWidget {
  const RamadanTimetablePage({super.key});

  @override
  State<RamadanTimetablePage> createState() => _RamadanTimetablePageState();
}

class _RamadanTimetablePageState extends State<RamadanTimetablePage> {
  final PrayerDbService _prayerDbService = PrayerDbService();

  DateTime _focusedMonth = DateTime(DateTime.now().year, DateTime.now().month);
  _ResolvedLocation? _location;
  List<_RamadanDayTiming> _days = const <_RamadanDayTiming>[];
  bool _loading = true;
  String? _errorMessage;

  @override
  void initState() {
    super.initState();
    HijriCalendar.setLocal('ar');
    _loadTimetable(requestLocation: true);
  }

  @override
  void dispose() {
    _prayerDbService.close();
    super.dispose();
  }

  Future<void> _loadTimetable({bool requestLocation = false}) async {
    setState(() {
      _loading = true;
      _errorMessage = null;
    });

    try {
      if (_location == null || requestLocation) {
        _location = await _resolveLocation();
      }

      final activeLocation = _location!;
      final days = await _fetchCalendar(
        city: activeLocation.city,
        month: _focusedMonth.month,
        year: _focusedMonth.year,
      );
      if (days.isEmpty) {
        throw Exception('No local Ramadan timetable rows');
      }

      if (!mounted) return;
      setState(() {
        _days = days;
        _loading = false;
      });
    } catch (_) {
      if (!mounted) return;
      setState(() {
        _errorMessage =
            'نەتوانرا خشتەی ئیفطار و سحوور لە داتابەی ناوخۆ بخوێندرێتەوە.';
        _loading = false;
      });
    }
  }

  Future<_ResolvedLocation> _resolveLocation() async {
    final fallbackCity = await _prayerDbService.resolveCurrentCity();
    final fallback = _ResolvedLocation(
      city: fallbackCity,
      label: fallbackCity.displayName,
      usedFallback: true,
    );

    try {
      final shouldAutoResolve = await _prayerDbService
          .shouldAutoResolveLocation();
      if (!shouldAutoResolve) {
        return fallback;
      }

      final serviceEnabled = await Geolocator.isLocationServiceEnabled();
      if (!serviceEnabled) return fallback;

      var permission = await Geolocator.checkPermission();
      if (permission == LocationPermission.denied) {
        permission = await Geolocator.requestPermission();
      }

      if (permission == LocationPermission.denied ||
          permission == LocationPermission.deniedForever) {
        return fallback;
      }

      final position = await Geolocator.getCurrentPosition(
        desiredAccuracy: LocationAccuracy.medium,
        timeLimit: const Duration(seconds: 12),
      );
      final nearest = await _prayerDbService.findNearestCity(
        latitude: position.latitude,
        longitude: position.longitude,
      );
      if (nearest == null) {
        return fallback;
      }

      await _prayerDbService.markLocationSelectionAutomatic();
      await _prayerDbService.saveSelectedCity(nearest.id);

      return _ResolvedLocation(
        city: nearest,
        label: nearest.displayName,
        usedFallback: false,
      );
    } catch (_) {
      return fallback;
    }
  }

  Future<List<_RamadanDayTiming>> _fetchCalendar({
    required PrayerCity city,
    required int month,
    required int year,
  }) async {
    final rows = await _prayerDbService.loadMonthMoments(
      city: city,
      month: month,
      year: year,
    );

    final result = <_RamadanDayTiming>[];
    for (final row in rows) {
      final suhoorEnd = _normalizeTimeValue(row.fajr?.timeLabel ?? '');
      final iftar = _normalizeTimeValue(row.maghrib?.timeLabel ?? '');
      final suhoorTime = _parseTime(suhoorEnd);
      final iftarTime = _parseTime(iftar);
      if (suhoorTime == null || iftarTime == null) continue;

      result.add(
        _RamadanDayTiming(
          date: row.date,
          hijriLabel: _hijriLabel(row.date),
          suhoorEnd: suhoorEnd,
          iftar: iftar,
          fastingDuration: _calculateFastingDuration(suhoorTime, iftarTime),
        ),
      );
    }

    return result;
  }

  String _hijriLabel(DateTime date) {
    final hijri = HijriCalendar.fromDate(date);
    return '${hijri.hDay} ${hijri.getLongMonthName()}'.trim();
  }

  String _normalizeTimeValue(String raw) {
    final firstPart = raw.split(' ').first.trim();
    final pieces = firstPart.split(':');
    if (pieces.length < 2) return '--:--';
    final hour = pieces[0].padLeft(2, '0');
    final minute = pieces[1].padLeft(2, '0');
    return '$hour:$minute';
  }

  TimeOfDay? _parseTime(String value) {
    final pieces = value.split(':');
    if (pieces.length < 2) return null;
    final hour = int.tryParse(pieces[0]);
    final minute = int.tryParse(pieces[1]);
    if (hour == null || minute == null) return null;
    return TimeOfDay(hour: hour, minute: minute);
  }

  Duration _calculateFastingDuration(TimeOfDay suhoorEnd, TimeOfDay iftar) {
    final startMinutes = (suhoorEnd.hour * 60) + suhoorEnd.minute;
    final endMinutes = (iftar.hour * 60) + iftar.minute;
    var diffMinutes = endMinutes - startMinutes;
    if (diffMinutes < 0) diffMinutes += 24 * 60;
    return Duration(minutes: diffMinutes);
  }

  void _changeMonth(int offset) {
    final next = DateTime(_focusedMonth.year, _focusedMonth.month + offset);
    setState(() {
      _focusedMonth = DateTime(next.year, next.month);
    });
    _loadTimetable();
  }

  String _monthTitle(DateTime date) {
    const months = <String>[
      'کانونی دووەم',
      'شوبات',
      'ئازار',
      'نیسان',
      'ئایار',
      'حوزەیران',
      'تەمووز',
      'ئاب',
      'ئەیلوول',
      'تشرینی یەکەم',
      'تشرینی دووەم',
      'کانونی یەکەم',
    ];
    return '${months[date.month - 1]} ${date.year}';
  }

  String _formatDuration(Duration duration) {
    final hours = duration.inHours;
    final minutes = duration.inMinutes.remainder(60);
    return '$hours کاتژمێر و $minutes خولەک';
  }

  String _formatDate(DateTime date) {
    final day = date.day.toString().padLeft(2, '0');
    final month = date.month.toString().padLeft(2, '0');
    return '$day/$month/${date.year}';
  }

  bool _isSameDate(DateTime a, DateTime b) {
    return a.year == b.year && a.month == b.month && a.day == b.day;
  }

  _RamadanDayTiming? _todayTiming() {
    final today = DateTime.now();
    for (final day in _days) {
      if (_isSameDate(day.date, today)) {
        return day;
      }
    }
    return null;
  }

  @override
  Widget build(BuildContext context) {
    final fontType = Provider.of<SettingsProvider>(
      context,
      listen: false,
    ).getsettingField('font_family');
    final fontFamily = fontType.toString();
    final todayTiming = _todayTiming();

    return _RamadanSceneScaffold(
      title: 'کاتی ئیفطار و سحوور',
      fontFamily: fontFamily,
      actions: <Widget>[
        _RamadanToolbarAction(
          icon: Icons.my_location_rounded,
          tooltip: 'نوێکردنەوەی شوێن',
          onTap: () => _loadTimetable(requestLocation: true),
        ),
      ],
      body: Directionality(
        textDirection: TextDirection.rtl,
        child: RefreshIndicator(
          color: _RamadanPalette.twilight,
          onRefresh: () => _loadTimetable(),
          child: ListView(
            physics: const AlwaysScrollableScrollPhysics(
              parent: BouncingScrollPhysics(),
            ),
            padding: const EdgeInsets.fromLTRB(16, 12, 16, 28),
            children: <Widget>[
              _RamadanReveal(index: 0, child: _buildTimetableHero(fontFamily)),
              const SizedBox(height: 14),
              AnimatedSwitcher(
                duration: const Duration(milliseconds: 480),
                switchInCurve: Curves.easeOutCubic,
                switchOutCurve: Curves.easeInCubic,
                transitionBuilder: _ramadanSwitcherTransition,
                child: _buildTimetableState(
                  fontFamily: fontFamily,
                  todayTiming: todayTiming,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildTimetableHero(String fontFamily) {
    return _RamadanPanel(
      padding: const EdgeInsets.all(18),
      borderColor: const Color(0x40F6E0B5),
      gradient: const <Color>[
        Color(0xFF18354A),
        Color(0xFF2C6B76),
        Color(0xFFC69149),
      ],
      child: Stack(
        children: <Widget>[
          Positioned(
            top: -10,
            left: -6,
            child: Icon(
              Icons.nightlight_round,
              size: 92,
              color: Colors.white.withValues(alpha: 0.12),
            ),
          ),
          Positioned(
            bottom: -32,
            right: -18,
            child: Container(
              width: 128,
              height: 128,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: Colors.white.withValues(alpha: 0.08),
              ),
            ),
          ),
          Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: <Widget>[
              Row(
                children: <Widget>[
                  _RamadanToolbarAction(
                    icon: Icons.chevron_right_rounded,
                    onTap: () => _changeMonth(-1),
                    foregroundColor: Colors.white,
                    backgroundColor: Colors.white.withValues(alpha: 0.12),
                    borderColor: Colors.white.withValues(alpha: 0.18),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Column(
                      children: <Widget>[
                        Text(
                          'ڕێکخستنی مانگی ڕەمەزان',
                          textAlign: TextAlign.center,
                          style: TextStyle(
                            fontFamily: fontFamily,
                            color: Colors.white.withValues(alpha: 0.82),
                            fontWeight: FontWeight.w700,
                            fontSize: 12.8,
                          ),
                        ),
                        const SizedBox(height: 6),
                        Text(
                          _monthTitle(_focusedMonth),
                          textAlign: TextAlign.center,
                          style: TextStyle(
                            fontFamily: fontFamily,
                            color: Colors.white,
                            fontWeight: FontWeight.w900,
                            fontSize: 22,
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(width: 10),
                  _RamadanToolbarAction(
                    icon: Icons.chevron_left_rounded,
                    onTap: () => _changeMonth(1),
                    foregroundColor: Colors.white,
                    backgroundColor: Colors.white.withValues(alpha: 0.12),
                    borderColor: Colors.white.withValues(alpha: 0.18),
                  ),
                ],
              ),
              const SizedBox(height: 18),
              Wrap(
                alignment: WrapAlignment.start,
                spacing: 10,
                runSpacing: 10,
                children: <Widget>[
                  _RamadanInfoPill(
                    icon: Icons.location_on_rounded,
                    label: _location?.label ?? 'شوێن: چاوەڕوانی...',
                    foreground: Colors.white,
                    background: Colors.white.withValues(alpha: 0.12),
                    borderColor: Colors.white.withValues(alpha: 0.18),
                    fontFamily: fontFamily,
                  ),
                  _RamadanInfoPill(
                    icon: Icons.calendar_month_rounded,
                    label: '${_days.length} ڕۆژ',
                    foreground: const Color(0xFF143047),
                    background: const Color(0xFFF8E6BF),
                    borderColor: const Color(0x44FFF5DD),
                    fontFamily: fontFamily,
                  ),
                ],
              ),
              if (_location?.usedFallback == true) ...<Widget>[
                const SizedBox(height: 12),
                Text(
                  'GPS بەردەست نەبوو، داتای ناوخۆی هەڵبژێردراو بەکارهاتووە.',
                  textAlign: TextAlign.right,
                  style: TextStyle(
                    fontFamily: fontFamily,
                    color: Colors.white.withValues(alpha: 0.80),
                    fontWeight: FontWeight.w700,
                    fontSize: 12.6,
                    height: 1.35,
                  ),
                ),
              ],
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildTimetableState({
    required String fontFamily,
    required _RamadanDayTiming? todayTiming,
  }) {
    if (_loading) {
      return _RamadanPanel(
        key: const ValueKey<String>('ramadan-loading'),
        padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 32),
        child: Column(
          children: <Widget>[
            const SizedBox(
              width: 34,
              height: 34,
              child: CircularProgressIndicator(strokeWidth: 3.2),
            ),
            const SizedBox(height: 16),
            Text(
              'خشتەی مانگ لە داتابەی ناوخۆ دێنین...',
              textAlign: TextAlign.center,
              style: TextStyle(
                fontFamily: fontFamily,
                color: _RamadanPalette.muted,
                fontWeight: FontWeight.w700,
              ),
            ),
          ],
        ),
      );
    }

    if (_errorMessage != null) {
      return _RamadanPanel(
        key: const ValueKey<String>('ramadan-error'),
        borderColor: const Color(0x33B85D56),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: <Widget>[
            Text(
              _errorMessage!,
              textAlign: TextAlign.right,
              style: TextStyle(
                fontFamily: fontFamily,
                color: const Color(0xFF8C3D3D),
                fontWeight: FontWeight.w800,
                height: 1.4,
              ),
            ),
            const SizedBox(height: 14),
            _RamadanActionButton(
              icon: Icons.refresh_rounded,
              label: 'دووبارە هەوڵبدەوە',
              fontFamily: fontFamily,
              onTap: () => _loadTimetable(requestLocation: true),
              backgroundColor: const Color(0xFFB65E5A),
              foregroundColor: Colors.white,
            ),
          ],
        ),
      );
    }

    return KeyedSubtree(
      key: ValueKey<String>(
        'ramadan-${_focusedMonth.year}-${_focusedMonth.month}-${_location?.city.id ?? 0}',
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: <Widget>[
          if (todayTiming != null) ...<Widget>[
            _RamadanReveal(
              index: 1,
              child: _buildTodaySpotlight(
                fontFamily: fontFamily,
                todayTiming: todayTiming,
              ),
            ),
            const SizedBox(height: 14),
          ],
          _RamadanReveal(
            index: 2,
            child: _RamadanSectionHeader(
              title: 'ڕۆژەکانی مانگ',
              subtitle: 'خشتەی تەواوی ئیفطار و سحوور',
              badge: '${_days.length} ڕۆژ',
              fontFamily: fontFamily,
            ),
          ),
          const SizedBox(height: 10),
          ...List<Widget>.generate(_days.length, (int index) {
            final day = _days[index];
            return Padding(
              padding: EdgeInsets.only(
                bottom: index == _days.length - 1 ? 0 : 10,
              ),
              child: _RamadanReveal(
                index: index + 3,
                child: _buildDayCard(fontFamily: fontFamily, day: day),
              ),
            );
          }),
        ],
      ),
    );
  }

  Widget _buildTodaySpotlight({
    required String fontFamily,
    required _RamadanDayTiming todayTiming,
  }) {
    return _RamadanPanel(
      padding: const EdgeInsets.all(18),
      borderColor: const Color(0x3CC48D3D),
      gradient: const <Color>[
        Color(0xFFFFF7E6),
        Color(0xFFF8E6C6),
        Color(0xFFF1F7FF),
      ],
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: <Widget>[
          Text(
            'ئەمڕۆ  •  ${_formatDate(todayTiming.date)}',
            textAlign: TextAlign.right,
            style: TextStyle(
              fontFamily: fontFamily,
              color: _RamadanPalette.ink,
              fontWeight: FontWeight.w900,
              fontSize: 18,
            ),
          ),
          const SizedBox(height: 4),
          Text(
            todayTiming.hijriLabel,
            textAlign: TextAlign.right,
            style: TextStyle(
              fontFamily: fontFamily,
              color: _RamadanPalette.muted,
              fontWeight: FontWeight.w700,
              fontSize: 12.8,
            ),
          ),
          const SizedBox(height: 16),
          LayoutBuilder(
            builder: (BuildContext context, BoxConstraints constraints) {
              const double spacing = 12;
              final double width = constraints.maxWidth;
              final int columns = width >= 980
                  ? 3
                  : width >= 620
                  ? 2
                  : 1;
              final double tileWidth =
                  (width - (spacing * (columns - 1))) / columns;

              return Wrap(
                alignment: WrapAlignment.start,
                spacing: spacing,
                runSpacing: spacing,
                children: <Widget>[
                  SizedBox(
                    width: tileWidth,
                    child: _RamadanMetricTile(
                      title: 'دوایین کاتی سحوور',
                      value: todayTiming.suhoorEnd,
                      subtitle: 'فجر',
                      icon: Icons.dark_mode_rounded,
                      accent: const Color(0xFF426FCD),
                      fontFamily: fontFamily,
                    ),
                  ),
                  SizedBox(
                    width: tileWidth,
                    child: _RamadanMetricTile(
                      title: 'کاتی ئیفطار',
                      value: todayTiming.iftar,
                      subtitle: 'مەغریب',
                      icon: Icons.wb_sunny_outlined,
                      accent: const Color(0xFF2E946D),
                      fontFamily: fontFamily,
                    ),
                  ),
                  SizedBox(
                    width: tileWidth,
                    child: _RamadanMetricTile(
                      title: 'ماوەی ڕۆژوو',
                      value: _formatDuration(todayTiming.fastingDuration),
                      subtitle: 'بەردەوامی',
                      icon: Icons.timelapse_rounded,
                      accent: const Color(0xFFB98532),
                      fontFamily: fontFamily,
                      useEnglishFont: false,
                    ),
                  ),
                ],
              );
            },
          ),
        ],
      ),
    );
  }

  Widget _buildDayCard({
    required String fontFamily,
    required _RamadanDayTiming day,
  }) {
    final bool isToday = _isSameDate(day.date, DateTime.now());
    final double progress = (day.fastingDuration.inMinutes / (18 * 60)).clamp(
      0.0,
      1.0,
    );

    return AnimatedContainer(
      duration: const Duration(milliseconds: 260),
      curve: Curves.easeOutCubic,
      decoration: BoxDecoration(
        gradient: isToday
            ? const LinearGradient(
                begin: Alignment.topRight,
                end: Alignment.bottomLeft,
                colors: <Color>[Color(0xFFF4FAFF), Color(0xFFFDF7EA)],
              )
            : null,
        color: isToday ? null : Colors.white.withValues(alpha: 0.94),
        borderRadius: BorderRadius.circular(24),
        border: Border.all(
          color: isToday ? const Color(0x556593D0) : const Color(0x14A17D43),
        ),
        boxShadow: const <BoxShadow>[
          BoxShadow(
            color: Color(0x12000000),
            blurRadius: 22,
            offset: Offset(0, 12),
          ),
        ],
      ),
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  Row(
                    children: <Widget>[
                      if (isToday)
                        Container(
                          padding: const EdgeInsets.symmetric(
                            horizontal: 10,
                            vertical: 5,
                          ),
                          decoration: BoxDecoration(
                            color: const Color(0xFF18354A),
                            borderRadius: BorderRadius.circular(999),
                          ),
                          child: Text(
                            'ئەمڕۆ',
                            style: TextStyle(
                              fontFamily: fontFamily,
                              color: Colors.white,
                              fontWeight: FontWeight.w800,
                              fontSize: 11.8,
                            ),
                          ),
                        ),
                      const Spacer(),
                      Flexible(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: <Widget>[
                            Text(
                              day.hijriLabel,
                              textAlign: TextAlign.right,
                              style: TextStyle(
                                fontFamily: fontFamily,
                                color: _RamadanPalette.ink,
                                fontWeight: FontWeight.w900,
                                fontSize: 15,
                              ),
                            ),
                            const SizedBox(height: 3),
                            Text(
                              _formatDate(day.date),
                              textAlign: TextAlign.right,
                              style: TextStyle(
                                fontFamily: 'english',
                                color: _RamadanPalette.muted,
                                fontWeight: FontWeight.w700,
                                fontSize: 12.6,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 12),
                  Wrap(
                    alignment: WrapAlignment.start,
                    spacing: 8,
                    runSpacing: 8,
                    children: <Widget>[
                      _RamadanMiniTag(
                        title: 'ئیفطار',
                        value: day.iftar,
                        accent: const Color(0xFF2D946C),
                        fontFamily: fontFamily,
                      ),
                      _RamadanMiniTag(
                        title: 'سحوور',
                        value: day.suhoorEnd,
                        accent: const Color(0xFF4A73D0),
                        fontFamily: fontFamily,
                      ),
                    ],
                  ),
                  const SizedBox(height: 12),
                  Text(
                    'ماوەی ڕۆژوو: ${_formatDuration(day.fastingDuration)}',
                    textAlign: TextAlign.right,
                    style: TextStyle(
                      fontFamily: fontFamily,
                      color: _RamadanPalette.muted,
                      fontWeight: FontWeight.w700,
                      fontSize: 12.7,
                    ),
                  ),
                  const SizedBox(height: 8),
                  ClipRRect(
                    borderRadius: BorderRadius.circular(999),
                    child: LinearProgressIndicator(
                      value: progress,
                      minHeight: 8,
                      backgroundColor: const Color(0x12000000),
                      valueColor: AlwaysStoppedAnimation<Color>(
                        isToday
                            ? const Color(0xFFB98532)
                            : const Color(0xFF5A82D4),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(width: 14),
            Container(
              width: 62,
              padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 6),
              decoration: BoxDecoration(
                gradient: isToday
                    ? const LinearGradient(
                        begin: Alignment.topCenter,
                        end: Alignment.bottomCenter,
                        colors: <Color>[Color(0xFF18354A), Color(0xFF2C6B76)],
                      )
                    : const LinearGradient(
                        begin: Alignment.topCenter,
                        end: Alignment.bottomCenter,
                        colors: <Color>[Color(0xFFF7F4EC), Color(0xFFECE6D7)],
                      ),
                borderRadius: BorderRadius.circular(18),
              ),
              child: Column(
                children: <Widget>[
                  Text(
                    day.date.day.toString().padLeft(2, '0'),
                    style: TextStyle(
                      fontFamily: 'english',
                      color: isToday ? Colors.white : _RamadanPalette.ink,
                      fontWeight: FontWeight.w900,
                      fontSize: 24,
                      height: 1,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    'ڕۆژ',
                    style: TextStyle(
                      fontFamily: fontFamily,
                      color: isToday
                          ? Colors.white.withValues(alpha: 0.84)
                          : _RamadanPalette.muted,
                      fontWeight: FontWeight.w700,
                      fontSize: 11.6,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class KhatmPlanPage extends StatefulWidget {
  const KhatmPlanPage({super.key});

  @override
  State<KhatmPlanPage> createState() => _KhatmPlanPageState();
}

class _KhatmPlanPageState extends State<KhatmPlanPage> {
  static const String _daysKey = 'ramadan_khatm_days';
  static const String _startDateKey = 'ramadan_khatm_start_ms';
  static const String _completedJuzKey = 'ramadan_khatm_completed_juz';

  int _planDays = 30;
  DateTime _startDate = DateTime.now();
  Set<int> _completedJuz = <int>{};
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _loadPlanState();
  }

  Future<void> _loadPlanState() async {
    final SharedPreferences prefs = await SharedPreferences.getInstance();
    final int savedDays = prefs.getInt(_daysKey) ?? 30;
    final int? savedStartMs = prefs.getInt(_startDateKey);
    final List<String> savedCompleted =
        prefs.getStringList(_completedJuzKey) ?? <String>[];

    final Set<int> parsedCompleted = <int>{};
    for (final String item in savedCompleted) {
      final int? value = int.tryParse(item);
      if (value != null && value >= 1 && value <= 30) {
        parsedCompleted.add(value);
      }
    }

    if (!mounted) return;
    setState(() {
      _planDays = savedDays.clamp(1, 30);
      _startDate = savedStartMs != null
          ? DateTime.fromMillisecondsSinceEpoch(savedStartMs)
          : DateTime.now();
      _completedJuz = parsedCompleted;
      _loading = false;
    });
  }

  Future<void> _savePlanState() async {
    final SharedPreferences prefs = await SharedPreferences.getInstance();
    await prefs.setInt(_daysKey, _planDays);
    await prefs.setInt(_startDateKey, _startDate.millisecondsSinceEpoch);
    await prefs.setStringList(
      _completedJuzKey,
      _completedJuz.map((int value) => value.toString()).toList(),
    );
  }

  List<_KhatmDayPlan> _buildPlans() {
    final List<_KhatmDayPlan> plans = <_KhatmDayPlan>[];
    final int basePerDay = 30 ~/ _planDays;
    final int extraDays = 30 % _planDays;
    int nextJuz = 1;

    for (int day = 1; day <= _planDays; day++) {
      final int count = basePerDay + (day <= extraDays ? 1 : 0);
      final int start = nextJuz;
      final int end = nextJuz + count - 1;
      final List<int> range = <int>[
        for (int juz = start; juz <= end && juz <= 30; juz++) juz,
      ];

      plans.add(
        _KhatmDayPlan(
          dayNumber: day,
          date: _startDate.add(Duration(days: day - 1)),
          juzRange: range,
        ),
      );
      nextJuz = end + 1;
    }
    return plans;
  }

  bool _isSameDate(DateTime a, DateTime b) {
    return a.year == b.year && a.month == b.month && a.day == b.day;
  }

  _KhatmDayPlan? _todayPlan(List<_KhatmDayPlan> plans) {
    final DateTime now = DateTime.now();
    for (final _KhatmDayPlan plan in plans) {
      if (_isSameDate(plan.date, now)) return plan;
    }
    return null;
  }

  String _formatDate(DateTime date) {
    final String day = date.day.toString().padLeft(2, '0');
    final String month = date.month.toString().padLeft(2, '0');
    return '$day/$month/${date.year}';
  }

  String _rangeText(List<int> range) {
    if (range.isEmpty) return '-';
    if (range.length == 1) return 'جزء ${range.first}';
    return 'جزء ${range.first} تا ${range.last}';
  }

  bool _isDayCompleted(_KhatmDayPlan plan) {
    if (plan.juzRange.isEmpty) return false;
    return plan.juzRange.every(_completedJuz.contains);
  }

  Future<void> _pickStartDate() async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: _startDate,
      firstDate: DateTime(2024),
      lastDate: DateTime(2100),
    );
    if (!mounted || picked == null) return;
    setState(() {
      _startDate = DateTime(picked.year, picked.month, picked.day);
    });
    _savePlanState();
  }

  void _toggleJuz(int juz, bool selected) {
    setState(() {
      if (selected) {
        _completedJuz.add(juz);
      } else {
        _completedJuz.remove(juz);
      }
    });
    _savePlanState();
  }

  void _markDayAsCompleted(_KhatmDayPlan plan) {
    setState(() {
      _completedJuz.addAll(plan.juzRange);
    });
    _savePlanState();
  }

  Future<void> _resetPlan() async {
    final bool? shouldReset = await showDialog<bool>(
      context: context,
      builder: (BuildContext dialogContext) {
        return AlertDialog(
          title: const Text('سڕینەوەی پلان'),
          content: const Text(
            'دڵنیایت کە دەتەوێت هەموو پێشکەوتنەکان بسڕیتەوە؟',
          ),
          actions: <Widget>[
            TextButton(
              onPressed: () => Navigator.pop(dialogContext, false),
              child: const Text('نەخێر'),
            ),
            FilledButton(
              onPressed: () => Navigator.pop(dialogContext, true),
              child: const Text('بەڵێ'),
            ),
          ],
        );
      },
    );

    if (shouldReset != true) return;
    setState(() {
      _planDays = 30;
      _startDate = DateTime.now();
      _completedJuz.clear();
    });
    _savePlanState();
  }

  @override
  Widget build(BuildContext context) {
    final fontType = Provider.of<SettingsProvider>(
      context,
      listen: false,
    ).getsettingField('font_family');
    final String fontFamily = fontType.toString();

    if (_loading) {
      return _RamadanSceneScaffold(
        title: 'پلانی خەتم',
        fontFamily: fontFamily,
        body: const Center(child: CircularProgressIndicator()),
      );
    }

    final List<_KhatmDayPlan> plans = _buildPlans();
    final _KhatmDayPlan? todayPlan = _todayPlan(plans);
    final double progress = (_completedJuz.length / 30).clamp(0.0, 1.0);
    final int completedDays = plans.where(_isDayCompleted).length;

    return _RamadanSceneScaffold(
      title: 'پلانی خەتم',
      fontFamily: fontFamily,
      actions: <Widget>[
        _RamadanToolbarAction(
          icon: Icons.restart_alt_rounded,
          tooltip: 'سڕینەوەی پلان',
          onTap: _resetPlan,
        ),
      ],
      body: Directionality(
        textDirection: TextDirection.rtl,
        child: ListView(
          physics: const BouncingScrollPhysics(),
          padding: const EdgeInsets.fromLTRB(16, 12, 16, 28),
          children: <Widget>[
            _RamadanReveal(
              index: 0,
              child: _buildKhatmHero(
                fontFamily: fontFamily,
                progress: progress,
                completedDays: completedDays,
              ),
            ),
            const SizedBox(height: 14),
            _RamadanReveal(index: 1, child: _buildKhatmControls(fontFamily)),
            const SizedBox(height: 14),
            _RamadanReveal(
              index: 2,
              child: _buildTodayMission(
                fontFamily: fontFamily,
                todayPlan: todayPlan,
              ),
            ),
            const SizedBox(height: 14),
            _RamadanReveal(
              index: 3,
              child: _RamadanSectionHeader(
                title: 'خشتەی ڕۆژانەی خەتم',
                subtitle: 'دابەشکردنی 30 جزء بەپێی ماوەی پلان',
                badge: '$completedDays / $_planDays',
                fontFamily: fontFamily,
              ),
            ),
            const SizedBox(height: 10),
            ...List<Widget>.generate(plans.length, (int index) {
              final _KhatmDayPlan plan = plans[index];
              return Padding(
                padding: EdgeInsets.only(
                  bottom: index == plans.length - 1 ? 0 : 10,
                ),
                child: _RamadanReveal(
                  index: index + 4,
                  child: _buildPlanDayCard(
                    fontFamily: fontFamily,
                    plan: plan,
                    isDone: _isDayCompleted(plan),
                  ),
                ),
              );
            }),
            const SizedBox(height: 14),
            _RamadanReveal(
              index: plans.length + 4,
              child: _RamadanSectionHeader(
                title: 'چێکلیستی 30 جزء',
                subtitle: 'هەر جزءێک کە تەواودەکەیت، نیشانی بکە',
                badge: '${_completedJuz.length} / 30',
                fontFamily: fontFamily,
              ),
            ),
            const SizedBox(height: 10),
            _RamadanReveal(
              index: plans.length + 5,
              child: _buildJuzBoard(fontFamily),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildKhatmHero({
    required String fontFamily,
    required double progress,
    required int completedDays,
  }) {
    return _RamadanPanel(
      padding: const EdgeInsets.all(18),
      borderColor: const Color(0x44E3C38B),
      gradient: const <Color>[
        Color(0xFF162C3A),
        Color(0xFF315B57),
        Color(0xFFB98532),
      ],
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Text(
                  'خەتمی قورئان بە هەنگاوە دیاریکراو',
                  textAlign: TextAlign.right,
                  style: TextStyle(
                    fontFamily: fontFamily,
                    color: Colors.white,
                    fontWeight: FontWeight.w900,
                    fontSize: 19,
                    height: 1.25,
                  ),
                ),
                const SizedBox(height: 6),
                Text(
                  'پلانی خۆت ڕێکبخە و لە هەر ڕۆژێکدا پێشکەوتنەکەت ببینە.',
                  textAlign: TextAlign.right,
                  style: TextStyle(
                    fontFamily: fontFamily,
                    color: Colors.white.withValues(alpha: 0.80),
                    fontWeight: FontWeight.w700,
                    fontSize: 12.8,
                    height: 1.4,
                  ),
                ),
                const SizedBox(height: 14),
                Wrap(
                  alignment: WrapAlignment.start,
                  spacing: 10,
                  runSpacing: 10,
                  children: <Widget>[
                    _RamadanInfoPill(
                      icon: Icons.date_range_rounded,
                      label: 'دەستپێک: ${_formatDate(_startDate)}',
                      foreground: Colors.white,
                      background: Colors.white.withValues(alpha: 0.12),
                      borderColor: Colors.white.withValues(alpha: 0.16),
                      fontFamily: fontFamily,
                    ),
                    _RamadanInfoPill(
                      icon: Icons.timer_outlined,
                      label: 'ماوە: $_planDays ڕۆژ',
                      foreground: Colors.white,
                      background: Colors.white.withValues(alpha: 0.12),
                      borderColor: Colors.white.withValues(alpha: 0.16),
                      fontFamily: fontFamily,
                    ),
                    _RamadanInfoPill(
                      icon: Icons.done_all_rounded,
                      label: 'ڕۆژی تەواوبوو: $completedDays',
                      foreground: const Color(0xFF143047),
                      background: const Color(0xFFF7E5BC),
                      borderColor: const Color(0x55FFF2D7),
                      fontFamily: fontFamily,
                    ),
                  ],
                ),
              ],
            ),
          ),
          const SizedBox(width: 14),
          _RamadanProgressRing(
            value: progress,
            title: '${(progress * 100).round()}%',
            subtitle: 'پێشکەوتن',
          ),
        ],
      ),
    );
  }

  Widget _buildKhatmControls(String fontFamily) {
    return _RamadanPanel(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: <Widget>[
          _RamadanSectionHeader(
            title: 'ڕێکخستن',
            subtitle: 'ژمارەی ڕۆژەکان و دەستپێکی پلان دیاری بکە',
            fontFamily: fontFamily,
          ),
          const SizedBox(height: 12),
          Text(
            'ماوەی خەتم: $_planDays ڕۆژ',
            textAlign: TextAlign.right,
            style: TextStyle(
              fontFamily: fontFamily,
              color: _RamadanPalette.ink,
              fontWeight: FontWeight.w900,
              fontSize: 15.5,
            ),
          ),
          SliderTheme(
            data: SliderTheme.of(context).copyWith(
              activeTrackColor: _RamadanPalette.gold,
              inactiveTrackColor: const Color(0x1AB98532),
              thumbColor: _RamadanPalette.gold,
              overlayColor: _RamadanPalette.gold.withValues(alpha: 0.12),
            ),
            child: Slider(
              value: _planDays.toDouble(),
              min: 1,
              max: 30,
              divisions: 29,
              label: '$_planDays',
              onChanged: (double value) {
                setState(() {
                  _planDays = value.round().clamp(1, 30);
                });
                _savePlanState();
              },
            ),
          ),
          const SizedBox(height: 6),
          Wrap(
            alignment: WrapAlignment.start,
            spacing: 8,
            runSpacing: 8,
            children: <Widget>[
              for (final int days in <int>[30, 20, 15, 10, 7, 5])
                _RamadanChoiceChip(
                  label: '$days ڕۆژ',
                  selected: _planDays == days,
                  fontFamily: fontFamily,
                  onTap: () {
                    setState(() => _planDays = days);
                    _savePlanState();
                  },
                ),
            ],
          ),
          const SizedBox(height: 14),
          _RamadanActionButton(
            icon: Icons.date_range_rounded,
            label: 'دەستپێکی پلان: ${_formatDate(_startDate)}',
            fontFamily: fontFamily,
            onTap: _pickStartDate,
            backgroundColor: Colors.white,
            foregroundColor: _RamadanPalette.ink,
            borderColor: const Color(0x1FB98532),
            outlined: true,
          ),
        ],
      ),
    );
  }

  Widget _buildTodayMission({
    required String fontFamily,
    required _KhatmDayPlan? todayPlan,
  }) {
    return _RamadanPanel(
      padding: const EdgeInsets.all(18),
      gradient: const <Color>[
        Color(0xFFFFF8E8),
        Color(0xFFF9E7C1),
        Color(0xFFFFFFFF),
      ],
      borderColor: const Color(0x36B98532),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: <Widget>[
          Text(
            'ئامانجی ئەمڕۆ',
            textAlign: TextAlign.right,
            style: TextStyle(
              fontFamily: fontFamily,
              color: _RamadanPalette.ink,
              fontWeight: FontWeight.w900,
              fontSize: 18,
            ),
          ),
          const SizedBox(height: 6),
          if (todayPlan == null)
            Text(
              'ئەمڕۆ لە ماوەی پلانی دیاریکراودا نییە. دەستپێک یان ژمارەی ڕۆژەکان بگۆڕە.',
              textAlign: TextAlign.right,
              style: TextStyle(
                fontFamily: fontFamily,
                color: _RamadanPalette.muted,
                fontWeight: FontWeight.w700,
                height: 1.45,
              ),
            )
          else ...<Widget>[
            Text(
              '${_formatDate(todayPlan.date)}  •  ${_rangeText(todayPlan.juzRange)}',
              textAlign: TextAlign.right,
              style: TextStyle(
                fontFamily: fontFamily,
                color: _RamadanPalette.muted,
                fontWeight: FontWeight.w700,
              ),
            ),
            const SizedBox(height: 12),
            Wrap(
              alignment: WrapAlignment.start,
              spacing: 8,
              runSpacing: 8,
              children: <Widget>[
                for (final int juz in todayPlan.juzRange)
                  _RamadanSelectableToken(
                    label: 'جزء $juz',
                    selected: _completedJuz.contains(juz),
                    fontFamily: fontFamily,
                  ),
              ],
            ),
            const SizedBox(height: 14),
            _RamadanActionButton(
              icon: Icons.done_all_rounded,
              label: _isDayCompleted(todayPlan)
                  ? 'تەواوبوو'
                  : 'هەموو ئامانجی ئەمڕۆ تەواوبکە',
              fontFamily: fontFamily,
              onTap: _isDayCompleted(todayPlan)
                  ? null
                  : () => _markDayAsCompleted(todayPlan),
              backgroundColor: const Color(0xFFB98532),
              foregroundColor: Colors.white,
            ),
          ],
        ],
      ),
    );
  }

  Widget _buildPlanDayCard({
    required String fontFamily,
    required _KhatmDayPlan plan,
    required bool isDone,
  }) {
    return AnimatedContainer(
      duration: const Duration(milliseconds: 220),
      curve: Curves.easeOutCubic,
      decoration: BoxDecoration(
        gradient: isDone
            ? const LinearGradient(
                begin: Alignment.topRight,
                end: Alignment.bottomLeft,
                colors: <Color>[Color(0xFFF2FBF4), Color(0xFFFFFFFF)],
              )
            : null,
        color: isDone ? null : Colors.white.withValues(alpha: 0.94),
        borderRadius: BorderRadius.circular(22),
        border: Border.all(
          color: isDone ? const Color(0x3360B27D) : const Color(0x18A17D43),
        ),
        boxShadow: const <BoxShadow>[
          BoxShadow(
            color: Color(0x10000000),
            blurRadius: 20,
            offset: Offset(0, 10),
          ),
        ],
      ),
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Row(
          children: <Widget>[
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  Text(
                    'ڕۆژ ${plan.dayNumber}  •  ${_formatDate(plan.date)}',
                    textAlign: TextAlign.right,
                    style: TextStyle(
                      fontFamily: fontFamily,
                      color: _RamadanPalette.ink,
                      fontWeight: FontWeight.w900,
                      fontSize: 14.2,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    _rangeText(plan.juzRange),
                    textAlign: TextAlign.right,
                    style: TextStyle(
                      fontFamily: fontFamily,
                      color: _RamadanPalette.muted,
                      fontWeight: FontWeight.w700,
                      fontSize: 12.8,
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(width: 12),
            Container(
              width: 52,
              height: 52,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: isDone
                    ? const Color(0xFF2E946D)
                    : const Color(0xFFF5EFE2),
              ),
              alignment: Alignment.center,
              child: isDone
                  ? const Icon(
                      Icons.check_rounded,
                      color: Colors.white,
                      size: 26,
                    )
                  : Text(
                      '${plan.dayNumber}',
                      style: TextStyle(
                        fontFamily: 'english',
                        color: _RamadanPalette.ink,
                        fontWeight: FontWeight.w900,
                        fontSize: 18,
                      ),
                    ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildJuzBoard(String fontFamily) {
    return _RamadanPanel(
      child: Wrap(
        alignment: WrapAlignment.start,
        spacing: 8,
        runSpacing: 8,
        children: <Widget>[
          for (int index = 0; index < 30; index++)
            _RamadanSelectableToken(
              label: 'جزء ${index + 1}',
              selected: _completedJuz.contains(index + 1),
              fontFamily: fontFamily,
              onTap: () =>
                  _toggleJuz(index + 1, !_completedJuz.contains(index + 1)),
            ),
        ],
      ),
    );
  }
}

class DailyHadithPage extends StatefulWidget {
  const DailyHadithPage({super.key});

  @override
  State<DailyHadithPage> createState() => _DailyHadithPageState();
}

class _DailyHadithPageState extends State<DailyHadithPage> {
  int _dayOffset = 0;

  static const List<_DailyHadithEntry> _hadithPool = <_DailyHadithEntry>[
    _DailyHadithEntry(
      arabic:
          'إِنَّمَا الأَعْمَالُ بِالنِّيَّاتِ، وَإِنَّمَا لِكُلِّ امْرِئٍ مَا نَوَى',
      sorani:
          'کردارەکان بە نییەتن. هەر کەسێک ئەوە وەردەگرێت کە نییەتی بۆ کردووە.',
      source: 'بخاری و مسلم',
    ),
    _DailyHadithEntry(
      arabic:
          'مَنْ كَانَ يُؤْمِنُ بِاللَّهِ وَالْيَوْمِ الآخِرِ فَلْيَقُلْ خَيْرًا أَوْ لِيَصْمُتْ',
      sorani: 'ئەگەر باوەڕت بە خوا و ڕۆژی دوایی هەیە، باش بڵێ یان بێدەنگ بە.',
      source: 'بخاری و مسلم',
    ),
    _DailyHadithEntry(
      arabic: 'مَنْ لا يَرْحَمْ لا يُرْحَمْ',
      sorani: 'ئەوەی میهرەبانی نەکات، میهرەبانی پێ ناکرێت.',
      source: 'بخاری',
    ),
    _DailyHadithEntry(
      arabic: 'خَيْرُكُمْ مَنْ تَعَلَّمَ الْقُرْآنَ وَعَلَّمَهُ',
      sorani: 'باشترینتان ئەوەیە کە قورئان فێر ببێت و فێری خەڵکی بکات.',
      source: 'بخاری',
    ),
    _DailyHadithEntry(
      arabic: 'تَبَسُّمُكَ فِي وَجْهِ أَخِيكَ صَدَقَةٌ',
      sorani: 'پێکەنینت لە ڕووی براکەتدا سەدەقەیە.',
      source: 'ترمذی',
    ),
    _DailyHadithEntry(
      arabic: 'الدِّينُ النَّصِيحَةُ',
      sorani: 'ئایین بریتییە لە دڵسۆزی و ئامۆژگاری ڕاستگۆیانە.',
      source: 'مسلم',
    ),
    _DailyHadithEntry(
      arabic: 'الْكَلِمَةُ الطَّيِّبَةُ صَدَقَةٌ',
      sorani: 'وشەی چاک سەدەقەیە.',
      source: 'بخاری و مسلم',
    ),
    _DailyHadithEntry(
      arabic: 'إِنَّ اللَّهَ جَمِيلٌ يُحِبُّ الْجَمَالَ',
      sorani: 'خوا جوانە و جوانی خۆش دەوێت.',
      source: 'مسلم',
    ),
    _DailyHadithEntry(
      arabic: 'يَسِّرُوا وَلا تُعَسِّرُوا، وَبَشِّرُوا وَلا تُنَفِّرُوا',
      sorani: 'ئاسانکاری بکەن، سەختی مەکەن. مژدە بدەن، نەفرت مەکەن.',
      source: 'بخاری و مسلم',
    ),
    _DailyHadithEntry(
      arabic: 'أَحَبُّ الأَعْمَالِ إِلَى اللَّهِ أَدْوَمُهَا وَإِنْ قَلَّ',
      sorani:
          'خۆشەویستترین کردار لەلای خوا ئەوەیە بەردەوام بێت، هەرچەندە کەم بێت.',
      source: 'بخاری و مسلم',
    ),
    _DailyHadithEntry(
      arabic:
          'مَنْ سَلَكَ طَرِيقًا يَلْتَمِسُ فِيهِ عِلْمًا، سَهَّلَ اللَّهُ لَهُ بِهِ طَرِيقًا إِلَى الْجَنَّةِ',
      sorani: 'ئەوەی ڕێگایەک بگرێت بۆ زانست، خوا ڕێگای بەهەشت بۆ ئاسان دەکات.',
      source: 'مسلم',
    ),
    _DailyHadithEntry(
      arabic: 'اتَّقِ اللَّهَ حَيْثُمَا كُنْتَ',
      sorani: 'لە هەر شوێنێک بیت، لە خوا بترسە و خواپەرستی بکە.',
      source: 'ترمذی',
    ),
  ];

  DateTime get _targetDate {
    final DateTime now = DateTime.now();
    final DateTime date = now.add(Duration(days: _dayOffset));
    return DateTime(date.year, date.month, date.day);
  }

  int get _dayOfYearIndex {
    final DateTime date = _targetDate;
    final DateTime start = DateTime(date.year, 1, 1);
    return date.difference(start).inDays;
  }

  _DailyHadithEntry get _activeHadith {
    final int index = _dayOfYearIndex % _hadithPool.length;
    return _hadithPool[index];
  }

  void _changeDay(int delta) {
    setState(() {
      _dayOffset = (_dayOffset + delta).clamp(-3650, 3650);
    });
  }

  void _backToToday() {
    if (_dayOffset == 0) return;
    setState(() => _dayOffset = 0);
  }

  String _formatDate(DateTime date) {
    final String day = date.day.toString().padLeft(2, '0');
    final String month = date.month.toString().padLeft(2, '0');
    return '$day/$month/${date.year}';
  }

  Future<void> _copyHadith() async {
    final _DailyHadithEntry hadith = _activeHadith;
    final String content =
        '${hadith.arabic}\n\n'
        '${hadith.sorani}\n\n'
        'سەرچاوە: ${hadith.source}';

    await Clipboard.setData(ClipboardData(text: content));
    if (!mounted) return;
    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(
        const SnackBar(
          behavior: SnackBarBehavior.floating,
          content: Text('فەرموودەکە کۆپی کرا'),
        ),
      );
  }

  @override
  Widget build(BuildContext context) {
    final fontType = Provider.of<SettingsProvider>(
      context,
      listen: false,
    ).getsettingField('font_family');
    final String fontFamily = fontType.toString();
    final _DailyHadithEntry hadith = _activeHadith;

    return _RamadanSceneScaffold(
      title: 'فەرموودەی ڕۆژانە',
      fontFamily: fontFamily,
      body: Directionality(
        textDirection: TextDirection.rtl,
        child: ListView(
          physics: const BouncingScrollPhysics(),
          padding: const EdgeInsets.fromLTRB(16, 12, 16, 28),
          children: <Widget>[
            _RamadanReveal(index: 0, child: _buildHadithHero(fontFamily)),
            const SizedBox(height: 14),
            AnimatedSwitcher(
              duration: const Duration(milliseconds: 500),
              switchInCurve: Curves.easeOutCubic,
              switchOutCurve: Curves.easeInCubic,
              transitionBuilder: _ramadanSwitcherTransition,
              child: KeyedSubtree(
                key: ValueKey<int>(_dayOffset),
                child: _buildHadithCard(fontFamily: fontFamily, hadith: hadith),
              ),
            ),
            const SizedBox(height: 14),
            _RamadanReveal(index: 1, child: _buildHadithActions(fontFamily)),
          ],
        ),
      ),
    );
  }

  Widget _buildHadithHero(String fontFamily) {
    return _RamadanPanel(
      padding: const EdgeInsets.all(18),
      gradient: const <Color>[
        Color(0xFF2B2B40),
        Color(0xFF304B68),
        Color(0xFFBD8B3E),
      ],
      borderColor: const Color(0x40F0D9AE),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: <Widget>[
          Text(
            'فەرموودەیەک بۆ هەر ڕۆژێک',
            textAlign: TextAlign.right,
            style: TextStyle(
              fontFamily: fontFamily,
              color: Colors.white,
              fontWeight: FontWeight.w900,
              fontSize: 19,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            _dayOffset == 0 ? 'ئەمڕۆ' : _formatDate(_targetDate),
            textAlign: TextAlign.right,
            style: TextStyle(
              fontFamily: fontFamily,
              color: Colors.white.withValues(alpha: 0.82),
              fontWeight: FontWeight.w700,
              fontSize: 13.4,
            ),
          ),
          const SizedBox(height: 16),
          Row(
            children: <Widget>[
              _RamadanToolbarAction(
                icon: Icons.chevron_right_rounded,
                tooltip: 'ڕۆژی پێشوو',
                foregroundColor: Colors.white,
                backgroundColor: Colors.white.withValues(alpha: 0.12),
                borderColor: Colors.white.withValues(alpha: 0.16),
                onTap: () => _changeDay(-1),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: _RamadanInfoPill(
                  icon: Icons.auto_awesome_rounded,
                  label: 'فەرموودەی ڕۆژانە',
                  foreground: const Color(0xFF143047),
                  background: const Color(0xFFF8E6BF),
                  borderColor: const Color(0x55FFF2D7),
                  fontFamily: fontFamily,
                ),
              ),
              const SizedBox(width: 10),
              _RamadanToolbarAction(
                icon: Icons.chevron_left_rounded,
                tooltip: 'ڕۆژی دواتر',
                foregroundColor: Colors.white,
                backgroundColor: Colors.white.withValues(alpha: 0.12),
                borderColor: Colors.white.withValues(alpha: 0.16),
                onTap: () => _changeDay(1),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildHadithCard({
    required String fontFamily,
    required _DailyHadithEntry hadith,
  }) {
    return _RamadanPanel(
      padding: const EdgeInsets.all(18),
      gradient: const <Color>[
        Color(0xFFFFF8EA),
        Color(0xFFF8EBD2),
        Color(0xFFFFFFFF),
      ],
      borderColor: const Color(0x36B98532),
      child: Stack(
        children: <Widget>[
          Positioned(
            top: -10,
            left: 0,
            child: Icon(
              Icons.format_quote_rounded,
              size: 88,
              color: const Color(0xFFB98532).withValues(alpha: 0.12),
            ),
          ),
          Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: <Widget>[
              SelectionArea(
                child: Text(
                  hadith.arabic,
                  textAlign: TextAlign.right,
                  style: TextStyle(
                    fontFamily: fontFamily,
                    color: _RamadanPalette.ink,
                    fontWeight: FontWeight.w900,
                    fontSize: 21,
                    height: 1.75,
                  ),
                ),
              ),
              const SizedBox(height: 16),
              Container(
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(
                  color: Colors.white.withValues(alpha: 0.85),
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(color: const Color(0x1BB98532)),
                ),
                child: SelectionArea(
                  child: Text(
                    hadith.sorani,
                    textAlign: TextAlign.right,
                    style: TextStyle(
                      fontFamily: fontFamily,
                      color: _RamadanPalette.muted,
                      fontWeight: FontWeight.w700,
                      fontSize: 14.5,
                      height: 1.55,
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 14),
              Align(
                alignment: AlignmentDirectional.centerStart,
                child: _RamadanInfoPill(
                  icon: Icons.menu_book_rounded,
                  label: 'سەرچاوە: ${hadith.source}',
                  foreground: const Color(0xFF6B4C21),
                  background: const Color(0xFFFFF0CD),
                  borderColor: const Color(0x30A77A34),
                  fontFamily: fontFamily,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildHadithActions(String fontFamily) {
    return Row(
      children: <Widget>[
        Expanded(
          child: _RamadanActionButton(
            icon: Icons.copy_rounded,
            label: 'کۆپی',
            fontFamily: fontFamily,
            onTap: _copyHadith,
            backgroundColor: Colors.white,
            foregroundColor: _RamadanPalette.ink,
            borderColor: const Color(0x1FB98532),
            outlined: true,
          ),
        ),
        const SizedBox(width: 10),
        Expanded(
          child: _RamadanActionButton(
            icon: Icons.today_rounded,
            label: 'گەڕانەوە بۆ ئەمڕۆ',
            fontFamily: fontFamily,
            onTap: _backToToday,
            backgroundColor: const Color(0xFFB98532),
            foregroundColor: Colors.white,
          ),
        ),
      ],
    );
  }
}

Widget _ramadanSwitcherTransition(Widget child, Animation<double> animation) {
  final CurvedAnimation curved = CurvedAnimation(
    parent: animation,
    curve: Curves.easeOutCubic,
  );

  return FadeTransition(
    opacity: curved,
    child: SlideTransition(
      position: Tween<Offset>(
        begin: const Offset(0, 0.06),
        end: Offset.zero,
      ).animate(curved),
      child: child,
    ),
  );
}

class _RamadanSceneScaffold extends StatelessWidget {
  const _RamadanSceneScaffold({
    required this.title,
    required this.fontFamily,
    required this.body,
    this.actions = const <Widget>[],
  });

  final String title;
  final String fontFamily;
  final Widget body;
  final List<Widget> actions;

  @override
  Widget build(BuildContext context) {
    final bool canPop = Navigator.of(context).canPop();
    final List<Widget> appBarActions = actions.isEmpty
        ? const <Widget>[]
        : <Widget>[
            Padding(
              padding: const EdgeInsetsDirectional.only(end: 16),
              child: Row(mainAxisSize: MainAxisSize.min, children: actions),
            ),
          ];

    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        backgroundColor: _RamadanPalette.canvas,
        appBar: AppBar(
          backgroundColor: Colors.transparent,
          elevation: 0,
          scrolledUnderElevation: 0,
          surfaceTintColor: Colors.transparent,
          foregroundColor: _RamadanPalette.ink,
          automaticallyImplyLeading: false,
          leadingWidth: canPop ? 56 : 16,
          leading: canPop
              ? Padding(
                  padding: const EdgeInsetsDirectional.only(start: 16),
                  child: IconButton(
                    tooltip: MaterialLocalizations.of(
                      context,
                    ).backButtonTooltip,
                    onPressed: () => Navigator.maybePop(context),
                    icon: const BackButtonIcon(),
                  ),
                )
              : const SizedBox.shrink(),
          systemOverlayStyle: SystemUiOverlayStyle.dark,
          titleSpacing: 16,
          title: Text(
            title,
            style: TextStyle(
              fontFamily: fontFamily,
              fontWeight: FontWeight.w900,
              color: _RamadanPalette.ink,
            ),
          ),
          actions: appBarActions,
        ),
        body: DecoratedBox(
          decoration: const BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: <Color>[
                Color(0xFFF7F0E1),
                Color(0xFFFDF9F1),
                Color(0xFFF0F5FB),
              ],
            ),
          ),
          child: Stack(
            children: <Widget>[
              const Positioned.fill(child: _RamadanBackdrop()),
              SafeArea(top: false, child: body),
            ],
          ),
        ),
      ),
    );
  }
}

class _RamadanBackdrop extends StatelessWidget {
  const _RamadanBackdrop();

  @override
  Widget build(BuildContext context) {
    return IgnorePointer(
      child: Stack(
        children: const <Widget>[
          _RamadanOrb(
            top: -60,
            right: -30,
            size: 180,
            color: Color(0x22C9923A),
          ),
          _RamadanOrb(top: 120, left: -50, size: 220, color: Color(0x1A5A82D4)),
          _RamadanOrb(
            bottom: 80,
            right: -40,
            size: 190,
            color: Color(0x1A2E946D),
          ),
          Positioned(
            top: 40,
            left: 18,
            child: Icon(
              Icons.nightlight_round,
              size: 120,
              color: Color(0x10B98532),
            ),
          ),
        ],
      ),
    );
  }
}

class _RamadanOrb extends StatelessWidget {
  const _RamadanOrb({
    this.top,
    this.right,
    this.bottom,
    this.left,
    required this.size,
    required this.color,
  });

  final double? top;
  final double? right;
  final double? bottom;
  final double? left;
  final double size;
  final Color color;

  @override
  Widget build(BuildContext context) {
    return Positioned(
      top: top,
      right: right,
      bottom: bottom,
      left: left,
      child: Container(
        width: size,
        height: size,
        decoration: BoxDecoration(shape: BoxShape.circle, color: color),
      ),
    );
  }
}

class _RamadanPanel extends StatelessWidget {
  const _RamadanPanel({
    super.key,
    required this.child,
    this.padding = const EdgeInsets.all(16),
    this.gradient,
    this.borderColor,
  });

  final Widget child;
  final EdgeInsets padding;
  final List<Color>? gradient;
  final Color? borderColor;

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        gradient: gradient == null
            ? null
            : LinearGradient(
                begin: Alignment.topRight,
                end: Alignment.bottomLeft,
                colors: gradient!,
              ),
        color: gradient == null ? Colors.white.withValues(alpha: 0.93) : null,
        borderRadius: BorderRadius.circular(28),
        border: Border.all(color: borderColor ?? const Color(0x18A17D43)),
        boxShadow: const <BoxShadow>[
          BoxShadow(
            color: Color(0x12000000),
            blurRadius: 24,
            offset: Offset(0, 14),
          ),
        ],
      ),
      child: Padding(padding: padding, child: child),
    );
  }
}

class _RamadanReveal extends StatelessWidget {
  const _RamadanReveal({required this.index, required this.child});

  final int index;
  final Widget child;

  @override
  Widget build(BuildContext context) {
    return TweenAnimationBuilder<double>(
      tween: Tween<double>(begin: 0, end: 1),
      duration: Duration(milliseconds: 320 + (index * 70)),
      curve: Curves.easeOutCubic,
      builder: (BuildContext context, double value, Widget? child) {
        return Opacity(
          opacity: value.clamp(0.0, 1.0),
          child: Transform.translate(
            offset: Offset(0, 28 * (1 - value)),
            child: child,
          ),
        );
      },
      child: child,
    );
  }
}

class _RamadanToolbarAction extends StatelessWidget {
  const _RamadanToolbarAction({
    required this.icon,
    required this.onTap,
    this.tooltip,
    this.foregroundColor = _RamadanPalette.ink,
    this.backgroundColor = Colors.white,
    this.borderColor = const Color(0x1AA17D43),
  });

  final IconData icon;
  final VoidCallback onTap;
  final String? tooltip;
  final Color foregroundColor;
  final Color backgroundColor;
  final Color borderColor;

  @override
  Widget build(BuildContext context) {
    final Widget button = Material(
      color: Colors.transparent,
      child: InkWell(
        borderRadius: BorderRadius.circular(16),
        onTap: onTap,
        child: Ink(
          width: 44,
          height: 44,
          decoration: BoxDecoration(
            color: backgroundColor,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: borderColor),
          ),
          child: Icon(icon, color: foregroundColor, size: 22),
        ),
      ),
    );

    if (tooltip == null || tooltip!.trim().isEmpty) {
      return button;
    }
    return Tooltip(message: tooltip, child: button);
  }
}

class _RamadanInfoPill extends StatelessWidget {
  const _RamadanInfoPill({
    required this.icon,
    required this.label,
    required this.foreground,
    required this.background,
    required this.borderColor,
    required this.fontFamily,
  });

  final IconData icon;
  final String label;
  final Color foreground;
  final Color background;
  final Color borderColor;
  final String fontFamily;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 9),
      decoration: BoxDecoration(
        color: background,
        borderRadius: BorderRadius.circular(999),
        border: Border.all(color: borderColor),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: <Widget>[
          Flexible(
            child: Text(
              label,
              overflow: TextOverflow.ellipsis,
              style: TextStyle(
                fontFamily: fontFamily,
                color: foreground,
                fontWeight: FontWeight.w800,
                fontSize: 12.2,
              ),
            ),
          ),
          const SizedBox(width: 7),
          Icon(icon, size: 16, color: foreground),
        ],
      ),
    );
  }
}

class _RamadanSectionHeader extends StatelessWidget {
  const _RamadanSectionHeader({
    required this.title,
    required this.fontFamily,
    this.subtitle,
    this.badge,
  });

  final String title;
  final String fontFamily;
  final String? subtitle;
  final String? badge;

  @override
  Widget build(BuildContext context) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
        Expanded(
          flex: 3,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Text(
                title,
                textAlign: TextAlign.right,
                style: TextStyle(
                  fontFamily: fontFamily,
                  color: _RamadanPalette.ink,
                  fontWeight: FontWeight.w900,
                  fontSize: 18,
                ),
              ),
              if (subtitle != null) ...<Widget>[
                const SizedBox(height: 3),
                Text(
                  subtitle!,
                  textAlign: TextAlign.right,
                  style: TextStyle(
                    fontFamily: fontFamily,
                    color: _RamadanPalette.muted,
                    fontWeight: FontWeight.w700,
                    fontSize: 12.6,
                  ),
                ),
              ],
            ],
          ),
        ),
        if (badge != null) ...<Widget>[
          const SizedBox(width: 12),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
            decoration: BoxDecoration(
              color: Colors.white.withValues(alpha: 0.88),
              borderRadius: BorderRadius.circular(999),
              border: Border.all(color: const Color(0x18A17D43)),
            ),
            child: Text(
              badge!,
              style: TextStyle(
                fontFamily: fontFamily,
                color: _RamadanPalette.ink,
                fontWeight: FontWeight.w800,
                fontSize: 12.2,
              ),
            ),
          ),
        ],
      ],
    );
  }
}

class _RamadanMetricTile extends StatelessWidget {
  const _RamadanMetricTile({
    required this.title,
    required this.value,
    required this.subtitle,
    required this.icon,
    required this.accent,
    required this.fontFamily,
    this.useEnglishFont = true,
  });

  final String title;
  final String value;
  final String subtitle;
  final IconData icon;
  final Color accent;
  final String fontFamily;
  final bool useEnglishFont;

  @override
  Widget build(BuildContext context) {
    return Container(
      // constraints: const BoxConstraints(minHeight: 158),
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 15),
      decoration: BoxDecoration(
        color: Colors.white.withValues(alpha: 0.86),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: accent.withValues(alpha: 0.22)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Row(
            children: <Widget>[
              Text(
                subtitle,
                style: TextStyle(
                  fontFamily: fontFamily,
                  color: accent,
                  fontWeight: FontWeight.w800,
                  fontSize: 12.2,
                ),
              ),
              const Spacer(),
              Container(
                width: 38,
                height: 38,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: accent.withValues(alpha: 0.12),
                ),
                alignment: Alignment.center,
                child: Icon(icon, color: accent, size: 20),
              ),
            ],
          ),
          const SizedBox(height: 12),
          Text(
            value,
            textAlign: TextAlign.start,
            style: TextStyle(
              fontFamily: useEnglishFont ? 'english' : fontFamily,
              color: _RamadanPalette.ink,
              fontWeight: FontWeight.w900,
              fontSize: useEnglishFont ? 20.5 : 16.4,
              height: 1.2,
            ),
          ),
          const SizedBox(height: 4),
          Text(
            title,
            textAlign: TextAlign.start,
            style: TextStyle(
              fontFamily: fontFamily,
              color: _RamadanPalette.muted,
              fontWeight: FontWeight.w700,
              fontSize: 12.8,
            ),
          ),
        ],
      ),
    );
  }
}

class _RamadanMiniTag extends StatelessWidget {
  const _RamadanMiniTag({
    required this.title,
    required this.value,
    required this.accent,
    required this.fontFamily,
  });

  final String title;
  final String value;
  final Color accent;
  final String fontFamily;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
      decoration: BoxDecoration(
        color: accent.withValues(alpha: 0.10),
        borderRadius: BorderRadius.circular(16),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: <Widget>[
          Text(
            title,
            style: TextStyle(
              fontFamily: fontFamily,
              color: _RamadanPalette.ink,
              fontWeight: FontWeight.w800,
              fontSize: 12.2,
            ),
          ),
          const SizedBox(width: 6),
          Text(
            value,
            style: TextStyle(
              fontFamily: 'english',
              color: accent,
              fontWeight: FontWeight.w900,
              fontSize: 13.4,
            ),
          ),
        ],
      ),
    );
  }
}

class _RamadanActionButton extends StatelessWidget {
  const _RamadanActionButton({
    required this.icon,
    required this.label,
    required this.fontFamily,
    required this.onTap,
    required this.backgroundColor,
    required this.foregroundColor,
    this.borderColor,
    this.outlined = false,
  });

  final IconData icon;
  final String label;
  final String fontFamily;
  final VoidCallback? onTap;
  final Color backgroundColor;
  final Color foregroundColor;
  final Color? borderColor;
  final bool outlined;

  @override
  Widget build(BuildContext context) {
    if (outlined) {
      return OutlinedButton.icon(
        onPressed: onTap,
        icon: Icon(icon),
        label: Text(
          label,
          style: TextStyle(fontFamily: fontFamily, fontWeight: FontWeight.w800),
        ),
        style: OutlinedButton.styleFrom(
          foregroundColor: foregroundColor,
          backgroundColor: backgroundColor,
          side: BorderSide(
            color: borderColor ?? foregroundColor.withValues(alpha: 0.18),
          ),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(18),
          ),
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
        ),
      );
    }

    return FilledButton.icon(
      onPressed: onTap,
      icon: Icon(icon),
      label: Text(
        label,
        style: TextStyle(fontFamily: fontFamily, fontWeight: FontWeight.w800),
      ),
      style: FilledButton.styleFrom(
        backgroundColor: backgroundColor,
        foregroundColor: foregroundColor,
        disabledBackgroundColor: const Color(0xFFCEC7B9),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
      ),
    );
  }
}

class _RamadanChoiceChip extends StatelessWidget {
  const _RamadanChoiceChip({
    required this.label,
    required this.selected,
    required this.fontFamily,
    required this.onTap,
  });

  final String label;
  final bool selected;
  final String fontFamily;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        borderRadius: BorderRadius.circular(999),
        onTap: onTap,
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 220),
          curve: Curves.easeOutCubic,
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 9),
          decoration: BoxDecoration(
            color: selected ? _RamadanPalette.gold : Colors.white,
            borderRadius: BorderRadius.circular(999),
            border: Border.all(
              color: selected ? _RamadanPalette.gold : const Color(0x1AA17D43),
            ),
          ),
          child: Text(
            label,
            style: TextStyle(
              fontFamily: fontFamily,
              color: selected ? Colors.white : _RamadanPalette.ink,
              fontWeight: FontWeight.w800,
              fontSize: 12.3,
            ),
          ),
        ),
      ),
    );
  }
}

class _RamadanProgressRing extends StatelessWidget {
  const _RamadanProgressRing({
    required this.value,
    required this.title,
    required this.subtitle,
  });

  final double value;
  final String title;
  final String subtitle;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: 96,
      height: 96,
      child: Stack(
        alignment: Alignment.center,
        children: <Widget>[
          SizedBox(
            width: 96,
            height: 96,
            child: CircularProgressIndicator(
              value: value,
              strokeWidth: 8,
              backgroundColor: Colors.white.withValues(alpha: 0.14),
              valueColor: const AlwaysStoppedAnimation<Color>(
                Color(0xFFF7E2B8),
              ),
            ),
          ),
          Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              Text(
                title,
                style: const TextStyle(
                  fontFamily: 'english',
                  color: Colors.white,
                  fontWeight: FontWeight.w900,
                  fontSize: 18,
                ),
              ),
              const SizedBox(height: 2),
              Text(
                subtitle,
                style: TextStyle(
                  color: Colors.white.withValues(alpha: 0.80),
                  fontWeight: FontWeight.w700,
                  fontSize: 11.4,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _RamadanSelectableToken extends StatelessWidget {
  const _RamadanSelectableToken({
    required this.label,
    required this.selected,
    required this.fontFamily,
    this.onTap,
  });

  final String label;
  final bool selected;
  final String fontFamily;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    final Widget chip = AnimatedContainer(
      duration: const Duration(milliseconds: 220),
      curve: Curves.easeOutCubic,
      padding: const EdgeInsets.symmetric(horizontal: 11, vertical: 9),
      decoration: BoxDecoration(
        color: selected ? const Color(0xFFE2F6E9) : Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: selected ? const Color(0xFF68B58F) : const Color(0x1AA17D43),
        ),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: <Widget>[
          Text(
            label,
            style: TextStyle(
              fontFamily: fontFamily,
              color: selected ? const Color(0xFF1E6B4D) : _RamadanPalette.ink,
              fontWeight: FontWeight.w800,
              fontSize: 12.1,
            ),
          ),
          if (selected) ...<Widget>[
            const SizedBox(width: 6),
            const Icon(Icons.check_rounded, size: 16, color: Color(0xFF2E946D)),
          ],
        ],
      ),
    );

    if (onTap == null) return chip;

    return Material(
      color: Colors.transparent,
      child: InkWell(
        borderRadius: BorderRadius.circular(16),
        onTap: onTap,
        child: chip,
      ),
    );
  }
}

class _RamadanPalette {
  static const Color canvas = Color(0xFFF8F2E8);
  static const Color ink = Color(0xFF1F2B37);
  static const Color muted = Color(0xFF667285);
  static const Color gold = Color(0xFFB98532);
  static const Color twilight = Color(0xFF426FCD);
}

class _ResolvedLocation {
  const _ResolvedLocation({
    required this.city,
    required this.label,
    required this.usedFallback,
  });

  final PrayerCity city;
  final String label;
  final bool usedFallback;
}

class _RamadanDayTiming {
  const _RamadanDayTiming({
    required this.date,
    required this.hijriLabel,
    required this.suhoorEnd,
    required this.iftar,
    required this.fastingDuration,
  });

  final DateTime date;
  final String hijriLabel;
  final String suhoorEnd;
  final String iftar;
  final Duration fastingDuration;
}

class _KhatmDayPlan {
  const _KhatmDayPlan({
    required this.dayNumber,
    required this.date,
    required this.juzRange,
  });

  final int dayNumber;
  final DateTime date;
  final List<int> juzRange;
}

class _DailyHadithEntry {
  const _DailyHadithEntry({
    required this.arabic,
    required this.sorani,
    required this.source,
  });

  final String arabic;
  final String sorani;
  final String source;
}
