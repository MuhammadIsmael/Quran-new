import 'package:background_app_bar/background_app_bar.dart';
import 'package:flutter/material.dart';
import 'package:flutter_staggered_animations/flutter_staggered_animations.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:runaki_islam/Screens/HomeItems/MangeRamazan/page_1.dart';
import 'package:runaki_islam/util/background.dart';
import 'dart:ui';
import 'package:runaki_islam/providers/settings_provider.dart';
import 'package:provider/provider.dart';
import 'package:runaki_islam/util/constans.dart';
import 'package:runaki_islam/util/navigate_between_pages/size_route.dart';

class MangeRamazanPage extends StatefulWidget {
  final String? sarder;

  const MangeRamazanPage({super.key, this.sarder});
  @override
  State<StatefulWidget> createState() => _MangeRamazanPageState();
}

class _MangeRamazanPageState extends State<MangeRamazanPage> {
  final List<String> _list = [
    "پێشوازی کردن لە ڕەمەزان",
    "چۆنیەتی ڕۆژوو گرتن لە ڕەمەزان",
    "ڕۆژێک لە ژیانی ڕۆژوەوان",
    "ئەرکی دە شەوی کۆتایی ڕەمەزان",
  ];

  int? fontType;
  @override
  void initState() {
    fontType = Provider.of<SettingsProvider>(
      context,
      listen: false,
    ).getsettingField('font_family');
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        backgroundColor: bgColor,
        body: NestedScrollView(
          physics: const BouncingScrollPhysics(),
          headerSliverBuilder: (_, _) => <Widget>[
            SliverAppBar(
              leading: IconButton(
                icon: Icon(Icons.arrow_back_ios_rounded, color: iconColor),
                onPressed: () {
                  Navigator.pop(context);
                },
              ),
              expandedHeight: 200,
              floating: false,
              pinned: true,
              snap: false,
              elevation: 0.0,
              backgroundColor: Colors.transparent,
              flexibleSpace: BackgroundFlexibleSpaceBar(
                collapseMode: CollapseMode.parallax,
                centerTitle: true,
                title: Text(
                  widget.sarder!,
                  style: bigTextStyle.copyWith(
                    fontFamily: fontType.toString(),
                    color: Colors.white,
                  ),
                ),
                titlePadding: const EdgeInsets.all(50),
                background: ClipRect(
                  child: Container(
                    decoration: const BoxDecoration(
                      image: DecorationImage(
                        image: AssetImage("assets/images/read-quran.jpg"),
                        fit: BoxFit.fill,
                      ),
                    ),
                    child: BackdropFilter(
                      filter: ImageFilter.blur(sigmaX: 5.0, sigmaY: 5.0),
                      child: Container(
                        decoration: BoxDecoration(
                          color: thirdColor.withValues(alpha: 0.5),
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ],
          body: Stack(
            children: [
              const Background2(),
              Padding(
                padding: const EdgeInsets.all(15.0),
                child: AnimationLimiter(
                  child: ListView.builder(
                    physics: const BouncingScrollPhysics(),
                    scrollDirection: Axis.vertical,
                    itemCount: _list.length,
                    itemBuilder: (context, i) {
                      final a = _list[i];
                      return AnimationConfiguration.staggeredList(
                        position: i,
                        delay: const Duration(milliseconds: 100),
                        child: SlideAnimation(
                          duration: const Duration(milliseconds: 2500),
                          curve: Curves.fastLinearToSlowEaseIn,
                          horizontalOffset: 30,
                          verticalOffset: 300.0,
                          child: FlipAnimation(
                            duration: const Duration(milliseconds: 3000),
                            curve: Curves.fastLinearToSlowEaseIn,
                            flipAxis: FlipAxis.y,
                            child: homePageCardsGroup(a, () {
                              if (i == 0) {
                                Navigator.push(
                                  context,
                                  SizeRoute(
                                    page: const RamazanPage1(
                                      sarder: "پێشوازی کردن لە ڕەمەزان",
                                      path:
                                          'assets/data/content/ramadan_page_17.json',
                                    ),
                                  ),
                                );
                              }
                              if (i == 1) {
                                Navigator.push(
                                  context,
                                  SizeRoute(
                                    page: const RamazanPage1(
                                      sarder: "چۆنیەتی ڕۆژوو گرتن لە ڕەمەزان",
                                      path:
                                          'assets/data/content/ramadan_page_16.json',
                                    ),
                                  ),
                                );
                              }
                              if (i == 2) {
                                Navigator.push(
                                  context,
                                  SizeRoute(
                                    page: const RamazanPage1(
                                      sarder: "ڕۆژێک لە ژیانی ڕۆژوەوان",
                                      path:
                                          'assets/data/content/ramadan_page_18.json',
                                    ),
                                  ),
                                );
                              }
                              if (i == 3) {
                                Navigator.push(
                                  context,
                                  SizeRoute(
                                    page: const RamazanPage1(
                                      sarder: "ئەرکی دە شەوی کۆتایی ڕەمەزان",
                                      path:
                                          'assets/data/content/ramadan_page_15.json',
                                    ),
                                  ),
                                );
                              }
                            }, "${i + 1}"),
                          ),
                        ),
                      );
                    },
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget homePageCardsGroup(String title, VoidCallback onTap, String count) {
    double w = MediaQuery.of(context).size.width;
    return Padding(
      padding: EdgeInsets.only(bottom: w / 17),
      child: homePageCard(title, onTap, count),
    );
  }

  Widget homePageCard(String title, VoidCallback onTap, String count) {
    return InkWell(
      splashColor: kActiveIconColor,
      customBorder: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(25),
      ),
      onTap: onTap,
      child: Stack(
        children: [
          Container(
            padding: const EdgeInsets.all(15),
            width: double.infinity,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(25),
              color: backgroundColor.withValues(alpha: 0.6),
              boxShadow: [
                BoxShadow(
                  color: const Color(0xFF282547).withValues(alpha: .15),
                  blurRadius: 20,
                ),
              ],
            ),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                const SizedBox(),
                Container(
                  padding: const EdgeInsets.all(10),
                  decoration: BoxDecoration(
                    color: kActiveIconColor.withValues(alpha: .1),
                    shape: BoxShape.circle,
                  ),
                  child: SvgPicture.asset(
                    "assets/icons/ramazan.svg",
                    height: 40,
                    width: 40,
                    colorFilter: ColorFilter.mode(
                      kActiveIconColor.withValues(alpha: .6),
                      BlendMode.srcIn,
                    ),
                  ),
                ),
                Text(
                  title,
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                    fontFamily: fontType.toString(),
                    fontSize: 18,
                    color: titleTextColor,
                    fontWeight: FontWeight.w700,
                  ),
                  textAlign: TextAlign.center,
                ),
                const SizedBox(),
              ],
            ),
          ),
          Container(
            padding: const EdgeInsets.symmetric(
              horizontal: 10.0,
              vertical: 5.0,
            ),
            decoration: const BoxDecoration(
              color: Color(0x83CEECE8),
              borderRadius: BorderRadius.only(
                bottomRight: Radius.circular(10),
                topLeft: Radius.circular(20),
              ),
            ),
            child: Text(
              count,
              textAlign: TextAlign.center,
              style: TextStyle(
                color: kActiveIconColor,
                fontWeight: FontWeight.w700,
                fontSize: 12,
              ),
            ),
          ),
        ],
      ),
    );
  }
}
