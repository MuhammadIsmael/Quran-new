import 'package:flutter/material.dart';
import 'package:runaki_islam/util/background.dart';
import 'package:runaki_islam/util/constans.dart';
import 'package:runaki_islam/providers/settings_provider.dart';
import 'package:provider/provider.dart';

class Bangdan extends StatefulWidget {
  final String? sarder;

  const Bangdan({super.key, this.sarder});
  @override
  State<StatefulWidget> createState() => _BangdanState();
}

class _BangdanState extends State<Bangdan> {
  String caption =
      "بانگ : مانای ئه‌وه‌یه‌ كه‌ كاتی نوێژ هات و ده‌ستكه‌ن به‌ نوێژكردن. \n: به‌م شێوه‌یه‌ ده‌گوترێ   \n ";

  String text =
      "\nالله اكبر، الله اكبر \n الله اكبر، الله اكبر \n \n اشهد ان لا اله الا الله \n اشهد ان لا اله الا الله \n \n اشهد ان محمدا رسول الله \n اشهد ان محمدا رسول الله \n \n حيّ على الصلاه \n حيّ على الصلاه \n \n حيّ على الفلاح \n حيّ على الفلاح \n \n الله اكبر, الله اكبر \n \n لا اله الا الله";

  int? fontType;
  int? quranFontType;
  double? quranFontSize;
  double? fontSize;

  @override
  void initState() {
    fontType = Provider.of<SettingsProvider>(context, listen: false)
        .getsettingField('font_family');
    quranFontType = Provider.of<SettingsProvider>(context, listen: false)
        .getsettingField('quran_font_family');
    quranFontSize = Provider.of<SettingsProvider>(context, listen: false)
        .getsettingField('quran_font_size');
    fontSize = Provider.of<SettingsProvider>(context, listen: false)
        .getsettingField('font_size');
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: backgroundColor,
      appBar: AppBar(
        centerTitle: true,
        title: Text(
          widget.sarder!,
          style:
              TextStyle(fontFamily: fontType.toString(), color: titleTextColor),
        ),
        backgroundColor: thirdColor,
        elevation: 0.8,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_rounded),
          color: iconColor,
          onPressed: () {
            Navigator.pop(context);
          },
        ),
      ),
      body: Stack(
        children: [
          const Background2(),
          SingleChildScrollView(
            padding:
                const EdgeInsets.only(right: 10, left: 10, top: 20, bottom: 80),
            physics: const BouncingScrollPhysics(
                parent: AlwaysScrollableScrollPhysics()),
            scrollDirection: Axis.vertical,
            child: Column(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: <Widget>[
                  Text(
                    caption,
                    style: simpleTextStyle.copyWith(
                      fontSize: fontSize,
                      fontFamily: fontType.toString(),
                    ),
                    textAlign: TextAlign.center,
                  ),
                  spaceLine(),
                  Center(
                    child: SelectableText(
                      text,
                      style: quranStyle.copyWith(
                        fontSize: quranFontSize,
                        fontFamily: quranFontType.toString(),
                      ),
                      textAlign: TextAlign.center,
                    ),
                  ),
                ]),
          ),
        ],
      ),
    );
  }

  Widget spaceLine() {
    return Container(
      width: double.infinity,
      height: 2,
      margin: const EdgeInsets.symmetric(vertical: 10),
      decoration: BoxDecoration(
        color: splashColor,
        borderRadius: BorderRadius.circular(555),
      ),
    );
  }
}
