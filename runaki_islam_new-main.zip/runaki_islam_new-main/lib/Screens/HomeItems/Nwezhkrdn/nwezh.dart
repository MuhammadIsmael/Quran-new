import 'package:flutter/material.dart';
import 'package:runaki_islam/util/background.dart';
import 'package:runaki_islam/util/constans.dart';
import 'package:runaki_islam/widgets/nwezh/balga.dart';
import 'package:runaki_islam/widgets/nwezh/header_nwezh.dart';
import 'package:runaki_islam/providers/settings_provider.dart';
import 'package:provider/provider.dart';

class NwezhKrdn extends StatefulWidget {
  final String? sarder;

  const NwezhKrdn({super.key, this.sarder});
  @override
  State<StatefulWidget> createState() => _NwezhKrdnState();
}

class _NwezhKrdnState extends State<NwezhKrdn> {
  int? fontType;
  int? quranFontType;
  double? quranFontSize;
  double? fontSize;

  @override
  void initState() {
    super.initState();
    fontType = Provider.of<SettingsProvider>(context, listen: false)
        .getsettingField('font_family');
    quranFontType = Provider.of<SettingsProvider>(context, listen: false)
        .getsettingField('quran_font_family');
    quranFontSize = Provider.of<SettingsProvider>(context, listen: false)
        .getsettingField('quran_font_size');
    fontSize = Provider.of<SettingsProvider>(context, listen: false)
        .getsettingField('font_size');
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: backgroundColor,
      appBar: AppBar(
        centerTitle: true,
        title: Text(
          widget.sarder!,
          style:
              TextStyle(fontFamily: fontType.toString(), color: titleTextColor),
        ),
        backgroundColor: thirdColor,
        elevation: 0.8,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_rounded),
          color: iconColor,
          onPressed: () {
            Navigator.pop(context);
          },
        ),
      ),
      body: Stack(
        children: [
          const Background2(),
          Scrollbar(
            thumbVisibility: true,
            radius: const Radius.circular(25),
            thickness: 10,
            child: SingleChildScrollView(
              padding: const EdgeInsets.only(
                  right: 10, left: 10, top: 20, bottom: 80),
              physics: const BouncingScrollPhysics(
                  parent: AlwaysScrollableScrollPhysics()),
              scrollDirection: Axis.vertical,
              child: Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: <Widget>[
                    const HeaderNwezhItem(text: "١- نوێژ چییه‌؟"),
                    const SizedBox(height: 20),
                    Text.rich(
                      TextSpan(
                        children: [
                          TextSpan(
                            text: "نوێژ : ",
                            style: simpleTextStyle.copyWith(
                                color: kActiveIconColor,
                                fontFamily: fontType.toString(),
                                fontSize: fontSize,),
                          ),
                          TextSpan(
                              text:
                                  "په‌رستشێكه‌ له‌ چه‌ند وته‌ و كرده‌وه‌یه‌ك‌ پێكدێت. به‌ ته‌كبیر ده‌ستپێده‌كا‌ت و به‌ سه‌لام دانه‌وه‌ ‌ كۆتایی پێدێت",
                              style: simpleTextStyle.copyWith(
                              fontFamily: fontType.toString(),
                              fontSize: fontSize,
                            ))
                        ],
                      ),
                      textAlign: TextAlign.center,
                    ),
                    const SizedBox(height: 20),
                    Divider(color: kActiveIconColor),
                    const SizedBox(height: 20),
                    const HeaderNwezhItem(text: "٢- خۆت پاك بكه‌وه‌‌‌"),
                    const SizedBox(height: 20),
                    Text(
                      ": ئه‌گه‌ر ویستت نوێژ بكه‌یت",
                      style: simpleTextStyle.copyWith(
                              fontFamily: fontType.toString(),
                              fontSize: fontSize,
                            ),
                      textAlign: TextAlign.center,
                    ),
                    const SizedBox(height: 10),
                    sortLine("ده‌ستنوێژ بگره‌"),
                    sortLine("خۆت بشۆ.(ئه‌گه‌ر له‌شگرانبوویت)"),
                    sortLine(
                        "به‌ڵام ئه‌گه‌ر ئاوت ‌ده‌ست نه‌كه‌و‌ت ، یان به‌كارهێنانی زیانت پێبگه‌یه‌نێت ته‌یه‌مموم بكه‌"),
                    const SizedBox(height: 20),
                    const BalgaWidget(
                      description:
                          "له‌به‌ر فه‌رمایشتی خوای گه‌وره‌ له‌ ئایه‌تی (6)ـی سوره‌تی (المائدة).",
                    ),
                    const SizedBox(height: 20),
                    Divider(color: kActiveIconColor),
                    const SizedBox(height: 20),
                    const HeaderNwezhItem(
                        text: "٣- با جێگای نوێژه‌كه‌ت پاك بێت"),
                    const SizedBox(height: 20),
                    Text("جل و وبەرگ و جێگای نوێژەکەت پاکبکەرەوە",
                        style: simpleTextStyle.copyWith(
                              fontFamily: fontType.toString(),
                              fontSize: fontSize,
                            ), textAlign: TextAlign.center),
                    const SizedBox(height: 20),
                    const BalgaWidget2(
                      quran: "وَثِيَابَكَ فَطَهِّرْ",
                      text:
                          "پۆشاکه‌كه‌ت خاوێن ‌ڕابگره‌) [سورة المدثر] وه‌ له‌به‌ر فه‌رمایشتی پێغه‌مبه‌ر ﷺ :(أريقوا عليه سجلا من الماء -كاتێك ده‌شته‌كییه‌ك له‌ مزگەوت میزی كرد- پێغه‌مبه‌ر ﷺ فه‌رمووی:سه‌تڵێك ئاوی پێدا بڕێژن ) [الدارقطني: 453 ، صححه الالباني الإرواء:280]",
                    ),
                    const SizedBox(height: 20),
                    Divider(color: kActiveIconColor),
                    const SizedBox(height: 20),
                    const HeaderNwezhItem(text: "٤- ڕوو بكه‌ره قیبله‌"),
                    const SizedBox(height: 20),
                    Text(
                        "ڕوو بكه‌ره قیبله ئه‌و شوێنه‌ی كه‌ موسوڵمانان ‌له‌ كاتی نوێژدا ڕووی تێده‌كه‌ن كه‌ بریتییه‌ له‌ كه‌عبه‌ی پیرۆز به‌‌بێ ڕوو وه‌رگێڕان",
                        style: simpleTextStyle.copyWith(
                              fontFamily: fontType.toString(),
                              fontSize: fontSize,
                            ),
                        textAlign: TextAlign.center),
                    const SizedBox(height: 20),
                    const BalgaWidget2(
                      quran: "ْفَوَلِّ وَجْهَكَ شَطْرَ الْمَسْجِدِ الْحَرَامَِ",
                      text:
                          "ڕوو بكه‌ره كه‌عبه‌ی پیرۆز) ، وه‌ له‌به‌ر فه‌رمایشتی پێغەمبەر ﷺ: (إذا قمت إلی الصلاة فأسبغ الوضوء ، ثم استقبل القبلة - كاتێك ویستت نوێژبكه‌یت به‌جوانی ده‌ستنوێژ بگره‌ ، پاشان ڕوو بكه‌ره‌ قیبله‌) (البخاري 6251 مسلم 397).",
                    ),
                    const SizedBox(height: 20),
                    Divider(color: kActiveIconColor),
                    const SizedBox(height: 20),
                    const HeaderNwezhItem(text: "٥- نیه‌تی نوێژ بهێنه‌"),
                    const SizedBox(height: 20),
                    Text(
                        "له‌ دڵی خۆت دا نیه‌تی ئه‌و نوێژه‌ بهێنه‌ كه‌ ده‌ته‌وێت بیكه‌یت. به‌زمان نیه‌ت مه‌هێنه‌‌. چونكه‌ جێگای نیه‌ت دڵه نه‌ك زمان",
                        style: simpleTextStyle.copyWith(
                              fontFamily: fontType.toString(),
                              fontSize: fontSize,
                            ),
                        textAlign: TextAlign.center),
                    const SizedBox(height: 20),
                    const BalgaWidget(
                      description:
                          "له‌به‌ر فه‌رمایشتی پێغەمبەر ﷺ: (إنما الأعمال بالنیات - هه‌موو كرده‌وه‌كان به‌ نیه‌ته‌وه‌ ئه‌نجام ده‌درێن)[البخاری ، مسلم]، وه‌ نابێت نیه‌ت به‌ زمان بهێنیت، ‌ته‌نها به‌دڵ بیرت لای ئه‌وه ‌بێت كه‌ نوێژ ده‌كه‌یت.",
                    ),
                    const SizedBox(height: 20),
                    Divider(color: kActiveIconColor),
                    const SizedBox(height: 20),
                    const HeaderNwezhItem(text: "٦- ته‌كبیر بكه‌‌"),
                    const SizedBox(height: 20),
                    Text(
                      ": ته‌كبیره‌ی نوێژ دابه‌ستن بكه‌ و بڵێ",
                      textAlign:TextAlign.center,
                      style: simpleTextStyle.copyWith(
                              fontFamily: fontType.toString(),
                              fontSize: fontSize,
                            ),
                    ),
                    const SizedBox(height: 10),
                    Text(
                      "(اللهُ أَكْبَرُ)",
                      style: quranStyle.copyWith(   fontFamily: quranFontType.toString(),
                        fontSize: quranFontSize,),
                    ),
                    const SizedBox(height: 20),
                    const BalgaWidget(
                      description:
                          "له‌به‌ر فه‌رمایشتی پێغەمبەر ﷺ: (إذا قمت إلی الصلاة فكبر - كاتێك ویستت ده‌ست به‌ نوێژ بكه‌یت: «الله أکبر» بكه‌) [البخاري(793) مسلم(397)] (تحريمها التكبير وتحليلها التسليم - به‌ ته‌كبیره‌ی نوێژ دابه‌ستن ئه‌و كرده‌وانه‌ی كه‌ له‌ ده‌ره‌وی نوێژدا ڕێگه‌پێدراون قه‌ده‌غه‌ ده‌كرێن ، وه‌ به‌ سه‌لام دانه‌وه‌ ئاسایی د‌ه‌بنه‌وه‌) [صحيح سنن ابن ماجه (224)].",
                    ),
                    const SizedBox(height: 20),
                    Divider(color: kActiveIconColor),
                    const SizedBox(height: 20),
                    const HeaderNwezhItem(
                        text: "٧- ده‌سته‌كانت به‌رز بكه‌ره‌وه‌"),
                    const SizedBox(height: 20),
                    Text(
                        "له‌گه‌ڵ (اللهُ أَكْبَرُ) ‌ده‌سته‌كانت به‌رز بكه‌وه به ‌هاوتای شانت یان گوێچكه‌ت. وه‌ بڕوانه شوێنی سوجده‌كه‌ت، وه‌ پێیه‌كانت به‌ فراوانی هه‌ردوو شانت بكه‌ره‌‌وه.",
                        style: simpleTextStyle.copyWith(
                              fontFamily: fontType.toString(),
                              fontSize: fontSize,
                            ),
                        textAlign: TextAlign.center),
                    const SizedBox(height: 20),
                    const BalgaWidget(
                      description:
                          "له‌به‌ر كرده‌ی پێغه‌مبه‌ر ﷺ :(أَنَّ رَسُولَ اللهِ صَلَّى اللهُ عَلَيْهِ وَسَلَّمَ كَانَ يَرْفَعُ يَدَيْهِ حَذْوَ مَنْكِبَيْهِ إِذَا افْتَتَحَ الصَّلَاةَ)(البخاري738) (فَرَفَعَ يَدَيْهِ حَتَّى حَاذَتَا بِأُذُنَيْهِ)[مسلم 401 ، أبو داود 957]",
                    ),
                    const SizedBox(height: 20),
                    Divider(color: kActiveIconColor),
                    const SizedBox(height: 20),
                    const HeaderNwezhItem(
                        text: "٨- ده‌ستی ڕاست له‌سه‌ر ده‌ستی چه‌پ دابنێ"),
                    const SizedBox(height: 20),
                    Text(
                        "ده‌ستت له‌سه‌ر سنگت دابنێ:\n ده‌ستی ڕاستت له‌سه‌ر ده‌ستی چه‌پت دابنێ",
                        style: simpleTextStyle.copyWith(
                              fontFamily: fontType.toString(),
                              fontSize: fontSize,
                            ),
                        textAlign: TextAlign.center),
                    const SizedBox(height: 20),
                    const BalgaWidget2(
                      quran: "ْوَضَعَ يَدَهُ الْيُمْنَى عَلَى الْيُسْرَى",
                      text:
                          "چونكه‌ پێغه‌مبه‌ر ﷺ له‌ ناو نوێژ ده‌ستی ڕاستی له‌سه‌ر ده‌ستی چه‌پی داده‌نا)[مسلم 401]",
                    ),
                    const SizedBox(height: 20),
                    Divider(color: kActiveIconColor),
                    const SizedBox(height: 20),
                    const HeaderNwezhItem(text: "٩- نزای ده‌سپێك بخوێنه‌"),
                    const SizedBox(height: 20),
                    Text(": بڵێ",
                        style: simpleTextStyle.copyWith(
                              fontFamily: fontType.toString(),
                              fontSize: fontSize,
                            ), textAlign: TextAlign.center),
                    const SizedBox(height: 10),
                    Text(
                        "اللهُمَّ بَاعِدْ بَيْنِي وَبَيْنَ خَطَايَايَ كَمَا بَاعَدْتَ بَيْنَ المَشْرِقِ وَالمَغْرِبِ، اللهُمَّ نَقِّنِي مِنَ الخَطَايَا كَمَا يُنَقَّى الثَّوْبُ الأَبْيَضُ مِنَ الدَّنَسِ ، اللهُمَّ اغْسِل خَطَايَايَ بِالمَاءِ وَالثَّلجِ",
                        style: quranStyle.copyWith(   fontFamily: quranFontType.toString(),
                        fontSize: quranFontSize,),
                        textAlign: TextAlign.center),
                    const SizedBox(height: 10),
                    Text(": یاخود بڵێ",
                        style: simpleTextStyle.copyWith(
                              fontFamily: fontType.toString(),
                              fontSize: fontSize,
                            ), textAlign: TextAlign.center),
                    const SizedBox(height: 10),
                    Text(
                        "اللهُمَّ بَاعِدْ بَيْنِي وَبَيْنَ خَطَايَايَ كَمَا بَاعَدْتَ بَيْنَ المَشْرِقِ وَالمَغْرِبِ، اللهُمَّ نَقِّنِي مِنَ الخَطَايَا كَمَا يُنَقَّى الثَّوْبُ الأَبْيَضُ مِنَ الدَّنَسِ ، اللهُمَّ اغْسِل خَطَايَايَ بِالمَاءِ وَالثَّلجِ",
                        style: quranStyle.copyWith(   fontFamily: quranFontType.toString(),
                        fontSize: quranFontSize,),
                        textAlign: TextAlign.center),
                    const SizedBox(height: 20),
                    const BalgaWidget(
                      description:
                          "[البخاري (744) مسلم (598)] [سنن الترمذي (242)سنن النسائي (899,900)سنن ابن ماجه (804) صححه الالباني. صحيح أبي داود (749)] سوننه‌ته‌ له‌ دوای ته‌كبیره‌ی ئیحرام و‌ پێش خوێندنی سوره‌تی (الفاتحة) یه‌كێك م نزایانه‌ بخوێنرێت‌.",
                    ),
                    const SizedBox(height: 20),
                    Divider(color: kActiveIconColor),
                    const SizedBox(height: 20),
                    const HeaderNwezhItem(
                        text: "١٠- سوره‌تی (الفاتحة) بخوێنه‌"),
                    const SizedBox(height: 20),
                    Text(
                        "أَعُوذُ بِاللهِ مِنَ الشَّيْطَانِ الرَّجِيمِ\nبِسْمِ اللَّـهِ الرَّحْمَـٰنِ الرَّحِيمِ ﴿١﴾ الْحَمْدُ لِلَّـهِ رَبِّ الْعَالَمِينَ ﴿٢﴾ الرَّحْمَـٰنِ الرَّحِيمِ ﴿٣﴾ مَالِكِ يَوْمِ الدِّينِ ﴿٤﴾ إِيَّاكَ نَعْبُدُ وَإِيَّاكَ نَسْتَعِينُ ﴿٥﴾ اهْدِنَا الصِّرَاطَ الْمُسْتَقِيمَ ﴿٦﴾ صِرَاطَ الَّذِينَ أَنْعَمْتَ عَلَيْهِمْ غَيْرِ الْمَغْضُوبِ عَلَيْهِمْ وَلَا الضَّالِّينَ ﴿٧﴾",
                        style: quranStyle.copyWith(   fontFamily: quranFontType.toString(),
                        fontSize: quranFontSize,),
                        textAlign: TextAlign.center),
                    const SizedBox(height: 10),
                    Text(": پاشان سوره‌تێكی تر بخوێنه‌ وه‌ك",
                        style: simpleTextStyle.copyWith(
                              fontFamily: fontType.toString(),
                              fontSize: fontSize,
                            ), textAlign: TextAlign.center),
                    const SizedBox(height: 10),
                    Text(
                      "بِسْمِ اللَّـهِ الرَّحْمَـٰنِ الرَّحِيمِ \nقُلْ هُوَ اللَّـهُ أَحَدٌ ﴿١﴾ اللَّـهُ الصَّمَدُ ﴿٢﴾ لَمْ يَلِدْ وَلَمْ يُولَدْ ﴿٣﴾ وَلَمْ يَكُن لَّهُ كُفُوًا أَحَدٌ ﴿٤﴾",
                      style: quranStyle.copyWith(   fontFamily: quranFontType.toString(),
                        fontSize: quranFontSize,),
                      textAlign: TextAlign.center,
                    ),
                    const SizedBox(height: 20),
                    const BalgaWidget3(
                      quran:
                          "ْفَإِذَا قَرَأْتَ الْقُرْآنَ فَاسْتَعِذْ بِاللهِ مِنَ الشَّيْطَانِ الرَّجِيمِ",
                      text1: ": خوای گه‌وره‌ ده‌فه‌رموێت",
                      text2:
                          "کاتێك قورئانت خوێند‌ په‌نا بگره به خوا له شه‌یتانی نه‌فرین لێکراو وبڵێ: (أعوذ باللهِ من الشيطان الرجيم). )[سورة النحل 98] وه‌ له‌به‌ر فه‌رمایشتی پێغه‌مبه‌ر ﷺ :(لَا صَلَاةَ لِمَنْ لَمْ يَقْرَأْ بِفَاتِحَةِ الْكِتَابِ - نوێژی ئه‌و كه‌سه‌ دروست نییه‌ كه‌ سوره‌تی (الفاتحة)ـی تێدا نه‌خوێنێت) [البخاري 765 مسلم 394] ، وه‌ (ثُمَّ اقْرَأْ مَا تَيَسَّرَ مَعَكَ مِنَ الْقُرْآنِ -هێنده‌ی بۆت گونجا له‌ قورئان بیخوێنه‌) [البخاري 722 مسلم 392]",
                    ),
                    const SizedBox(height: 20),
                    Divider(color: kActiveIconColor),
                    const SizedBox(height: 20),
                    const HeaderNwezhItem(text: "١١- ڕكوع ببه‌"),
                    const SizedBox(height: 20),
                    Text(
                        "بڵێ:‌ (اللهُ أَكْبَرُ) وه‌ له‌گه‌ڵ -اللهُ أَكْبَرُ-دا هه‌ردوو ده‌سته‌كانت ‌به‌رزبكه‌ره‌وه‌ ، وه‌ په‌نجه‌كانت به‌ ڕاستی بگره‌ و بڵاویان مه‌كه‌ره‌وه‌.\nپاشان‌ ‌بچۆره‌ ڕكوع، پشتت بچه‌مێنه‌ره‌وه‌ ، وه‌ سه‌رت‌ له‌ ئاستی پشتت ڕابگره وه‌ ده‌سته‌كانت له‌سه‌ر ئه‌ژنۆت دابنێ هه‌ر وه‌ك ئه‌وه‌ی ئه‌ژنۆكانت بگریت.\nوه‌ په‌نجه‌كانت بڵاوبكه‌ره‌‌وه وه‌ (3 جار) بڵێ: «سُبْحَانَ رَبِّي الْعَظِيم» .",
                        style: simpleTextStyle.copyWith(
                              fontFamily: fontType.toString(),
                              fontSize: fontSize,
                            ),
                        textAlign: TextAlign.center),
                    const SizedBox(height: 20),
                    const BalgaWidget(
                      description:
                          "له‌به‌ر كرده‌ی پێغه‌مبه‌ر ﷺ :(وَإِذَا رَكَعَ أَمْكَنَ يَدَيْهِ مِنْ رُكْبَتَيْهِ، ثُمَّ هَصَرَ ظَهْرَهُ - كاتێك پێغەمبەر ﷺ بچوایه‌ته‌ ڕکوع به‌باشی دەسته‌كانی له‌سەر ئه‌ژنۆی داده‌نا ، وه‌ پشتی ده‌چه‌مانده‌وه‌ )[البخاري 828] (وَكَانَ إِذَا رَكَعَ لَمْ يُشْخِصْ رَأْسَهُ، وَلَمْ يُصَوِّبْهُ، وَلَكِنْ بَيْنَ ذَلِكَ - كاتێك پێغەمبەر ﷺ چووبایه‌ته‌ ڕكوع سه‌ری به‌رز نه‌ده‌كرده‌وه‌ و نزمیشی نه‌ده‌كرده‌وه‌ بەڵكو له ‌نێوانیاندا ڕایده‌گرت)[مسلم 498] (فوضع يديه على ركبتيه كأنه قابض عليهما - ده‌سته‌كانی له‌سه‌ر ئه‌ژنۆی داده‌نا ، هه‌ر وه‌كو ئه‌وه‌ی بیانگرێت.)[صححه الألباني: جامع الترمذي 260] (يَقُولُ إِذَا رَكَعَ « سُبْحَانَ رَبِّيَ الْعَظِيمِ » ثَلَاثَ مَرَّاتٍ) [ابن ماجه 888 «صحيح ابن ماجه 725»]",
                    ),
                    const SizedBox(height: 20),
                    Divider(color: kActiveIconColor),
                    const SizedBox(height: 20),
                    const HeaderNwezhItem(text: "١٢- هه‌سته‌وه‌ له‌ ڕكوع"),
                    const SizedBox(height: 20),
                    Text(
                        "كاتێك هه‌ستایته‌وه‌ له‌ ڕكوع بڵێ‌: (سَمِعَ اللهُ لِمِنْ حَمِدَهُ) وه جارێكی تر ده‌سته‌كانت به‌رز بكه‌ره‌وه به ‌هاوتای شانت یان گوێچكه‌ت. \n پاشان پشتت ڕاست بكه‌ره‌وە وه‌ بڵێ: (رَبنَا وَلَك الْحَمد).",
                        style: simpleTextStyle.copyWith(
                              fontFamily: fontType.toString(),
                              fontSize: fontSize,
                            ),
                        textAlign: TextAlign.center),
                    const SizedBox(height: 20),
                    const BalgaWidget(
                      description:
                          "(وَإِذَا رَفَعَ رَأْسَهُ مِنَ الرُّكُوعِ رَفَعَهُمَا كَذَلِكَ أَيْضًا - كاتێك پێغەمبەر ﷺ سه‌ری به‌رز ده‌كرده‌وه‌ له‌ ڕكوع ده‌سته‌كانیشی به‌رزده‌كرده‌وه‌)[البخاري 735] (فَإِذَا رَفَعَ رَأْسَهُ اسْتَوَى حَتَّى يَعُودَ كُلُّ فَقَارٍ مَكَانَه - كاتێك پێغەمبەر ﷺ سه‌ری به‌رز ده‌كرده‌وه‌ -له‌ ڕكوع- پشتی ڕاست ده‌كرده‌وه‌ هەتاوه‌كو بڕبڕه‌كانی پشتی ده‌گه‌ڕانه‌وه‌ جێگای خۆیان ) [البخاري 828] (حِينَ يَرْفَعُ رَأْسَهُ يَقُولُ : « سَمِعَ اللَّهُ لِمَنْ حَمِدَهُ، رَبَّنَا وَلَكَ الْحَمْدُ » )[البخاري 804]",
                    ),
                    const SizedBox(height: 20),
                    Divider(color: kActiveIconColor),
                    const SizedBox(height: 20),
                    const HeaderNwezhItem(text: "١٣- سوجده‌ ببه‌"),
                    const SizedBox(height: 20),
                    Text(
                        "بڵێ‌: (اللهُ أَكْبَرُ) و سه‌رت له‌سه‌ر ڕووی‌ زه‌وی دابنێ. • ده‌بێت (حه‌وت) ئه‌ندامی لاشه‌ت‌ له‌سه‌ر زه‌وی دابنێیت.\n• (ناوچاوان و لوت پێكه‌وه‌ – هه‌ردوو ده‌ست – هه‌ردوو ئه‌ژنۆ – هه‌ردوو پێ) \n• په‌نجه‌كانی ده‌ستت بڵاو مه‌كه‌ره‌وه‌ و ڕوویان بكه‌ره‌ قیبله‌.\n• ده‌سته‌كانت له‌ ئاستی شانت دابنێ یان له‌ ئاستی گوێچكه‌كانت.\n• ئانیشكت له‌سه‌ر زه‌وی دامه‌نێ.\n• هه‌ردوو پێیه‌كانت به‌یه‌كه‌وه‌ بلكێنه‌ ، وه‌ په‌نجه‌كانی پێت ڕوو بكه‌ره‌ قیبله‌.\n• (٣ جار) بڵێ: (سُبْحَانَ رَبِّي الْأَعْلَى).",
                        style: simpleTextStyle.copyWith(
                              fontFamily: fontType.toString(),
                              fontSize: fontSize,
                            ),
                        textAlign: TextAlign.center),
                    const SizedBox(height: 20),
                    const BalgaWidget(
                      description:
                          "له‌به‌ر كرده‌ و فه‌رمایشتی خۆشه‌ویستمان ﷺ: (فَإِذَا سَجَدَ وَضَعَ يَدَيْهِ غَيْرَ مُفْتَرِشٍ، وَلَا قَابِضِهِمَا وَاسْتَقْبَلَ بِأَطْرَافِ أَصَابِعِ رِجْلَيْهِ الْقِبْلَةَ - كاتێك پێغەمبەر ﷺ سوجده‌ی ببردایه‌، ده‌ستی خۆی له‌ سه‌ر زه‌وی داده‌نا وه‌ په‌نجه‌كانی بڵاو نه‌ده‌كرده‌وه‌ و ده‌ستیشی دانه‌ده‌خست ، وه‌ سەری په‌نجه‌كانی پێ ی ڕوو ده‌كرده‌ قیبله‌) [البخاري 828]\n(وَيَنْهَى أَنْ يَفْتَرِشَ الرَّجُلُ ذِرَاعَيْهِ افْتِرَاشَ السَّبُعِ - پێغەمبەر ﷺ ڕێگری ده‌کرد كه‌ نوێژخوێن ده‌سته‌كانی ڕابخات وەک ڕاخستنی دڕنده‌)[مسلم 498]\n(أُمِرْتُ أَنْ أَسْجُدَ عَلَى سَبْعَةِ أَعْظُمٍ : عَلَى الْجَبْهَةِ - وَأَشَارَ بِيَدِهِ عَلَى أَنْفِهِ - وَالْيَدَيْنِ، وَالرُّكْبَتَيْنِ، وَأَطْرَافِ الْقَدَمَيْنِ، وَلَا نَكْفِتَ الثِّيَابَ وَالشَّعَرَ – فه‌رمانم پێكراوه‌ كه‌ له‌سه‌ر حه‌وت ئه‌ندام سوجده‌ ببه‌م ...). [البخاري 812 مسلم 490]\n(وَإِذَا سَجَدَ قَالَ : « سُبْحَانَ رَبِّيَ الْأَعْلَى «، ثَلَاثَ مَرَّاتٍ) [ابن ماجه 888 «صحيح ابن ماجه 725»]",
                    ),
                    const SizedBox(height: 20),
                    Divider(color: kActiveIconColor),
                    const SizedBox(height: 20),
                    const HeaderNwezhItem(text: "١٤- نێوان هه‌ردوو سوجده"),
                    const SizedBox(height: 20),
                    Text(
                        "بڵێ‌: (اللهُ أَكْبَرُ)، وه‌ هه‌سته‌وه‌ له‌ سوجده‌. \nپێی چه‌پت ڕابخه ‌و له‌سه‌ری دابنیشه‌ ، وه‌ پێی ڕاستت بچه‌قێنه‌ره‌ زه‌وی،وه‌ په‌نجه‌كانی ڕوو بكه‌ره‌‌ قیبله‌. \nوه‌ بڵێ‌: (رَبِّ اغْفِرْ لِي رَبِّ اغْفِرْ لِي). \nجارێكی تر بڵێ: (اللهُ أَكْبَرُ) و سوجده‌ی (دووه‌م‌) ببە.",
                        style: simpleTextStyle.copyWith(
                              fontFamily: fontType.toString(),
                              fontSize: fontSize,
                            ),
                        textAlign: TextAlign.center),
                    const SizedBox(height: 20),
                    const BalgaWidget(
                      description:
                          "(أن النبي صلى اللَّهُ عليه وسلم كان يقول بين السجدتين: ( رَبِّ اغْفِرْ لِي رَبِّ اغْفِرْ لِي ) – پێغه‌مبه‌ر ﷺ له‌ نێوان هه‌ردوو سوجده‌كه‌دا ده‌یفه‌رموو:( رَبِّ اغْفِرْ لِي رَبِّ اغْفِرْ لِي) ) [( صحيح ) الارواء 335 ابن ماجه 888] .",
                    ),
                    const SizedBox(height: 20),
                    Divider(color: kActiveIconColor),
                    const SizedBox(height: 20),
                    const HeaderNwezhItem(text: "١٥- ڕكا‌تی (دووه‌م) بكه‌"),
                    const SizedBox(height: 20),
                    Text(
                        "بڵێ ‌: (اللهُ أَكْبَرُ) وه‌ هه‌سته‌وه‌ وه‌ ڕكا‌تی (دووه‌م) بكه‌ ‌هه‌ر وه‌ك ڕكا‌تی (یه‌كه‌م)",
                        style: simpleTextStyle.copyWith(
                              fontFamily: fontType.toString(),
                              fontSize: fontSize,
                            ),
                        textAlign: TextAlign.center),
                    const SizedBox(height: 20),
                    const BalgaWidget(
                      description:
                          "(ثُمَّ يَفْعَلُ ذَلِكَ فِي الصَّلَاةِ كُلِّهَا حَتَّى يَقْضِيَهَا - پاشان پێغەمبەر ﷺ هه‌مان كاری ئه‌نجام ده‌دایه‌وه‌ هه‌تاوه‌كو نوێژه‌كه‌ی كۆتایی پێده‌هێنا). [البخاري 789]",
                    ),
                    const SizedBox(height: 20),
                    Divider(color: kActiveIconColor),
                    const SizedBox(height: 20),
                    const HeaderNwezhItem(text: "١٦- ته‌حیات بخوێنه‌"),
                    const SizedBox(height: 20),
                    Text(
                        "له دوای ئه‌وه‌ی سوجده‌ی (دووه‌م) ده‌بەیت له‌ ڕكاتی (دووه‌م) د‌ابنیشه‌ له‌سه‌ر پێی چه‌پت به‌ ڕاخراوی،وه‌ پێی ڕاستت بچه‌قێنه‌ره‌ زه‌وی به‌هه‌مان شێوازی دانیشتنی نێوان دوو سوجده‌كه‌‌.\nته‌حیات بخوێنه‌ و بڵێ:",
                        style: simpleTextStyle.copyWith(
                              fontFamily: fontType.toString(),
                              fontSize: fontSize,
                            ),
                        textAlign: TextAlign.center),
                    const SizedBox(height: 10),
                    Text(
                      "(التَّحِيَّاتُ للهِ وَالصَّلَوَاتُ وَالطَّيِّبَاتُ، السَّلَامُ عَلَيْكَ أَيُّهَا النَّبِيُّ وَرَحْمَةُ اللهِِ وَبَرَكَاتُهُ، السَّلَامُ عَلَيْنَا وَعَلَى عِبَادِ اللهِ الصَّالِحِينَ ؛ أَشْهَدُ أَنْ لَا إِلَهَ إِلَّا اللهُ، وَأَشْهَدُ أَنَّ مُحَمَّدًا عَبْدُهُ وَرَسُولُهُ )",
                      style: quranStyle.copyWith(   fontFamily: quranFontType.toString(),
                        fontSize: quranFontSize,),
                      textAlign: TextAlign.center,
                    ),
                    const SizedBox(height: 10),
                    Text(
                      "[البخاري 831]",
                      style: simpleTextStyle.copyWith(
                              fontFamily: fontType.toString(),
                              fontSize: fontSize,
                            ),
                      textAlign: TextAlign.center,
                    ),
                    const SizedBox(height: 10),
                    Text(
                        "(اللَّهُمَّ صَلِّ عَلَى مُحَمَّدٍ وَعَلَى آلِ مُحَمَّدٍ، كَمَا صَلَّيْتَ عَلَى إِبْرَاهِيمَ وَعَلَى آلِ إِبْرَاهِيمَ، إِنَّكَ حَمِيدٌ مَجِيدٌ، اللَّهُمَّ بَارِكْ عَلَى مُحَمَّدٍ وَعَلَى آلِ مُحَمَّدٍ، كَمَا بَارَكْتَ عَلَى إِبْرَاهِيمَ وَعَلَى آلِ إِبْرَاهِيمَ، إِنَّكَ حَمِيدٌ مَجِيدٌ)",
                        style: quranStyle.copyWith(   fontFamily: quranFontType.toString(),
                        fontSize: quranFontSize,),
                        textAlign: TextAlign.center),
                    const SizedBox(height: 10),
                    Text("[البخاري 3370]",
                        style: simpleTextStyle.copyWith(
                              fontFamily: fontType.toString(),
                              fontSize: fontSize,
                            ), textAlign: TextAlign.center),
                    const SizedBox(height: 20),
                    Divider(color: kActiveIconColor),
                    const SizedBox(height: 20),
                    const HeaderNwezhItem(text: "١٧- ڕكاتی (3 و 4) بكه‌"),
                    const SizedBox(height: 20),
                    Text(
                        "له‌دوای ئه‌وه‌ی كه‌ ته‌حیاتی یه‌كه‌م ده‌خوێنیت هه‌سته‌وه‌ و بڵێ:(اللهُ أَكْبَرُ). وه‌ ده‌سته‌كانت به‌رزبكه‌ره‌وه‌‌ و ڕكاتی (3 و4) بكه‌ وه‌كو ڕكاته‌كانی تر.\nوه‌ ده‌شتوانیت له‌ ڕكاتی (3 و4) جار جار له‌دوای سوره‌تی (الفاتحة) سوره‌تێكی تر بخوێنیت .",
                        style: simpleTextStyle.copyWith(
                              fontFamily: fontType.toString(),
                              fontSize: fontSize,
                            ),
                        textAlign: TextAlign.center),
                    const SizedBox(height: 20),
                    const BalgaWidget(
                        description:
                            "(ثُمَّ يَفْعَلُ ذَلِكَ فِي الصَّلَاةِ كُلِّهَا حَتَّى يَقْضِيَهَا - پاشان پێغه‌مبه‌ر ﷺ هه‌مان كاری ده‌كرد هه‌تاوه‌كو نوێژه‌كه‌ی كۆتایی پێده‌هێنا). [البخاري 789]"),
                    const SizedBox(height: 20),
                    Divider(color: kActiveIconColor),
                    const SizedBox(height: 20),
                    const HeaderNwezhItem(text: "١٨- ته‌حیاتی كۆتایی بخوێنه‌"),
                    const SizedBox(height: 20),
                    Text(
                        "دوای ئه‌وه‌ی سوجده‌ی (دووه‌م) ده‌بەیت له‌ ڕكاتی (چواره‌م) دابنیشه‌ به‌شێوازی ته‌وه‌ڕوك هه‌روه‌ك چۆن ئاماژه‌ی پێده‌كه‌ین.\nوه‌ ته‌حیات بخوێنه ، وه‌ ئه‌م نزایه‌شی ‌بۆ زیادبكه‌: (اللَّهُمَّ إِنِّي أَعُوذُ بِكَ مِنْ عَذَابِ الْقَبْرِ وَمِنْ عَذَابِ النَّارِ وَمِنْ فِتْنَةِ الْمَحْيَا وَالْمَمَاتِ وَمِنْ فِتْنَةِ الْمَسِيحِ الدَّجَّالِ).\nدوای هه‌موو ته‌حیاتێكی كۆتایی ئه‌م نزایه‌ له‌ بیرمه‌كه‌ چونكه‌: واجبه‌ بیخوێنیت.",
                        style: simpleTextStyle.copyWith(
                              fontFamily: fontType.toString(),
                              fontSize: fontSize,
                            ),
                        textAlign: TextAlign.center),
                    const SizedBox(height: 20),
                    const BalgaWidget(
                      description:
                          "له‌به‌ر فه‌رمایشتی پێغەمبەر ﷺ: (إِذَا تَشَهَّدَ أَحَدُكُمْ، فَلْيَسْتَعِذْ بِاللَّهِ مِنْ أَرْبَعٍ يَقُولُ : اللَّهُمَّ إِنِّي أَعُوذُ بِكَ مِنْ عَذَابِ جَهَنَّمَ، وَمِنْ عَذَابِ الْقَبْرِ، وَمِنْ فِتْنَةِ الْمَحْيَا وَالْمَمَاتِ، وَمِنْ شَرِّ فِتْنَةِ الْمَسِيحِ الدَّجَّالِ)[البخاري 1377 مسلم 588]",
                    ),
                    const SizedBox(height: 20),
                    Divider(color: kActiveIconColor),
                    const SizedBox(height: 20),
                    const HeaderNwezhItem(
                        text: "١٩- به‌ شێوازی ته‌وه‌ڕوك ‌دابنیشه‌"),
                    const SizedBox(height: 20),
                    Text(
                        "ئه‌و نوێژه‌ی دوو ته‌حیاتی تێدایه‌،وه‌ك: (نیوه‌ڕۆ - عه‌سر - ئێواره‌ - خه‌وتنان) ده‌توانیت شێوه‌دانیشتنی (ته‌وه‌ڕوك) له‌ ته‌حیاتی كۆتایی دا به‌كاربهێنیت‌.\nشێوازه‌كه‌ی: پێی ڕاستت ده‌چه‌قێنیت، وه‌ پێی ‌چه‌پت ده‌خه‌یته‌ ژێر پێ ی ڕاستت .",
                        style: simpleTextStyle.copyWith(
                              fontFamily: fontType.toString(),
                              fontSize: fontSize,
                            ),
                        textAlign: TextAlign.center),
                    const SizedBox(height: 20),
                    const BalgaWidget(
                        description:
                            "له‌به‌ر كرده‌ی پێغه‌مبه‌ر ﷺ:(وَإِذَا جَلَسَ فِي الرَّكْعَةِ الْآخِرَةِ قَدَّمَ رِجْلَهُ الْيُسْرَى وَنَصَبَ الْأُخْرَى وَقَعَدَ عَلَى مَقْعَدَتِهِ ) [البخاري 828]. \n (حَتَّى إِذَا كَانَتِ السَّجْدَةُ الَّتِي فِيهَا التَّسْلِيمُ أَخَّرَ رِجْلَهُ الْيُسْرَى وَقَعَدَ مُتَوَرِّكًا عَلَى شِقِّهِ الْأَيْسَرِ. قَالُوا : صَدَقْتَ، هَكَذَا كَانَ يُصَلِّي صَلَّى اللَّهُ عَلَيْهِ وَسَلَّمَ.) [صحيح سنن أبي داود 730]"),
                    const SizedBox(height: 20),
                    Divider(color: kActiveIconColor),
                    const SizedBox(height: 20),
                    const HeaderNwezhItem(
                        text: "٢٠- چۆنیه‌تی دانیشتنت له‌ ته‌حیات"),
                    const SizedBox(height: 20),
                    Text(
                        "له‌و كاته‌ی كه‌ ته‌حیات ده‌خوێنیت:\nده‌ستی ڕاستت له‌سه‌ر ڕانی ڕاستت دابنێ ، وه‌ دەستی چه‌پت له‌سه‌ر ڕانی چه‌پت دابنێ. وه‌ په‌نجه‌كانی ده‌ستی چه‌پت ته‌خت بكه‌،وه‌ په‌نجه‌كانی دەستی ڕاستت بنوشتێنه‌ره‌‌وه‌ جگه‌ له‌ په‌نجه‌ی شایه‌تومان.\nكاتێك كه‌ ته‌حیات ده‌خوێنیت سه‌یری په‌نجه‌ی شایه‌تومانت بكه‌ و په‌نجه‌ی شایه‌تومان به‌رزبکەره‌وه‌.",
                        style: simpleTextStyle.copyWith(
                              fontFamily: fontType.toString(),
                              fontSize: fontSize,
                            ),
                        textAlign: TextAlign.center),
                    const SizedBox(height: 20),
                    const BalgaWidget(
                        description:
                            "(أَنَّ النَّبِيَّ صَلَّى اللَّهُ عَلَيْهِ وَسَلَّمَ كَانَ إِذَا جَلَسَ فِي الصَّلَاةِ، وَضَعَ يَدَيْهِ عَلَى رُكْبَتَيْهِ، وَرَفَعَ إِصْبَعَهُ الْيُمْنَى الَّتِي تَلِي الْإِبْهَامَ، فَدَعَا بِهَا، وَيَدَهُ الْيُسْرَى عَلَى رُكْبَتِهِ الْيُسْرَى بَاسِطَهَا عَلَيْهَا)\n[مسلم 580]\n(فَوَضَعَ يَدَهُ الْيُمْنَى عَلَى فَخِذِهِ الْيُمْنَى، وَأَشَارَ بِأُصْبُعِهِ الَّتِي تَلِي الْإِبْهَامَ فِي الْقِبْلَةِ، وَرَمَى بِبَصَرِهِ إِلَيْهَا أَوْ نَحْوِهَا، ثُمَّ قَالَ : هَكَذَا رَأَيْتُ رَسُولَ اللَّهِ صَلَّى اللَّهُ عَلَيْهِ وَسَلَّمَ يَصْنَعُ.)\n [قال الألباني: «حسن صحيح» في صحيح سنن النسائي 1160]"),
                    const SizedBox(height: 20),
                    Divider(color: kActiveIconColor),
                    const SizedBox(height: 20),
                    const HeaderNwezhItem(text: "٢١- سه‌لام بده‌وه‌"),
                    const SizedBox(height: 20),
                    Text(
                        "له دوای ئه‌وه‌ی كه‌ ته‌حیاتی كۆتاییت خوێند، ‌سه‌لام بده‌ره‌‌وه‌.\nسه‌ره‌تا به‌لای ڕاستدا سه‌لام بده‌ره‌‌وه‌ و بڵێ (السَّلَامُ عَلَيْكُمْ وَرَحْمَةُ اللهِ) پاشان به‌لای چه‌پدا‌ سه‌لام بده‌ره‌وه‌ و بڵێ (السَّلَامُ عَلَيْكُمْ وَرَحْمَةُ اللهِ).",
                        style: simpleTextStyle.copyWith(
                              fontFamily: fontType.toString(),
                              fontSize: fontSize,
                            ),
                        textAlign: TextAlign.center),
                    const SizedBox(height: 20),
                    const BalgaWidget(
                        description:
                            "وَكَانَ يَخْتِمُ الصَّلَاةَ بِالتَّسْلِيمِ - پێغەمبەر ﷺ به‌ سه‌لام دانه‌وه‌ كۆتایی به‌ نوێژ ده‌هێنا) \n[مسلم 498] \n(كُنَّا إِذَا صَلَّيْنَا مَعَ رَسُولِ الله صَلَّى الله عَلَيْهِ وَسَلَّمَ، قُلْنَا : السَّلَامُ عَلَيْكُمْ وَرَحْمَةُ الله، السَّلَامُ عَلَيْكُمْ وَرَحْمَةُ الله)\n[مسلم 431] \n(كُنْتُ أَرَى رَسُولَ الله صَلَّى الله عَلَيْهِ وَسَلَّمَ يُسَلِّمُ عَنْ يَمِينِهِ وَعَنْ يَسَارِهِ، حَتَّى أَرَى بَيَاضَ خَدِّهِ) \n[مسلم 582]")
                  ]),
            ),
          ),
        ],
      ),
    );
  }

  Widget sortLine(String title) {
    return Column(
      children: [
        const SizedBox(height: 10),
        Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
                color: thirdColor.withValues(alpha: 0.2),
                borderRadius: BorderRadius.circular(10)),
            child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.end,
                children: <Widget>[
                  Container(
                      padding: const EdgeInsets.all(8),
                      decoration: BoxDecoration(
                          color: kActiveIconColor.withValues(alpha: 0.5),
                          shape: BoxShape.circle)),
                  const SizedBox(height: 8),
                  Text(
                    title,
                    style: simpleTextStyle.copyWith(
                              fontFamily: fontType.toString(),
                              fontSize: fontSize,
                            ),
                    textAlign: TextAlign.center,
                  ),
                ])),
      ],
    );
  }
}
