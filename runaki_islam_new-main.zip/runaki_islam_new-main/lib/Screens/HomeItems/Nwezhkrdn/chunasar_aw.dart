import 'package:flutter/material.dart';
import 'package:runaki_islam/util/background.dart';
import 'package:runaki_islam/util/constans.dart';
import 'package:runaki_islam/widgets/nwezh/header_nwezh.dart';
import 'package:runaki_islam/providers/settings_provider.dart';
import 'package:provider/provider.dart';
import 'package:runaki_islam/widgets/nwezh/balga.dart';

class SarAw extends StatefulWidget {
  final String? sarder;

  const SarAw({super.key, this.sarder});
  @override
  State<StatefulWidget> createState() => _SarAwState();
}

class _SarAwState extends State<SarAw> {
  int? fontType;
  int? quranFontType;
  double? quranFontSize;
  double? fontSize;

  @override
  void initState() {
    super.initState();
    fontType = Provider.of<SettingsProvider>(context, listen: false)
        .getsettingField('font_family');
    quranFontType = Provider.of<SettingsProvider>(context, listen: false)
        .getsettingField('quran_font_family');
    quranFontSize = Provider.of<SettingsProvider>(context, listen: false)
        .getsettingField('quran_font_size');
    fontSize = Provider.of<SettingsProvider>(context, listen: false)
        .getsettingField('font_size');
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: backgroundColor,
      appBar: AppBar(
        centerTitle: true,
        title: Text(
          widget.sarder!,
          style:
              TextStyle(fontFamily: fontType.toString(), color: titleTextColor),
        ),
        backgroundColor: thirdColor,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_rounded),
          color: iconColor,
          onPressed: () {
            Navigator.pop(context);
          },
        ),
      ),
      body: Stack(
        children: [
          const Background2(),
          SingleChildScrollView(
            padding:
                const EdgeInsets.only(right: 10, left: 10, top: 20, bottom: 80),
            physics: const BouncingScrollPhysics(
                parent: AlwaysScrollableScrollPhysics()),
            scrollDirection: Axis.vertical,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: <Widget>[
                const HeaderNwezhItem(text: "ویردی چوونه‌ سه‌رئاو"),
                const SizedBox(height: 12),
                Text(
                  ": بڵێ    ",
                  style: simpleTextStyle.copyWith(
                    fontFamily: fontType.toString(),
                    fontSize: fontSize,
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.symmetric(vertical: 6),
                  child: Text(
                      "( بِسْمِ الله ِ، اللَّهُمَّ إِنِّي أَعُوذُ بِكَ مِنَ الْخُبْثِ وَالْخَبائِث )",
                      style: quranStyle.copyWith(
                        fontFamily: quranFontType.toString(),
                        fontSize: quranFontSize,
                      ),
                      textAlign: TextAlign.center),
                ),
                Text(
                  "پاشان بە پێی چەپت بچۆرە ژوورەوە",
                  textAlign: TextAlign.right,
                  style: simpleTextStyle.copyWith(
                      fontFamily: fontType.toString(), fontSize: fontSize),
                ),
                const SizedBox(height: 20),
                Container(
                    height: 200,
                    decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(20),
                        border: Border.all(color: thirdColor, width: 1),
                        image: const DecorationImage(
                            fit: BoxFit.fill,
                            image: AssetImage("assets/images/sar_aw.jpg")))),
                const SizedBox(height: 20),
                const BalgaWidget(
                  description:
                      "(په‌رده‌ی نێوان چاوی جنۆكه‌كان و عه‌وره‌تی ئاده‌میزاد ئه‌وه‌یه‌ كه‌وا یه‌كێكیان چووه‌ سه‌ر ئاو بڵێت: بسم الله)[ابن ماجة و الترمذي. صحيح الجامع: 3611]، وه‌ فه‌رمووده‌ی ئەنەس -رضي الله عنه- كاتێك كه‌ پێغەمبەر ﷺ د‌ه‌چووه‌ سه‌رئاو ده‌یفه‌رموو: (اللَّهُم إني أعوذ بك من الخبث والخبائث - واته‌: ئه‌ی خوایه‌ په‌نات پێ ده‌گرم له نێرینه‌‌ و مێیینه‌ی شه‌یتانه‌كانی جنۆكه‌) [البخاري: 142 ، مسلم: 375]",
                ),
                const SizedBox(height: 20),
                Divider(
                  color: kActiveIconColor,
                ),
                const SizedBox(height: 20),
                const HeaderNwezhItem(text: "ویردی هاتنه‌ ده‌ر له‌ سه‌رئاو"),
                const SizedBox(height: 20),
                Text(
                  " : به‌ پێی ڕاستت بڕۆ د‌‌ه‌ره‌وه‌ و پاشان بڵێ",
                  textAlign: TextAlign.right,
                  style: simpleTextStyle.copyWith(
                      fontFamily: fontType.toString(), fontSize: fontSize),
                ),
                Padding(
                  padding: const EdgeInsets.symmetric(vertical: 20),
                  child: Center(
                    child: Text("(غُفْرَانَكَ)",
                        style: quranStyle.copyWith(
                            fontFamily: quranFontType.toString(),
                            fontSize: quranFontSize),
                        textAlign: TextAlign.center),
                  ),
                ),
                const SizedBox(height: 20),
                const BalgaWidget(
                  description:
                      "فه‌رمووده‌ی عائیشه‌ -رضي الله عنها- كاتێك كه‌ پێغەمبەر ﷺ له‌ سه‌رئاو ده‌هاته‌ ده‌ره‌وه‌ ده‌یفه‌رموو: (غفرانك - واته‌: ئه‌ی خوایه‌ داوای لێخۆشبوونت لێ ده‌كه‌م‌) [صحيح الجامع(4707)]",
                )
              ],
            ),
          ),
        ],
      ),
    );
  }
}
