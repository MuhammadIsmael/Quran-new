import 'package:background_app_bar/background_app_bar.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_staggered_animations/flutter_staggered_animations.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:runaki_islam/Screens/HomeItems/Nwezhkrdn/qdast_nwezh.dart';
import 'package:runaki_islam/Screens/HomeItems/Nwezhkrdn/bangdan.dart';
import 'package:runaki_islam/Screens/HomeItems/Nwezhkrdn/batalkary_nwezh.dart';
import 'package:runaki_islam/Screens/HomeItems/Nwezhkrdn/chunasar_aw.dart';
import 'package:runaki_islam/Screens/HomeItems/Nwezhkrdn/dastnwezh.dart';
import 'package:runaki_islam/Screens/HomeItems/Nwezhkrdn/hala_bawakan.dart';
import 'package:runaki_islam/Screens/HomeItems/Nwezhkrdn/j_nwezhakan.dart';
import 'package:runaki_islam/Screens/HomeItems/Nwezhkrdn/manay_nwezh.dart';
import 'package:runaki_islam/Screens/HomeItems/Nwezhkrdn/manay_tahyat.dart';
import 'package:runaki_islam/Screens/HomeItems/Nwezhkrdn/nwezh.dart';
import 'package:runaki_islam/Screens/HomeItems/Nwezhkrdn/q_nwezh.dart';
import 'package:runaki_islam/Screens/HomeItems/Nwezhkrdn/tayamum.dart';
import 'package:runaki_islam/util/background.dart';
import 'dart:ui';
import 'package:runaki_islam/providers/settings_provider.dart';
import 'package:provider/provider.dart';
import 'package:runaki_islam/util/constans.dart';
import 'package:runaki_islam/util/navigate_between_pages/fade_route.dart';
import 'package:runaki_islam/util/navigate_between_pages/scale_route.dart';
import 'package:runaki_islam/util/navigate_between_pages/size_route.dart';

class NwezhPage extends StatefulWidget {
  const NwezhPage({super.key});

  @override
  State<StatefulWidget> createState() => _NwezhPageState();
}

class _NwezhPageState extends State<NwezhPage>
    with SingleTickerProviderStateMixin {
  List<Nwezh> nwezhList = [];

  int? fontType;
  @override
  void initState() {
    super.initState();
    fontType = Provider.of<SettingsProvider>(
      context,
      listen: false,
    ).getsettingField('font_family');
    nwezhList.add(Nwezh(title: "چوونە سەرئاو"));
    nwezhList.add(Nwezh(title: "تەیەمموم"));
    nwezhList.add(Nwezh(title: "دەستنوێژ"));
    nwezhList.add(Nwezh(title: "هەڵە باوەکان"));
    nwezhList.add(Nwezh(title: "نوێژکردن"));
    nwezhList.add(Nwezh(title: "مانای تەحیات"));
    nwezhList.add(Nwezh(title: "مانای نوێژ"));
    nwezhList.add(Nwezh(title: "پرسیار دەربارەی دەستنوێژ"));
    nwezhList.add(Nwezh(title: "پرسیار دەربارەی نوێژ"));
    nwezhList.add(Nwezh(title: "بانگدان"));
    nwezhList.add(Nwezh(title: "شەو نوێژ"));
    nwezhList.add(Nwezh(title: "نوێژی چێشتەنگاو"));
    nwezhList.add(Nwezh(title: "نوێژی ئیستیخارە"));
    nwezhList.add(Nwezh(title: "نوێژی تۆبەکردن"));
    nwezhList.add(Nwezh(title: "نوێژە فەرزەکان"));
    nwezhList.add(Nwezh(title: "نوێژی جەژن"));
    nwezhList.add(Nwezh(title: "زیکرەکان"));
    nwezhList.add(Nwezh(title: "بەتاڵکەری نوێژ"));
  }
  // nwezhList.add(Nwezh(
  //   title: "",
  // ));

  @override
  Widget build(BuildContext context) {
    final bool isDark = Theme.of(context).brightness == Brightness.dark;
    final SystemUiOverlayStyle overlayStyle =
        (isDark ? SystemUiOverlayStyle.light : SystemUiOverlayStyle.dark)
            .copyWith(
              statusBarColor: Colors.transparent,
              systemNavigationBarColor: Colors.transparent,
              systemNavigationBarDividerColor: Colors.transparent,
              statusBarIconBrightness: isDark
                  ? Brightness.light
                  : Brightness.dark,
              systemNavigationBarIconBrightness: isDark
                  ? Brightness.light
                  : Brightness.dark,
              statusBarBrightness: isDark ? Brightness.dark : Brightness.light,
              systemStatusBarContrastEnforced: false,
              systemNavigationBarContrastEnforced: false,
            );

    return AnnotatedRegion<SystemUiOverlayStyle>(
      value: overlayStyle,
      child: Scaffold(
        extendBodyBehindAppBar: true,
        extendBody: true,
        backgroundColor: bgColor,
        body: NestedScrollView(
          physics: const BouncingScrollPhysics(),
          headerSliverBuilder: (_, _) => <Widget>[
            SliverAppBar(
              leading: IconButton(
                icon: Icon(Icons.arrow_back_ios_rounded, color: iconColor),
                onPressed: () {
                  Navigator.pop(context);
                },
              ),
              expandedHeight: 200,
              floating: false,
              pinned: true,
              snap: false,
              elevation: 0.0,
              backgroundColor: Colors.transparent,
              flexibleSpace: BackgroundFlexibleSpaceBar(
                collapseMode: CollapseMode.parallax,
                centerTitle: true,
                title: Text(
                  "نوێژەکانم",
                  style: bigTextStyle.copyWith(
                    fontFamily: fontType.toString(),
                    color: Colors.white,
                  ),
                ),
                titlePadding: const EdgeInsets.all(50),
                background: ClipRect(
                  child: Container(
                    decoration: const BoxDecoration(
                      image: DecorationImage(
                        image: AssetImage("assets/images/read-quran.jpg"),
                        fit: BoxFit.fill,
                      ),
                    ),
                    child: BackdropFilter(
                      filter: ImageFilter.blur(sigmaX: 5.0, sigmaY: 5.0),
                      child: Container(
                        decoration: BoxDecoration(
                          color: thirdColor.withValues(alpha: 0.5),
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ],
          body: Stack(
            children: [
              const Background2(),
              Column(
                children: [
                  Expanded(
                    child: Center(
                      child: AnimationLimiter(
                        child: GridView.builder(
                          itemCount: nwezhList.length,
                          physics: const BouncingScrollPhysics(
                            parent: AlwaysScrollableScrollPhysics(),
                          ),
                          padding: const EdgeInsets.only(
                            left: 10,
                            right: 10,
                            top: 10,
                            bottom: 30,
                          ),
                          gridDelegate:
                              const SliverGridDelegateWithFixedCrossAxisCount(
                                crossAxisCount: 2,
                                crossAxisSpacing: 10,
                              ),
                          itemBuilder: (BuildContext context, i) {
                            final a = nwezhList[i];
                            return AnimationConfiguration.staggeredGrid(
                              position: i,
                              columnCount: 2,
                              duration: const Duration(milliseconds: 500),
                              child: SlideAnimation(
                                duration: const Duration(milliseconds: 800),
                                horizontalOffset: 50,
                                verticalOffset: 300,
                                child: ScaleAnimation(
                                  duration: const Duration(milliseconds: 1200),
                                  curve: Curves.fastLinearToSlowEaseIn,
                                  child: homePageCardsGroup(
                                    kActiveIconColor,
                                    "assets/icons/praying.svg",
                                    a.title!,
                                    () {
                                      if (i == 0) {
                                        Navigator.push(
                                          context,
                                          SizeRoute(
                                            page: const SarAw(
                                              sarder: "چوونە سەرئاو",
                                            ),
                                          ),
                                        );
                                      }
                                      if (i == 1) {
                                        Navigator.push(
                                          context,
                                          ScaleRoute(
                                            page: const Tayamum(
                                              sarder: "تەیەمموم",
                                            ),
                                          ),
                                        );
                                      }
                                      if (i == 2) {
                                        Navigator.push(
                                          context,
                                          FadeRoute(
                                            page: const DastNwezh(
                                              sarder: "دەستنوێژ",
                                            ),
                                          ),
                                        );
                                      }
                                      if (i == 3) {
                                        Navigator.push(
                                          context,
                                          SizeRoute(
                                            page: const HalaBawakan(
                                              sarder: "هەڵە باوەکان",
                                            ),
                                          ),
                                        );
                                      }
                                      if (i == 4) {
                                        Navigator.push(
                                          context,
                                          ScaleRoute(
                                            page: const NwezhKrdn(
                                              sarder: "نوێژکردن",
                                            ),
                                          ),
                                        );
                                      }
                                      if (i == 5) {
                                        Navigator.push(
                                          context,
                                          FadeRoute(
                                            page: const ManayTahyat(
                                              sarder: "مانای تەحیات",
                                            ),
                                          ),
                                        );
                                      }
                                      if (i == 6) {
                                        Navigator.push(
                                          context,
                                          SizeRoute(
                                            page: const ManayNwezh(
                                              sarder: "مانای نوێژ",
                                            ),
                                          ),
                                        );
                                      }
                                      if (i == 7) {
                                        Navigator.push(
                                          context,
                                          ScaleRoute(
                                            page: const QDastNwezh(
                                              sarder:
                                                  "پرسیار دەربارەی دەستنوێژ",
                                            ),
                                          ),
                                        );
                                      }
                                      if (i == 8) {
                                        Navigator.push(
                                          context,
                                          SizeRoute(
                                            page: const QNwezh(
                                              sarder: " پرسیار دەربارەی نوێژ",
                                            ),
                                          ),
                                        );
                                      }
                                      if (i == 9) {
                                        Navigator.push(
                                          context,
                                          FadeRoute(
                                            page: const Bangdan(
                                              sarder: "بانگدان",
                                            ),
                                          ),
                                        );
                                      }
                                      if (i == 10) {
                                        Navigator.push(
                                          context,
                                          ScaleRoute(
                                            page: JNwezhakan(
                                              sarder: a.title,
                                              text:
                                                  "بسم الله الرحمن الرحیم\nسوپاس و ستایش بۆ خواى گەورە وە درودو سڵاو لە سەر گیانى پێغەمبەرى خوا وە لەسەر خێزان و كەس وكارى ئیماندارو هاوەڵان و شوێن كەوتوانى تا رۆژى دوایى\n\n\n١- كاتەكەی لەدوای نوێژی عيشا دەست پێدەكات هەتا پێش بانگی بەيانی ؛ واتە هەركاتێك لەم كاتانەدا بکرێت دروستە ؛ بەڵام کۆتایی شەو لەهەمووی باشترە و خێر ترە .\n\n\n٢- ژماره‌ی ركه‌عه‌ته‌كانی پێك هاتووە لە يازدە ركه‌عه‌ت ؛ دوو ركه‌عه‌ت دوو ركه‌عه‌ت دەكرێت ئينجا لەكۆتايی يەك ركه‌عه‌ت دەكرێت ؛ وە هەندێک لەزانایان فەرمویانە ئەگەر لە یازدە رکەعەت زیاتریش بکرێت دروستە و ئاساییە .\n\n\n٣- مەرج نيە ئیلا بخەویت ئينجا هەڵبستیت شةونوێژ بكەی ؛ دروستە يەكسەر لەدوای نوێژی عيشا راستەوخۆ شەو نوێژەکەت بكەیت و ئاساییە ؛ بەڵام چەند درەنگتربێت خيرترە و باشترە .\n\n\n٤- وە نيەت هێنانيش بەدڵەو بەزمان نيە ؛ بەدڵ نيەتت هەبێت كە ئەم شەونوێژە تەنها لە پێناو خوای گەورە ئەنجام دەدەیت .\n\n\n٥- وە سەبارەت بەفەزڵەکەی پێغەمبەری خوا صلى الله عليه وسلم فەرمویەتی : ( أَفْضَلُ الصَّلَاةِ بَعْدَ الْفَرِيضَةِ صَلَاةُ اللَّيْلِ) رواه مسلم .\nواته‌ : گه‌وره‌ترین و چاکترین نوێژ له‌دوای نوێژه‌ فه‌ڕزه‌كان شه‌ونوێژه ‌.\n\n\n",
                                            ),
                                          ),
                                        );
                                      }
                                      if (i == 11) {
                                        Navigator.push(
                                          context,
                                          SizeRoute(
                                            page: JNwezhakan(
                                              sarder: a.title,
                                              text:
                                                  "بسم الله الرحمن الرحیم\nسوپاس و ستایش بۆ خواى گەورە وە درودو سڵاو لە سەر گیانى پێغەمبەرى خوا وە لەسەر خێزان و كەس وكارى ئیماندارو هاوەڵان و شوێن كەوتوانى تا رۆژى دوایى\n\n\n1- كاتەکەی لەدوای خۆرهەڵاتن بەئەندازەی رمحێک دەست پێ دەکات (واتە چارەگێك دوای دەرکەوتنی خۆر) هەتا پێش گەییشتنی خۆر بەناوەڕاستی ئاسمانەوە (واتە ١٠ دەقە یان ١٥ دەقە پێش بانگی نیوەرۆ).\n\n\n٢- باشترین کاتی ئەوکاتەیە کە خۆر زۆر گەرم دەبێت (کە دەکاتە ٢ سعات پێش بانگی نیوەرۆ) والله أعلم . \n\n\n٣ -ژمارەی رکەعەتەکانی له ٢ رکاعەت هەتا ٨ رکاعەت دەکرێت . \n\n\n٤- فەزڵەکەی وەکو ئەوە وایە سەدەقەت بەرامبەر هەرئەندامێك لە ئەندامەکانی لاشەت کردبێت.\nوە بە نوێژی تەوبەکاران ناسراوە.\n",
                                            ),
                                          ),
                                        );
                                      }
                                      if (i == 12) {
                                        Navigator.push(
                                          context,
                                          FadeRoute(
                                            page: JNwezhakan(
                                              sarder: a.title,
                                              text:
                                                  "نوێژی (الإستخارە)\n\nجابرى كوڕى عبدالله (ڕەزای خودایان لێبێت) دەفەرمووێت \n\nپێغەمبەری خودا (ﷺ) نوێژی (الإستخارە)ی فێردەکردین ، کە لە ھەموو کارێکی دونیاییدا ئەنجامی بدەین، ھەر وەکو چۆن سوورەتێکی قورئانی فێردەکردین، پێغەمبەری خودا (ﷺ) پێی دەفەرمووین: ھەریەکێک لە ئێوە ویستی شتێک بکات ئەوە با دوو ڕکات نوێژی سوننەت بکات، پاشان بڵێ\n.\nاللَّهُمَّ إِنِّي أَسْتَخِيرُكَ بِعِِلْمِكَ, وَأَسْتَقْدِرُكَ بِقُدْرَتِكَ, وَأَسْأَلُكَ مِنْ فَضْلِكَ الْعَظِيم, فَإِنَّكَ تَقْدِرُ وَلا أَقْدِرُ, وَتَعْلَمُ وَلاَ أَعْلَمُ, وَأَنْتَ عَلاَّمُ الْغُيُوبِ, اللَّهُمَّ إِنْ كُنْتَ تَعْلَمُ أَنَّ هَذَا الأَمْرَ ـ ناوی پێداویستیەکەی دەھێنێت ـ خَيْرٌ لِي في دِينِي وَمَعَاشِي وَعَاقِبَةِ أَمْرِي ـ یان فەرمووی: عَاجِلِهِ وَآجِلِهِ ـ فَاقْدُرْهُ لِي وَيَسِّرْهُ لِي ثُمَّ بَارِكْ لِي فِيهِ, وَإِنْ كُنْتَ تَعْلَمُ أَنَّ هَذَا الأَمْرَ شَرٌّ لِي في دِينِي وَمَعَاشِي وَعَاقِبَةِ أَمْرِي ـ یان فەرمووی - عَاجِلِهِ وَآجِلِهِ ـ فَاصْرِفْهُ عَنِّي وَاصْرِفْنِي عَنْهُ وَاقْدُرْ لِيَ الْخَيْرَ حَيْثُ كَانَ ثُمَّ أَرْضِنِي بِهِ\n.\nواتە: خودایە من بە عیلم و زانیاری خۆت داوای خێر و چاکەت لێدەکەم و کار و باری خۆم بە تۆ دەسپێرم، خودایە بە قودرەت و توانایی خۆت داوای تواناییت لێدەکەم، خودایە لە فەزڵ و گەورەییت داوات لێدەکەم، خودایە بەڕاستی تۆ دەتوانیت و من ناتوانم، تۆ دەزانیت و من نازانم، تۆ زۆر زانای بە نھێنیەکان و غەیبیەکان، خودایە تۆ دەزانیت، ئەگەر ئەم کارە - ناوی پێداویستیەکەی دەھێنێت - سوود و خێری تێدایە بۆ خۆم و ئایین و ژیان و کۆتایی تەمەنم، یان ئێستا و کۆتاییم، خودایە ئەوە بەنسیبمی بکە و ئاسانی بکە بۆم و پاشان سوود و بەرەکەتیشی تێبکە بۆم، خودایە خۆت باش دەزانیت خۆ، ئەگەر ئەم کارە شەڕە و خراپە بۆ خۆم و ئایین و ژیان و کۆتایی تەمەنم، یان ئێستا و کۆتاییم، خودایە ئەوە پێم نەبەخشیت و لێمی دوور بخەرەوە و منیش لەو دوور بخەرەوە و بۆشمی ئاسان نەکەیت کە ئەنجامی بدەم سوود و خێرم بە نسیب بکە لە ھەر شوێنێکەو پاشان ڕازیم بکە پێی.\n\n\nئەوکەسە پەشیمان نابێتەوە لە ئەنجامدانی کارەکەی و کە ئیستیخارە بە خودا بکات و ڕاوێژ بە بەندە باوەڕدارەکانی خوداش بکات، خودای پاک و\nبێگەرد دەفەرمووێت:\nوَشَاوِرْهُمْ فِي الأَمْرِ فَإِذَا عَزَمْتَ\nفَتَوَكَّلْ عَلَى اللّهِ [آل عمران: ١٥٩]\n.\nواتە : لە کارەکانتدا ڕاوێژ بە باوەڕداران بکە، کاتێکیش، کە دڵت چەسپا لە سەر کارەکەت ئەوە پشت و تەوەککول بە خودا ببەستە.\n.\nالبخاري ٧ / ١٦٢ .",
                                            ),
                                          ),
                                        );
                                      }
                                      if (i == 13) {
                                        Navigator.push(
                                          context,
                                          ScaleRoute(
                                            page: JNwezhakan(
                                              sarder: a.title,
                                              text:
                                                  "نوێژی تۆبە كردن \n\n\nپێویستە لەسەر موسڵمان سوور بێت لەسەر تەقوا ولەخواترسان و هەست كردن بە چاودێری خوا بەوەی نەكەوێتە ناو تاوانەوە, جا ئەگەریش تاوانێكی ئەنجام دا, بێ دواكەوتن دەستپێشخەری دەكات بۆ تۆبە و گەڕانەوە. \n\n\nوە پێغەمبەری خوا صلى الله عليه وسلم رێگەی داوە بە ئەنجامدانی ئەم نوێژە لەكاتی تۆبەكردندا. \n\n\nعَنْ أَسْمَاءَ بْنِ الحَكَمِ الفَزَارِيِّ؛ قَالَ: سَمِعْتُ عَلِيًّا يَقُولُ: إِنِّي كُنْتُ رَجُلًا إِذَا سَمِعْتُ مِنْ رَسُولِ اللهِ صلى الله عليه وسلم حَدِيثًا؛ نَفَعَنِي اللهُ مِنْهُ بِمَا شَاءَ أَنْ يَنْفَعَنِيَ بِهِ، وَإِذَا حَدَّثَنِي رَجُلٌ مِنْ أَصْحَابِهِ؛ اسْتَحْلَفْتُهُ، فَإِذَا حَلَفَ لِي؛ صَدَّقْتُهُ، وَإِنَّهُ حَدَّثَنِي أَبُو بَكْرٍ، وَصَدَقَ أَبُو بَكْرٍ؛ قَالَ: سَمِعْتُ رَسُولَ اللهِ صلى الله عليه وسلم يَقُولُ: مَا مِنْ رَجُلٍ يُذْنِبُ ذَنْبًا، ثُمَّ يَقُومُ فَيَتَطَهَّرُ، ثُمَّ يُصَلِّي، ثُمَّ يَسْتَغْفِرُ اللهَ؛ إِلَّا غَفَرَ اللهُ لَهُ، ثُمَّ قَرَأَ هَذِهِ الآيَةَ: ﴿وَالَّذِينَ إِذَا فَعَلُوا فَاحِشَةً أَوْ ظَلَمُوا أَنفُسَهُمْ ذَكَرُوا اللَّهَ فَاسْتَغْفَرُوا لِذُنُوبِهِمْ وَمَن يَغْفِرُ الذُّنُوبَ إِلَّا اللَّهُ وَلَمْ يُصِرُّوا عَلَىٰ مَا فَعَلُوا وَهُمْ يَعْلَمُونَ ﴾ [سورەتی: آلعمران ئایەتی ژمارە: ١٣٥] (1).\n\n\nواتە: لە ئەسمائی كوڕی حەكەمی فەزاریەوە ، دەڵێت: بیستم لە عەلیەوە كە دەیووت: من پیاوێك بووم كە فەرموودەیەكم لە پێغەمبەری خواوە صلى الله عليه وسلم دەبیست خوای گەورە بەهۆی ئەوەوە سوودی پێم دەگەیاند ئەوەی دەیویست، وە ئەگەریش یەكێك لەهاوەڵان فەرموودەیەكی بۆم بگێڕایەوە ئەوا سوێندیم دەدا ، جا ئەگەر سوێندی بخواردایە, ئەوا بەڕاستم دەزانی, وە ئەبوبەكر فەرموودەیەكی بۆم گێڕاوە و ڕاستی كرد، ووتی لە پێغەمبەری خوام بیستووە صلى الله عليه وسلم كە فەرموویەتی: \" هیچ كەسێك نیە كە تاوانێك دەكات و پاشان هەڵدەستێت و دەستنوێژ دەگرێت و پاشان نوێژ دەكات و پاشان داوای لێخۆشبوون لەخوا دەكات ئیلا خوای گەورە لێی خۆش دەبێت و پاشان ئەم ئایەتەی خوێندەوە: ﴿وَالَّذِينَ إِذَا فَعَلُوا فَاحِشَةً أَوْ ظَلَمُوا أَنفُسَهُمْ ذَكَرُوا اللَّهَ فَاسْتَغْفَرُوا لِذُنُوبِهِمْ وَمَن يَغْفِرُ الذُّنُوبَ إِلَّا اللَّهُ وَلَمْ يُصِرُّوا عَلَىٰ مَا فَعَلُوا وَهُمْ يَعْلَمُونَ ﴾ .\n\n\nواتە: وه‌ ئه‌و كه‌سانه‌ی كاتێك كه‌ كارێكی به‌دڕه‌وشتی و زینایه‌كیان كرد [أَوْ ظَلَمُوا أَنْفُسَهُمْ] یان زوڵمیان له‌ نه‌فسی خۆیان كرد به‌تاوان [ذَكَرُوا اللَّهَ فَاسْتَغْفَرُوا لِذُنُوبِهِمْ] زیكرو یادی خوای گه‌وره‌ ئه‌كه‌نه‌وه‌و داوای لێخۆشبوون له‌ خوای گه‌وره‌ ئه‌كه‌ن بۆ ئه‌و تاوانه‌ی كه‌ كردوویانه‌و له‌سه‌ری به‌رده‌وام نابن [وَمَنْ يَغْفِرُ الذُّنُوبَ إِلَّا اللَّهُ] وه‌ كێ هه‌یه‌ له‌تاوان خۆشبێ جگه‌ له‌ خوای گه‌وره‌، ته‌نها خوای گه‌وره‌ له‌ تاوانه‌كان خۆش ئه‌بێ [وَلَمْ يُصِرُّوا عَلَى مَا فَعَلُوا] وه‌ به‌رده‌وام نه‌بوونه‌ له‌سه‌ر ئه‌و كرده‌وه‌ خراپانه‌ی كه‌ كردوویانه‌ [وَهُمْ يَعْلَمُونَ (135)] وه‌ ئه‌وان ئه‌زانن ئه‌گه‌ر به‌رده‌وام بن گوناهبار ئه‌بن، یان ئه‌زانن ئه‌گه‌ر ته‌وبه‌ بكه‌ن خوا لێیان خۆش ده‌بێت .\n\n\nسەچاوە : کتێبی (( نوێژە سوننەتەکان))\nلە نوسینى شێخ محمد بن عمر بن سالم بازمول\n\n\n\n(1) حديث حسن: أخرجه الترمذي فِي كتاب الصلاة، باب ما جاء فِي الصلاة عند التوبة، حديث رقم (406) واللفظ له، وفِي كتاب التفسير، باب ومن سورة آل عمران، حديث رقم (3009)، وأبو داود فِي كتاب الصلاة، باب فِي الاستغفار، حديث رقم (1521)، وأخرجه مُختصرًا دون ذكر الآية ابن ماجه فِي كتاب إقامة الصلاة، حديث رقم (1395)، وبنحوه ابن حبان فِي (صحيحه) (2/389-390-الإحسان).\nوالحديث جوّد إسناده ابن حجر فِي ترجمة أسماء بن الحكم من (التهذيب)، وصححه العلامة أحمد شاكر فِي تَحقيقه للترمذي، وحسنه الألباني فِي (صحيح سنن الترمذي) (1/128)، وحسنه مُحقق (جامع الأصول) (4/390)، ومُحقق (الإحسان) (2/390).\n",
                                            ),
                                          ),
                                        );
                                      }
                                      if (i == 14) {
                                        Navigator.push(
                                          context,
                                          SizeRoute(
                                            page: JNwezhakan(
                                              sarder: a.title,
                                              text:
                                                  "مرۆڤی موسلمان له‌ شه‌و ڕۆژدا پێنج نوێژی فه‌رز ده‌كات، كه‌ (17) ركعاتن و بریتین له‌ : \n \n 1) نوێژی به‌یانی : دوو ركعاته‌ \n 2) نوێژی نیوه‌رۆ : چوار ركعاته‌ \n 3) نوێژی عه‌سر : چوار ركعاته‌ \n 4) نوێژی ئێواره‌ : سێ ركعاته‌ \n 5) نوێژی عیشا : چوار ركعاته‌ \n \n ئه‌و نوێژانه‌ی به‌ده‌نگ ده‌خوێندرێ بریتین له‌ : \n 1) نوێژی به‌یانی \n 2) نوێژی ئێواره‌ (مغرب) \n 3) نوێژی عیشا \n \n ئه‌و نوێژانه‌ی بێ ده‌نگ ده‌خوێندرێ بریتین له‌ : \n 1) نوێژی نیوه‌ڕۆ \n 2) نوێژی عه‌سر ‌",
                                            ),
                                          ),
                                        );
                                      }
                                      if (i == 15) {
                                        Navigator.push(
                                          context,
                                          FadeRoute(
                                            page: JNwezhakan(
                                              sarder: a.title,
                                              text:
                                                  "موسلمانان دوو جه‌ژنیان هه‌یه‌ : \n جه‌ژنی ڕه‌مه‌زان \n جه‌ژنی قوربان \n \n له‌ هه‌ردوو جه‌ژن دا موسلمانان به‌ كۆمه‌ڵ نوێژی جه‌ژن ده‌كه‌ن. نوێژی جه‌ژن سوننه‌تێكه‌ پێغه‌مبه‌ر ﷺ ته‌ئكیدی له‌سه‌ر كردووه‌، كه‌ بكرێت كاته‌كه‌شی دوای ڕۆژ هه‌ڵاتنه‌ به‌ بیست خوله‌ك (ده‌قیقه‌). \n نوێژی جه‌ژن دوو ركعاته‌، ئیمام پێش نوێژی بۆ موسلمانان ده‌كات، كه‌ به‌ده‌نگ سوره‌تی فاتیحه‌ ده‌خوێنێ، له‌ ركعاتی یه‌كه‌م حه‌وت جار ده‌ڵێ : (الله اكبر). \n له‌نێوان هه‌ر (الله اكبر)ێك ده‌گوترێ : (سبحان الله والحمد لله ولا اله الا الله)، له‌ ركعاتی دووه‌م پێنج جار (الله اكبر) ده‌گوترێ، دوای ئه‌وه‌ی نوێژه‌كه‌ كرا، ئینجا ئیمام وتار ده‌خوێنێته‌وه‌.",
                                            ),
                                          ),
                                        );
                                      }

                                      if (i == 16) {
                                        Navigator.push(
                                          context,
                                          ScaleRoute(
                                            page: JNwezhakan(
                                              sarder: a.title,
                                              text:
                                                  "ئه‌و زیكرانه‌ی له‌دوای نوێژ ده‌گوترێن \n \n هه‌ر كه‌ نوێژه‌كه‌ت ئه‌نجام دا، ئه‌و زیكرانه‌ بخوێنه‌وه‌ كه‌ پێغه‌مبه‌ر ﷺ خوێندوویه‌تیه‌وه‌ : \n \n (3) جار ده‌ڵێی : (استغفرالله) رواه احمد. \n (3) جار ده‌ڵێی : (اللهم انت السلام و منك السلام تباركت يا ذا الجلال والإكرام) رواه النسائي. \n (33) جار ده‌ڵێی : (سبحان الله). \n (33) جار ده‌ڵێی : (الحمد لله). \n (33) جار ده‌ڵێی : (الله اكبر). \n\n\n دواتر ده‌ڵێی : (لا الهَ الا الله, وَحدَهُ لا شَريكَ لهُ, لهُ المُلكُ ولهُ الحَمدُ, وهوَ على كُلِّ شئٍ قدير) رواه البخاري. ‌",
                                            ),
                                          ),
                                        );
                                      }
                                      if (i == 17) {
                                        Navigator.push(
                                          context,
                                          FadeRoute(
                                            page: BatalkarNwezh(
                                              sarder: a.title,
                                            ),
                                          ),
                                        );
                                      }
                                    },
                                    "${i + 1}",
                                  ),
                                ),
                              ),
                            );
                          },
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget homePageCardsGroup(
    Color color,
    String icon,
    String title,
    VoidCallback onTap,
    String count,
  ) {
    double w = MediaQuery.of(context).size.width;
    return Padding(
      padding: EdgeInsets.only(bottom: w / 17),
      child: homePageCard(color, icon, title, onTap, count),
    );
  }

  Widget homePageCard(
    Color color,
    String icon,
    String title,
    VoidCallback onTap,
    String count,
  ) {
    double w = MediaQuery.of(context).size.width;
    return InkWell(
      splashColor: kActiveIconColor,
      customBorder: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(25),
      ),
      onTap: onTap,
      child: Stack(
        children: [
          Container(
            padding: const EdgeInsets.all(15),
            height: w / 2,
            width: w / 2.4,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(25),
              color: backgroundColor.withValues(alpha: 0.8),
              boxShadow: [
                BoxShadow(
                  color: const Color(0xFF282547).withValues(alpha: .15),
                  blurRadius: 20,
                ),
              ],
            ),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                const SizedBox(),
                Container(
                  height: w / 8,
                  width: w / 8,
                  padding: const EdgeInsets.all(10),
                  decoration: BoxDecoration(
                    color: color.withValues(alpha: .1),
                    shape: BoxShape.circle,
                  ),
                  child: SvgPicture.asset(
                    icon,
                    colorFilter: ColorFilter.mode(
                      color.withValues(alpha: .6),
                      BlendMode.srcIn,
                    ),
                  ),
                ),
                Text(
                  title,
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                    fontFamily: fontType.toString(),
                    fontSize: 18,
                    color: descriptionTectColor,
                    fontWeight: FontWeight.w700,
                  ),
                  textAlign: TextAlign.center,
                ),
                const SizedBox(),
              ],
            ),
          ),
          Container(
            padding: const EdgeInsets.symmetric(
              horizontal: 10.0,
              vertical: 5.0,
            ),
            decoration: const BoxDecoration(
              color: Color(0x83CEECE8),
              borderRadius: BorderRadius.only(
                bottomRight: Radius.circular(10),
                topLeft: Radius.circular(20),
              ),
            ),
            child: Text(
              count,
              textAlign: TextAlign.center,
              style: TextStyle(
                color: kActiveIconColor,
                fontWeight: FontWeight.w700,
                fontSize: 12,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class Nwezh {
  final String? title;

  Nwezh({this.title});
}
