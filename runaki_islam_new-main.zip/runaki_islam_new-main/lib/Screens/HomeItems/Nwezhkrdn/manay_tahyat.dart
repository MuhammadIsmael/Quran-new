import 'package:flutter/material.dart';
import 'package:runaki_islam/util/background.dart';
import 'package:runaki_islam/util/constans.dart';
import 'package:runaki_islam/providers/settings_provider.dart';
import 'package:provider/provider.dart';

class ManayTahyat extends StatefulWidget {
  final String? sarder;

  const ManayTahyat({super.key, this.sarder});
  @override
  State<StatefulWidget> createState() => _ManayTahyatState();
}

class _ManayTahyatState extends State<ManayTahyat> {
  int? fontType;
  int? quranFontType;
  double? quranFontSize;
  double? fontSize;

  @override
  void initState() {
    super.initState();
    fontType = Provider.of<SettingsProvider>(context, listen: false)
        .getsettingField('font_family');
    quranFontType = Provider.of<SettingsProvider>(context, listen: false)
        .getsettingField('quran_font_family');
    quranFontSize = Provider.of<SettingsProvider>(context, listen: false)
        .getsettingField('quran_font_size');
    fontSize = Provider.of<SettingsProvider>(context, listen: false)
        .getsettingField('font_size');
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: backgroundColor,
      appBar: AppBar(
        centerTitle: true,
        title: Text(
          widget.sarder!,
          style:
              TextStyle(fontFamily: fontType.toString(), color: titleTextColor),
        ),
        backgroundColor: thirdColor,
        elevation: 0.8,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_rounded),
          color: iconColor,
          onPressed: () {
            Navigator.pop(context);
          },
        ),
      ),
      body: Stack(
        children: [
          const Background2(),
          SingleChildScrollView(
            padding:
                const EdgeInsets.only(right: 10, left: 10, top: 20, bottom: 80),
            physics: const BouncingScrollPhysics(
                parent: AlwaysScrollableScrollPhysics()),
            scrollDirection: Axis.vertical,
            child: Column(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: <Widget>[
                  Text(
                      "التَّحِيَّاتُ للهِ, وَالصَّلَوَاتُ, وَالطَّيِّبَاتُ, السَّلامُ عَلَيْكَ أَيُّهَا النَّبِيُّ (١) وَرَحْمَةُ اللهِ وَبَرَكَاتُهُ, السَّلامُ عَلَيْنَا وَعَلَى عِبَادِ اللهِ الصَّالِحِينَ، أَشْهَدُ أَنْ لاَ إِلهَ إِلاَّ اللهُ وَأَشْهَدُ أَنَّ مُحَمَّدًا عَبْدُهُ وَرَسُولُهُ . (٢)",
                      style: quranStyle.copyWith(
                        fontFamily: quranFontType.toString(),
                        fontSize: quranFontSize,
                      ),
                      textAlign: TextAlign.center),
                  Container(
                      width: double.infinity,
                      margin: const EdgeInsets.symmetric(vertical: 10),
                      height: 2,
                      decoration: BoxDecoration(
                          color: splashColor,
                          borderRadius: BorderRadius.circular(555))),
                  Text(
                    "واتە: (سـەلام و موڵک و گەورەیی و پەرستش و وشە و کردەوەی پاک و چاک ھەر بۆ خودایە، سڵاو و ڕەحمەتی خودات لەسەر بێت ئەی پێغەمبەری خودا (صلى الله عليه وسلم) سڵاو لەسەر ئێمەش و لەسەر ھەموو بەندە چاکەکانی خودابێت، شایەتی دەدەم، کە ھیچ پەرستراوێک شایستەی پەرستن نییە، جگە لە (الله)، شایەتیش دەدەم، کە موحەممەد بەندە و نێردراوی خودایە) .",
                    style: simpleTextStyle.copyWith(
                        fontFamily: fontType.toString(), fontSize: fontSize),
                    textAlign: TextAlign.center,
                  ),
                  const SizedBox(height: 20),
                  sortLine(
                      "١- پێغەمبەر (صلى الله عليه وسلم) بەو شێوەیە ھاوەڵانی فێرکردوە، بەڵام کاتێک، کە وەفاتی کرد ھاوەڵان ڕەزای خودایان لێبێت بەم شێوەیان دەگوت: (السلام على النبِي ورحمة الله وبركاته) وصححه الألباني في الإرواء (٢/ ٢٧) ."),
                  sortLine(
                      "٢ - البخاري مع الفتح ١ / ١٣ ومسلم ١ / ٣٠١ {وصحابي الحديث هو عبد الله بن مسعود (رضي الله عنه)}.")
                ]),
          ),
        ],
      ),
    );
  }

  Widget sortLine(String title) {
    return Column(
      children: [
        const SizedBox(height: 10),
        Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
                color: thirdColor.withValues(alpha: 0.4),
                borderRadius: BorderRadius.circular(10)),
            child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.end,
                children: <Widget>[
                  Container(
                      padding: const EdgeInsets.all(8),
                      decoration: BoxDecoration(
                          color: kActiveIconColor.withValues(alpha: 0.5),
                          shape: BoxShape.circle)),
                  const SizedBox(height: 8),
                  Text(
                    title,
                    style: simpleTextStyle.copyWith(
                        fontFamily: fontType.toString(), fontSize: fontSize),
                    textAlign: TextAlign.center,
                  ),
                ])),
      ],
    );
  }
}
