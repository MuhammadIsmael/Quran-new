import 'package:flutter/material.dart';
import 'package:runaki_islam/util/background.dart';
import 'package:runaki_islam/util/constans.dart';
import 'package:runaki_islam/widgets/nwezh/balga.dart';
import 'package:runaki_islam/widgets/nwezh/header_nwezh.dart';
import 'package:runaki_islam/providers/settings_provider.dart';
import 'package:provider/provider.dart';

class Tayamum extends StatefulWidget {
  final String? sarder;

  const Tayamum({super.key, this.sarder});
  @override
  State<StatefulWidget> createState() => _TayamumState();
}

class _TayamumState extends State<Tayamum> {
  int? fontType;
  int? quranFontType;
  double? quranFontSize;
  double? fontSize;

  @override
  void initState() {
    super.initState();
    fontType = Provider.of<SettingsProvider>(context, listen: false)
        .getsettingField('font_family');
    quranFontType = Provider.of<SettingsProvider>(context, listen: false)
        .getsettingField('quran_font_family');
    quranFontSize = Provider.of<SettingsProvider>(context, listen: false)
        .getsettingField('quran_font_size');
    fontSize = Provider.of<SettingsProvider>(context, listen: false)
        .getsettingField('font_size');
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: backgroundColor,
      appBar: AppBar(
        centerTitle: true,
        title: Text(
          widget.sarder!,
          style:
              TextStyle(fontFamily: fontType.toString(), color: titleTextColor),
        ),
        backgroundColor: thirdColor,
        elevation: 0.8,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_rounded),
          color: iconColor,
          onPressed: () {
            Navigator.pop(context);
          },
        ),
      ),
      body: Stack(
        children: [
          const Background2(),
          SingleChildScrollView(
            padding:
                const EdgeInsets.only(right: 10, left: 10, top: 20, bottom: 80),
            physics: const BouncingScrollPhysics(
                parent: AlwaysScrollableScrollPhysics()),
            scrollDirection: Axis.vertical,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: <Widget>[
                //bashe1
                const HeaderNwezhItem(text: "١- كه‌ی ته‌یه‌مموم ده‌كه‌یت؟"),
                const SizedBox(height: 20),
                Container(
                    padding: const EdgeInsets.all(8),
                    decoration: BoxDecoration(
                        color: thirdColor.withValues(alpha: 0.2),
                        borderRadius: BorderRadius.circular(10)),
                    child: Column(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        mainAxisAlignment: MainAxisAlignment.end,
                        children: <Widget>[
                          Container(
                              padding: const EdgeInsets.all(8),
                              decoration: BoxDecoration(
                                  color: kActiveIconColor.withValues(alpha: 0.5),
                                  shape: BoxShape.circle)),
                          const SizedBox(height: 8),
                          Text(
                            ".كاتێك ئاوت ‌ده‌ست نه‌كه‌و‌ت",
                            style: simpleTextStyle.copyWith(
                                fontFamily: fontType.toString(),
                                fontSize: fontSize),
                            textAlign: TextAlign.center,
                          ),
                        ])),
                const SizedBox(height: 10),
                Container(
                    padding: const EdgeInsets.all(8),
                    decoration: BoxDecoration(
                        color: thirdColor.withValues(alpha: 0.2),
                        borderRadius: BorderRadius.circular(10)),
                    child: Column(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        mainAxisAlignment: MainAxisAlignment.end,
                        children: <Widget>[
                          Container(
                              padding: const EdgeInsets.all(8),
                              decoration: BoxDecoration(
                                  color: kActiveIconColor.withValues(alpha: 0.5),
                                  shape: BoxShape.circle)),
                          const SizedBox(height: 8),
                          Text(
                            "کاتێک ئاو هه‌بوو به‌ڵام به‌كارهێنانی زیانی پێ گه‌یاندیت ئه‌وكات‌ ته‌یه‌مموم بكه‌.",
                            style: simpleTextStyle.copyWith(
                                fontFamily: fontType.toString(),
                                fontSize: fontSize),
                            textAlign: TextAlign.center,
                          ),
                        ])),
                const SizedBox(height: 20),
                Center(
                  child: Container(
                    height: 100,
                    width: 100,
                    decoration: BoxDecoration(
                        boxShadow: [
                          BoxShadow(
                            color: kActiveIconColor.withValues(alpha: 0.1),
                            spreadRadius: 10,
                            blurRadius: 7,
                            offset: const Offset(
                                0, 3), // changes position of shadow
                          ),
                        ],
                        color: thirdColor.withValues(alpha: 0.2),
                        shape: BoxShape.circle,
                        image: const DecorationImage(
                            image: AssetImage(
                          "assets/images/nwezh/18.png",
                        ))),
                  ),
                ),
                const SizedBox(height: 30),
                Center(
                    child: Column(children: <Widget>[
                  Align(
                    alignment: Alignment.centerRight,
                    child: Container(
                      padding: const EdgeInsets.all(8),
                      decoration: BoxDecoration(
                        color: thirdColor.withValues(alpha: 0.5),
                        borderRadius: const BorderRadius.only(
                          topLeft: Radius.circular(10),
                          topRight: Radius.circular(10),
                        ),
                      ),
                      child: Text(
                        "بەڵگە",
                        textAlign: TextAlign.center,
                        style: simpleTextStyle
                            .copyWith(
                                fontFamily: fontType.toString(),
                                fontSize: fontSize)
                            .copyWith(color: kActiveIconColor),
                      ),
                    ),
                  ),
                  Container(
                      width: double.infinity,
                      padding: const EdgeInsets.all(8),
                      decoration: BoxDecoration(
                          color: thirdColor.withValues(alpha: 0.5),
                          borderRadius: const BorderRadius.only(
                            topLeft: Radius.circular(10),
                            bottomLeft: Radius.circular(10),
                            bottomRight: Radius.circular(10),
                          )),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Text(
                            'وَإِنْ كُنْتُمْ مَرْضَىٰ أَوْ عَلَىٰ سَفَرٍ أَوْ جَاءَ أَحَدٌ مِنْكُمْ مِنَ الْغَائِطِ أَوْ لَامَسْتُمُ النِّسَاءَ فَلَمْ تَجِدُوا مَاءً فَتَيَمَّمُوا صَعِيدًا طَيِّبًا',
                            style: quranStyle.copyWith(
                              fontFamily: quranFontType.toString(),
                              fontSize: quranFontSize,
                            ),
                            textAlign: TextAlign.center,
                          ),
                          Text(
                            'ئه‌گه‌ر نه‌خۆش بوون یان له سه‌فه‌ردا بوون یان یه‌كێك له‌ ئێوه‌ له‌ سه‌رئاوه‌وه‌ هات یان چوونه‌ لای خێزانتان ، وه‌ ئاوتان ده‌ست نه‌که‌وت ئه‌وکاته ته‌یه‌مموم بکه‌ن) [سورة المائدة, آية 6]',
                            style: simpleTextStyle.copyWith(
                                fontFamily: fontType.toString(),
                                fontSize: fontSize),
                            textAlign: TextAlign.center,
                          ),
                        ],
                      )),
                ])),
                const SizedBox(height: 20),
                Divider(color: kActiveIconColor.withValues(alpha: 0.7), thickness: 1),
                const SizedBox(height: 20),

                //bashe 2
                const HeaderNwezhItem(text: "٢- نیه‌تی ته‌یه‌مموم بهێنه‌"),
                const SizedBox(height: 20),
                Text(
                    "نیه‌تی ته‌یه‌مموم بهێــنه‌‌ له‌ دڵی خۆت دا له‌ بری ئه‌و شته‌ی كه‌ ته‌یه‌ممومی له‌جێگا د‌ه‌كه‌یت كه‌ بریتییه‌ له‌",
                    style: simpleTextStyle.copyWith(
                        fontFamily: fontType.toString(), fontSize: fontSize),
                    textAlign: TextAlign.center,
                    maxLines: 3),

                const SizedBox(height: 20),
                Container(
                    padding: const EdgeInsets.all(8),
                    decoration: BoxDecoration(
                        color: thirdColor.withValues(alpha: 0.2),
                        borderRadius: BorderRadius.circular(10)),
                    child: Column(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        mainAxisAlignment: MainAxisAlignment.end,
                        children: <Widget>[
                          Container(
                              padding: const EdgeInsets.all(8),
                              decoration: BoxDecoration(
                                  color: kActiveIconColor.withValues(alpha: 0.5),
                                  shape: BoxShape.circle)),
                          const SizedBox(height: 8),
                          Text(
                            "ده‌ستنوێژگرتن‌",
                            style: simpleTextStyle.copyWith(
                                fontFamily: fontType.toString(),
                                fontSize: fontSize),
                            textAlign: TextAlign.center,
                          ),
                        ])),
                const SizedBox(height: 10),
                Container(
                    padding: const EdgeInsets.all(8),
                    decoration: BoxDecoration(
                        color: thirdColor.withValues(alpha: 0.2),
                        borderRadius: BorderRadius.circular(10)),
                    child: Column(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        mainAxisAlignment: MainAxisAlignment.end,
                        children: <Widget>[
                          Container(
                              padding: const EdgeInsets.all(8),
                              decoration: BoxDecoration(
                                  color: kActiveIconColor.withValues(alpha: 0.5),
                                  shape: BoxShape.circle)),
                          const SizedBox(height: 8),
                          Text(
                            "خۆ شۆردن‌",
                            style: simpleTextStyle.copyWith(
                                fontFamily: fontType.toString(),
                                fontSize: fontSize),
                            textAlign: TextAlign.center,
                          ),
                        ])),
                const SizedBox(height: 20),
                const BalgaWidget(
                    description:
                        "له‌به‌ر فه‌رمایشتی پێغەمبەر ﷺ: (إنما الأعمال بالنیات - هه‌موو كرده‌وه‌كان به‌ نیه‌ته‌وه‌ ئه‌نجام ده‌درێن) . [البخاری ، مسلم]"),
                const SizedBox(height: 20),
                Divider(color: kActiveIconColor.withValues(alpha: 0.7), thickness: 1),
                const SizedBox(height: 20),
                //bashe 3
                const HeaderNwezhItem(
                    text: "٣- ده‌سته‌كانت له‌ ڕووی زه‌وی بده‌‌"),
                const SizedBox(height: 20),
                Text(
                    "ده‌سته‌كانت له‌ ڕووی زه‌وییه‌كی پاك بده‌‌‌. ئه‌گه‌ر خاكت ده‌ست نه‌كه‌وت ئه‌وكات هه‌ر شوێنێكی تر كه‌ خۆڵی پێوه‌بێت",
                    style: simpleTextStyle.copyWith(
                        fontFamily: fontType.toString(), fontSize: fontSize),
                    textAlign: TextAlign.center),
                const SizedBox(height: 20),
                Center(
                  child: Container(
                    height: 100,
                    width: 100,
                    decoration: BoxDecoration(
                        boxShadow: [
                          BoxShadow(
                            color: kActiveIconColor.withValues(alpha: 0.1),
                            spreadRadius: 10,
                            blurRadius: 7,
                            offset: const Offset(
                                0, 3), // changes position of shadow
                          ),
                        ],
                        shape: BoxShape.circle,
                        color: thirdColor.withValues(alpha: 0.2),
                        image: const DecorationImage(
                            image: AssetImage(
                          "assets/images/nwezh/19.png",
                        ))),
                  ),
                ),
                const SizedBox(height: 30),
                Center(
                    child: Column(children: <Widget>[
                  Align(
                    alignment: Alignment.centerRight,
                    child: Container(
                      padding: const EdgeInsets.all(8),
                      decoration: BoxDecoration(
                        color: thirdColor.withValues(alpha: 0.5),
                        borderRadius: const BorderRadius.only(
                          topLeft: Radius.circular(10),
                          topRight: Radius.circular(10),
                        ),
                      ),
                      child: Text(
                        "بەڵگە",
                        textAlign: TextAlign.center,
                        style: simpleTextStyle
                            .copyWith(
                                fontFamily: fontType.toString(),
                                fontSize: fontSize)
                            .copyWith(color: kActiveIconColor),
                      ),
                    ),
                  ),
                  Container(
                      width: double.infinity,
                      padding: const EdgeInsets.all(8),
                      decoration: BoxDecoration(
                          color: thirdColor.withValues(alpha: 0.5),
                          borderRadius: const BorderRadius.only(
                            topLeft: Radius.circular(10),
                            bottomLeft: Radius.circular(10),
                            bottomRight: Radius.circular(10),
                          )),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Text(
                            'فَتَيَمَّمُوا صَعِيدًا طَيِّبًا',
                            style: quranStyle.copyWith(
                              fontFamily: quranFontType.toString(),
                              fontSize: quranFontSize,
                            ),
                            textAlign: TextAlign.center,
                          ),
                          Text(
                            'به‌ ڕووی زوییه‌كی پاك ته‌یه‌مموم بكه‌ [سورة المائدة, آية 6]',
                            style: simpleTextStyle.copyWith(
                                fontFamily: fontType.toString(),
                                fontSize: fontSize),
                            textAlign: TextAlign.center,
                          ),
                        ],
                      )),
                ])),
                const SizedBox(height: 20),
                Divider(color: kActiveIconColor.withValues(alpha: 0.7), thickness: 1),
                const SizedBox(height: 20),
                //bashe4
                const HeaderNwezhItem(
                    text: "٤- ده‌ست بهێنه‌ به‌ ڕوخسار و ده‌سته‌كانتدا"),
                const SizedBox(height: 20),
                Text(
                    "ده‌ست بهێنه‌ به‌ ڕوخسار و ده‌سته‌كانتدا ‌ڕوخسارت وه‌ ‌پاشان هه‌ردوو ده‌ستته‌كانت به‌و خۆڵه‌ مه‌سح بكه‌. ڕاست پاشان ده‌ستی چه‌پ",
                    style: simpleTextStyle.copyWith(
                        fontFamily: fontType.toString(), fontSize: fontSize),
                    textAlign: TextAlign.center),
                const SizedBox(height: 20),
                Center(
                  child: Container(
                    height: 100,
                    width: 100,
                    decoration: BoxDecoration(
                        boxShadow: [
                          BoxShadow(
                            color: kActiveIconColor.withValues(alpha: 0.1),
                            spreadRadius: 10,
                            blurRadius: 7,
                            offset: const Offset(
                                0, 3), // changes position of shadow
                          ),
                        ],
                        color: thirdColor.withValues(alpha: 0.2),
                        shape: BoxShape.circle,
                        image: const DecorationImage(
                            image: AssetImage(
                          "assets/images/nwezh/20.png",
                        ))),
                  ),
                ),
                const SizedBox(height: 20),
                Center(
                    child: Column(children: <Widget>[
                  Align(
                    alignment: Alignment.centerRight,
                    child: Container(
                      padding: const EdgeInsets.all(8),
                      decoration: BoxDecoration(
                        color: thirdColor.withValues(alpha: 0.5),
                        borderRadius: const BorderRadius.only(
                          topLeft: Radius.circular(10),
                          topRight: Radius.circular(10),
                        ),
                      ),
                      child: Text(
                        "بەڵگە",
                        textAlign: TextAlign.center,
                        style: simpleTextStyle
                            .copyWith(
                                fontFamily: fontType.toString(),
                                fontSize: fontSize)
                            .copyWith(color: kActiveIconColor),
                      ),
                    ),
                  ),
                  Container(
                      width: double.infinity,
                      padding: const EdgeInsets.all(8),
                      decoration: BoxDecoration(
                          color: thirdColor.withValues(alpha: 0.5),
                          borderRadius: const BorderRadius.only(
                            topLeft: Radius.circular(10),
                            bottomLeft: Radius.circular(10),
                            bottomRight: Radius.circular(10),
                          )),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Text(
                            'فَامْسَحُوا بِوُجُوهِكُمْ وَأَيْدِيكُمْ مِنْهُ',
                            style: quranStyle.copyWith(
                              fontFamily: quranFontType.toString(),
                              fontSize: quranFontSize,
                            ),
                            textAlign: TextAlign.center,
                          ),
                          Text(
                            "له‌پی ده‌ستتان بده‌ن به‌خاکه‌دا) و بیهێنن به ڕوخسار و ده‌ستتاندا) [سورة المائدة, آية 6]",
                            style: simpleTextStyle.copyWith(
                                fontFamily: fontType.toString(),
                                fontSize: fontSize),
                            textAlign: TextAlign.center,
                          ),
                        ],
                      )),
                ])),
                const SizedBox(height: 30)
              ],
            ),
          ),
        ],
      ),
    );
  }
}
