import 'package:flutter/material.dart';
import 'package:runaki_islam/util/background.dart';
import 'package:runaki_islam/util/constans.dart';
import 'package:runaki_islam/widgets/nwezh/balga.dart';
import 'package:runaki_islam/widgets/nwezh/header_nwezh.dart';
import 'package:runaki_islam/providers/settings_provider.dart';
import 'package:provider/provider.dart';

class DastNwezh extends StatefulWidget {
  final String? sarder;

  const DastNwezh({super.key, this.sarder});
  @override
  State<StatefulWidget> createState() => _DastNwezhState();
}

class _DastNwezhState extends State<DastNwezh> {
  int? fontType;
  int? quranFontType;
  double? quranFontSize;
  double? fontSize;

  @override
  void initState() {
    super.initState();
    fontType = Provider.of<SettingsProvider>(context, listen: false)
        .getsettingField('font_family');
    quranFontType = Provider.of<SettingsProvider>(context, listen: false)
        .getsettingField('quran_font_family');
    quranFontSize = Provider.of<SettingsProvider>(context, listen: false)
        .getsettingField('quran_font_size');
    fontSize = Provider.of<SettingsProvider>(context, listen: false)
        .getsettingField('font_size');
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: backgroundColor,
      appBar: AppBar(
        centerTitle: true,
        title: Text(
          widget.sarder!,
          style:
              TextStyle(fontFamily: fontType.toString(), color: titleTextColor),
        ),
        backgroundColor: thirdColor,
        elevation: 0.8,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_rounded),
          color: iconColor,
          onPressed: () {
            Navigator.pop(context);
          },
        ),
      ),
      body: Stack(
        children: [
          const Background2(),
          SingleChildScrollView(
              padding: const EdgeInsets.only(
                  right: 10, left: 10, top: 20, bottom: 80),
              physics: const BouncingScrollPhysics(
                  parent: AlwaysScrollableScrollPhysics()),
              scrollDirection: Axis.vertical,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: <Widget>[
                  //bashe1
                  Container(
                    padding:
                        const EdgeInsets.symmetric(vertical: 8, horizontal: 12),
                    alignment: Alignment.center,
                    decoration: BoxDecoration(
                        color: kActiveIconColor,
                        borderRadius: BorderRadius.circular(555)),
                    child: Text("مه‌رجه‌كانی ده‌ستنوێژگرتن",
                        style: bigTextStyle.copyWith(
                            color: Colors.white,
                            fontFamily: fontType.toString())),
                  ),
                  const SizedBox(height: 20),
                  Container(
                      alignment: Alignment.topCenter,
                      padding: const EdgeInsets.all(10),
                      decoration: BoxDecoration(
                          color: thirdColor.withValues(alpha: 0.5),
                          borderRadius: BorderRadius.circular(10),
                          boxShadow: [
                            BoxShadow(
                                blurRadius: 20,
                                color: thirdColor,
                                offset: const Offset(0, 5))
                          ]),
                      child: Column(children: <Widget>[
                        Container(
                            padding: const EdgeInsets.all(8),
                            decoration: BoxDecoration(
                                color: splashColor.withAlpha(100),
                                borderRadius: BorderRadius.circular(10)),
                            child: Text(
                              "1- شۆردنی هەموو ڕوخسار",
                              style: bigTextStyle.copyWith(
                                  color: kActiveIconColor,
                                  fontSize: fontSize,
                                  fontFamily: fontType.toString()),
                              textAlign: TextAlign.center,
                            )),
                        Container(
                            padding: const EdgeInsets.all(8),
                            decoration: BoxDecoration(
                                color: thirdColor.withValues(alpha: 0.5),
                                borderRadius: const BorderRadius.only(
                                  topLeft: Radius.circular(10),
                                  bottomLeft: Radius.circular(10),
                                  bottomRight: Radius.circular(10),
                                )),
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Text(
                                  ": له‌به‌ر فه‌رمایشتی خوای په‌روه‌ردگار",
                                  style: simpleTextStyle.copyWith(
                                      fontFamily: fontType.toString(),
                                      fontSize: fontSize),
                                  textAlign: TextAlign.center,
                                ),
                                Padding(
                                  padding:
                                      const EdgeInsets.symmetric(vertical: 10),
                                  child: Text(
                                    'إِذَا قُمْتُمْ إِلَى الصَّلَاةِ فَاغْسِلُوا وُجُوهَكُمْ',
                                    style: quranStyle.copyWith(
                                      fontFamily: quranFontType.toString(),
                                      fontSize: quranFontSize,
                                    ),
                                    textAlign: TextAlign.center,
                                  ),
                                ),
                                Text(
                                  'كاتێك هه‌ستان بۆ نوێژكردن ڕوخسارتان بشۆن [سورة المائدة, آية 6] ، وه‌ تێوەردانی ئاو له‌ دەم و لوت هه‌ر له‌ شۆردنی ‌ڕوخساره‌.',
                                  style: simpleTextStyle.copyWith(
                                      fontFamily: fontType.toString(),
                                      fontSize: fontSize),
                                  textAlign: TextAlign.center,
                                ),
                              ],
                            )),
                      ])),
                  const SizedBox(height: 20),
                  Container(
                      alignment: Alignment.topCenter,
                      padding: const EdgeInsets.all(10),
                      decoration: BoxDecoration(
                          color: thirdColor.withValues(alpha: 0.5),
                          borderRadius: BorderRadius.circular(10),
                          boxShadow: [
                            BoxShadow(
                                blurRadius: 20,
                                color: thirdColor,
                                offset: const Offset(0, 5))
                          ]),
                      child: Column(children: <Widget>[
                        Container(
                            padding: const EdgeInsets.all(8),
                            decoration: BoxDecoration(
                                color: splashColor.withAlpha(100),
                                borderRadius: BorderRadius.circular(10)),
                            child: Text(
                              'شۆردنی هەردوو دەست لەگەڵ ئانیشکەکان -2',
                              style: bigTextStyle.copyWith(
                                color: kActiveIconColor,
                                fontFamily: fontType.toString(),
                                fontSize: fontSize,
                              ),
                              textAlign: TextAlign.center,
                            )),
                        Container(
                            padding: const EdgeInsets.all(8),
                            decoration: BoxDecoration(
                                color: thirdColor.withValues(alpha: 0.5),
                                borderRadius: const BorderRadius.only(
                                  topLeft: Radius.circular(10),
                                  bottomLeft: Radius.circular(10),
                                  bottomRight: Radius.circular(10),
                                )),
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Text(
                                  ": له‌به‌ر فه‌رمایشتی خوای په‌روه‌ردگار",
                                  style: simpleTextStyle.copyWith(
                                      fontFamily: fontType.toString(),
                                      fontSize: fontSize),
                                  textAlign: TextAlign.center,
                                ),
                                Padding(
                                  padding:
                                      const EdgeInsets.symmetric(vertical: 10),
                                  child: Text(
                                    " وَأَيْدِيَكُمْ إِلَى الْمَرَافِقِ",
                                    style: quranStyle.copyWith(
                                      fontFamily: quranFontType.toString(),
                                      fontSize: quranFontSize,
                                    ),
                                    textAlign: TextAlign.center,
                                  ),
                                ),
                                Text(
                                  "وده‌سته‌كانتان ‌تاوه‌كو ئانيشكه‌كانتان بشۆن [سورة المائدة, آية 6] ",
                                  style: simpleTextStyle.copyWith(
                                    fontFamily: fontType.toString(),
                                    fontSize: fontSize,
                                  ),
                                  textAlign: TextAlign.center,
                                ),
                              ],
                            )),
                      ])),
                  const SizedBox(height: 20),
                  Container(
                      alignment: Alignment.topCenter,
                      padding: const EdgeInsets.all(10),
                      decoration: BoxDecoration(
                          color: thirdColor.withValues(alpha: 0.5),
                          borderRadius: BorderRadius.circular(10),
                          boxShadow: [
                            BoxShadow(
                                blurRadius: 20,
                                color: thirdColor,
                                offset: const Offset(0, 5))
                          ]),
                      child: Column(children: <Widget>[
                        Container(
                            padding: const EdgeInsets.all(8),
                            decoration: BoxDecoration(
                                color: splashColor.withAlpha(100),
                                borderRadius: BorderRadius.circular(10)),
                            child: Text(
                              'دەستهێنان بە هەموو سەردا لەگەڵ هەردوو گوێچکەکان -3',
                              style: bigTextStyle.copyWith(
                                color: kActiveIconColor,
                                fontFamily: fontType.toString(),
                                fontSize: fontSize,
                              ),
                              textAlign: TextAlign.center,
                            )),
                        Container(
                            padding: const EdgeInsets.all(8),
                            decoration: BoxDecoration(
                                color: thirdColor.withValues(alpha: 0.5),
                                borderRadius: const BorderRadius.only(
                                  topLeft: Radius.circular(10),
                                  bottomLeft: Radius.circular(10),
                                  bottomRight: Radius.circular(10),
                                )),
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Text(
                                  ": له‌به‌ر فه‌رمایشتی خوای په‌روه‌ردگار",
                                  style: simpleTextStyle.copyWith(
                                      fontFamily: fontType.toString(),
                                      fontSize: fontSize),
                                  textAlign: TextAlign.center,
                                ),
                                Padding(
                                  padding:
                                      const EdgeInsets.symmetric(vertical: 10),
                                  child: Text(
                                    "وَامْسَحُوا بِرُءُوسِكُمْ",
                                    style: quranStyle.copyWith(
                                      fontFamily: quranFontType.toString(),
                                      fontSize: quranFontSize,
                                    ),
                                    textAlign: TextAlign.center,
                                  ),
                                ),
                                Text(
                                  "وه‌ ده‌ستتان بهێنن به‌ سه‌رتاندا) [المائدة, 6] ، وه‌ له‌به‌ر فه‌رمایشتی پێغەمبەر ﷺ : (الأذنان من الرأس - هه‌ردوو گوێ به‌شێكن‌‌ له‌ سه‌ر) [الترمذي:38 ، ابن ماجه: 443 ، «السلسلة الصحيحة: 36» ]",
                                  style: simpleTextStyle.copyWith(
                                      fontFamily: fontType.toString(),
                                      fontSize: fontSize),
                                  textAlign: TextAlign.center,
                                ),
                              ],
                            )),
                      ])),
                  const SizedBox(height: 20),
                  Container(
                      alignment: Alignment.topCenter,
                      padding: const EdgeInsets.all(10),
                      decoration: BoxDecoration(
                          color: thirdColor.withValues(alpha: 0.5),
                          borderRadius: BorderRadius.circular(10),
                          boxShadow: [
                            BoxShadow(
                                blurRadius: 20,
                                color: thirdColor,
                                offset: const Offset(0, 5))
                          ]),
                      child: Column(children: <Widget>[
                        Container(
                            padding: const EdgeInsets.all(8),
                            decoration: BoxDecoration(
                                color: splashColor.withAlpha(100),
                                borderRadius: BorderRadius.circular(10)),
                            child: Text(
                              "شۆردنی هەردوو پێ لەگەڵ هەردوو قولە پێ -4",
                              style: bigTextStyle.copyWith(
                                color: kActiveIconColor,
                                fontFamily: fontType.toString(),
                                fontSize: fontSize,
                              ),
                              textAlign: TextAlign.center,
                            )),
                        Container(
                            padding: const EdgeInsets.all(8),
                            decoration: BoxDecoration(
                                color: thirdColor.withValues(alpha: 0.5),
                                borderRadius: const BorderRadius.only(
                                  topLeft: Radius.circular(10),
                                  bottomLeft: Radius.circular(10),
                                  bottomRight: Radius.circular(10),
                                )),
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Text(
                                  ": له‌به‌ر فه‌رمایشتی خوای په‌روه‌ردگار",
                                  style: simpleTextStyle.copyWith(
                                      fontFamily: fontType.toString(),
                                      fontSize: fontSize),
                                  textAlign: TextAlign.center,
                                ),
                                Padding(
                                  padding:
                                      const EdgeInsets.symmetric(vertical: 10),
                                  child: Text(
                                    "وَأَرْجُلَكُمْ إِلَى الْكَعْبَيْنِ",
                                    style: quranStyle.copyWith(
                                      fontFamily: quranFontType.toString(),
                                      fontSize: quranFontSize,
                                    ),
                                    textAlign: TextAlign.center,
                                  ),
                                ),
                                Text(
                                  "وه‌ هه‌ردوو پێیه‌كانیشتان تاوه‌كو قوله پێكانتان بشۆن [سورة المائدة, آية 6].",
                                  style: simpleTextStyle.copyWith(
                                      fontFamily: fontType.toString(),
                                      fontSize: fontSize),
                                  textAlign: TextAlign.center,
                                ),
                              ],
                            )),
                      ])),
                  const SizedBox(height: 20),
                  Container(
                      alignment: Alignment.topCenter,
                      padding: const EdgeInsets.all(10),
                      decoration: BoxDecoration(
                          color: thirdColor.withValues(alpha: 0.5),
                          borderRadius: BorderRadius.circular(10),
                          boxShadow: [
                            BoxShadow(
                                blurRadius: 20,
                                color: thirdColor,
                                offset: const Offset(0, 5))
                          ]),
                      child: Column(children: <Widget>[
                        Container(
                            padding: const EdgeInsets.all(8),
                            decoration: BoxDecoration(
                                color: splashColor.withAlpha(100),
                                borderRadius: BorderRadius.circular(10)),
                            child: Text(
                              "ڕیزبەندی -5",
                              style: bigTextStyle.copyWith(
                                color: kActiveIconColor,
                                fontFamily: fontType.toString(),
                                fontSize: fontSize,
                              ),
                              textAlign: TextAlign.center,
                            )),
                        Container(
                            padding: const EdgeInsets.all(8),
                            decoration: BoxDecoration(
                                color: thirdColor.withValues(alpha: 0.5),
                                borderRadius: const BorderRadius.only(
                                  topLeft: Radius.circular(10),
                                  bottomLeft: Radius.circular(10),
                                  bottomRight: Radius.circular(10),
                                )),
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Text(
                                  "چونکه‌ خوای گه‌وره‌ به‌ ڕیزبه‌ندی باسی ئه‌ندامه‌كانی ده‌ستنوێژی كردووه‌‌؛ وه‌پێغەمبەر ﷺ به‌ڕیز ئه‌ندامه‌كانی ده‌ستنوێژی ده‌شۆرد هه‌ر وه‌ك چۆن له‌ فه‌رمووده‌دا هاتووه‌ (مسلم؛ 235) (1-ڕوخسار 2- دەسته‌كان تاوه‌كو ئانیشك 3- ده‌ستهێنان به‌ سه‌ر سه‌ردا 4- شۆردنی پێیه‌كان)",
                                  style: simpleTextStyle.copyWith(
                                      fontFamily: fontType.toString(),
                                      fontSize: fontSize),
                                  textAlign: TextAlign.center,
                                ),
                              ],
                            )),
                      ])),
                  const SizedBox(height: 20),
                  Container(
                      alignment: Alignment.topCenter,
                      padding: const EdgeInsets.all(10),
                      decoration: BoxDecoration(
                          color: thirdColor.withValues(alpha: 0.5),
                          borderRadius: BorderRadius.circular(10),
                          boxShadow: [
                            BoxShadow(
                                blurRadius: 20,
                                color: thirdColor,
                                offset: const Offset(0, 5))
                          ]),
                      child: Column(children: <Widget>[
                        Container(
                            padding: const EdgeInsets.all(8),
                            decoration: BoxDecoration(
                                color: splashColor.withAlpha(100),
                                borderRadius: BorderRadius.circular(10)),
                            child: Text(
                              "بەدوای یەکتردابوون بەبێ دواخستن -6",
                              style: bigTextStyle.copyWith(
                                color: kActiveIconColor,
                                fontFamily: fontType.toString(),
                                fontSize: fontSize,
                              ),
                              textAlign: TextAlign.center,
                            )),
                        Container(
                            padding: const EdgeInsets.all(8),
                            decoration: BoxDecoration(
                                color: thirdColor.withValues(alpha: 0.5),
                                borderRadius: const BorderRadius.only(
                                  topLeft: Radius.circular(10),
                                  bottomLeft: Radius.circular(10),
                                  bottomRight: Radius.circular(10),
                                )),
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Text(
                                  "كاتێك ئه‌ندامێكت ده‌شۆیت ده‌بێت ڕاسته‌وخۆ ئەندامی ‌دوای ئه‌و بشۆیت و دوای نه‌خه‌یت ، چونکه‌ كاتێك پێغەمبەر ﷺ دەستنوێژی ده‌گرت و ئەندامێکی ده‌شۆرد شۆردنی ئەندامه‌كه‌ی دوای ئه‌وی دوا نه‌ده‌خست.",
                                  style: simpleTextStyle.copyWith(
                                      fontFamily: fontType.toString(),
                                      fontSize: fontSize),
                                  textAlign: TextAlign.center,
                                ),
                              ],
                            )),
                      ])),
                  const SizedBox(height: 20),
                  Divider(color: kActiveIconColor),
                  const SizedBox(height: 20),
                  Container(
                    padding:
                        const EdgeInsets.symmetric(vertical: 8, horizontal: 12),
                    alignment: Alignment.center,
                    decoration: BoxDecoration(
                        color: kActiveIconColor,
                        borderRadius: BorderRadius.circular(555)),
                    child: Text("دەستنوێژگرتن بە ڕوونی",
                        style: bigTextStyle.copyWith(
                            color: Colors.white,
                            fontFamily: fontType.toString())),
                  ),
                  const SizedBox(height: 20),
                  const HeaderNwezhItem(text: "١- نیه‌تی ده‌ستنوێژگرتن بهێنه‌"),
                  const SizedBox(height: 20),
                  Text(
                    "كاتێك ویستت ده‌ستنوێژ بگریت : نیه‌ت له‌ دڵی خۆت دا بهێنه‌‌ ، وه‌ به‌ زمان ‌نیه‌ت مه‌هێنه‌، چونكه جێگای نیه‌ت دڵه‌.",
                    style: simpleTextStyle.copyWith(
                        fontFamily: fontType.toString(), fontSize: fontSize),
                    textAlign: TextAlign.center,
                  ),
                  const SizedBox(height: 20),
                  const BalgaWidget(
                    description:
                        "له‌به‌ر فه‌رمایشتی پێغەمبەر ﷺ: (إنما الأعمال بالنیات - هه‌موو كرده‌وه‌كان به‌ نیه‌ته‌وه‌ ئه‌نجام ده‌درێن) . [البخاری ، مسلم]",
                  ),
                  const SizedBox(height: 20),
                  Divider(color: kActiveIconColor),
                  const SizedBox(height: 20),
                  const HeaderNwezhItem(
                      text: "٢- ناوی خوای گه‌وره‌ بهێنه‌ و ده‌سته‌كانت بشۆ"),
                  const SizedBox(height: 20),
                  Text(
                    "بڵێ:‌ (بسم اللهِ) واته‌: به‌ ناوی خوا ده‌ستنوێژ ده‌گرم وه‌ ده‌سته‌كانت (3 جار) بشۆ.",
                    style: simpleTextStyle.copyWith(
                        fontFamily: fontType.toString(), fontSize: fontSize),
                    textAlign: TextAlign.center,
                  ),
                  const SizedBox(height: 20),
                  const BalgaWidget(
                    description:
                        "وتنی(بسم الله) واجبە ، له‌به‌ر فه‌رمایشتی پێغەمبەر ﷺ (لا وضوء لمن لم يذكر اسم الله عليه - دەسنوێژی ئه‌و كه‌سه‌ ته‌واو نییه‌ كه‌ ناوی خوای له‌سه‌ر نه‌هێنابێت). [احمد ، أبو داود ، الحاکم - وحسنه الألباني في «إرواء الغلیل 1/122»]",
                  ),
                  const SizedBox(height: 20),
                  Divider(color: kActiveIconColor),
                  const SizedBox(height: 20),
                  const HeaderNwezhItem(
                      text: "٣- ئاو له‌ ده‌م و لوتت وه‌رده‌ وفڕێی بده‌‌وه‌‌"),
                  const SizedBox(height: 20),
                  Text(
                    "به‌ ده‌ستی ڕاست، ئاو له‌ ده‌م و لوتت پێكه‌وه وه‌رده‌. وه‌ به ‌ده‌ستی چه‌پ ئاوه‌كه‌ فڕێ بدره‌‌وه‌‌ ( 3 جار)",
                    style: simpleTextStyle.copyWith(
                        fontFamily: fontType.toString(), fontSize: fontSize),
                    textAlign: TextAlign.center,
                  ),
                  const SizedBox(height: 20),
                  Center(
                      child: Column(children: <Widget>[
                    Align(
                      alignment: Alignment.centerRight,
                      child: Container(
                        padding: const EdgeInsets.all(8),
                        decoration: BoxDecoration(
                          color: thirdColor.withValues(alpha: 0.5),
                          borderRadius: const BorderRadius.only(
                            topLeft: Radius.circular(10),
                            topRight: Radius.circular(10),
                          ),
                        ),
                        child: Text(
                          "بەڵگە",
                          textAlign: TextAlign.center,
                          style: simpleTextStyle
                              .copyWith(
                                  fontFamily: fontType.toString(),
                                  fontSize: fontSize)
                              .copyWith(color: kActiveIconColor),
                        ),
                      ),
                    ),
                    Container(
                        width: double.infinity,
                        padding: const EdgeInsets.all(8),
                        decoration: BoxDecoration(
                            color: thirdColor.withValues(alpha: 0.5),
                            borderRadius: const BorderRadius.only(
                              topLeft: Radius.circular(10),
                              bottomLeft: Radius.circular(10),
                              bottomRight: Radius.circular(10),
                            )),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Text(
                              "فَمَضْمَضَ وَاسْتَنْشَقَ وَاسْتَنْثَرَ ثَلاثاً بِثَلاثِ غَرْفَاتٍ",
                              style: quranStyle.copyWith(
                                fontFamily: quranFontType.toString(),
                                fontSize: quranFontSize,
                              ),
                              textAlign: TextAlign.center,
                            ),
                            Text(
                              "پێغەمبەر ﷺ ئاوی وه‌ردا له‌ ده‌م و لوتی پێكه‌وه‌ وه‌ فڕێیدایه‌وه‌ «3 جار» ئه‌مه‌ی دووباره‌ ده‌كرده‌وه‌ به‌ سێ مشت)[البخاري(185) مسلم(235)]",
                              style: simpleTextStyle.copyWith(
                                  fontFamily: fontType.toString(),
                                  fontSize: fontSize),
                              textAlign: TextAlign.center,
                            ),
                          ],
                        )),
                  ])),
                  const SizedBox(height: 20),
                  Divider(color: kActiveIconColor),
                  const SizedBox(height: 20),
                  const HeaderNwezhItem(text: "٤- ڕوخسارت بشۆ"),
                  const SizedBox(height: 20),
                  Text(
                      "ڕوخساری خۆت (3 جار) بشۆ. سنوری ڕوخسار(الوجه): \nپانییه‌كه‌ی: نێوان دوو گوێچكه‌كه‌كان \nدرێژیه‌كه‌ی: له‌ شوێنی ڕووانی مووی سه‌ر تا چه‌ناگه‌",
                      style: simpleTextStyle.copyWith(
                          fontFamily: fontType.toString(), fontSize: fontSize),
                      textAlign: TextAlign.center),
                  const SizedBox(height: 20),
                  Center(
                      child: Column(children: <Widget>[
                    Align(
                      alignment: Alignment.centerRight,
                      child: Container(
                        padding: const EdgeInsets.all(8),
                        decoration: BoxDecoration(
                          color: thirdColor.withValues(alpha: 0.5),
                          borderRadius: const BorderRadius.only(
                            topLeft: Radius.circular(10),
                            topRight: Radius.circular(10),
                          ),
                        ),
                        child: Text(
                          "بەڵگە",
                          textAlign: TextAlign.center,
                          style: simpleTextStyle
                              .copyWith(
                                  fontFamily: fontType.toString(),
                                  fontSize: fontSize)
                              .copyWith(color: kActiveIconColor),
                        ),
                      ),
                    ),
                    Container(
                        width: double.infinity,
                        padding: const EdgeInsets.all(8),
                        decoration: BoxDecoration(
                            color: thirdColor.withValues(alpha: 0.5),
                            borderRadius: const BorderRadius.only(
                              topLeft: Radius.circular(10),
                              bottomLeft: Radius.circular(10),
                              bottomRight: Radius.circular(10),
                            )),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Text(
                              "إِذَا قُمْتُمْ إِلَى الصَّلَاةِ فَاغْسِلُوا وُجُوهَكُمْ",
                              style: quranStyle.copyWith(
                                fontFamily: quranFontType.toString(),
                                fontSize: quranFontSize,
                              ),
                              textAlign: TextAlign.center,
                            ),
                            Text(
                              "ڕوخسارتان بشۆن [سورة المائدة, آية 6]",
                              style: simpleTextStyle.copyWith(
                                  fontFamily: fontType.toString(),
                                  fontSize: fontSize),
                              textAlign: TextAlign.center,
                            ),
                          ],
                        )),
                  ])),
                  const SizedBox(height: 20),
                  Divider(color: kActiveIconColor),
                  const SizedBox(height: 20),
                  const HeaderNwezhItem(
                      text: "٥- ده‌سته‌كانت بشۆ تا ئانیشكه‌كانت"),
                  const SizedBox(height: 20),
                  Text(
                      "ده‌سته‌كانت له‌ سه‌ری په‌نجه‌كانته‌وه‌ تاوه‌كو ئانیشكه‌كانت (3 جار) بشۆ (ده‌ستی ڕاست پاشان ده‌ستی چه‌پ)",
                      style: simpleTextStyle.copyWith(
                          fontFamily: fontType.toString(), fontSize: fontSize),
                      textAlign: TextAlign.center),
                  const SizedBox(height: 20),
                  Center(
                      child: Column(children: <Widget>[
                    Align(
                      alignment: Alignment.centerRight,
                      child: Container(
                        padding: const EdgeInsets.all(8),
                        decoration: BoxDecoration(
                          color: thirdColor.withValues(alpha: 0.5),
                          borderRadius: const BorderRadius.only(
                            topLeft: Radius.circular(10),
                            topRight: Radius.circular(10),
                          ),
                        ),
                        child: Text(
                          "بەڵگە",
                          textAlign: TextAlign.center,
                          style: simpleTextStyle
                              .copyWith(
                                  fontFamily: fontType.toString(),
                                  fontSize: fontSize)
                              .copyWith(color: kActiveIconColor),
                        ),
                      ),
                    ),
                    Container(
                        width: double.infinity,
                        padding: const EdgeInsets.all(8),
                        decoration: BoxDecoration(
                            color: thirdColor.withValues(alpha: 0.5),
                            borderRadius: const BorderRadius.only(
                              topLeft: Radius.circular(10),
                              bottomLeft: Radius.circular(10),
                              bottomRight: Radius.circular(10),
                            )),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Text(
                              "وَأَيْدِيَكُمْ إِلَى الْمَرَافِقِ",
                              style: quranStyle.copyWith(
                                fontFamily: quranFontType.toString(),
                                fontSize: quranFontSize,
                              ),
                              textAlign: TextAlign.center,
                            ),
                            Text(
                              "وده‌سته‌كانتان ‌تاوه‌كو ئه‌نيشكه‌كانتان بشۆن",
                              style: simpleTextStyle.copyWith(
                                  fontFamily: fontType.toString(),
                                  fontSize: fontSize),
                              textAlign: TextAlign.center,
                            ),
                            Padding(
                              padding: const EdgeInsets.symmetric(vertical: 10),
                              child: Text(
                                "وَيَدَيْهِ إلَى الْمِرْفَقَيْنِ ثَلاثًا",
                                style: quranStyle.copyWith(
                                  fontFamily: quranFontType.toString(),
                                  fontSize: quranFontSize,
                                ),
                                textAlign: TextAlign.center,
                              ),
                            ),
                            Text(
                              "پێغەمبەر ﷺ ده‌سته‌كانی ‌تا ئانیشكه‌كانی (3 جار) ده‌شۆرد).[البخاري(164) مسلم(226 )]",
                              style: simpleTextStyle.copyWith(
                                  fontFamily: fontType.toString(),
                                  fontSize: fontSize),
                              textAlign: TextAlign.center,
                            ),
                          ],
                        )),
                  ])),

                  const SizedBox(height: 20),
                  Divider(color: kActiveIconColor),
                  const SizedBox(height: 20),
                  const HeaderNwezhItem(
                      text: "٦- ده‌ست بهێنه‌ به‌سه‌ر سه‌رت دا‌‌"),
                  const SizedBox(height: 20),
                  Text(
                      "له ده‌سپێكی سه‌ر تاوه‌كو پشته‌مل. وه‌ (سوننه‌ته‌) جارێكیتر ده‌سته‌كانت بگه‌ڕێنیته‌‌وه‌ شوێنی ده‌سپێك.",
                      style: simpleTextStyle.copyWith(
                          fontFamily: fontType.toString(), fontSize: fontSize),
                      textAlign: TextAlign.center),
                  const SizedBox(height: 20),
                  Center(
                      child: Column(children: <Widget>[
                    Align(
                      alignment: Alignment.centerRight,
                      child: Container(
                        padding: const EdgeInsets.all(8),
                        decoration: BoxDecoration(
                          color: thirdColor.withValues(alpha: 0.5),
                          borderRadius: const BorderRadius.only(
                            topLeft: Radius.circular(10),
                            topRight: Radius.circular(10),
                          ),
                        ),
                        child: Text(
                          "بەڵگە",
                          textAlign: TextAlign.center,
                          style: simpleTextStyle
                              .copyWith(
                                  fontFamily: fontType.toString(),
                                  fontSize: fontSize)
                              .copyWith(color: kActiveIconColor),
                        ),
                      ),
                    ),
                    Container(
                        width: double.infinity,
                        padding: const EdgeInsets.all(8),
                        decoration: BoxDecoration(
                            color: thirdColor.withValues(alpha: 0.5),
                            borderRadius: const BorderRadius.only(
                              topLeft: Radius.circular(10),
                              bottomLeft: Radius.circular(10),
                              bottomRight: Radius.circular(10),
                            )),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Text(
                              ": له‌به‌ر فه‌رمایشتی خوای په‌روه‌ردگار‌",
                              style: simpleTextStyle.copyWith(
                                  fontFamily: fontType.toString(),
                                  fontSize: fontSize),
                              textAlign: TextAlign.center,
                            ),
                            Padding(
                              padding: const EdgeInsets.symmetric(vertical: 10),
                              child: Text(
                                "وَامْسَحُوا بِرُءُوسِكُمْ",
                                style: quranStyle.copyWith(
                                  fontFamily: quranFontType.toString(),
                                  fontSize: quranFontSize,
                                ),
                                textAlign: TextAlign.center,
                              ),
                            ),
                            Text(
                              "وه‌ ده‌ست بهێنن به‌ سه‌ر تاندا)[سورة المائدة, آية 6]. مەسح کرنی به‌شێك له‌ سەر دروست نییه‌؛ ده‌بێت هەموو سەری خۆت مەسح بکەیت.",
                              style: simpleTextStyle.copyWith(
                                  fontFamily: fontType.toString(),
                                  fontSize: fontSize),
                              textAlign: TextAlign.center,
                            ),
                          ],
                        )),
                  ])),

                  const SizedBox(height: 20),
                  Divider(color: kActiveIconColor),
                  const SizedBox(height: 20),
                  const HeaderNwezhItem(
                      text: "٧- ده‌ست بهێنه‌ به‌ گوێچكه‌كانت دا"),
                  const SizedBox(height: 20),
                  Text(
                      "ده‌ست بهێنه‌ به گوێچكه‌كانتدا به‌و ئاوه‌ی كه‌ به‌ ده‌ستته‌وه‌ ماوه‌ته‌وه‌. به‌ هه‌ردوو په‌نجه‌ی شایه‌تومان ناوه‌وه‌ی هه‌ردوو گوێت مه‌سح بكه‌. به‌ په‌نجه گه‌وره‌كانت ‌ده‌ره‌وه‌ی گوێت مه‌سح بكه‌.",
                      style: simpleTextStyle.copyWith(
                          fontFamily: fontType.toString(), fontSize: fontSize),
                      textAlign: TextAlign.center),
                  const SizedBox(height: 20),
                  const BalgaWidget(
                      description:
                          "له‌به‌ر فه‌رمایشتی پێغەمبەر ﷺ : (الأذنان من الرأس - هه‌ردوو گوێ به‌شێكن‌‌ له‌ سه‌ر) [الترمذي:38 ، ابن ماجه: 443 ، صححه الالباني في«السلسلة الصحيحة: 36» ]."),

                  const SizedBox(height: 20),
                  Divider(color: kActiveIconColor),
                  const SizedBox(height: 20),
                  const HeaderNwezhItem(text: "٨- پێیەکانت بشۆ"),
                  const SizedBox(height: 20),
                  Text(
                      "پێیه‌كانت له‌ سه‌ری په‌نجه‌كانته‌‌وه‌‌ ‌تاوه‌كو قوله‌ پێت (3 جار) بشۆ. \n (پێ ی ڕاست پاشان پێ ی چه‌پ)",
                      style: simpleTextStyle.copyWith(
                          fontFamily: fontType.toString(), fontSize: fontSize),
                      textAlign: TextAlign.center),
                  const SizedBox(height: 20),
                  Center(
                      child: Column(children: <Widget>[
                    Align(
                      alignment: Alignment.centerRight,
                      child: Container(
                        padding: const EdgeInsets.all(8),
                        decoration: BoxDecoration(
                          color: thirdColor.withValues(alpha: 0.5),
                          borderRadius: const BorderRadius.only(
                            topLeft: Radius.circular(10),
                            topRight: Radius.circular(10),
                          ),
                        ),
                        child: Text(
                          "بەڵگە",
                          textAlign: TextAlign.center,
                          style: simpleTextStyle
                              .copyWith(
                                  fontFamily: fontType.toString(),
                                  fontSize: fontSize)
                              .copyWith(color: kActiveIconColor),
                        ),
                      ),
                    ),
                    Container(
                        width: double.infinity,
                        padding: const EdgeInsets.all(8),
                        decoration: BoxDecoration(
                            color: thirdColor.withValues(alpha: 0.5),
                            borderRadius: const BorderRadius.only(
                              topLeft: Radius.circular(10),
                              bottomLeft: Radius.circular(10),
                              bottomRight: Radius.circular(10),
                            )),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Text(
                              "غَسَلَ كِلْتَا رِجْلَيْهِ ثَلاثًا",
                              style: quranStyle.copyWith(
                                fontFamily: quranFontType.toString(),
                                fontSize: quranFontSize,
                              ),
                              textAlign: TextAlign.center,
                            ),
                            Text(
                              "پێغه‌مبه‌ر ﷺ( 3 جار) هه‌ردوو پێیه‌كانی ده‌شۆرد. [البخاري(164) مسلم(226)]",
                              style: simpleTextStyle.copyWith(
                                  fontFamily: fontType.toString(),
                                  fontSize: fontSize),
                              textAlign: TextAlign.center,
                            ),
                          ],
                        )),
                  ])),

                  const SizedBox(height: 20),
                  Divider(color: kActiveIconColor),
                  const SizedBox(height: 20),
                  const HeaderNwezhItem(text: "٩- ویردی دوای ده‌ستنوێژ"),
                  const SizedBox(height: 20),
                  Text(": كاتێك كه‌ له‌ ده‌ستنوێژ ته‌واو ده‌بیت، بڵێ‌",
                      style: simpleTextStyle.copyWith(
                          fontFamily: fontType.toString(), fontSize: fontSize),
                      textAlign: TextAlign.center),
                  const SizedBox(height: 20),
                  Text(
                    "أَشْهَدُ أَنْ لاَ إِلَهَ إِلاَّ الله وَحْدَهُ لاَ شَرِيكَ لَهُ وَأَشْهَدُ أَنَّ مُحَمَّداً عَبْدُهُ وَرَسُولُهُ ، اللَّهُمَّ اجْعَلْنِي مِنَ التَّوَابِينَ وَاجْعَلْنِي مِنَ المُتَطَهِّرِينَ",
                    style: quranStyle.copyWith(
                      fontFamily: quranFontType.toString(),
                      fontSize: quranFontSize,
                    ),
                    textAlign: TextAlign.center,
                  ),
                  const SizedBox(height: 20),

                  const BalgaWidget(
                    description:
                        "[مسلم (234) ،و زاد الترمذي (اللَّهُم اجعلني..) (صححه الألباني في «الإرواء 96»)",
                  )
                ],
              ))
        ],
      ),
    );
  }
}
