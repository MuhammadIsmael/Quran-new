import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:runaki_islam/providers/settings_provider.dart';
import 'package:runaki_islam/util/background.dart';
import 'package:runaki_islam/util/constans.dart';

class BatalkarNwezh extends StatefulWidget {
  final String? sarder;

  const BatalkarNwezh({super.key, this.sarder});
  @override
  State<StatefulWidget> createState() => _BatalkarNwezhState();
}

class _BatalkarNwezhState extends State<BatalkarNwezh> {
  List<Batalkar> batalkaryNwezh = [];

  int? fontType;
  double? fontSize;

  @override
  void initState() {
    super.initState();
    fontType = Provider.of<SettingsProvider>(context, listen: false)
        .getsettingField('font_family');

    fontSize = Provider.of<SettingsProvider>(context, listen: false)
        .getsettingField('font_size');
    batalkaryNwezh.add(
      Batalkar("دەستنوێژ شکاندن",
          "ئه‌و شتانه‌ی ده‌ستنوێژ ده‌شكێنن \n\n 1) میزكردن و پیسایی كردن و با لێ به‌ربوون (تڕ و فس) \n\n 2) شتێك ببێته‌ قه‌تماغه‌ له‌سه‌ر پێست، وه‌ك مۆم یان بۆیه‌ی نینۆك، یان هه‌ر شتێك تری هاوشێوه‌ \n\n 3) نووستنێكی قوڵ \n\n 4) له‌هۆش خۆ چوون ‌"),
    );
    batalkaryNwezh.add(
      Batalkar("بەتاڵکەری نوێژ",
          "ئه‌و شتانه‌ی نوێژ به‌تاڵ ده‌كه‌نه‌وه‌ \n \n 1) قسه‌كردن له‌كاتی نوێژ \n\n 2) شت خواردن \n\n 3) زۆر جوڵانه‌وه‌ \n\n 4) پێكه‌نینی به‌ ده‌نگ \n\n هه‌ر شتێكیش ده‌ستنوێژ بشكێنێ له‌كاتی نوێژدا، نوێژه‌كه‌ به‌تاڵ ده‌بێته‌وه‌."),
    );
    batalkaryNwezh.add(
      Batalkar("جوڵەی ناپەسەند",
          "ئه‌و شتانه‌ی له‌كاتی نوێژدا ناپه‌سه‌نده‌ (مكروه)ه بكرێن \n \n 1) ته‌ماشا نه‌كردنی شوێنی سوجده‌ \n\n 2) به‌په‌له‌ ئه‌نجامدانی نوێژ \n\n 3) ته‌ماشاكردنی ئاسمان \n\n 4) ئاوڕدانه‌وه‌ \n\n 5) په‌نجه‌ ته‌قاندن \n\n 6) هه‌ڵگرتنی شت به‌بێ پێویستی \n\n 7) نوێژ كردن له‌و كاته‌ی خه‌و به‌سه‌رت دا زاڵ بێ \n\n 8) باوێشك"),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: backgroundColor,
      appBar: AppBar(
        centerTitle: true,
        title: Text(
          widget.sarder!,
          style:
              TextStyle(fontFamily: fontType.toString(), color: titleTextColor),
        ),
        backgroundColor: thirdColor,
        elevation: 0.8,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_rounded),
          color: iconColor,
          onPressed: () {
            Navigator.pop(context);
          },
        ),
      ),
      body: Stack(
        children: [
          const Background2(),
          ListView.builder(
            padding:
                const EdgeInsets.only(top: 10, right: 8, left: 8, bottom: 80),
            scrollDirection: Axis.vertical,
            shrinkWrap: true,
            physics: const BouncingScrollPhysics(
                parent: AlwaysScrollableScrollPhysics()),
            itemCount: batalkaryNwezh.length,
            itemBuilder: (context, i) {
              String title = batalkaryNwezh[i].title;
              String text = batalkaryNwezh[i].text!;
              return _buildModelList(Batalkar(title, text), "${i + 1}");
            },
          ),
        ],
      ),
    );
  }

  Widget _buildModelList(Batalkar items, String count) {
    return Card(
      color: bgColor.withValues(alpha: 0.7),
      shadowColor: secondColor,
      elevation: 0,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      child: ExpansionTile(
        iconColor: kActiveIconColor,
        textColor: kActiveIconColor,
        childrenPadding: const EdgeInsets.all(8),
        expandedAlignment: Alignment.center,
        expandedCrossAxisAlignment: CrossAxisAlignment.center,
        leading: Text(count),
        title: Text(
          items.title,
          style: TextStyle(
              fontSize: fontSize,
              fontFamily: fontType.toString(),
              fontWeight: FontWeight.w500,
              color: titleTextColor),
          textAlign: TextAlign.center,
        ),
        children: <Widget>[
          ListTile(
            shape:
                RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
            title: Text(
              items.text!,
              style: simpleTextStyle.copyWith(
                  fontFamily: fontType.toString(), fontSize: fontSize),
              textAlign: TextAlign.center,
            ),
          )
        ],
      ),
    );
  }
}

class Batalkar {
  final String title;
  final String? text;

  Batalkar(this.title, this.text);
}
