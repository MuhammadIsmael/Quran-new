import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:runaki_islam/providers/settings_provider.dart';
import 'package:runaki_islam/util/background.dart';
import 'package:runaki_islam/util/constans.dart';

class HalaBawakan extends StatefulWidget {
  final String? sarder;

  const HalaBawakan({super.key, this.sarder});
  @override
  State<StatefulWidget> createState() => _HalaBawakanState();
}

class _HalaBawakanState extends State<HalaBawakan> {
  int? fontType;
  @override
  void initState() {
    fontType = Provider.of<SettingsProvider>(context, listen: false)
        .getsettingField('font_family');
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: backgroundColor,
      appBar: AppBar(
        centerTitle: true,
        title: Text(
          widget.sarder!,
          style:
              TextStyle(fontFamily: fontType.toString(), color: titleTextColor),
        ),
        backgroundColor: thirdColor,
        elevation: 0.8,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_rounded),
          color: iconColor,
          onPressed: () {
            Navigator.pop(context);
          },
        ),
      ),
      body: Stack(
        children: [
          const Background2(),
          Scrollbar(
            child: SingleChildScrollView(
              padding: const EdgeInsets.only(
                  right: 10, left: 10, top: 20, bottom: 80),
              physics: const BouncingScrollPhysics(
                  parent: AlwaysScrollableScrollPhysics()),
              scrollDirection: Axis.vertical,
              child: Column(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: <Widget>[
                    Container(
                      decoration: BoxDecoration(boxShadow: [
                        BoxShadow(
                            blurRadius: 20,
                            color: thirdColor,
                            offset: const Offset(0, 5))
                      ]),
                      child: ClipRRect(
                          borderRadius: BorderRadius.circular(10),
                          child: Image.asset("assets/images/nwezh/42.png")),
                    ),
                    const SizedBox(height: 20),
                    Container(
                      decoration: BoxDecoration(boxShadow: [
                        BoxShadow(
                            blurRadius: 20,
                            color: thirdColor,
                            offset: const Offset(0, 5))
                      ]),
                      child: ClipRRect(
                          borderRadius: BorderRadius.circular(10),
                          child: Image.asset("assets/images/nwezh/43.png")),
                    ),
                    const SizedBox(height: 20),
                    Container(
                      decoration: BoxDecoration(boxShadow: [
                        BoxShadow(
                            blurRadius: 20,
                            color: thirdColor,
                            offset: const Offset(0, 5))
                      ]),
                      child: ClipRRect(
                          borderRadius: BorderRadius.circular(10),
                          child: Image.asset("assets/images/nwezh/44.png")),
                    ),
                    const SizedBox(height: 20),
                    Container(
                      decoration: BoxDecoration(boxShadow: [
                        BoxShadow(
                            blurRadius: 20,
                            color: thirdColor,
                            offset: const Offset(0, 5))
                      ]),
                      child: ClipRRect(
                          borderRadius: BorderRadius.circular(10),
                          child: Image.asset("assets/images/nwezh/45.png")),
                    ),
                    const SizedBox(height: 20),
                    Container(
                      decoration: BoxDecoration(boxShadow: [
                        BoxShadow(
                            blurRadius: 20,
                            color: thirdColor,
                            offset: const Offset(0, 5))
                      ]),
                      child: ClipRRect(
                          borderRadius: BorderRadius.circular(10),
                          child: Image.asset("assets/images/nwezh/46.png")),
                    ),
                    const SizedBox(height: 20),
                    Container(
                      decoration: BoxDecoration(boxShadow: [
                        BoxShadow(
                            blurRadius: 20,
                            color: thirdColor,
                            offset: const Offset(0, 5))
                      ]),
                      child: ClipRRect(
                          borderRadius: BorderRadius.circular(10),
                          child: Image.asset("assets/images/nwezh/47.png")),
                    ),
                    const SizedBox(height: 20),
                    Container(
                      decoration: BoxDecoration(boxShadow: [
                        BoxShadow(
                            blurRadius: 20,
                            color: thirdColor,
                            offset: const Offset(0, 5))
                      ]),
                      child: ClipRRect(
                          borderRadius: BorderRadius.circular(10),
                          child: Image.asset("assets/images/nwezh/48.png")),
                    ),
                  ]),
            ),
          ),
        ],
      ),
    );
  }
}
