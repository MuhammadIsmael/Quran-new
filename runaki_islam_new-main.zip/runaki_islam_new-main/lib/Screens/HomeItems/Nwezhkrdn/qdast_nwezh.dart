import 'package:flutter/material.dart';
import 'package:flutter_staggered_animations/flutter_staggered_animations.dart';
import 'package:provider/provider.dart';
import 'package:runaki_islam/providers/settings_provider.dart';
import 'package:runaki_islam/util/background.dart';
import 'package:runaki_islam/util/constans.dart';

class QDastNwezh extends StatefulWidget {
  final String? sarder;

  const QDastNwezh({super.key, this.sarder});
  @override
  State<StatefulWidget> createState() => _QDastNwezhState();
}

class _QDastNwezhState extends State<QDastNwezh> {
  List<Question> dastNwezhList = [];

  int? fontType;
  double? fontSize;

  @override
  void initState() {
    super.initState();
    fontType = Provider.of<SettingsProvider>(context, listen: false)
        .getsettingField('font_family');

    fontSize = Provider.of<SettingsProvider>(context, listen: false)
        .getsettingField('font_size');
    dastNwezhList.add(Question("ئایا وتنی بسم اللە لەسەرەتای دەست نوێژ واجبە؟",
        "وەڵام؛بەڵێ واجبە بەپێی ئەم فەرموودەیە؛ \nعن ابي هريرة قال؛قال رسول الله ﷺ:(لا صلاة لمن لا وضوء له،ولا وضوء لمن لم يذكر اسم الله تعالی عليه.(صحیح)\nواتە؛نوێژ بۆ کەسێک نییە کە دەست نوێژی نەبێت،وە کەسێکیش لەسەرەتاوە بسم اللەـی نەکردبێت ئەوا دەستنوێژی نییە."));

    dastNwezhList.add(Question(
      "ئایا تەنها سێ جار شووشتنی ئەندامەکانی دەست نوێژ سوننەتە؟",
      "وەڵام؛نەخێر بەڵکو ڕیوایەتی تر هەیە کە پێغەمبەری خوا ﷺ "
          "یەک جار"
          " و "
          "دوو جار"
          " و "
          "سێ جار"
          "ـیش ئئەندامەکانی دەست نوێژی شووشتووە. \nتێبینی؛ئەم وەڵامە بەپێی ئەو فەرموودانەی کە لەکتێبی سونەتەکانی ئەبوداود هەیە وەڵام دراوەتەوە←بەرگی یەکەم←لاپەڕە ۱۰۱-۱۰٥",
    ));
    dastNwezhList.add(Question(
      "پرسیار ئایا ئاو پرژاندن لە نافەک لەکاتی دەست بەئاوگەیاندن ڕێگە پێدراوە؟",
      "وەڵام؛بەڵێ دروستە بەپێی ئەم فەرموودەیە \nعن سفيان بن الحكم الثقفي او الحكم الثقفي قال:كان رسول الله ﷺ اذا بال يتوضأ وينتضح. واتە؛کاتێک پێغەمبەری خوا ﷺ دەستی بەئاو بگەیاندایە دەستنوێژی دەگرت و ئاوی دەپرژاند لەنافەکی.\nسەرچاوە؛کتێبی سوننەتەکانی ئەبوداود",
    ));
    dastNwezhList.add(Question(
      "چارەسەری گومانی شکانی دەست نوێژ بەهۆی " "دەنگ و بۆن" " چییە؟",
      "وەڵام؛ئەمە وەسوەسەی شەیتانە و پێویستە پاڵی نەیت و گوێی پێ نەدەیت، لە بەر ئەم فەرموودەیە: پرسیار كرا لە پێغەمبەری خوا صلى الله عليه وسلم وترا: ئەی پێغەمبەری خوا ئەگەر پیاوێك گومانی ئەوەی بۆ دروست بوو كەوا شتێكی لێبووەتەوە لە ناو نوێژدا ؟ فەرمووی:((لا ينصرف حتـى يسمع صوتاً أو يـجد ريـحاً)) [متفق عليه] .\nواتە: لە نوێژەكەی نابێتەوە تاوەكو گوێی لە دەنگێك نەبێت یان هەست بە بۆنێك نەكات.",
    ));
    dastNwezhList.add(Question(
      "کەسێک لە کاتی نوێژدا میزەچرکێی بێت و قەترەیەک لەزەکەری بێتە خوارەوە،ئایا بەردەوام بێت لە نوێژ یاخود نوێژەکەی بپچڕێنێت و دەست نوێژ تازە بکاتەوە؟",
      "وەڵام؛لەکاتی نوێژدا میزەچرکە گوێی پێ نادرێ و بەردەوام دەبێت لەنوێژەکەی،بەڵام  دوای ئەوە دەست نوێژی شکاوە دەبێ دەست نوێژ بگرێتەوە و ئەو شوێنی میزەچرکێی بەرکەوتوە بیشوات. تێبینی؛بۆدڵنیابوون لەکەسێکی شارەزا بپرسە",
    ));

    dastNwezhList.add(Question(
      "ئایا دەست بەر زەکەر بکەوێت دەست نوێژ دەشکێت؟",
      "وەڵام؛بەڵێ دەست نوێژی دەشکێت ئەگەر ڕاستەوخۆ دەستی بەر زەکەری\nکەوتبێت،پێغەمبەری خوا ﷺ فەرموویەتی؛(هەر کەسێک دەست بدات لەزەکەری با دەستنوێژ بگرێتەوە).\nسەرچاوە؛کتێبی ئەبو داود بەرگی یەک لاپەڕە ۱۳٦-۱۳۷",
    ));
    dastNwezhList.add(Question(
      "چەندە ئاو بەسە بۆ دەست نوێژ؟",
      "وەڵام؛لەخاتو عائیشەوە ڕەزی خوای لێ بێت دەگێڕنەوە کە پێغەمبەری خوا ﷺ بە "
          "صاع"
          "ێک خۆی دەشت و بە موددێک دەستنوێژی دەگرت.(سەحیح)\nئاگاداربە بەفیڕۆدانی ئاو ڕێگەپێ نەدراوە.",
    ));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: backgroundColor,
      appBar: AppBar(
        centerTitle: true,
        title: Text(
          widget.sarder!,
          style:
              TextStyle(fontFamily: fontType.toString(), color: titleTextColor),
        ),
        backgroundColor: thirdColor,
        elevation: 0.8,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_rounded),
          color: iconColor,
          onPressed: () {
            Navigator.pop(context);
          },
        ),
      ),
      body: Stack(
        children: [
          const Background2(),
          AnimationLimiter(
            child: ListView.builder(
              padding:
                  const EdgeInsets.only(top: 10, right: 8, left: 8, bottom: 80),
              scrollDirection: Axis.vertical,
              shrinkWrap: true,
              physics: const BouncingScrollPhysics(
                  parent: AlwaysScrollableScrollPhysics()),
              itemCount: dastNwezhList.length,
              itemBuilder: (context, i) {
                String title = dastNwezhList[i].title;
                String text = dastNwezhList[i].text!;
                return AnimationConfiguration.staggeredGrid(
                    position: i,
                    duration: const Duration(milliseconds: 500),
                    columnCount: dastNwezhList.length,
                    child: ScaleAnimation(
                        duration: const Duration(milliseconds: 900),
                        curve: Curves.fastLinearToSlowEaseIn,
                        child: SlideAnimation(
                            horizontalOffset: 150,
                            verticalOffset: -100,
                            duration: const Duration(milliseconds: 900),
                            child: _buildModelList(
                                Question(title, text), "${i + 1}"))));
              },
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildModelList(Question items, String count) {
    return Card(
      color: bgColor.withValues(alpha: 0.7),
      shadowColor: secondColor,
      elevation: 0,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      child: ExpansionTile(
        textColor: kActiveIconColor,
        iconColor: kActiveIconColor,
        childrenPadding: const EdgeInsets.all(8),
        expandedAlignment: Alignment.center,
        expandedCrossAxisAlignment: CrossAxisAlignment.center,
        leading: Text(count),
        title: Text(
          items.title,
          style: TextStyle(
              fontFamily: fontType.toString(),
              fontSize: fontSize,
              fontWeight: FontWeight.w500,
              color: descriptionTectColor),
          textAlign: TextAlign.center,
        ),
        children: <Widget>[
          ListTile(
            shape:
                RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
            title: Text(
              items.text!,
              style: simpleTextStyle.copyWith(
                  fontFamily: fontType.toString(), fontSize: fontSize),
              textAlign: TextAlign.center,
            ),
          )
        ],
      ),
    );
  }
}

class Question {
  final String title;
  final String? text;

  Question(this.title, this.text);
}
