import 'package:flutter/material.dart';
import 'package:runaki_islam/util/background.dart';
import 'package:runaki_islam/util/constans.dart';
import 'package:runaki_islam/providers/settings_provider.dart';
import 'package:provider/provider.dart';

class ManayNwezh extends StatefulWidget {
  final String? sarder;

  const ManayNwezh({super.key, this.sarder});
  @override
  State<StatefulWidget> createState() => _ManayNwezhState();
}

class _ManayNwezhState extends State<ManayNwezh> {
  int? fontType;
  int? quranFontType;
  double? quranFontSize;
  double? fontSize;

  @override
  void initState() {
    super.initState();
    fontType = Provider.of<SettingsProvider>(context, listen: false)
        .getsettingField('font_family');
    quranFontType = Provider.of<SettingsProvider>(context, listen: false)
        .getsettingField('quran_font_family');
    quranFontSize = Provider.of<SettingsProvider>(context, listen: false)
        .getsettingField('quran_font_size');
    fontSize = Provider.of<SettingsProvider>(context, listen: false)
        .getsettingField('font_size');
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: backgroundColor,
      appBar: AppBar(
        centerTitle: true,
        title: Text(
          widget.sarder!,
          style:
              TextStyle(fontFamily: fontType.toString(), color: titleTextColor),
        ),
        backgroundColor: thirdColor,
        elevation: 0.8,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_rounded),
          color: iconColor,
          onPressed: () {
            Navigator.pop(context);
          },
        ),
      ),
      body: Stack(
        children: [
          const Background2(),
          SingleChildScrollView(
            padding:
                const EdgeInsets.only(right: 10, left: 10, top: 20, bottom: 80),
            physics: const BouncingScrollPhysics(
                parent: AlwaysScrollableScrollPhysics()),
            scrollDirection: Axis.vertical,
            child:
                Column(crossAxisAlignment: CrossAxisAlignment.end, children: <
                    Widget>[
              Container(
                  alignment: Alignment.center,
                  width: double.infinity,
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                      color: kActiveIconColor,
                      borderRadius: BorderRadius.circular(555)),
                  child: Text("مانای ئایەت و تەکبیرەکانی ناو نوێژ",
                      style: TextStyle(
                          fontFamily: fontType.toString(),
                          color: Colors.white))),
              const SizedBox(height: 20),
              middleTextStyle("تەکبیرەی دەست پێکردنی نوێژ"),
              quranTextStyle("اللهُ ٲَکْبَر"),
              textStyle(
                  "خودا لە هەموو شتێک گەورە ترە لە زات و ناو و سیفاتە جوان و بەرزەکانی"),
              spaceLine(),
              middleTextStyle("مانای سورەتی الفاتیحە"),
              quranTextStyle("بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِِ (١)"),
              textStyle(
                  "به ناوی خوای به‌خشنده‌ی میهره‌بان به ناوی ئه‌و خوایه‌ی كانگای ڕه‌حمه‌ت و سۆزو به‌زه‌ییه"),
              spaceLine(),
              quranTextStyle("الْحَمْدُ لِلَّهِ رَبِّ الْعَالَمِينَ (٢)"),
              textStyle(
                  "‌سوپاس و ستایش هه‌ر شایسته‌ی خوایه و بۆ خوایه‌، که خاوه‌ن و په‌روه‌ردگاری هه‌موو جیهانیان و هه‌موو بوونه‌وه‌ره."),
              spaceLine(),
              quranTextStyle("(٣)الرَّحْمَٰنِ الرَّحِيمِ"),
              textStyle(
                  "به‌خشنده‌ی میهره‌بان‌، کانگای ڕه‌حمه‌ت و میهره‌بانیه (ڕه‌حمه‌تی له دنیادا هه‌موو شتێکی گرتۆته‌وه‌، به‌ڵام له قیامه‌تدا ته‌نها بۆ ئیماندارانه‌)."),
              spaceLine(),
              quranTextStyle("(٤)مَالِكِ يَوْمِ الدِّينِ"),
              textStyle(
                  "خاوه‌ن و سه‌رداری ڕۆژی پاداشت و سزایه (پادشای ڕۆژی قیامه‌ته که دادپه‌روه‌ری ڕه‌هاو بێ سنووری تێدا به‌رپا ده‌کات)."),
              spaceLine(),
              quranTextStyle("إِيَّاكَ نَعْبُدُ وَإِيَّاكَ نَسْتَعِينُ (٥)"),
              textStyle(
                  "خوایه‌، ته‌نها هه‌ر تۆ ده‌په‌رستین و هه‌ر له‌تۆش داوای یارمه‌تی و پشتیوانی ده‌که‌ین (له کاروباری دین و دنیاماندا، به‌که‌سی تر له به‌نده‌کانت ناکرێت)."),
              spaceLine(),
              quranTextStyle("اهْدِنَا الصِّرَاطَ الْمُسْتَقِيمَ (٦)"),
              textStyle(
                  "خوایه به‌رده‌وام ڕێنمووییمان بفه‌رموو بۆ ئه‌م ڕێبازی ڕاست و دروستی ئیسلامه‌."),
              spaceLine(),
              quranTextStyle(
                  "صِرَاطَ الَّذِينَ أَنْعَمْتَ عَلَيْهِمْ غَيْرِ الْمَغْضُوبِ عَلَيْهِمْ وَلَا الضَّالِّينَ(٧)"),
              textStyle(
                  "که به‌رنامه و ڕێبازی ئه‌وانه‌یه له نازو نیعمه‌تی خۆت به‌هره‌وه‌رت کردوون، نه‌مانخه‌یته سه‌ر ڕێبازی ئه‌وانه‌ی خه‌شم و قینیان لێگیراوه (به‌هۆی ئه‌وه‌وه ده‌یزانن و لایانداوه‌)، هه‌روه‌ها نه‌مانخاته سه‌ر ڕێبازی ئه‌وانه‌ش، که سه‌رگه‌ردان و گومڕان (به‌هۆی لاساری و یاخی بوون و نه‌زانینیانه‌وه‌)"),
              spaceLine(),
              quranTextStyle("آمین"),
              textStyle("خوایە دوعاکانمان قبوڵ بکە و وەڵاممان بدەوە"),
              spaceLine(),
              middleTextStyle("مانای زیکری چەمینەوە و رکوع"),
              quranTextStyle("سبحان ربي العظيم"),
              textStyle("پاکی و بێ گەردی بۆ پەروەردگاری گەورە و مەزنم"),
              middleTextStyle("مانای ڕاستبوونەوە وهەستانەوە لە ڕوکوع"),
              quranTextStyle(
                  "سَمِعَ اللهُ لِمَنْ حَمِدَە / رَبَّنا وَ لَكَ الْحَمْدُ"),
              textStyle(
                  "خودا نزا و ستایشی ئەو کەسەی بیست و وەری گرت کە سوپاس و ستایشی کرد / پەروەردگارمان هەموو سوپاس و ستایش هەر بۆ تۆیە"),
              spaceLine(),
              middleTextStyle("مانای زیکری سوجدە بردن"),
              quranTextStyle("سُبْـحانَ رَبِّـيَ الأَعْلـى"),
              textStyle("پاکی و بێ گەردی بۆ پەروەردگاری بەرز و بڵند"),
              spaceLine(),
              middleTextStyle("دوعای دانیشتنی نێوان دوو سوجدە بردنەکە"),
              quranTextStyle("رَبِّ اغْفِرْ لِي ، رَبِّ اغْفِرْ لِي"),
              textStyle("پەروەردگارم لێم خۆش ببە ، پەروەردگارم لێم خۆش ببە"),
              spaceLine(),
              middleTextStyle("مانای تەحیات"),
              quranTextStyle("التحياتُ لله و الصَلَواتُ و والطَیباتُ"),
              textStyle(
                  "سەلام و گەورەیی و پاک و بێ گەردی و داوا کردن و کردەوەی پاک و چاک هەر بۆ خودایە"),
              spaceLine(),
              quranTextStyle("السلام علی النَبى و رحمةُ الله وبركاتهُ"),
              textStyle(
                  "سڵاو ڕەحمەت و بەرەکەتی خوا لەسەر پێغەمبەری خودا بێت ﷺ"),
              spaceLine(),
              quranTextStyle("اسلام علینا و علی عباد اللە الصالحین"),
              textStyle(
                  "سڵاو لەسەر ئێمە و لەسەر هەموو بەندە چاکەکانی خوای گەورە بێت"),
              spaceLine(),
              quranTextStyle(
                  "أشهدُ أن لا اله الا الله و أشهد أنَ محمداَ عبدە و رسولە"),
              textStyle(
                  "شایەتی دەدەم کە هیج پەرستراوێک شایستەی پەرستن نییە جگە لە الله ، وە شایەتیش دەدەم کە محمد ﷺ بەندە و نێردراوی خودایە"),
              spaceLine(),
              quranTextStyle("أللهم صل على محمد و على آل محمد"),
              textStyle(
                  "خوایە دروود و سەڵاوات بڕژێنە بە سەر محمد ﷺ و خانەوادەی محمد ﷺ"),
              spaceLine(),
              quranTextStyle("كما صليت على إبراهيم و على آل إبراهيم"),
              textStyle(
                  "هەروەکو چۆن دروودت ڕژاند بەسەر ئیبراهیم و خانەوادەی ئیبراهیم"),
              spaceLine(),
              quranTextStyle("اللهم بارك علی محمد و علی آل محمد"),
              textStyle("خوایە پیرۆزی بڕژێنە بە سەر محمد ﷺ و خانەوادەی محمد ﷺ"),
              spaceLine(),
              quranTextStyle("کما بارکت علی ابراهیم و علی آل ابراهیم"),
              textStyle(
                  "هەروەکو چۆن پیرۆزیت ڕژاند بەسەر ئیبراهیم و خانەوادەی ئیبراهیم"),
              spaceLine(),
              quranTextStyle("إنك حميدُ مجيد"),
              textStyle("بەڕاستی تۆ سوپاس و ستایش کراویت و خاوەن شکۆیت"),
              spaceLine(),
              middleTextStyle("مانای دوعای دوای تەحیات"),
              quranTextStyle(
                  "اللَّهُمَّ إِنِّي أَعُوذُ بِكَ مِنْ عَذَابِ الْقَبْر ِ, و َمِنْ عَذَابِ جَهَنَّمَ ، وَمِنْ فِتْنَةِ الْمَحْيَا وَالْمَمَاتِ, وَمِنْ شَرِّ فِتْنَةِ الْمَسِيحِ الدَّجَّالِ"),
              textStyle(
                  "خودایە پەنات پێدەگرم لە سزای ناو گۆڕ و سزای دۆزەخ و ئاشوبەی ژیان و ئاشوبەی مردن و خراپەی ئاشوبەی مەسیحی دەجال"),
              spaceLine(),
            ]),
          ),
        ],
      ),
    );
  }

  Widget middleTextStyle(String text) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.only(bottom: 10),
        child: Text(
          text,
          style: simpleTextStyle.copyWith(
              fontFamily: fontType.toString(), fontSize: fontSize),
          textAlign: TextAlign.center,
        ),
      ),
    );
  }

  Widget textStyle(String text) {
    return Padding(
      padding: const EdgeInsets.only(top: 10),
      child: Text(
        text,
        style: simpleTextStyle.copyWith(
            fontFamily: fontType.toString(), fontSize: fontSize),
        textAlign: TextAlign.right,
      ),
    );
  }

  Widget quranTextStyle(String text) {
    return Text(
      text,
      style: quranStyle.copyWith(
        fontFamily: quranFontType.toString(),
        fontSize: quranFontSize,
      ),
      textAlign: TextAlign.right,
    );
  }

  Widget spaceLine() {
    return Divider(
      color: splashColor,
      thickness: 3,
      height: 25,
    );
  }
}
