import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:runaki_islam/providers/settings_provider.dart';
import 'package:runaki_islam/util/background.dart';
import 'package:runaki_islam/util/constans.dart';

class JNwezhakan extends StatefulWidget {
  final String? sarder;
  final String? text;

  const JNwezhakan({super.key, this.sarder, this.text});
  @override
  State<StatefulWidget> createState() => _JNwezhakanState();
}

class _JNwezhakanState extends State<JNwezhakan> {
  int? fontType;
  double? fontSize;
  @override
  void initState() {
    fontType = Provider.of<SettingsProvider>(context, listen: false)
        .getsettingField('font_family');
    fontSize = Provider.of<SettingsProvider>(context, listen: false)
        .getsettingField('font_size');
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: backgroundColor,
      appBar: AppBar(
        centerTitle: true,
        title: Text(
          widget.sarder!,
          style:
              TextStyle(fontFamily: fontType.toString(), color: titleTextColor),
        ),
        backgroundColor: thirdColor,
        elevation: 0.8,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_rounded),
          color: iconColor,
          onPressed: () {
            Navigator.pop(context);
          },
        ),
      ),
      body: Stack(
        children: [
          const Background2(),
          SingleChildScrollView(
            padding:
                const EdgeInsets.only(right: 10, left: 10, top: 20, bottom: 80),
            physics: const BouncingScrollPhysics(
                parent: AlwaysScrollableScrollPhysics()),
            scrollDirection: Axis.vertical,
            child: Column(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: <Widget>[
                  Text(
                    widget.text!,
                    style: simpleTextStyle.copyWith(
                      fontFamily: fontType.toString(),
                      fontSize: fontSize,
                    ),
                    textAlign: TextAlign.center,
                  ),
                ]),
          ),
        ],
      ),
    );
  }
}
