import 'package:background_app_bar/background_app_bar.dart';
import 'package:flutter/material.dart';
import 'package:flutter_staggered_animations/flutter_staggered_animations.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:runaki_islam/Screens/HomeItems/PayakaneEmanIslam/ArkakaneEman/arkakane_eman.dart';
import 'package:runaki_islam/Screens/HomeItems/PayakaneEmanIslam/ArkakaneIslam/arkakane_islam.dart';
import 'package:runaki_islam/util/background.dart';
import 'dart:ui';
import 'package:runaki_islam/providers/settings_provider.dart';
import 'package:provider/provider.dart';
import 'package:runaki_islam/util/constans.dart';
import 'package:runaki_islam/util/navigate_between_pages/size_route.dart';

class PayakaneEmanuIskam extends StatefulWidget {
  final String? sarder;

  const PayakaneEmanuIskam({super.key, this.sarder});
  @override
  State<StatefulWidget> createState() => _ZhyanNamayPexambarmanState();
}

class _ZhyanNamayPexambarmanState extends State<PayakaneEmanuIskam> {
  int? fontType;
  @override
  void initState() {
    fontType = Provider.of<SettingsProvider>(context, listen: false)
        .getsettingField('font_family');
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
      backgroundColor: bgColor,
      body: NestedScrollView(
        physics: const BouncingScrollPhysics(),
        headerSliverBuilder: (_, _) => <Widget>[
          SliverAppBar(
            leading: IconButton(
              icon: Icon(
                Icons.arrow_back_ios_rounded,
                color: iconColor,
              ),
              onPressed: () {
                Navigator.pop(context);
              },
            ),
            expandedHeight: 200,
            floating: false,
            pinned: true,
            snap: false,
            elevation: 0.0,
            backgroundColor: Colors.transparent,
            flexibleSpace: BackgroundFlexibleSpaceBar(
              collapseMode: CollapseMode.parallax,
              centerTitle: true,
              title: Text(
                widget.sarder!,
                style: bigTextStyle.copyWith(
                    fontFamily: fontType.toString(), color: Colors.white),
              ),
              titlePadding: const EdgeInsets.all(50),
              background: ClipRect(
                child: Container(
                  decoration: const BoxDecoration(
                      image: DecorationImage(
                    image: AssetImage(
                      "assets/images/read-quran.jpg",
                    ),
                    fit: BoxFit.fill,
                  )),
                  child: BackdropFilter(
                    filter: ImageFilter.blur(sigmaX: 5.0, sigmaY: 5.0),
                    child: Container(
                      decoration: BoxDecoration(
                        color: thirdColor.withValues(alpha: 0.5),
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ),
        ],
        body: Stack(
          children: [
            const Background2(),
            Padding(
              padding: const EdgeInsets.all(15.0),
              child: AnimationLimiter(
                child: Column(children: [
                  Expanded(
                    child: homePageCardsGroup(kActiveIconColor,
                        "assets/icons/tajwed.svg", 'ئەرکەکانی ئیمان', () {
                      Navigator.push(
                          context,
                          SizeRoute(
                              page: const ArkakaneEmanPage(
                                  sarder: "ئەرکەکانی ئیمان")));
                    }, "1"),
                  ),
                  Expanded(
                    child: homePageCardsGroup(kActiveIconColor,
                        "assets/icons/tajwed.svg", 'ئەرکەکانی ئیسلام', () {
                      Navigator.push(
                          context,
                          SizeRoute(
                              page: const ArkakaneIslamPage(
                                  sarder: "ئەرکەکانی ئیسلام")));
                    }, "2"),
                  )
                ]),
              ),
            ),
          ],
        ),
      ),
    ));
  }

  Widget homePageCardsGroup(Color color, String icon, String title,
      VoidCallback onTap, String count) {
    double w = MediaQuery.of(context).size.width;
    return Padding(
      padding: EdgeInsets.only(bottom: w / 17),
      child: homePageCard(color, icon, title, onTap, count),
    );
  }

  Widget homePageCard(Color color, String icon, String title,
      VoidCallback onTap, String count) {
    return InkWell(
      splashColor: kActiveIconColor,
      customBorder:
          RoundedRectangleBorder(borderRadius: BorderRadius.circular(25)),
      onTap: onTap,
      child: Stack(
        children: [
          Container(
            padding: const EdgeInsets.all(15),
            width: double.infinity,
            height: double.infinity,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(25),
              color: backgroundColor.withValues(alpha: 0.8),
              boxShadow: [
                BoxShadow(
                  color: const Color(0xFF282547).withValues(alpha: .15),
                  blurRadius: 20,
                ),
              ],
            ),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                const SizedBox(),
                Container(
                  padding: const EdgeInsets.all(10),
                  decoration: BoxDecoration(
                    color: color.withValues(alpha: .1),
                    shape: BoxShape.circle,
                  ),
                  child: SvgPicture.asset(
                    icon,
                    height: 40,
                    width: 40,
                    colorFilter: ColorFilter.mode(
                      color.withValues(alpha: .6),
                      BlendMode.srcIn,
                    ),
                  ),
                ),
                Text(
                  title,
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                    fontFamily: fontType.toString(),
                    fontSize: 20,
                    color: descriptionTectColor,
                    fontWeight: FontWeight.w700,
                  ),
                  textAlign: TextAlign.center,
                ),
                const SizedBox(),
              ],
            ),
          ),
          Container(
            padding:
                const EdgeInsets.symmetric(horizontal: 10.0, vertical: 5.0),
            decoration: const BoxDecoration(
              color: Color(0x83CEECE8),
              borderRadius: BorderRadius.only(
                  bottomRight: Radius.circular(10),
                  topLeft: Radius.circular(20)),
            ),
            child: Text(
              count,
              textAlign: TextAlign.center,
              style: TextStyle(
                fontFamily: fontType.toString(),
                color: kActiveIconColor,
                fontWeight: FontWeight.w700,
                fontSize: 12,
              ),
            ),
          ),
        ],
      ),
    );
  }
}
