import 'package:runaki_islam/Screens/HomeItems/Pexambarman/page_view.dart';
import 'package:flutter/material.dart';
import 'package:flutter_staggered_animations/flutter_staggered_animations.dart';
import 'package:runaki_islam/util/background.dart';
import 'package:runaki_islam/util/constans.dart';
import 'package:runaki_islam/util/item_list.dart';
import 'package:page_transition/page_transition.dart';
import 'package:runaki_islam/providers/settings_provider.dart';
import 'package:provider/provider.dart';

class BawarbunBaxwda extends StatefulWidget {
  final String? sarder;

  const BawarbunBaxwda({super.key, this.sarder});
  @override
  State<StatefulWidget> createState() => _ZhyanNamaState();
}

class _ZhyanNamaState extends State<BawarbunBaxwda> {
  final List<MyList> _list = [];int? fontType;

  @override
  void initState() {
    super.initState();    fontType = Provider.of<SettingsProvider>(context, listen: false)
        .getsettingField('font_family');
    _list.add(MyList(
      title: "خوا لە ئیسلامدا",
      desc:
          "خوا لە ئیسلامدا، زاتێکی بێ ھاوتا و دادپەروەرە، نەمرە و ھیچ ھاوەڵ و ھاوبەشێکی نیە، پەرستراوی حەقی ھەموو دروستکراوانە، و موسڵمانان لەو باوەڕەدان کە خوا تاک و تەنھایە و جێی ڕاز ونیازە، بەخشندە و میھرەبانە، لە گوناە خۆش دەبێت و گەڕانەوە وەر ئەگرێت و جیاوازی ناکات لە نێوان خەڵکدا تەنھا بە کردەوەی چاک نەبێت. دروستکەری گەردوونە و باڵادەستە بەسەر ھەموو شتێکیا، جیاوازە لە ھەموو دروستکراوانی و دوورە لە پێشبینی بەشەر.... یەکەم بنەمای بیروباوەڕ یان عەقیدەی ئیسلام باوەڕبوونە بە بوونی خوا (أللە). کە ئەمەش باوەڕی تەواو ئەگریتەوە بە خوا وەک پەروەردگاری پەرستراوی تاک و بێ ھاوەڵ، و ھەروەھا باوەڕبوون بە ھەموو ناو و سیفەتەکانی خوا کە لە قورئان و سوننەتی پێغەمبەردا ھاتوون.",
    ));
    _list.add(MyList(
      title: "باوەربوون بە خوا",
      desc:
          "باوەڕبوون بە خوا یەکەم پایەیە لە پایەکانی باوەڕ وەک پێغەمبەری ئیسلام ڕوونی کردۆتەوە لە وەڵامی پرسیارێکی جوبڕەیلدا لەسەر باوەڕ، فەرموویەتی (باوەڕت بە خوا و فریشتەکانی و کتێبەکانی و پێغەمبەرەکانی ھەبێت...) [١]\n\nو باوەڕ بە خوا ڕۆحی ئیسلامە، و گرنگنرین پایەی بیروباوەری ڕاستە، و مانای باوەربوون بە خوا ئەوەیە کە موسڵمان باوەری ھەبێت بەوەی کە خوا پەروەردگاری ھەموو بونەوەرە، و ھیچ پەروەردگارێک نیە بێجگە لە ئەو، بەدیھینەری ھەموو بوونەوەرە و بەدیھینەر نیە بێجگە لە ئەو، و خاوەن ڕەھایی تەواوە، و بڕیاردان و خاوەنێتی بە دەستە، و پەرستراوی حەقە و ھاوبەشی نیە، و موسڵمانان لەو باوەرەدان کە خوا خاوەنی ھەموو سیفەتێکی تەواوە، لە کەس نەبووە و کەسی لێ نابێت و هاوبەشی نیە. بەم شێوەیە باوەربوون بە خوا چوار بوار ئەگرێتەوە؛\n\n    یەکەم/ باوەڕبوون بە بوونی خوا.\n    دووەم/ باوەربوون بە پەروەردگارێتی خوا\n    سێیەم/ باوەربوون بە پەرستراوێتی خوا\n    چوارەم/ باوەڕبوون بە ناو وسیفەتەکانی.\n",
    ));
    _list.add(MyList(
      title: "سیفەتەکانی خوا",
      desc:
          "لە ئیسلامدا، خوا پەرستراوی حەق و تاک و تەنھایە، زانا و بەدیھێنەرە و ڕۆزی دەری ھەموو زیندەوەرانە، بەتوانا و بەخشندە و بە بەزییە لە گوناە خۆش دەبێت و گەڕانەوە وەردەگرێت و لێبوردە و لێخۆشبووە و کار بەجێ و لێزانە و جێی ڕاز و نیازە، ھەروەھا خوا نەوەد و نۆ ناوی ھەیە کە موسڵمانان باوەڕیان پێی ھەیە.",
    ));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bgColor,
      appBar: AppBar(
        toolbarHeight: 80,
        backgroundColor: thirdColor,
        title: Text(
          "${widget.sarder}",
          style: simpleTextStyle.copyWith(  fontFamily: fontType.toString(),)
        ),
        shape: const RoundedRectangleBorder(
            borderRadius: BorderRadius.vertical(bottom: Radius.circular(20))),
        centerTitle: true,
        elevation: 0,
        leading: IconButton(
          color: iconColor,
          onPressed: () => Navigator.pop(context),
          icon: const Icon(Icons.arrow_back_ios_rounded),
        ),
      ),
      body: Stack(
        children: [
          const Background(),
          Column(
            children: [
              Expanded(
                child: Padding(
                  padding: const EdgeInsets.only(top: 20),
                  child: AnimationLimiter(
                    child: ListView.builder(
                      physics: const BouncingScrollPhysics(),
                      scrollDirection: Axis.vertical,
                      itemCount: _list.length,
                      itemBuilder: (context, i) {
                        final a = _list[i];
                        return AnimationConfiguration.staggeredList(
                            position: i,
                            delay: const Duration(milliseconds: 100),
                            child: SlideAnimation(
                                duration: const Duration(milliseconds: 2500),
                                curve: Curves.fastLinearToSlowEaseIn,
                                horizontalOffset: 30,
                                verticalOffset: 300.0,
                                child: FlipAnimation(
                                  duration: const Duration(milliseconds: 3000),
                                  curve: Curves.fastLinearToSlowEaseIn,
                                  flipAxis: FlipAxis.y,
                                  child: ItemCard2(
                                    title: a.title,
                                    count: "${i + 1}",
                                    onPress: () {
                                      getItemNavigate(
                                          a.title!, a.desc!, context);
                                    },
                                  ),
                                )));
                      },
                    ),
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  void getItemNavigate(String title, String desc, BuildContext context) {
    Navigator.push(
        context,
        PageTransition(
            child: TextPageView(
              sarder: widget.sarder!,
              title: title,
              desc: desc,
            ),
            type: PageTransitionType.leftToRightWithFade));
  }
}

class MyList {
  final String? title;
  final String? desc;

  MyList({this.title, this.desc});
}
