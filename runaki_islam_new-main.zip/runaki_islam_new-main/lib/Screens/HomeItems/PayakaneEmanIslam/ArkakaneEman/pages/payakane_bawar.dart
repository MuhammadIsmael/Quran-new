import 'package:runaki_islam/Screens/HomeItems/Pexambarman/page_view.dart';
import 'package:flutter/material.dart';
import 'package:flutter_staggered_animations/flutter_staggered_animations.dart';
import 'package:runaki_islam/util/background.dart';
import 'package:runaki_islam/util/constans.dart';
import 'package:runaki_islam/util/item_list.dart';
import 'package:page_transition/page_transition.dart';
import 'package:runaki_islam/providers/settings_provider.dart';
import 'package:provider/provider.dart';

class PayakaneBawar extends StatefulWidget {
  final String? sarder;

  const PayakaneBawar({super.key, this.sarder});
  @override
  State<StatefulWidget> createState() => _ZhyanNamaState();
}

class _ZhyanNamaState extends State<PayakaneBawar> {
  final List<MyList> _list = [];

  int? fontType;

  @override
  void initState() {
    super.initState();
    fontType = Provider.of<SettingsProvider>(context, listen: false)
        .getsettingField('font_family');
    _list.add(MyList(
        title: "پایەکانی باوەڕ لە ئیسلامدا",
        desc:
            "بۆ ئەوەی مرۆڤ موسڵمان بێت پێویستە لەسەری باوەڕی بە پایەکانی باوەڕ هەبێت کە لە ئیسلامدا بە شەش پایە ناسراون؛ وەک لە قورئاندا هاتووە ؛ ﴿آمَنَ الرَّسُولُ بِمَا أُنزِلَ إِلَيْهِ مِن رَّبِّهِ وَالْمُؤْمِنُونَ كُلٌّ آمَنَ بِاللّهِ وَمَلآئِكَتِهِ وَكُتُبِهِ وَرُسُلِهِ لاَ نُفَرِّقُ بَيْنَ أَحَدٍ مِّن رُّسُلِهِ وَقَالُواْ سَمِعْنَا وَأَطَعْنَا غُفْرَانَكَ رَبَّنَا وَإِلَيْكَ الْمَصِيرُ) واتە؛ پێغه‌مبه‌رو ئیمانداران باوه‌ڕیان هه‌یه به‌وه‌ی له لایه‌ن په‌روه‌ردگاریانه‌وه هاتۆته خواره‌وه‌، هه‌موویان باوه‌ڕیان هه‌یه به خواو فریشته‌کانی و کتێبه‌کانی و پێغه‌مبه‌ره‌کانی (ده‌ڵێن) هیچ جۆره جیاوازیه‌ک ناکه‌ین له نێوان هیچ پێغه‌مبه‌رێ له پێغه‌مبه‌ره‌کانی خوادا.\n\nو کاتێک لە پێغەمبەر محەمەد پرسراوە لەسەر باوەر، لە وەڵامدا فەرموویەتی؛ {أن تؤمن بالله وملائكته وكتبه ورسله واليوم الآخر, وتؤمن بالقدر خيره وشره} واتە؛ باوەڕت بە خوا و فریشتەکانی و کتێبەکانی و پێغەمبەرەکانی و و ڕۆژی دوایی هەبێت، هەروەها باوەڕت بە قەدەر هەبێت بە باش و خراپیەوە. "));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bgColor,
      appBar: AppBar(
        toolbarHeight: 80,
        backgroundColor: thirdColor,
        title: Text(
          "${widget.sarder}",
          style: simpleTextStyle.copyWith(
            fontFamily: fontType.toString(),
          ),
        ),
        shape: const RoundedRectangleBorder(
            borderRadius: BorderRadius.vertical(bottom: Radius.circular(20))),
        centerTitle: true,
        elevation: 0,
        leading: IconButton(
          color: iconColor,
          onPressed: () => Navigator.pop(context),
          icon: const Icon(Icons.arrow_back_ios_rounded),
        ),
      ),
      body: Stack(
        children: [
          const Background(),
          Column(
            children: [
              Expanded(
                child: Padding(
                  padding: const EdgeInsets.only(top: 20),
                  child: AnimationLimiter(
                    child: ListView.builder(
                      physics: const BouncingScrollPhysics(),
                      scrollDirection: Axis.vertical,
                      itemCount: _list.length,
                      itemBuilder: (context, i) {
                        final a = _list[i];
                        return AnimationConfiguration.staggeredList(
                            position: i,
                            delay: const Duration(milliseconds: 100),
                            child: SlideAnimation(
                                duration: const Duration(milliseconds: 2500),
                                curve: Curves.fastLinearToSlowEaseIn,
                                horizontalOffset: 30,
                                verticalOffset: 300.0,
                                child: FlipAnimation(
                                  duration: const Duration(milliseconds: 3000),
                                  curve: Curves.fastLinearToSlowEaseIn,
                                  flipAxis: FlipAxis.y,
                                  child: ItemCard2(
                                    title: a.title,
                                    count: "${i + 1}",
                                    onPress: () {
                                      getItemNavigate(
                                          a.title!, a.desc!, context);
                                    },
                                  ),
                                )));
                      },
                    ),
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  void getItemNavigate(String title, String desc, BuildContext context) {
    Navigator.push(
        context,
        PageTransition(
            child: TextPageView(
              sarder: widget.sarder!,
              title: title,
              desc: desc,
            ),
            type: PageTransitionType.leftToRightWithFade));
  }
}

class MyList {
  final String? title;
  final String? desc;

  MyList({this.title, this.desc});
}
