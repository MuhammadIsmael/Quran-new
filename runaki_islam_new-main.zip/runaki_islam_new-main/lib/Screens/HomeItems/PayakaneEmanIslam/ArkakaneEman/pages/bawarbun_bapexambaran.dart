import 'package:runaki_islam/Screens/HomeItems/Pexambarman/page_view.dart';
import 'package:flutter/material.dart';
import 'package:flutter_staggered_animations/flutter_staggered_animations.dart';
import 'package:runaki_islam/util/background.dart';
import 'package:runaki_islam/util/constans.dart';
import 'package:runaki_islam/util/item_list.dart';
import 'package:page_transition/page_transition.dart';
import 'package:runaki_islam/providers/settings_provider.dart';
import 'package:provider/provider.dart';

class BawarbunbaPexambaran extends StatefulWidget {
  final String? sarder;

  const BawarbunbaPexambaran({super.key, this.sarder});
  @override
  State<StatefulWidget> createState() => _ZhyanNamaState();
}

class _ZhyanNamaState extends State<BawarbunbaPexambaran> {
  int? fontType;
  final List<MyList> _list = [];

  @override
  void initState() {
    super.initState();

    fontType = Provider.of<SettingsProvider>(context, listen: false)
        .getsettingField('font_family');
    _list.add(MyList(
        title: "پێغەمبەرەکان له‌ ئیسلامدا",
        desc:
            "پێغەمبەرەکان لە ئیسلامدا، ئەو کەسانەن کە خوا هەڵیبژاردوون بۆ ڕێنمایی کردنی خەڵک بۆ پەرستنی خوا بە بێ دانانی هاوەڵ و هاوبەش، و بانگیان بکات بۆ چاکە و ڕەوشتەکان و وازهێنان لە بتپەرستی و قەدەغەکراوەکان."));
    _list.add(MyList(
        title: "باوەربوون بە پێغەمبەران",
        desc:
            "باوەربوون بە پێغەمبەر و نێردراوەکانی خوا یەکێکە لە پایەکانی باوەڕ لە ئیسلامدا و ئەم باوەڕبوونەش چوار بوار ئەگرێتەوە؛\n\n    یەکەم/ باوەڕبوون بەوەی کە پەیامەکانیان حەق و ڕاستن و لای خواوە هاتوون، و ئەوەی بیباوەڕ بێت بە یەکێکیان ئەوا بێباوەڕ دەبێت بە هەموویان.\n    دووەم/ باوەربوون بە هەموو ئەو پێغەمبەرانەی کە ناوەکانیان زانراوە وەک (محەمەد و عیسا و موسا و نوح و ئیبراهیم ...هتد)، هەروەها باوەربوون بەوانەی ناوەکانیان نەزانراوە بە گشتی، خوا لە قورئاندا دەفەرموێت؛ لَقَدْ أَرْسَلْنَا رُسُلًا مِّن قَبْلِكَ مِنْهُم مَّن قَصَصْنَا عَلَيْكَ وَمِنْهُم مَّن لَّمْ نَقْصُصْ عَلَيْكَ [١]، واتە؛ ه‌ڕاستی ئێمه پێش تۆ پێغه‌مبه‌رانی تریشمان ڕه‌وانه کردووه‌، هه‌یانه سه‌رگوزه‌شته و به‌سه‌رهاتیانمان بۆ گێڕاویته‌وه‌، هه‌شیانه که سه‌رگوزه‌شته و به‌سه‌رهاتیمان بۆ نه‌گێڕاویته‌وه‌.\n    سێیەم/ بە ڕاست دانانی ئەوەی کە ڕاستە لە هەواڵ و باسەکانیان.\n    چوارەم/ کردەوە کردن بە شەریعەتی دوایین پێغەمبەریان کە پێغەمبەری ئیسلامە (محەمەد).\n"));
    _list.add(MyList(
        title: "ئەو پێغەمبەرانەی لە قورئاندا ناویان هاتووە",
        desc:
            "\n\nئادەم · ئیدریس · نووح · ھوود · ساڵح · ئیبراھیم · لووت · ئیسماعیل · ئیسحاق · یەعقوب · یووسف · ئەیووب · شوعەیب · مووسا · ھاروون · زول کیفل · داوود · سولەیمان · ئیلیاس · ئیلیەسع · یوونس · زەکەریا · یەحیا · عیسا · موحەممەد\n"));
    _list.add(MyList(
        title: "خاوەن توانا و خۆڕاگرەکان",
        desc:
            "خاوەن توانا و خۆڕاگرەکان (أولوا العزم)، لە ئیسلامدا پێنج پێغەمبەرن کە خاوەن توان و خۆڕاگریین لە ناو پێغەمبەرەکانی خوادا ئەوانیش (محەمەد و عیسا و موسا و نوح و ئیبراهیم)ن، وەک لەم ئایەتەدا هاتووە؛ وَإِذْ أَخَذْنَا مِنَ النَّبِيِّينَ مِيثَاقَهُمْ وَمِنكَ وَمِن نُّوحٍ وَإِبْرَاهِيمَ وَمُوسَىٰ وَعِيسَى ابْنِ مَرْيَمَ ۖ وَأَخَذْنَا مِنْهُم مِّيثَاقًا غَلِيظًا [٢]، واتە؛ په‌یمانمان له‌پێغه‌مبه‌ران وه‌رگرتووه په‌یمانی یه‌کتاپه‌ره‌ستی، په‌یمانی گه‌یاندنی بانگه‌وازی خوا، به‌تایبه‌ت تۆ ئه‌ی محمد و له‌نوح و ئیبراهیم و موسا و عیسای کوڕی مه‌ریه‌م، بێگومان په‌یمانێکی به‌هێز و پته‌ومان لێ وه‌رگرتن..."));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bgColor,
      appBar: AppBar(
        toolbarHeight: 80,
        backgroundColor: thirdColor,
        title: Text(
          "${widget.sarder}",
          style: simpleTextStyle.copyWith(  fontFamily: fontType.toString(),),
        ),
        shape: const RoundedRectangleBorder(
            borderRadius: BorderRadius.vertical(bottom: Radius.circular(20))),
        centerTitle: true,
        elevation: 0,
        leading: IconButton(
          color: iconColor,
          onPressed: () => Navigator.pop(context),
          icon: const Icon(Icons.arrow_back_ios_rounded),
        ),
      ),
      body: Stack(
        children: [
          const Background(),
          Column(
            children: [
              Expanded(
                child: Padding(
                  padding: const EdgeInsets.only(top: 20),
                  child: AnimationLimiter(
                    child: ListView.builder(
                      physics: const BouncingScrollPhysics(),
                      scrollDirection: Axis.vertical,
                      itemCount: _list.length,
                      itemBuilder: (context, i) {
                        final a = _list[i];
                        return AnimationConfiguration.staggeredList(
                            position: i,
                            delay: const Duration(milliseconds: 100),
                            child: SlideAnimation(
                                duration: const Duration(milliseconds: 2500),
                                curve: Curves.fastLinearToSlowEaseIn,
                                horizontalOffset: 30,
                                verticalOffset: 300.0,
                                child: FlipAnimation(
                                  duration: const Duration(milliseconds: 3000),
                                  curve: Curves.fastLinearToSlowEaseIn,
                                  flipAxis: FlipAxis.y,
                                  child: ItemCard2(
                                    title: a.title,
                                    count: "${i + 1}",
                                    onPress: () {
                                      getItemNavigate(
                                          a.title!, a.desc!, context);
                                    },
                                  ),
                                )));
                      },
                    ),
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  void getItemNavigate(String title, String desc, BuildContext context) {
    Navigator.push(
        context,
        PageTransition(
            child: TextPageView(
              sarder: widget.sarder!,
              title: title,
              desc: desc,
            ),
            type: PageTransitionType.leftToRightWithFade));
  }
}

class MyList {
  final String? title;
  final String? desc;

  MyList({this.title, this.desc});
}
