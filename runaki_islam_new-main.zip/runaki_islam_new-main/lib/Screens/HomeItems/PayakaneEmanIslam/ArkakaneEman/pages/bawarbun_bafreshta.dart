import 'package:runaki_islam/Screens/HomeItems/Pexambarman/page_view.dart';
import 'package:flutter/material.dart';
import 'package:flutter_staggered_animations/flutter_staggered_animations.dart';
import 'package:runaki_islam/util/background.dart';
import 'package:runaki_islam/util/constans.dart';
import 'package:runaki_islam/util/item_list.dart';
import 'package:page_transition/page_transition.dart';
import 'package:runaki_islam/providers/settings_provider.dart';
import 'package:provider/provider.dart';

class BawarbunBafreshta extends StatefulWidget {
  final String? sarder;

  const BawarbunBafreshta({super.key, this.sarder});
  @override
  State<StatefulWidget> createState() => _ZhyanNamaState();
}

class _ZhyanNamaState extends State<BawarbunBafreshta> {
  int? fontType;
  final List<MyList> _list = [];

  @override
  void initState() {
    super.initState();
    fontType = Provider.of<SettingsProvider>(context, listen: false)
        .getsettingField('font_family');
    _list.add(MyList(
      title: "فریشتە لە ئیسلامدا",
      desc:
          "فریشتە لە ئیسلامدا، جیھانێکی نادیارن، پاک وبێگەردن لە سیفەت و کرداردا، خوا لە ڕوناکی (نور) دروستی کردوون، بەندایەتی بۆ خوا دەکەن و دەیپەرستن.",
    ));
    _list.add(MyList(
      title: "لە بیر و باوەڕی ئیسلامیدا",
      desc:
          "بە پێی بیروباوەڕی ئیسلامی، فریشتە جیھانێکی نادیارن و خوا بەدیھێناون پابەندبوونی تەواو و توانای جێبەجێکردنی فەرمانەکانی پێ بەخشیوون، و گوێڕایەڵ و مل کەچی فەرمانەکانی خوان، خوا لە قورئاندا دەربارەیان ئەفەرموێت، ﴿لَا یَسْبِقُونَھُ بِالْقَوْلِ وَھُم بِأَمْرِھِ یَعْمَلُونَ، یَعْلَمُ مَا بَیْنَ أَیْدِیھِمْ وَمَا خَلْفَھُمْ وَلَا یَشْفَعُونَ إِلَّا لِمَنِ ارْتَضَی وَھُم مِّنْ خَشْیَتِھِ مُشْفِقُونَ﴾[١]، واتە؛ (ئەو فریشتانە ئەوەندە ڕەوشت بەرزن) ھەرگیز (نافەرمانی ناکەن و) قسە لەقسەیدا ناکەن و لە گوفتاردا پێشی ناکەون، ئەوانە بە فەرمانی ئەو دەجوڵێنەوە و فەرمانی ئە جێبەجێ دەکەن.\n\nژمارەیان زۆرە و کەس ناتوانێت بیانژمێرێت تەنھا خوا نەبێت، بەندەی رێزلێنراون، ناخۆن و ناخۆنەوە و بێزار و ھیلاک نابن، ئەرکیان پیرۆزکردنی ناوی خوا و ھەڵگرتنی عەرش فریشتەکان و گەیاندنی سروشی خوا و تۆمارکردنی کردوەی کەسەکان لە چاکە وخراپە، کێشانی ڕۆح کاتی مردن و ... ھتد.",
    ));
    _list.add(MyList(
      title: "باوەربوون بە فریشتە",
      desc:
          "باوەڕبوون بە فریشتە دووەم پایەی باوەڕە لە ئیسلامدا، پێویستە لەسەر موسڵمان باوەڕی ھەبێت بە بوونی فریشتە و بە سیفەتەکانیان کە لە قورئان و سوننەتدا ھاتوون.\n\nباوەڕبوون بە فریشتە چوار بوار دەگرێتەوە؛",
    ));
    _list.add(MyList(
      title: "یەکەم؛ باوەربوون بەبوونیان",
      desc:
          "واتە باوەڕبوون بە ھەبوونی فریشتە بە بێ شک و گومان، لەبەرئەوەی فرمان بەمە کراوە لە قورئان و سوننەتی پێغەمبەردا، باوەربوون پێیان پێویستە و باوەڕ تەواو نابێت بە بێ ئەمە. وەک لە قورئاندا ھاتووە؛ ﴿آمَنَ الرَّسُولُ بِمَا أُنزِلَ إِلَیْھِ مِن رَّبِّھِ وَالْمُؤْمِنُونَ کُلٌّ آمَنَ بِاللّھِ وَمَلآئِکَتِھِ وَکُتُبِھِ وَرُسُلِھِ﴾[٢] واتە؛ پێغەمبەرو ئیمانداران باوەڕیان ھەیە بەوەی لە لایەن پەروەردگاریانەوە ھاتۆتە خوارەوە، ھەموویان باوەڕیان ھەیە بە خواو فریشتەکانی و کتێبەکانی و پێغەمبەرەکانی. ھەروەھا ئەفەرموێت؛ ﴿وَمَن یَکْفُرْ بِاللّھِ وَمَلاَئِکَتِھِ وَکُتُبِھِ وَرُسُلِھِ وَالْیَوْمِ الآخِرِ فَقَدْ ضَلَّ ضَلاَلاً بَعِیدًا﴾[٣]، واتە؛ ئەوەی باوەڕی نەبێت بەخواو فریشتەکانی و بە کتێبەکانی و بەپێغەمبەرانی و بەرۆژی دوایی، ئەوە بەڕاستی گومڕابووە بەئەوپەڕی گومڕایی.",
    ));
    _list.add(MyList(
      title: "دووەم؛ باوەربوون پێیان بە گشتی",
      desc:
          "یان باوەڕبوون بەوانەی ناوەکانیان زانراوە و ئەوانەی نەزانراوە، لەوانەش کە ناوەکانیان زانراوە وەک؛\n\n    جوبڕەیل؛ سەرپەرشتیار بەسەر سروشی خواوە.\n    میکائیل؛ ڕاسپاردەکراوە بە باران و ڕووەک\n    ئیسڕافیل؛ ڕاسپاردەکراوە بە فووکردن بە کەڕەنادا لە کاتی ھاتنی قیامەت و زیندبوونەوەی دروستکراواندل.\n    ملک الموت؛ واتە فریشتەی گیان کێشان لە کاتی مردندا\n    مالک؛ ڕاسپاردەکراوە بە ئاگر، بەرپرسی دۆززەخە.\n    ڕەزوان؛ ڕاسپێردراوە بە بەھەشت.\n    مونکیر و نەکیر؛ ناویان ھاتووە لە فەرموودەکانی تایبەت بە سزای ناو گۆڕ.\n    ھاروت و ماروت؛ لە قورئاندا ناویان ھاتووە لەم ئایەتەدا؛ ﴿ولکن الشیاطین کفروا یعلمون الناس السحر وما أنزل علی الملکین ببابل ھاروت وماروت﴾[٤] واتە؛ بەڵکو شەیتانەکان کافربوون و خەڵکیان فێری سیحرو جادوو دەکرد، ھەروەھا مەردومیان فێری ئەوە دەکرد کە بۆ ھاروت و ماروت دابەزی بوو (کە دوو فریشتە بوون) لە بابل (مەبەستیشیان تێگەیاندنی خەڵکی بوو لە سیحرو جادوو).\n",
    ));
    _list.add(MyList(
      title: "سێیەم؛ باوەربوون بە سیفاتەکانیان",
      desc:
          "ئەمەش باوەڕبوون بەو سیفەتانە ئەگرێتەوە کە ئەیانزانین، و فریشتە ھەیانە دووباڵی ھەیە یان سێ یان چوار و زیاتر بۆ نموونە پێغەمبەر (محەمەد) دەربارەی جوبڕەیل ئەفەرموێت؛ شەش سەد باڵی ھەیە، ھەروەھا زۆر جار فریشتەکان خۆیا ئەخەنە سەر شێوەی پیاو یان شێوەی خۆیان ئەگۆڕن بە پێی ئەو فەرمانەی خوای گەورە داوایان لێدەکات.",
    ));
    _list.add(MyList(
      title: "چوارەم؛ باوەربوون بە ئیشەکانیان",
      desc:
          "ئەمەش باوەڕبوون ئەگریتەوە بە ھەموو ئەو ئیشانەی فریشتەکان کە زانراون بان نەزانرابن و لە ئیشەکانیان؛ پەرستن و بەندایەتی کردنی خوای گەورەیە بە بێ دابڕان و بێزاربوون، و ھەندێکیان ئیشی تایبەتیان ھەیە، وەک؛ فریشتەی ڕاسپێردراو بە گیان کێشان لە کاتی مردن و فریشتەی ڕاسپێردراو بە پرسیارکردن لە مردوو لە کاتی ناشتیدا، و فریشتەی ڕاسپێردراو بە چاودێری کردنی کۆرپەلە لە سکی دایکیدا، و فریشتەی ڕاسپێردراو بە چاودێڕی و پارێزگاری کردن لە کاروکردەوەی ئادەمیزاد بە تۆمارکردن و نوسینەوەیان، و ھەموو مرۆڤێک دوو فریشتەی ھەیە یەکێکیان لای چەپیەتی و ئەوی تریان لای ڕاست.",
    ));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bgColor,
      appBar: AppBar(
        toolbarHeight: 80,
        backgroundColor: thirdColor,
        title: Text(
          "${widget.sarder}",
          style: simpleTextStyle.copyWith(
            fontFamily: fontType.toString(),
          ),
        ),
        shape: const RoundedRectangleBorder(
            borderRadius: BorderRadius.vertical(bottom: Radius.circular(20))),
        centerTitle: true,
        elevation: 0,
        leading: IconButton(
          color: iconColor,
          onPressed: () => Navigator.pop(context),
          icon: const Icon(Icons.arrow_back_ios_rounded),
        ),
      ),
      body: Stack(
        children: [
          const Background(),
          Column(
            children: [
              Expanded(
                child: Padding(
                  padding: const EdgeInsets.only(top: 20),
                  child: AnimationLimiter(
                    child: ListView.builder(
                      physics: const BouncingScrollPhysics(),
                      scrollDirection: Axis.vertical,
                      itemCount: _list.length,
                      itemBuilder: (context, i) {
                        final a = _list[i];
                        return AnimationConfiguration.staggeredList(
                            position: i,
                            delay: const Duration(milliseconds: 100),
                            child: SlideAnimation(
                                duration: const Duration(milliseconds: 2500),
                                curve: Curves.fastLinearToSlowEaseIn,
                                horizontalOffset: 30,
                                verticalOffset: 300.0,
                                child: FlipAnimation(
                                  duration: const Duration(milliseconds: 3000),
                                  curve: Curves.fastLinearToSlowEaseIn,
                                  flipAxis: FlipAxis.y,
                                  child: ItemCard2(
                                    title: a.title,
                                    count: "${i + 1}",
                                    onPress: () {
                                      getItemNavigate(
                                          a.title!, a.desc!, context);
                                    },
                                  ),
                                )));
                      },
                    ),
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  void getItemNavigate(String title, String desc, BuildContext context) {
    Navigator.push(
        context,
        PageTransition(
            child: TextPageView(
              sarder: widget.sarder!,
              title: title,
              desc: desc,
            ),
            type: PageTransitionType.leftToRightWithFade));
  }
}

class MyList {
  final String? title;
  final String? desc;

  MyList({this.title, this.desc});
}
