import 'package:runaki_islam/Screens/HomeItems/Pexambarman/page_view.dart';
import 'package:flutter/material.dart';
import 'package:flutter_staggered_animations/flutter_staggered_animations.dart';
import 'package:runaki_islam/util/background.dart';
import 'package:runaki_islam/util/constans.dart';
import 'package:runaki_islam/util/item_list.dart';
import 'package:page_transition/page_transition.dart';
import 'package:runaki_islam/providers/settings_provider.dart';
import 'package:provider/provider.dart';

class BawarbunbaQadar extends StatefulWidget {
  final String? sarder;

  const BawarbunbaQadar({super.key, this.sarder});
  @override
  State<StatefulWidget> createState() => _ZhyanNamaState();
}

class _ZhyanNamaState extends State<BawarbunbaQadar> {
  int? fontType;
  final List<MyList> _list = [];

  @override
  void initState() {
    super.initState();
        fontType = Provider.of<SettingsProvider>(context, listen: false)
        .getsettingField('font_family');
    _list.add(MyList(
        title: "قەزاو قەدەر",
        desc:
            "قەزا و قەدەر، لە ڕووی ئابوری و یاساییەوە ھەر ھەڵسوکەوت و کردارێک ئەگرێتەوە کە لە دەرەوەی توانای مرۆڤدا بێت و نەتوانێت دەستی بەسەردا بگرێت، بۆ نموونە؛ گەردەلوول و بوومەلەرزە و ھاوشێوەکانیان، وبەو شێوەیە بڕگەیەکی یاسایی ھەیە لە گرێبەستە بازرگانیەکاندا لە حاڵەتی ڕوودانی ئەو کارەساتانەی دەربازبوون لێیان لە توانادانیە ھەروەھا ئەو کارەساتە کتوپڕانەی بە شێوەیەکی سروشتی ڕووئەدەن، وەک قەربووکردنەوەی ئابووری کۆمپانیاکانی دڵنیایی لە ڕووداوەکانی نوقم بوون و مردن و کەوتنە خوارەوەی فڕۆکە و ئەوانی تردا."));
    _list.add(MyList(
        title: "قەزا و قەدەر لەئیسلامدا",
        desc:
            "قەزا و قەدەر بە پێی بیروباوەڕی ئیسلامی بریتیە ‌لە زانستی خوا ‌بەشتەکان و نوسینیان پێش ئەوەی ببن، لەسەر ئەو شێوەی کەھەن، وەک لە قورئاندا هاتووە؛ (ما أَصَابَ مِن مُّصِيبَةٍ فِي الْأَرْضِ وَلَا فِي أَنفُسِكُمْ إِلَّا فِي كِتَابٍ مِّن قَبْلِ أَن نَّبْرَأَهَا إِنَّ ذَلِكَ عَلَى اللَّهِ يَسِيرٌ، لِكَيْلا تَأْسَوْا عَلَى مَا فَاتَكُمْ وَلا تَفْرَحُوا بِمَا آتَاكُمْ وَاللَّهُ لا يُحِبُّ كُلَّ مُخْتَالٍ فَخُورٍ)، واتە؛ هیچ به‌ڵاو ڕوداوێک له‌زه‌ویدا، بۆتان پێش نه‌هاتووه‌که‌له‌_ لوح المحفوظ _ دا تۆمارمان نه‌کردبێت، پێش ئه‌وه‌ی ڕووداوه‌که‌پێش بێت، ئه‌و کاره‌ش بۆ خوا زۆر ئاسانه‌، ئه‌مه‌ش بۆ ئه‌وه‌ی که‌خه‌فه‌ت نه‌خۆن بۆ ئه‌وه‌ی له‌کیستان چووه‌و به‌وه‌ش دڵخۆش و غه‌ڕڕا نه‌بن که‌پێمان به‌خشیوون، چونکه‌خوا که‌سانی خۆ به‌گه‌وره‌زان و فه‌خرفرۆشی خۆش ناوێت."));
    _list.add(MyList(
        title: "باوەربوون بە قەزاو قەدەر",
        desc:
            "قەزا و قەدەر، لە ڕووی ئابوری و یاساییەوە ھەر ھەڵسوکەوت و کردارێک ئەگرێتەوە کە لە دەرەوەی توانای مرۆڤدا بێت و نەتوانێت دەستی بەسەردا بگرێت، بۆ نموونە؛ گەردەلوول و بوومەلەرزە و ھاوشێوەکانیان، وبەو شێوەیە بڕگەیەکی یاسایی ھەیە لە گرێبەستە بازرگانیەکاندا لە حاڵەتی ڕوودانی ئەو کارەساتانەی دەربازبوون لێیان لە توانادانیە ھەروەھا ئەو کارەساتە کتوپڕانەی بە شێوەیەکی سروشتی ڕووئەدەن، وەک قەربووکردنەوەی ئابووری کۆمپانیاکانی دڵنیایی لە ڕووداوەکانی نوقم بوون و مردن و کەوتنە خوارەوەی فڕۆکە و ئەوانی تردا."));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bgColor,
      appBar: AppBar(
        toolbarHeight: 80,
        backgroundColor: thirdColor,
        title: Text(
          "${widget.sarder}",
          style: simpleTextStyle.copyWith(  fontFamily: fontType.toString(),),
        ),
        shape: const RoundedRectangleBorder(
            borderRadius: BorderRadius.vertical(bottom: Radius.circular(20))),
        centerTitle: true,
        elevation: 0,
        leading: IconButton(
          color: iconColor,
          onPressed: () => Navigator.pop(context),
          icon: const Icon(Icons.arrow_back_ios_rounded),
        ),
      ),
      body: Stack(
        children: [
          const Background(),
          Column(
            children: [
              Expanded(
                child: Padding(
                  padding: const EdgeInsets.only(top: 20),
                  child: AnimationLimiter(
                    child: ListView.builder(
                      physics: const BouncingScrollPhysics(),
                      scrollDirection: Axis.vertical,
                      itemCount: _list.length,
                      itemBuilder: (context, i) {
                        final a = _list[i];
                        return AnimationConfiguration.staggeredList(
                            position: i,
                            delay: const Duration(milliseconds: 100),
                            child: SlideAnimation(
                                duration: const Duration(milliseconds: 2500),
                                curve: Curves.fastLinearToSlowEaseIn,
                                horizontalOffset: 30,
                                verticalOffset: 300.0,
                                child: FlipAnimation(
                                  duration: const Duration(milliseconds: 3000),
                                  curve: Curves.fastLinearToSlowEaseIn,
                                  flipAxis: FlipAxis.y,
                                  child: ItemCard2(
                                    title: a.title,
                                    count: "${i + 1}",
                                    onPress: () {
                                      getItemNavigate(
                                          a.title!, a.desc!, context);
                                    },
                                  ),
                                )));
                      },
                    ),
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  void getItemNavigate(String title, String desc, BuildContext context) {
    Navigator.push(
        context,
        PageTransition(
            child: TextPageView(
              sarder: widget.sarder!,
              title: title,
              desc: desc,
            ),
            type: PageTransitionType.leftToRightWithFade));
  }
}

class MyList {
  final String? title;
  final String? desc;

  MyList({this.title, this.desc});
}
