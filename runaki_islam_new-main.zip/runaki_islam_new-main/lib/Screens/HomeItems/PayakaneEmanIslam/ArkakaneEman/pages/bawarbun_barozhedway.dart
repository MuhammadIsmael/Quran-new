import 'package:runaki_islam/Screens/HomeItems/Pexambarman/page_view.dart';
import 'package:flutter/material.dart';
import 'package:flutter_staggered_animations/flutter_staggered_animations.dart';
import 'package:runaki_islam/util/background.dart';
import 'package:runaki_islam/util/constans.dart';
import 'package:runaki_islam/util/item_list.dart';
import 'package:page_transition/page_transition.dart';
import 'package:runaki_islam/providers/settings_provider.dart';
import 'package:provider/provider.dart';

class BawarbunbaRozheDway extends StatefulWidget {
  final String? sarder;

  const BawarbunbaRozheDway({super.key, this.sarder});
  @override
  State<StatefulWidget> createState() => _ZhyanNamaState();
}

class _ZhyanNamaState extends State<BawarbunbaRozheDway> {
  int? fontType;
  final List<MyList> _list = [];

  @override
  void initState() {
    super.initState();
        fontType = Provider.of<SettingsProvider>(context, listen: false)
        .getsettingField('font_family');
    _list.add(MyList(
        title: "ڕۆژی دوایی لە ئیسلامدا",
        desc:
            "ڕۆژی دوایی یان ڕۆژی قیامەت یان ڕۆژی لێپرسینەوە، بە پێی بیروباوەڕی ئیسلامی کۆتایی جیھان و ژیانی دونیایە، و خاوەن ئاینەکانی تری وەک مەسیحی و جولەکە ھاوبەشن لەگەڵ ئیسلامدا لەم بیروباوەڕەدا، کە کاتی لێپرسینەوەیە لە بەردەم خوادا کە خوا ھەڵدەسێت بە پاداشتدانەوەی باوەڕدارە یەکتاپەرستەکان بە بەھەشت و بیباوەڕ و ھاوەڵدانەرەکان بە ئاگر، ناو دەبرێت بە ڕۆژی قیامەت کە بە مانای ھەستانەوە لەبەر ئەوەی خەڵکی تێدا زیندوو دەبنەوە، ھەروەھا ناودەبرێت بە ڕۆژی دوایی لەبەر ئەوەی ھیچ ڕۆژێکی تری لە دوا نیە لە ژیانی دونیادا، ھەروەک ڕۆژی دوایی چەند نیشانەیەکی ھەیە کە بە نیشانەکانی ڕۆژی دوایی ئەناسرێن و دابەش دەبن بۆ نیشانە گەورە و بچوکەکان."));
    _list.add(MyList(
        title: "باوەربوون بە ڕۆژی دوایی",
        desc:
            "باوەربوون بە ڕۆژی دوایی یەکێکە لە پایەکانی باوەڕ لە ئیسلامدا، ئەمەش سێ بوار دەگرێتەوە؛"));
    _list.add(MyList(
        title: "یەکەم/باوەربوون بە زیندوو بوونەوە",
        desc:
            "ئەمەش زیندووبوونەوەی خەڵکی دەگرێتەوە بۆ لێرسینەوە لەبەردەم خوادا، وەک لە قورئاندا هاتووە؛ كَمَا بَدَأْنَا أَوَّلَ خَلْقٍ نُّعِيدُهُ وَعْدًا عَلَيْنَا إِنَّا كُنَّا فَاعِلِين، واتە؛ هه‌روه‌ک چۆن له سه‌ره‌تاوه دروستمان کرد، وه‌ک ئه‌وسای خۆی لێ ده‌که‌ینه‌وه، ئه‌وه په‌یمان و به‌ڵێنی ئێمه‌یه‌، بێگومان ئێمه ئه‌و کاره ئه‌نجام ده‌ده‌ین."));
    _list.add(MyList(
        title: "دووەم/ باوەڕبوون بە لێپرسینەوە و پاداشت وەرگرتنەوە",
        desc:
            "ئەمەش باوەڕبوون دەگرێتەوە بەوەی کە خەڵک لێپرسینەوەیان لەگەڵ دەکرێت و بە پێی کردەوەکانی خۆیان پاداشت وەرئەگرن، وەک لە قورئاندا هاتووە، إِنَّ إِلَيْنَا إِيَابَهُمْ، ثُمَّ إِنَّ عَلَيْنَا حِسَابَهُم، واتە؛ بێگومان ئه‌وانه گه‌ڕانه‌وه‌یان هه‌ر بۆ لای ئێمه. له‌وه‌ودوایش به‌ڕاستی حیساب و لێپرسینه‌وه و دادگاییان له‌سه‌ر ئێمه‌یه‌."));
    _list.add(MyList(
        title: "سێیەم/ باوەربوون بە بەهەشت و ئاگر",
        desc:
            "باوەڕبوون بە بەهەشت و ئاگر (دۆزەخ) کە سەرئەنجامی هەتاهەتایین بۆ خەڵک، بەهەشت ماڵی خۆشگوزەرانیە و خوا ئامادەی کردووە بۆ باوەڕداران و چاکەکاران، و دۆزەخ ماڵی سزای خوایە بۆ بێباوەڕ و ستەمکاران."));
    _list.add(MyList(
        title: "لە ناوەکانی ڕۆژی دوایی",
        desc:
            "ڕۆژی دوایی بە چەندین ناوی جیاواز ناوی هاتووە لە قورئاندا، ئەمانەی خوارەوە چەند ناوێکیانن؛\n\n    یوم هەستانەوە (قیامەت) : لە قورئاندا هاتووە { ... إلی یوم القیامه‌ } واته‌ : تا ڕۆژی هه‌ڵسانه‌وه‌ .\n    ڕۆژی دوایی : لە قورئاندا هاتووە { ... ولكن البر من آ‌من بالله والیوم اڵاخر ... }. واته‌ : به‌ڵكو كرداری باش و كرداری چاك بریتیه‌ له‌وه‌ی كه‌ ئاده‌میزاد باوه‌ڕی هێنابێت به‌ ڕۆژی دوایی .\n    کاتی دیاریکراو : لە قورئاندا هاتووە { وأن الساعة لآتیة‌ }. واته‌ : بێگومان كاتی دیاری كراو دێت .\n    زیندووبوونەوە: لە قورئاندا هاتووە {... إن كنتم فی ریب من البعث ...}. واته‌ :ئێوه‌ ئه‌گه‌ر گومانتان له‌ زیندوو بوونه‌وه‌ هه‌یه‌ .\n    ڕۆژی دەرچوون: لە قورئاندا هاتووە { یوم یسمعون الصیحه‌ بالحق ذلك یوم الخروج }. واته‌ : له‌م ڕۆژه‌دا به‌ ڕاستی گوێ‌ بیستی هاوارى‌ قیزه‌ون ده‌بن ئا ئه‌وه‌ ڕۆژی ده‌رچوونه‌ .\n    قاریعە : خوای گه‌وره‌ ده‌فه‌رموێ‌ { القارعة ما القارعة‌ ... }. واته‌ : ئه‌و گرمه‌یه‌ی دڵان ده‌له‌رزێنێت , ئاخۆ – قارعة‌ – چی بێت ؟ .\n    ڕۆژی هەڕەشە : لە قورئاندا هاتووە {هذا یوم الفصل }. واته‌ : ئینجا به‌ هه‌ڕه‌شه‌وه‌ پێیان ده‌وترێت ئا ئه‌مه‌ ڕۆژی هه‌ڕه‌شه‌یه‌ .\n    ڕۆژی دین : لە قورئاندا هاتووە { وإن الفجار لفی جحیم یصلونها یوم الدین }. واته‌ :بێگومان تاوانبارو تاوانكاره‌كانیش له‌ ناو دۆزه‌خدا ژیانى پڕ له‌ ئێش و ئازار ده‌به‌نه‌ سه‌ر , كه‌ له‌ ڕۆژی پاداشت و سزا دووچاری ده‌بن .\n    دەنگێکی بەهێز: لە قورئاندا هاتووە {فإذا جا‌ءت الصاخة }. واته‌ : جا كاتێك قیامه‌ت به‌رپابوو به‌هۆی ده‌نگێكی به‌هێزی كپ كه‌ره‌وه‌ .\n    بەڵا گەورەکە : خوای گه‌وره‌ ده‌فه‌رموێ‌ {فإذا جا‌ءت الطامة الكبری }. واته‌ : جا كاتێك به‌ڵا گه‌وره‌كه‌ پێش هات , كه‌ ته‌نگانه‌ سامناكه‌كه‌ ڕوی دا .\n    ڕۆژی پەشیمانی : لە قورئاندا هاتووە { وأنذرهم یوم الحسره‌ إذ قضی اڵامر }. واته‌ : ئه‌ی پێغه‌مبەر سته‌مكاران ئاگادار بكه‌ له‌ ڕۆژی ئاهو ناڵه‌و په‌شیمانی كاتێك كار له‌ كار ترازاوه‌ .\n    غاشیە : لە قورئاندا هاتووە { هل أتاك حدیث الغاشیة‌ }. واته‌ : ئایا هه‌واڵ و ده‌نگ و باسی ڕۆژی قیامه‌تت پێگه‌یشتووه‌ ؟ ( ڕۆژێكه‌ سه‌ختیه‌كه‌ی هه‌موو كه‌سێك داگیر ده‌كات ) .\n    ڕۆژی نەمر: لە قورئاندا هاتووە { ادخلوها بسلام ذلك یوم الخلود }. واته‌ : بفه‌رموون بچنه‌ ناو به‌هه‌شته‌وه‌ له‌گه‌ڵ ئاشتی و ئارامی و هێمنیدا , ئا ئه‌وه‌ ئیتر ڕۆژی نه‌مری و نه‌بڕاوه‌یه‌ .\n    ڕۆژی لێپرسینەوە: لە قورئاندا هاتووە { ... لا یؤمن بیوم الحساب }. واته‌ : ... باوه‌ڕی به‌ ڕۆژی لێپرسینه‌وه‌ نه‌بێت .\n    واقیعە: لە قورئاندا هاتووە {إذا وقعت الواقعة}. واته‌ : كاتێك ڕوداوه‌ سامناكه‌كه‌ پێش هات .\n    ڕۆژی پێشهاتن : لە قورئاندا هاتووە { ... ذلك یوم الوعید }. واته‌ : ... ئیتر ئه‌وه‌ ڕۆژی پێشهاتنی هه‌ڕه‌شه‌و ئاگاداركردنه‌وه‌كانه‌ .\n    ڕۆژە نزیکەکە : لە قورئاندا هاتووە {... وانذرهم یوم الآزفة‌ ... }. واته‌ : ئه‌ی موحه‌ممه‌د بیانترسێنه‌و ئاگایان بكه‌وه‌ له‌ ڕۆژه‌ نزیكه‌كه‌ .\n    ڕۆژی کۆکردنەوە : لە قورئاندا هاتووە { ... یوم الجمع لا ریب فیه ... }. واته‌ : ئاگادارو هۆشیاریان بكه‌یت له‌ ڕۆژی كۆكردنه‌وه‌ كه‌ هیچ گومانی تێدا نیه‌ ...\n    حاقە : لە قورئاندا هاتووە { الحاقة ما الحاقة‌ }. واته‌ : یه‌كێكه‌ له‌ ناوه‌كانی ڕۆژی قیامه‌ت ئه‌وه‌ ده‌گه‌یه‌نێت كه‌ له‌و ڕۆژه‌دا خوای گه‌وره‌ حه‌ق و ڕاستی به‌ته‌واوه‌تی ده‌چه‌سپێنێت , چی بێ‌ ئه‌و ڕۆژه‌ ؟! .\n    ڕۆژی بەیەکگەیشتنەوە : لە قورئاندا هاتووە { لینذر یوم التلاق }. واته‌ : بۆ ئه‌وه‌ی خه‌ڵكی بترسێنێت له‌ ڕۆژی به‌یه‌كگه‌یشتنه‌وه‌ ( گه‌یشتنه‌وه‌ى ڕۆح و جه‌سته‌ , گه‌یشتنه‌وه‌ی ئاده‌میزاد به‌ كرده‌وه‌كانی ) .\n    ڕۆژی هاوار : لە قورئاندا هاتووە { ... إنی أخاف علیكم یوم التناد }. واته‌ : ... من به‌ڕاستی ده‌ترسم له‌ ڕۆژی هاوارو ئاهو ناڵه‌و بانگكردنتان بۆ لێپرسینه‌وه‌ ( قیامه‌ت ) .\n    ڕۆژی کۆبوونەوە : لە قورئاندا هاتووە { یوم یجمعكم لیوم الجمع ذلك یوم التغابن ...}. واته‌ : ڕۆژێك دێت خوا هه‌موانتان كۆ ده‌كاته‌وه‌ , بۆ ڕۆژی كۆبوونه‌وه‌كه‌ , ئه‌وه‌ ڕۆژی زیان باری یه‌ .\n\nهەروەها چەندین ناوی تری هەیە....."));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bgColor,
      appBar: AppBar(
        toolbarHeight: 80,
        backgroundColor: thirdColor,
        title: Text(
          "${widget.sarder}",
          style: simpleTextStyle.copyWith(  fontFamily: fontType.toString(),),
        ),
        shape: const RoundedRectangleBorder(
            borderRadius: BorderRadius.vertical(bottom: Radius.circular(20))),
        centerTitle: true,
        elevation: 0,
        leading: IconButton(
          color: iconColor,
          onPressed: () => Navigator.pop(context),
          icon: const Icon(Icons.arrow_back_ios_rounded),
        ),
      ),
      body: Stack(
        children: [
          const Background(),
          Column(
            children: [
              Expanded(
                child: Padding(
                  padding: const EdgeInsets.only(top: 20),
                  child: AnimationLimiter(
                    child: ListView.builder(
                      physics: const BouncingScrollPhysics(),
                      scrollDirection: Axis.vertical,
                      itemCount: _list.length,
                      itemBuilder: (context, i) {
                        final a = _list[i];
                        return AnimationConfiguration.staggeredList(
                            position: i,
                            delay: const Duration(milliseconds: 100),
                            child: SlideAnimation(
                                duration: const Duration(milliseconds: 2500),
                                curve: Curves.fastLinearToSlowEaseIn,
                                horizontalOffset: 30,
                                verticalOffset: 300.0,
                                child: FlipAnimation(
                                  duration: const Duration(milliseconds: 3000),
                                  curve: Curves.fastLinearToSlowEaseIn,
                                  flipAxis: FlipAxis.y,
                                  child: ItemCard2(
                                    title: a.title,
                                    count: "${i + 1}",
                                    onPress: () {
                                      getItemNavigate(
                                          a.title!, a.desc!, context);
                                    },
                                  ),
                                )));
                      },
                    ),
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  void getItemNavigate(String title, String desc, BuildContext context) {
    Navigator.push(
        context,
        PageTransition(
            child: TextPageView(
              sarder: widget.sarder!,
              title: title,
              desc: desc,
            ),
            type: PageTransitionType.leftToRightWithFade));
  }
}

class MyList {
  final String? title;
  final String? desc;

  MyList({this.title, this.desc});
}
