import 'package:runaki_islam/Screens/HomeItems/Pexambarman/page_view.dart';
import 'package:flutter/material.dart';
import 'package:flutter_staggered_animations/flutter_staggered_animations.dart';
import 'package:runaki_islam/util/background.dart';
import 'package:runaki_islam/util/constans.dart';
import 'package:runaki_islam/util/item_list.dart';
import 'package:page_transition/page_transition.dart';import 'package:runaki_islam/providers/settings_provider.dart';
import 'package:provider/provider.dart';

class ShayatMan extends StatefulWidget {
  final String? sarder;

  const ShayatMan({super.key, this.sarder});
  @override
  State<StatefulWidget> createState() => _ZhyanNamaState();
}

class _ZhyanNamaState extends State<ShayatMan> {
  final List<MyList> _list = [];int? fontType;

  @override
  void initState() {
    super.initState();    fontType = Provider.of<SettingsProvider>(context, listen: false)
        .getsettingField('font_family');
    _list.add(MyList(
        title: "شایەتمان",
        desc:
            "شایەتمانلە ئیسلامدا، باوەڕھێنانە بەوەی کە ھیچ خوایەک نیە بێجگە لە اللە (خوای تاک وتەنیا) و باوەڕھێنان بەوەی محەمەد پێغەمبەری نێردراوی خوایە، (و بە پێی شەریعەتی ئیسلامی) کەسێک ئیسلام ئەبێت بە وتنی شایەتمان لەکاتێکدا باوەڕی تەواوی بە ماناکەی ھەبێت."));
    _list.add(MyList(
        title: "مانای شایەتمان",
        desc:
            "مەبەستی ئیسلام لەو ڕستەیە؛ باوەڕھێنانی تەواوە بەوەی کە تەنھا خوا شایەنی ئەوەیە بپەرسترێتو دروستکارە و تەنھا ئەو حەقی پەرستنی ھەیە، محەمەد پێغەمبەری خوایە کە ناردویەتی بۆ مرۆڤایەتی تا ئیسلام بڵاوبکاتەوە و خەڵک بەدوای پەیامەکەیدا بچن، ھەروەک شایەتمان بە یەکەم ڕوکنی ئیسلام دادەنرێت و موسوڵمانبوون تەواو نابێت بە بێ شایەتمان، و دوو بنەمای بنەڕەتی لە خۆ دەگرێت کە ئیسلام لەسەری دامەزراوە، کە ئەوانیش دڵسۆزی و بەدواداچوونە، واتە؛ دڵسۆزبوون بۆ خوا لە پەرستن و بیروباوەڕ و کاروباردا، و بەدواداچوونی سونەتی پێغەمبەرەکەی. ھەروەک لە پێویستیەکانی شایەتمان گوێڕایەڵبوونە بۆ پێغەمبەر لە فەرمانەکانی و خۆلادان لەوەی ڕێی لێگرتووە."));
    _list.add(MyList(
        title: "شایەتمان بنەمای هەموو شتێکە",
        desc:
            "شایەتمان بنەمای ھەموو شتێکە بۆ موسڵمان کە ھەموو باوەڕ دەگرێتەوە، بە بێ ئەو ھیچ ئیشێکی موسڵمان ڕاست نابێت و پاداشتی لەسەر وەرناگرێت و نە نوێژ و نە ڕۆژوو ڕاست نابن بە بێ ھاتنەدی ئەسڵی ئەو باوەڕەی لە شایەتماندا ھەیە، وەک خوای گەورە لە قورئاندا دەڵێت: "
            "فَاعْلَمْ أَنَّەُ لَا إِلَٰەَ إِلَّا اللَّەُ وَاسْتَغْفِرْ لِذَنْبِکَ وَلِلْمُؤْمِنِینَ وَالْمُؤْمِنَاتِ ۗ وَاللَّەُ یَعْلَمُ مُتَقَلَّبَکُمْ وَمَثْوَاکُمْ"
            "(محمد؛ ١٩) واتە؛ ئەی ئینسان!! دەی کەواتا چاک بزانەو دڵنیابە جگەلەخوا، ھیچ خوایەکی ترنیە، داوای لێخۆشبوونی گوناە بۆ خۆت و ئیمانداران لەپیاوان و ئافرەتان ھەر لەو بکەو دڵنیابە کەخوا دەزانێت لەرۆژدا بەچی یەوە خەریکن و، لەشەویشدا لەکۆی دەحەوێنەوە و ئارام دەگرن، یاخود دەزانێت چی دەکەن لەدونیاداو، دەرەنجامەکەشی لەقیامەتدا چۆنە."));
    _list.add(MyList(
        title: "لە وتەکان سەبارەت بە شایەتمان",
        desc:
            "لە وتەکانی پێغەمبەری ئیسلام (محەمەد سەبارەت بە شایەتمان؛\n\nعن ابن عمر (رضی اللە عنە) قال:قال رسول اللھ (صلی اللە علیە وسلم): بنی الاسلام علی خمس: شھادة ان لا الە اللە وان محمدا رسول اللە، واقام الصلاە وایتاء الزکاة والحج وصوم رمضان) اخرجە البخاری (اللؤلؤ والمرجان: باب قول النبی (بنی الاسلام علی خمس).\nواتە: ئیسلام لەسەر پێنج پایە دامەزراوە، شایەتیدان بەوە کەس بەکەڵکی ئەوە نایەت بیکەیتە خودا زاتی پاکی (اللە) نەبێت و شایەتیدانیش بەوەی کە محمد پێغەمبەری خوایە، نوێژ ڕاگرتن وزەکاتدان و حەجکردن و ڕۆژوگرتنی ڕەمەزان.."));
    _list.add(MyList(
        title: "مەرجەکانی شایەتمان",
        desc:
            "ئەو مەرجانەی کە پێویستە لە شایەتماندا بێنە دی وەک لە کتێبی شایەتمانی سەعید حەوادا ھاتووە ئەم مەرجانەی خوارەوەن؛\n\nباوەڕکردن و قەناعەتکردن لە ناخی دڵ و دەروون و ژیرییدا بەوەی کە ھیچ شتێک شایەنی پەرستن نیە جگە لە خوای پەروەردگار...\nدەربڕین و ئاشکراکردنی ئەو قەناعەت و بڕیارە بە زمان.\nددڵنیایی بنوێنێت و دوور بێت لە دوودڵی و ڕاڕایی.\nو جێگەی ئاماژەیە شیعە ئەم ئاماژەیە بۆ شایەتمان زیاد دەکەن؛ \"علی ولی اللە\" واتە؛ عەلی وەلی خوایە، بەگەڕانەوە بۆ ئەم وتەی پێغەمبەر؛ \" من کنت مولاە فھذا علی مولاە، اللھم والی من والاە و عادی من عاداە \"."));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bgColor,
      appBar: AppBar(
        toolbarHeight: 80,
        backgroundColor: thirdColor,
        title: Text(
          "${widget.sarder}",
          style: simpleTextStyle.copyWith(  fontFamily: fontType.toString(),),
        ),
        shape: const RoundedRectangleBorder(
            borderRadius: BorderRadius.vertical(bottom: Radius.circular(20))),
        centerTitle: true,
        elevation: 0,
        leading: IconButton(
          color: iconColor,
          onPressed: () => Navigator.pop(context),
          icon: const Icon(Icons.arrow_back_ios_rounded),
        ),
      ),
      body: Stack(
        children: [
          const Background(),
          Column(
            children: [
              Expanded(
                child: Padding(
                  padding: const EdgeInsets.only(top: 20),
                  child: AnimationLimiter(
                    child: ListView.builder(
                      physics: const BouncingScrollPhysics(),
                      scrollDirection: Axis.vertical,
                      itemCount: _list.length,
                      itemBuilder: (context, i) {
                        final a = _list[i];
                        return AnimationConfiguration.staggeredList(
                            position: i,
                            delay: const Duration(milliseconds: 100),
                            child: SlideAnimation(
                                duration: const Duration(milliseconds: 2500),
                                curve: Curves.fastLinearToSlowEaseIn,
                                horizontalOffset: 30,
                                verticalOffset: 300.0,
                                child: FlipAnimation(
                                  duration: const Duration(milliseconds: 3000),
                                  curve: Curves.fastLinearToSlowEaseIn,
                                  flipAxis: FlipAxis.y,
                                  child: ItemCard2(
                                    title: a.title,
                                    count: "${i + 1}",
                                    onPress: () {
                                      getItemNavigate(
                                          a.title!, a.desc!, context);
                                    },
                                  ),
                                )));
                      },
                    ),
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  void getItemNavigate(String title, String desc, BuildContext context) {
    Navigator.push(
        context,
        PageTransition(
            child: TextPageView(
              sarder: widget.sarder!,
              title: title,
              desc: desc,
            ),
            type: PageTransitionType.leftToRightWithFade));
  }
}

class MyList {
  final String? title;
  final String? desc;

  MyList({this.title, this.desc});
}
