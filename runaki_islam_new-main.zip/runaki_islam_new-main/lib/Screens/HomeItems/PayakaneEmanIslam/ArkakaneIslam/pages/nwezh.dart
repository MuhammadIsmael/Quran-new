import 'package:runaki_islam/Screens/HomeItems/Pexambarman/page_view.dart';
import 'package:flutter/material.dart';
import 'package:flutter_staggered_animations/flutter_staggered_animations.dart';
import 'package:runaki_islam/util/background.dart';
import 'package:runaki_islam/util/constans.dart';
import 'package:runaki_islam/util/item_list.dart';import 'package:runaki_islam/providers/settings_provider.dart';
import 'package:provider/provider.dart';
import 'package:page_transition/page_transition.dart';

class Nwezh extends StatefulWidget {
  final String? sarder;

  const Nwezh({super.key, this.sarder});
  @override
  State<StatefulWidget> createState() => _ZhyanNamaState();
}

class _ZhyanNamaState extends State<Nwezh> {int? fontType;
  final List<MyList> _list = [];

  @override
  void initState() {
    super.initState();    fontType = Provider.of<SettingsProvider>(context, listen: false)
        .getsettingField('font_family');
    _list.add(MyList(
        title: "نوێژ",
        desc:
            "نوێژ دووەم بنەمای ئیسلامە, بە گەڕانەوە بۆ ئەم فەرمودەیەی پێغەمبەر (محەمەد) (صلی الله‌ علیه‌ وسلم)؛ بُنِیَ الإِسْلاَمُ عَلَى خَمْسٍ شَهَادَةِ أَنْ لاَ إِلَهَ إِلاَّ اللَّهُ وَأَنَّ مُحَمَّداً رَسُولُ اللَّهِ، وَإِقَامِ الصَّلاَةِ، وَإِیتَاءِ الزَّكَاةِ، وَالْحَجِّ، وَصَوْمِ رَمَضَانَ ». رواه البخاری و مسلم. واتە: ئیسلام لەسەر پێنج پایە دامەزراوە: شایەتی دان بەوەی کەوا ھیچ پەرستراویک نییە شایەنی پەرستن بێت بەڕاستی جگە لە (اللە)، وە موحەممەدیش نێرراو و پێغەمبەری (اللە) یە، و نویژ کردن، و زەکات دان، و حەج کردنی ماڵی خودایە، و ڕۆژوو گرتنی رەمەزانە. نوێژ فەڕزە (پێویستە)‌ لەسەر ھەموو مسوڵمانێکی ژن و پیاو، و پێویستە لەسەریان ئەو فەرزە لەکاتی دیاریکراوی خۆیدا بەجێ بھێنن. و فەڕزکرا لە مەککە پێش کۆچکردنی پێغەمبەر بۆ مەدینە لە ساڵی سێیەمی پێغەمبەرایەتیدا، ئەمەش لە کاتی ئیسرا و میعراجدا بوو بە پێی بیروباوەڕی ئیسلامی. لە ئیسلامدا ڕۆژانە پێنج نوێژ فەڕزە لەسەر موسڵمانان, ھەروەھا چەند جۆرێکی تری نوێژ ھەیە وەک؛ نویژی جەژن و نوێژە بارانە و نوێژی مردوو و نوێژی خۆرگیران."));
    _list.add(MyList(
        title: 'پایەکانی نوێژ لە ئیسلامدا',
        desc:
            'ئیسلام پایەیەکی داوە بە نوێژ کە نەیداوە بە ھیچ پەرستنێکی تر، یەکەم ئەرکە کە خوا فەڕزی کردووە لە پەرستەنەکاندا، و لە شەوی میعراجدا فەڕز کراوە ؛ ھەروەھا پێغەمبەر (صلی الله‌ علیه‌ وسلم) فەرموویەتی یەکەم شت مرۆڤ لێیدەپرسرێتەوە لەسەری لە ڕۆژی دواییدا نوێژە، ھەروەھا نویژ لە چەند جێگەیەکدا لە قورئاندا باس کراوە وەک لە سورەتی المۆمنون (قد أفلح المؤمنون*الذین ھم فی صلاتھم خاشعون) ،واتە؛ بە ڕاستی ئەو بڕوادارانە سەرکەوتوو سەرفراز بوون* ئەوانەش ئەوانەن کە لە نوێژەکانیاندا ملکەچ و دڵ ئارام و دڵ دامەزراون و دڵیان لای خوایە...و لە سورەتی الکوثردا ھاتووە (فصل لربک وأنحر) واتە؛ کەواتە نوێژ تەنھا لەبەر خوا و بۆ خوا و بۆ بەدەست ھێنانی ڕەزامەندی پەروەردگارت ئەنجام بدەو قوربانیش بکە و لە سورەتی الأعلی دا ھاتووە (وذکر اسم ربە فصلی) الاعلی واتە؛ ناوی پەروەردگاری خۆی ھێنا، جا نوێژی کرد، واتە: ئەوەی لەسەری فەرز کراوە لە پێنج نوێژەکان ، وھەروەھا لە سورەتی کەدا (وأقم الصلاة لذکری) واتە؛ نوێژەکانیشت بەچاکی ئەنجام بدە، تا ھەمیشە منت لە یاد بێت..'));
    _list.add(MyList(
        title: 'گرنگی نوێژ',
        desc:
            'لە قورئاندا ئاماژەکراوە بەوەی (إن الصلاة کانت علی المؤمنین کتاباً موقوتاً) [سورة النساء] واتە؛ چونکە بەڕاستی نوێژ لەسەر ئیمانداران فەرزە لەکاتی دیاریکراودا دەبێ ئەنجام بدرێت. ھەروەھا ھاتووە: (وأقیموا الصلاة وآتوا الزکاة وارکعوا مع الراکعین) [البقرة] واتە؛ نوێژەکانتان بەچاکی ئەنجام بدەن بە دروشمەکانیەوەو زەکاتیش بدەن، لەگەڵ کڕنووش بەراندا کڕنووش ببەن (بۆ پەروەردگارتان).وێژ کۆڵەکەی ئاینە وھیچ پۆزشێک لەو کەسە وەرناگیرێت کە وازی لێ بھێنێت لە کاتێکدا لە توانایدا بێت ولەسەری بێت.'));
    _list.add(MyList(
        title: 'مەرجەکانی نوێژ',
        desc:
            'یەکەم: ئیسلام، واتە ئەو کەسە دەبێت مسوڵمان بێت، وە بە ھیچ شێوەیەک نوێژی کافر وەرناگیرێت. دووەم: عەقڵ، واتە ئەو کەسە لەگەڵ ئەوەدا کە مسوڵمانە دەبێت عەقڵیشی ھەبێت واتە شێت نەبێت، چونکە بە ھیچ شێوەیەک لەسەر کەسی بێ عەقڵ و شێت نوێژکردن پێویست نیە. سێیەم: جودکاری لە نێوان پاک و خاوێنی، واتە لەگەڵ ئەوەدا ئەو کەسە دەبێت مسوڵمانێکی عاقڵ بێت، لە ھەمان کاتیشدا نابێت منداڵ بێت بتوانێت پاک و خاوێنی جیا بکاتەوە، بۆیە دەبێت ئەو کەس گەیشتبێت بەو تەمەنەی کە بتوانێت ئەم مەرجە لە خۆیدا بھێنێتە دی. چوارەم: پاکڕاگری، کە دەست نویژ و خۆشتن و پاکڕاگرتنی جەستە و جل و جێگەی نوێژ ئەگرێتەوە. شەشەم: شاردنەوەی عەورەت حەوتەم: چوونە کاتی نوێژەوە، نوێژکردن لە کاتە دیاریکراوەکانی خۆیدا ھەشتەم: ڕووکردنە قیبلە، لە ھەموو لایەکی جیھانەوە، پێویستە لەسەر موسڵمان ڕووبکاتە قیبلە بۆ نوێژکردن، و قیبلەش کەعبەی پیرۆزە لە شاری مەککە لە عەرەبستانی سعودی نۆیەم: نییەت، سەرچاوەی لە دڵەوە گرتووە، و ئەمەش بە خۆ ئامادەکردن و بە مەبەستەوە ھەڵدەستێت بەو نوێژە.'));
    _list.add(MyList(
        title: 'پێشنوێژ',
        desc:
            'وشەی (ئیمام) بە دوو کەس ئەوترێ : ئەو کەسەی پێش نوێژی ئەکات، و لەگەڵ ئەو کەسەی پێشەوا و پێشڕەوی خەڵک دەکات، پێشڕەو (ئیمام)یش لەلای شیعەکان ھەمان ئەو کەسەیە کە سوننییەکان پێی دەڵێنجێنشین (خلیفە)، بۆیە ئەتوانرێ کە بوترێ : کۆمەڵ، بەبێ پێشەوا نابێ، مەبەستیش پێی تەنھا پێش نوێژ نیە، چونکە ژیانی تاکی موسڵمان ژیانێکی ئیسلامیانەیە، کە بەڕێوە ناچێ مەگەر لەناو کۆمەڵدا نەبێ. جا دەبێ ئەم پێشەوایەش پارێزکارو (تقیە) لە خواترس بێت ، زانستێکی زۆری لە لابێت و باش لە قورئان شارەزابێت، و زۆرینەی موسڵمانان لێی ڕازی بن، بەھەمان شێوەش لە پێشەوا و پێشرەوی خەڵکی، واتە : کاربەدەستیان. دەبێ پێش نوێژ ئاگاداری حاڵی نوێژ خوێنەکانی دوای خۆی ببێ، چونکە بێ توانا و نەخۆش ....ھتد یان تێدادەبێت تا بەسۆزبێ لەگەڵیان وە نوێژیان بەسەردا درێژنەکاتەوە و ئەگەر ئەویش بیانوێکی ھەبوو، شوێنی چۆڵ دەکات بۆ یەکێکیتر بە ھەمان شێوە پێشەوای خەڵکیش ھەروا. دەبێ خەڵکیش گوێ ڕایەڵی پێشەوا بێ بەتەواوی پەیوەست بن بەوەی کە ئەم پێی ھەلئەستێ چۆن کە نابێ لە کاتی نوێژدا پێش (إمام) بکەوێ، کاتێ کە کڕنۆش و سوجدە دەبا، بەھەمان شێوەش دەبێ گوێ رایەڵ بن بۆ پێشەوا -تەنھا لە کاتێک گەر فەرمانی دەرکرد بە پێچەوانەی شەرعی خودا، ئەو کاتە ئەتوانی گوێڕایەل نەبن، ھەروەک کە ‌ئەگەر پێش نوێژخوێن ھەڵەێکی کرد ئەبێ بۆی ڕاست بکرێتەوە، پێشەواش بەھەمان شێوە، ئەو رێوشوێنانەش کە باس کران، ئەوە ڕوون دەکاتەوە، کەدەبێ نێوانی پێشەواو خەڵکی چۆن بێت.'));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bgColor,
      appBar: AppBar(
        toolbarHeight: 80,
        backgroundColor: thirdColor,
        title: Text(
          "${widget.sarder}",
          style:  simpleTextStyle.copyWith(  fontFamily: fontType.toString(),),
        ),
        shape: const RoundedRectangleBorder(
            borderRadius: BorderRadius.vertical(bottom: Radius.circular(20))),
        centerTitle: true,
        elevation: 0,
        leading: IconButton(
          color: iconColor,
          onPressed: () => Navigator.pop(context),
          icon: const Icon(Icons.arrow_back_ios_rounded),
        ),
      ),
      body: Stack(
        children: [
          const Background(),
          Column(
            children: [
              Expanded(
                child: Padding(
                  padding: const EdgeInsets.only(top: 20),
                  child: AnimationLimiter(
                    child: ListView.builder(
                      physics: const BouncingScrollPhysics(),
                      scrollDirection: Axis.vertical,
                      itemCount: _list.length,
                      itemBuilder: (context, i) {
                        final a = _list[i];
                        return AnimationConfiguration.staggeredList(
                            position: i,
                            delay: const Duration(milliseconds: 100),
                            child: SlideAnimation(
                                duration: const Duration(milliseconds: 2500),
                                curve: Curves.fastLinearToSlowEaseIn,
                                horizontalOffset: 30,
                                verticalOffset: 300.0,
                                child: FlipAnimation(
                                  duration: const Duration(milliseconds: 3000),
                                  curve: Curves.fastLinearToSlowEaseIn,
                                  flipAxis: FlipAxis.y,
                                  child: ItemCard2(
                                    title: a.title,
                                    count: "${i + 1}",
                                    onPress: () {
                                      getItemNavigate(
                                          a.title!, a.desc!, context);
                                    },
                                  ),
                                )));
                      },
                    ),
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  void getItemNavigate(String title, String desc, BuildContext context) {
    Navigator.push(
        context,
        PageTransition(
            child: TextPageView(
              sarder: widget.sarder!,
              title: title,
              desc: desc,
            ),
            type: PageTransitionType.leftToRightWithFade));
  }
}

class MyList {
  final String? title;
  final String? desc;

  MyList({this.title, this.desc});
}
