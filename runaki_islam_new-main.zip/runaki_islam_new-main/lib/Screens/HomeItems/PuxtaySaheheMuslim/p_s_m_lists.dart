import 'dart:convert';
import 'dart:math' as math;
import 'dart:ui';

import 'package:flutter/material.dart';
import 'package:page_transition/page_transition.dart';
import 'package:provider/provider.dart';
import 'package:runaki_islam/Screens/HomeItems/Pexambarman/page_view.dart';
import 'package:runaki_islam/models/puxtay_sahehe_muslim_model.dart';
import 'package:runaki_islam/providers/sections_provider.dart';
import 'package:runaki_islam/providers/settings_provider.dart';
import 'package:runaki_islam/util/animation_helper.dart';
import 'package:runaki_islam/util/background.dart';
import 'package:runaki_islam/util/constans.dart';

class PSMLists extends StatefulWidget {
  final int? pageNum;
  final String? sarder;

  const PSMLists({super.key, this.pageNum, this.sarder});

  @override
  State<PSMLists> createState() => _PSMListsState();
}

class _PSMListsState extends State<PSMLists> {
  final List<PSMModel> _items = <PSMModel>[];
  final TextEditingController _searchController = TextEditingController();
  final FocusNode _searchFocusNode = FocusNode();
  final ScrollController _scrollController = ScrollController();

  bool _loading = true;
  bool _showScrollToTop = false;
  String? _errorMessage;
  String? _fontFamily;

  String get _sectionTitle {
    final title = widget.sarder?.trim() ?? '';
    return title.isEmpty ? 'پوختەی سەحیحی موسلیم' : title;
  }

  String get _sectionBadge {
    final pageNum = widget.pageNum;
    if (pageNum == null) {
      return 'بابەتەکان';
    }
    return 'بەشی $pageNum';
  }

  String get _query => _searchController.text.trim();

  bool get _isSearching => _query.isNotEmpty;

  List<PSMModel> get _sectionItems {
    return _items
        .where((item) {
          final matchesPage =
              widget.pageNum == null || item.pageNum == widget.pageNum;
          return matchesPage && _itemTitle(item).isNotEmpty;
        })
        .toList(growable: false);
  }

  List<PSMModel> get _visibleItems {
    if (!_isSearching) {
      return _sectionItems;
    }

    final query = _query.toLowerCase();
    return _sectionItems
        .where((item) {
          final title = _itemTitle(item).toLowerCase();
          final description = _itemDescription(item).toLowerCase();
          return title.contains(query) || description.contains(query);
        })
        .toList(growable: false);
  }

  PSMModel? get _featuredItem {
    final items = _visibleItems;
    if (items.isEmpty) {
      return null;
    }
    return items.first;
  }

  Future<String> loadNoteAsset() async {
    return Provider.of<SectionsProvider>(
      context,
      listen: false,
    ).loadLegacyJsonAsset('assets/data/content/puxtay_sahehe_muslim.json');
  }

  Future<void> _fetchData() async {
    setState(() {
      _loading = true;
      _errorMessage = null;
    });

    try {
      final response = await loadNoteAsset();
      final decoded = jsonDecode(response);
      final parsed = <PSMModel>[];

      if (decoded is List) {
        for (final item in decoded) {
          if (item is Map<String, dynamic>) {
            parsed.add(PSMModel.formJson(item));
          } else if (item is Map) {
            parsed.add(PSMModel.formJson(Map<String, dynamic>.from(item)));
          }
        }
      }

      if (!mounted) {
        return;
      }

      setState(() {
        _items
          ..clear()
          ..addAll(parsed);
        _loading = false;
      });
    } catch (error) {
      if (!mounted) {
        return;
      }

      setState(() {
        _items.clear();
        _loading = false;
        _errorMessage = _friendlyErrorMessage(error);
      });
    }
  }

  @override
  void initState() {
    super.initState();
    final fontSetting = Provider.of<SettingsProvider>(
      context,
      listen: false,
    ).getsettingField('font_family');
    _fontFamily = fontSetting?.toString();
    _scrollController.addListener(_handleScroll);
    _fetchData();
  }

  @override
  void dispose() {
    _scrollController
      ..removeListener(_handleScroll)
      ..dispose();
    _searchController.dispose();
    _searchFocusNode.dispose();
    super.dispose();
  }

  void _handleScroll() {
    if (!_scrollController.hasClients) {
      return;
    }
    final shouldShow = _scrollController.offset > 260;
    if (_showScrollToTop == shouldShow) {
      return;
    }
    setState(() {
      _showScrollToTop = shouldShow;
    });
  }

  void _onSearchChanged(String _) {
    setState(() {});
  }

  Future<void> _clearSearch() async {
    _searchController.clear();
    _searchFocusNode.unfocus();
    if (!mounted) {
      return;
    }
    setState(() {});
  }

  Future<void> _scrollToTop() async {
    if (!_scrollController.hasClients) {
      return;
    }
    await _scrollController.animateTo(
      0,
      duration: const Duration(milliseconds: 260),
      curve: Curves.easeOutCubic,
    );
  }

  String _itemTitle(PSMModel item) => item.sarder?.trim() ?? '';

  String _itemDescription(PSMModel item) => item.drezha?.trim() ?? '';

  void _openItem(PSMModel item) {
    final title = _itemTitle(item);
    if (title.isEmpty) {
      return;
    }

    Navigator.push(
      context,
      PageTransition(
        child: TextPageView(
          sarder: _sectionTitle,
          title: title,
          desc: _itemDescription(item),
        ),
        type: PageTransitionType.leftToRightWithFade,
      ),
    );
  }

  Future<void> _showPreviewSheet(PSMModel item) async {
    final scheme = Theme.of(context).colorScheme;
    final title = _itemTitle(item);
    final description = _itemDescription(item);

    await showModalBottomSheet<void>(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (context) {
        return Directionality(
          textDirection: TextDirection.rtl,
          child: Padding(
            padding: EdgeInsets.fromLTRB(
              16,
              16,
              16,
              16 + MediaQuery.of(context).viewPadding.bottom,
            ),
            child: _BlurSurface(
              borderRadius: BorderRadius.circular(28),
              color: scheme.surface.withValues(alpha: 0.92),
              border: Border.all(color: scheme.outline.withValues(alpha: 0.12)),
              boxShadow: <BoxShadow>[
                BoxShadow(
                  color: scheme.shadow.withValues(alpha: 0.12),
                  blurRadius: 20,
                  offset: const Offset(0, 12),
                ),
              ],
              padding: const EdgeInsets.all(20),
              child: SingleChildScrollView(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    Row(
                      textDirection: TextDirection.rtl,
                      children: [
                        Expanded(
                          child: Text(
                            title,
                            textAlign: TextAlign.right,
                            style: TextStyle(
                              fontFamily: _fontFamily,
                              fontSize: 20,
                              fontWeight: FontWeight.w800,
                              color: scheme.onSurface,
                            ),
                          ),
                        ),
                        const SizedBox(width: 12),
                        IconButton(
                          onPressed: () => Navigator.of(context).pop(),
                          icon: Icon(
                            Icons.close_rounded,
                            color: scheme.onSurfaceVariant,
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 12),
                    Text(
                      description.isEmpty
                          ? 'ناوەڕۆکی ئەم بابەتە لە پەڕەی دواتر بە تەواوی دەبینیت.'
                          : description,
                      textAlign: TextAlign.right,
                      style: TextStyle(
                        fontFamily: _fontFamily,
                        fontSize: 15,
                        height: 1.8,
                        color: scheme.onSurfaceVariant,
                      ),
                    ),
                    const SizedBox(height: 18),
                    ElevatedButton.icon(
                      onPressed: () {
                        Navigator.of(context).pop();
                        _openItem(item);
                      },
                      icon: const Icon(Icons.menu_book_rounded),
                      label: Text(
                        'کردنەوەی بابەت',
                        style: TextStyle(
                          fontFamily: _fontFamily,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: scheme.primary,
                        foregroundColor: scheme.onPrimary,
                        padding: const EdgeInsets.symmetric(vertical: 14),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(18),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final visibleItems = _visibleItems;
    final featuredItem = _featuredItem;
    final hasActiveSearch = _isSearching;
    final sectionTitle = hasActiveSearch
        ? 'ئەنجامی گەڕان'
        : widget.pageNum == null
        ? 'هەموو بابەتەکان'
        : 'بابەتەکانی $_sectionBadge';

    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        backgroundColor: bgColor,
        body: Stack(
          children: [
            ClipRect(
              child: ImageFiltered(
                imageFilter: ImageFilter.blur(sigmaX: 3, sigmaY: 3),
                child: CustomBackground(
                  color: bgColor,
                  imageColor: bgImageColor.withValues(alpha: 0.22),
                ),
              ),
            ),
            RefreshIndicator(
              color: kActiveIconColor,
              backgroundColor: bgColor,
              onRefresh: _fetchData,
              child: CustomScrollView(
                controller: _scrollController,
                physics: const BouncingScrollPhysics(
                  parent: AlwaysScrollableScrollPhysics(),
                ),
                slivers: [
                  SliverAppBar(
                    pinned: true,
                    stretch: true,
                    elevation: 0,
                    expandedHeight: 170,
                    backgroundColor: scheme.surface.withValues(alpha: 0.94),
                    surfaceTintColor: Colors.transparent,
                    titleSpacing: 0,
                    leadingWidth: 64,
                    leading: Padding(
                      padding: const EdgeInsetsDirectional.only(start: 16),
                      child: _TopCircleButton(
                        icon: Icons.arrow_back_ios_new_rounded,
                        tooltip: 'گەڕانەوە',
                        onTap: () => Navigator.of(context).pop(),
                      ),
                    ),
                    actions: [
                      Padding(
                        padding: const EdgeInsetsDirectional.only(end: 16),
                        child: _TopCircleButton(
                          icon: hasActiveSearch
                              ? Icons.close_rounded
                              : Icons.auto_stories_rounded,
                          tooltip: hasActiveSearch
                              ? 'پاککردنەوەی گەڕان'
                              : _sectionBadge,
                          onTap: hasActiveSearch ? _clearSearch : null,
                        ),
                      ),
                    ],
                    title: Text(
                      _sectionTitle,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(
                        fontFamily: _fontFamily,
                        fontSize: 16,
                        fontWeight: FontWeight.w700,
                        color: kTextColor,
                      ),
                    ),
                    flexibleSpace: FlexibleSpaceBar(
                      stretchModes: const [StretchMode.zoomBackground],
                      background: SafeArea(
                        bottom: false,
                        child: Padding(
                          padding: const EdgeInsets.fromLTRB(16, 74, 16, 18),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.stretch,
                            children: [
                              _PSMSearchField(
                                controller: _searchController,
                                focusNode: _searchFocusNode,
                                fontFamily: _fontFamily,
                                onChanged: _onSearchChanged,
                                onClear: hasActiveSearch ? _clearSearch : null,
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ),
                  SliverToBoxAdapter(
                    child: Padding(
                      padding: const EdgeInsets.fromLTRB(16, 12, 16, 0),
                      child: _PSMOverviewCard(
                        badge: _sectionBadge,
                        totalCount: _sectionItems.length,
                        searchCount: visibleItems.length,
                        isSearching: hasActiveSearch,
                        fontFamily: _fontFamily,
                      ),
                    ),
                  ),
                  SliverToBoxAdapter(
                    child: Padding(
                      padding: const EdgeInsets.fromLTRB(16, 12, 16, 16),
                      child: AnimatedSwitcher(
                        duration: const Duration(milliseconds: 320),
                        switchInCurve: AppMotion.curve,
                        switchOutCurve: AppMotion.curve,
                        transitionBuilder: (child, animation) {
                          return FadeTransition(
                            opacity: animation,
                            child: SizeTransition(
                              sizeFactor: animation,
                              axisAlignment: -1,
                              child: child,
                            ),
                          );
                        },
                        child: featuredItem == null || _loading
                            ? const SizedBox.shrink()
                            : FadeSlideIn(
                                key: ValueKey<String>(
                                  '${_itemTitle(featuredItem)}-${_query.trim()}',
                                ),
                                duration: const Duration(milliseconds: 320),
                                child: _FeaturedPSMCard(
                                  badge: hasActiveSearch
                                      ? 'یەکەم ئەنجام'
                                      : _sectionBadge,
                                  title: _itemTitle(featuredItem),
                                  subtitle: _descriptionPreview(
                                    _itemDescription(featuredItem),
                                    maxLength: 180,
                                  ),
                                  fontFamily: _fontFamily,
                                  onOpen: () => _openItem(featuredItem),
                                  onPreview: () =>
                                      _showPreviewSheet(featuredItem),
                                ),
                              ),
                      ),
                    ),
                  ),
                  if (_loading)
                    SliverPadding(
                      padding: const EdgeInsets.fromLTRB(16, 0, 16, 24),
                      sliver: SliverList(
                        delegate: SliverChildBuilderDelegate(
                          (context, index) => const _LoadingCard(),
                          childCount: 5,
                        ),
                      ),
                    )
                  else if (_errorMessage != null)
                    SliverFillRemaining(
                      hasScrollBody: false,
                      child: _StatePane(
                        icon: Icons.error_outline_rounded,
                        title: 'ناتوانرێت بابەتەکان باربکرێن',
                        message: _errorMessage!,
                        actionLabel: 'دووبارە هەوڵ بدە',
                        onAction: _fetchData,
                        fontFamily: _fontFamily,
                      ),
                    )
                  else if (visibleItems.isEmpty)
                    SliverFillRemaining(
                      hasScrollBody: false,
                      child: _StatePane(
                        icon: hasActiveSearch
                            ? Icons.search_off_rounded
                            : Icons.menu_book_rounded,
                        title: hasActiveSearch
                            ? 'هیچ ئەنجامێک نەدۆزرایەوە'
                            : 'هیچ بابەتێک بەردەست نییە',
                        message: hasActiveSearch
                            ? 'وشەی گەڕانەکەت بگۆڕە بۆ ئەنجامی زیاتر.'
                            : 'ناوەڕۆکێک بۆ ئەم بەشە نەدۆزرایەوە.',
                        actionLabel: hasActiveSearch ? 'پاککردنەوە' : null,
                        onAction: hasActiveSearch ? _clearSearch : null,
                        fontFamily: _fontFamily,
                      ),
                    )
                  else ...[
                    SliverToBoxAdapter(
                      child: Padding(
                        padding: const EdgeInsets.fromLTRB(16, 0, 16, 12),
                        child: Row(
                          textDirection: TextDirection.rtl,
                          children: [
                            Expanded(
                              child: Text(
                                sectionTitle,
                                textAlign: TextAlign.right,
                                style: TextStyle(
                                  fontFamily: _fontFamily,
                                  fontSize: 17,
                                  fontWeight: FontWeight.w800,
                                  color: kTextColor,
                                ),
                              ),
                            ),
                            const SizedBox(width: 12),
                            Text(
                              '${visibleItems.length} بابەت',
                              style: TextStyle(
                                fontFamily: _fontFamily,
                                fontSize: 13.2,
                                fontWeight: FontWeight.w700,
                                color: kActiveIconColor,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                    SliverPadding(
                      padding: const EdgeInsets.fromLTRB(16, 0, 16, 28),
                      sliver: SliverList(
                        delegate: SliverChildBuilderDelegate((context, index) {
                          final item = visibleItems[index];
                          return FadeSlideIn(
                            delay: Duration(
                              milliseconds: math.min(index * 40, 280),
                            ),
                            duration: const Duration(milliseconds: 320),
                            offsetY: 18,
                            child: _PSMEntryCard(
                              index: index + 1,
                              title: _itemTitle(item),
                              preview: _descriptionPreview(
                                _itemDescription(item),
                                maxLength: 120,
                              ),
                              fontFamily: _fontFamily,
                              onTap: () => _openItem(item),
                              onPreview: () => _showPreviewSheet(item),
                            ),
                          );
                        }, childCount: visibleItems.length),
                      ),
                    ),
                  ],
                ],
              ),
            ),
            PositionedDirectional(
              start: 16,
              bottom: 20,
              child: IgnorePointer(
                ignoring: !_showScrollToTop,
                child: AnimatedSlide(
                  duration: AppMotion.fast,
                  curve: AppMotion.curve,
                  offset: _showScrollToTop ? Offset.zero : const Offset(0, 1.2),
                  child: AnimatedOpacity(
                    duration: AppMotion.fast,
                    curve: AppMotion.curve,
                    opacity: _showScrollToTop ? 1 : 0,
                    child: FloatingActionButton.small(
                      heroTag: 'psm_scroll_top',
                      backgroundColor: scheme.primary,
                      foregroundColor: scheme.onPrimary,
                      onPressed: _scrollToTop,
                      child: const Icon(Icons.keyboard_arrow_up_rounded),
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _TopCircleButton extends StatelessWidget {
  const _TopCircleButton({
    required this.icon,
    required this.tooltip,
    required this.onTap,
  });

  final IconData icon;
  final String tooltip;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return Tooltip(
      message: tooltip,
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: onTap,
          borderRadius: BorderRadius.circular(18),
          child: Ink(
            width: 46,
            height: 46,
            decoration: BoxDecoration(
              color: scheme.surface.withValues(alpha: 0.78),
              borderRadius: BorderRadius.circular(18),
              border: Border.all(color: scheme.outline.withValues(alpha: 0.14)),
            ),
            child: Icon(
              icon,
              size: 20,
              color: onTap == null ? scheme.outline : scheme.primary,
            ),
          ),
        ),
      ),
    );
  }
}

class _PSMSearchField extends StatelessWidget {
  const _PSMSearchField({
    required this.controller,
    required this.focusNode,
    required this.fontFamily,
    required this.onChanged,
    required this.onClear,
  });

  final TextEditingController controller;
  final FocusNode focusNode;
  final String? fontFamily;
  final ValueChanged<String> onChanged;
  final Future<void> Function()? onClear;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;

    return _BlurSurface(
      borderRadius: BorderRadius.circular(22),
      color: scheme.surface.withValues(alpha: 0.56),
      border: Border.all(color: scheme.outline.withValues(alpha: 0.14)),
      boxShadow: <BoxShadow>[
        BoxShadow(
          color: scheme.shadow.withValues(alpha: 0.08),
          blurRadius: 18,
          offset: const Offset(0, 10),
        ),
      ],
      child: TextField(
        controller: controller,
        focusNode: focusNode,
        onChanged: onChanged,
        maxLines: 1,
        textAlign: TextAlign.right,
        textDirection: TextDirection.rtl,
        cursorColor: kActiveIconColor,
        decoration: InputDecoration(
          border: InputBorder.none,
          hintText: 'گەڕان بە ناونیشان یان ناوەڕۆک',
          hintStyle: TextStyle(
            fontFamily: fontFamily,
            fontSize: 14,
            color: titleTextColor,
          ),
          prefixIcon: Icon(Icons.search_rounded, color: scheme.primary),
          suffixIcon: onClear == null
              ? null
              : IconButton(
                  onPressed: () => onClear!(),
                  icon: Icon(
                    Icons.close_rounded,
                    color: scheme.onSurfaceVariant,
                  ),
                ),
          contentPadding: const EdgeInsets.symmetric(
            horizontal: 18,
            vertical: 15,
          ),
        ),
        style: TextStyle(
          fontFamily: fontFamily,
          fontSize: 15,
          color: kTextColor,
        ),
      ),
    );
  }
}

class _PSMOverviewCard extends StatelessWidget {
  const _PSMOverviewCard({
    required this.badge,
    required this.totalCount,
    required this.searchCount,
    required this.isSearching,
    required this.fontFamily,
  });

  final String badge;
  final int totalCount;
  final int searchCount;
  final bool isSearching;
  final String? fontFamily;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;

    return _BlurSurface(
      borderRadius: BorderRadius.circular(26),
      color: scheme.surface.withValues(alpha: 0.50),
      border: Border.all(color: scheme.outline.withValues(alpha: 0.12)),
      boxShadow: <BoxShadow>[
        BoxShadow(
          color: scheme.shadow.withValues(alpha: 0.08),
          blurRadius: 18,
          offset: const Offset(0, 10),
        ),
      ],
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Wrap(
            alignment: WrapAlignment.end,
            spacing: 8,
            runSpacing: 8,
            children: [
              Container(
                padding: const EdgeInsets.symmetric(
                  horizontal: 12,
                  vertical: 8,
                ),
                decoration: BoxDecoration(
                  color: scheme.primaryContainer.withValues(alpha: 0.55),
                  borderRadius: BorderRadius.circular(16),
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  textDirection: TextDirection.rtl,
                  children: [
                    Icon(
                      Icons.auto_stories_rounded,
                      size: 16,
                      color: scheme.primary,
                    ),
                    const SizedBox(width: 8),
                    Text(
                      badge,
                      style: TextStyle(
                        fontFamily: fontFamily,
                        fontSize: 12,
                        fontWeight: FontWeight.w700,
                        color: scheme.primary,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 14),
          Row(
            textDirection: TextDirection.rtl,
            children: [
              Expanded(
                child: _PSMMetric(
                  icon: Icons.search_rounded,
                  label: isSearching ? 'ئەنجامی گەڕان' : 'ئامادە بۆ گەڕان',
                  value: '$searchCount',
                  fontFamily: fontFamily,
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: _PSMMetric(
                  icon: Icons.menu_book_rounded,
                  label: 'بابەتەکان',
                  value: '$totalCount',
                  fontFamily: fontFamily,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _PSMMetric extends StatelessWidget {
  const _PSMMetric({
    required this.icon,
    required this.label,
    required this.value,
    required this.fontFamily,
  });

  final IconData icon;
  final String label;
  final String value;
  final String? fontFamily;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;

    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: scheme.surface.withValues(alpha: 0.78),
        borderRadius: BorderRadius.circular(22),
        border: Border.all(color: scheme.outline.withValues(alpha: 0.10)),
      ),
      child: Row(
        textDirection: TextDirection.rtl,
        children: [
          Container(
            width: 42,
            height: 42,
            decoration: BoxDecoration(
              color: scheme.primary.withValues(alpha: 0.12),
              borderRadius: BorderRadius.circular(14),
            ),
            child: Icon(icon, color: scheme.primary, size: 22),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Text(
                  value,
                  textAlign: TextAlign.right,
                  style: TextStyle(
                    fontFamily: fontFamily,
                    color: scheme.onSurface,
                    fontSize: 18,
                    fontWeight: FontWeight.w800,
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  label,
                  textAlign: TextAlign.right,
                  style: TextStyle(
                    fontFamily: fontFamily,
                    color: scheme.onSurfaceVariant,
                    fontSize: 12,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _FeaturedPSMCard extends StatelessWidget {
  const _FeaturedPSMCard({
    required this.badge,
    required this.title,
    required this.subtitle,
    required this.fontFamily,
    required this.onOpen,
    required this.onPreview,
  });

  final String badge;
  final String title;
  final String subtitle;
  final String? fontFamily;
  final VoidCallback onOpen;
  final VoidCallback onPreview;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;

    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: onOpen,
        borderRadius: BorderRadius.circular(30),
        child: _BlurSurface(
          borderRadius: BorderRadius.circular(30),
          color: scheme.surface.withValues(alpha: 0.52),
          border: Border.all(
            color: scheme.primary.withValues(alpha: 0.20),
            width: 1.1,
          ),
          boxShadow: <BoxShadow>[
            BoxShadow(
              color: scheme.shadow.withValues(alpha: 0.08),
              blurRadius: 20,
              offset: const Offset(0, 12),
            ),
          ],
          padding: const EdgeInsets.all(18),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Wrap(
                alignment: WrapAlignment.end,
                spacing: 10,
                runSpacing: 8,
                children: [
                  Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 12,
                      vertical: 8,
                    ),
                    decoration: BoxDecoration(
                      color: scheme.primaryContainer.withValues(alpha: 0.58),
                      borderRadius: BorderRadius.circular(16),
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      textDirection: TextDirection.rtl,
                      children: [
                        Icon(
                          Icons.auto_awesome_rounded,
                          size: 16,
                          color: scheme.primary,
                        ),
                        const SizedBox(width: 8),
                        Text(
                          badge,
                          style: TextStyle(
                            fontFamily: fontFamily,
                            color: scheme.primary,
                            fontSize: 12,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 12),
              Text(
                'بابەتی هەڵبژێردراو',
                textAlign: TextAlign.right,
                style: TextStyle(
                  fontFamily: fontFamily,
                  fontSize: 13.2,
                  fontWeight: FontWeight.w700,
                  color: scheme.onSurfaceVariant,
                ),
              ),
              const SizedBox(height: 8),
              Text(
                title,
                textAlign: TextAlign.right,
                style: TextStyle(
                  fontFamily: fontFamily,
                  fontSize: 22,
                  fontWeight: FontWeight.w800,
                  color: scheme.onSurface,
                ),
              ),
              if (subtitle.isNotEmpty) ...[
                const SizedBox(height: 10),
                Text(
                  subtitle,
                  maxLines: 3,
                  overflow: TextOverflow.ellipsis,
                  textAlign: TextAlign.right,
                  style: TextStyle(
                    fontFamily: fontFamily,
                    fontSize: 13.6,
                    height: 1.7,
                    color: scheme.onSurfaceVariant,
                  ),
                ),
              ],
              const SizedBox(height: 18),
              Wrap(
                alignment: WrapAlignment.end,
                spacing: 10,
                runSpacing: 8,
                children: [
                  _InlineAction(
                    icon: Icons.visibility_outlined,
                    label: 'پێشبینین',
                    onTap: onPreview,
                  ),
                  _InlineAction(
                    icon: Icons.menu_book_rounded,
                    label: 'خوێندنەوە',
                    selected: true,
                    onTap: onOpen,
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _PSMEntryCard extends StatelessWidget {
  const _PSMEntryCard({
    required this.index,
    required this.title,
    required this.preview,
    required this.fontFamily,
    required this.onTap,
    required this.onPreview,
  });

  final int index;
  final String title;
  final String preview;
  final String? fontFamily;
  final VoidCallback onTap;
  final VoidCallback onPreview;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;

    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: onTap,
          onLongPress: onPreview,
          borderRadius: BorderRadius.circular(24),
          child: ClipRRect(
            borderRadius: BorderRadius.circular(24),
            child: BackdropFilter(
              filter: ImageFilter.blur(sigmaX: 14, sigmaY: 14),
              child: AnimatedContainer(
                duration: AppMotion.fast,
                curve: AppMotion.curve,
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(
                  color: scheme.surface.withValues(alpha: 0.92),
                  borderRadius: BorderRadius.circular(24),
                  border: Border.all(
                    color: scheme.outline.withValues(alpha: 0.12),
                  ),
                  boxShadow: [
                    BoxShadow(
                      color: scheme.shadow.withValues(alpha: 0.06),
                      blurRadius: 16,
                      offset: const Offset(0, 10),
                    ),
                  ],
                ),
                child: Row(
                  textDirection: TextDirection.rtl,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                      width: 52,
                      height: 52,
                      decoration: BoxDecoration(
                        color: scheme.primary.withValues(alpha: 0.9),
                        borderRadius: BorderRadius.circular(18),
                      ),
                      child: Center(
                        child: Text(
                          '$index',
                          style: TextStyle(
                            fontFamily: fontFamily,
                            fontSize: 15,
                            fontWeight: FontWeight.w800,
                            color: scheme.onPrimary,
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(width: 14),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.stretch,
                        children: [
                          Text(
                            title,
                            textAlign: TextAlign.right,
                            maxLines: 2,
                            overflow: TextOverflow.ellipsis,
                            style: TextStyle(
                              fontFamily: fontFamily,
                              fontSize: 16.6,
                              fontWeight: FontWeight.w800,
                              color: scheme.onSurface,
                            ),
                          ),
                          if (preview.isNotEmpty) ...[
                            const SizedBox(height: 8),
                            Text(
                              preview,
                              maxLines: 2,
                              overflow: TextOverflow.ellipsis,
                              textAlign: TextAlign.right,
                              style: TextStyle(
                                fontFamily: fontFamily,
                                fontSize: 13.4,
                                height: 1.7,
                                color: scheme.onSurfaceVariant,
                              ),
                            ),
                          ],
                          const SizedBox(height: 14),
                          Wrap(
                            alignment: WrapAlignment.end,
                            spacing: 10,
                            runSpacing: 8,
                            children: [
                              _InlineAction(
                                icon: Icons.visibility_outlined,
                                label: 'پێشبینین',
                                onTap: onPreview,
                              ),
                              _InlineAction(
                                icon: Icons.arrow_back_rounded,
                                label: 'کردنەوە',
                                onTap: onTap,
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class _InlineAction extends StatelessWidget {
  const _InlineAction({
    required this.icon,
    required this.label,
    required this.onTap,
    this.selected = false,
  });

  final IconData icon;
  final String label;
  final VoidCallback onTap;
  final bool selected;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;

    return Tooltip(
      message: label,
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: onTap,
          borderRadius: BorderRadius.circular(14),
          child: Ink(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
            decoration: BoxDecoration(
              color: selected
                  ? scheme.primaryContainer.withValues(alpha: 0.45)
                  : scheme.surfaceContainerHighest.withValues(alpha: 0.28),
              borderRadius: BorderRadius.circular(14),
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              textDirection: TextDirection.rtl,
              children: [
                Icon(
                  icon,
                  size: 18,
                  color: selected ? scheme.primary : scheme.onSurfaceVariant,
                ),
                const SizedBox(width: 8),
                Text(
                  label,
                  style: TextStyle(
                    fontSize: 12,
                    fontWeight: FontWeight.w700,
                    color: selected ? scheme.primary : scheme.onSurfaceVariant,
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _BlurSurface extends StatelessWidget {
  const _BlurSurface({
    required this.child,
    required this.borderRadius,
    required this.color,
    this.border,
    this.padding,
    this.boxShadow = const <BoxShadow>[],
  });

  final Widget child;
  final BorderRadius borderRadius;
  final Color color;
  final BoxBorder? border;
  final EdgeInsetsGeometry? padding;
  final List<BoxShadow> boxShadow;

  @override
  Widget build(BuildContext context) {
    return ClipRRect(
      borderRadius: borderRadius,
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 14, sigmaY: 14),
        child: Container(
          padding: padding,
          decoration: BoxDecoration(
            color: color,
            borderRadius: borderRadius,
            border: border,
            boxShadow: boxShadow,
          ),
          child: child,
        ),
      ),
    );
  }
}

class _StatePane extends StatelessWidget {
  const _StatePane({
    required this.icon,
    required this.title,
    required this.message,
    required this.fontFamily,
    this.actionLabel,
    this.onAction,
  });

  final IconData icon;
  final String title;
  final String message;
  final String? fontFamily;
  final String? actionLabel;
  final Future<void> Function()? onAction;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;

    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: _BlurSurface(
          borderRadius: BorderRadius.circular(28),
          color: scheme.surface.withValues(alpha: 0.90),
          border: Border.all(color: scheme.outline.withValues(alpha: 0.10)),
          padding: const EdgeInsets.all(22),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Container(
                width: 68,
                height: 68,
                decoration: BoxDecoration(
                  color: scheme.primary.withValues(alpha: 0.10),
                  borderRadius: BorderRadius.circular(22),
                ),
                child: Icon(icon, size: 32, color: scheme.primary),
              ),
              const SizedBox(height: 16),
              Text(
                title,
                textAlign: TextAlign.right,
                style: TextStyle(
                  fontFamily: fontFamily,
                  fontSize: 18,
                  fontWeight: FontWeight.w800,
                  color: scheme.onSurface,
                ),
              ),
              const SizedBox(height: 8),
              Text(
                message,
                textAlign: TextAlign.right,
                style: TextStyle(
                  fontFamily: fontFamily,
                  fontSize: 13.4,
                  height: 1.7,
                  color: scheme.onSurfaceVariant,
                ),
              ),
              if (actionLabel != null && onAction != null) ...[
                const SizedBox(height: 18),
                ElevatedButton(
                  onPressed: () => onAction!(),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: scheme.primary,
                    foregroundColor: scheme.onPrimary,
                    padding: const EdgeInsets.symmetric(vertical: 14),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(18),
                    ),
                  ),
                  child: Text(
                    actionLabel!,
                    style: TextStyle(
                      fontFamily: fontFamily,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }
}

class _LoadingCard extends StatelessWidget {
  const _LoadingCard();

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;

    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: scheme.surface.withValues(alpha: 0.80),
          borderRadius: BorderRadius.circular(24),
          border: Border.all(color: scheme.outline.withValues(alpha: 0.08)),
        ),
        child: Row(
          textDirection: TextDirection.rtl,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              width: 52,
              height: 52,
              decoration: BoxDecoration(
                color: scheme.surfaceContainerHighest.withValues(alpha: 0.45),
                borderRadius: BorderRadius.circular(18),
              ),
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Container(
                    height: 16,
                    decoration: BoxDecoration(
                      color: scheme.surfaceContainerHighest.withValues(
                        alpha: 0.45,
                      ),
                      borderRadius: BorderRadius.circular(10),
                    ),
                  ),
                  const SizedBox(height: 10),
                  Container(
                    height: 13,
                    width: double.infinity,
                    decoration: BoxDecoration(
                      color: scheme.surfaceContainerHighest.withValues(
                        alpha: 0.32,
                      ),
                      borderRadius: BorderRadius.circular(10),
                    ),
                  ),
                  const SizedBox(height: 8),
                  Container(
                    height: 13,
                    width: 160,
                    decoration: BoxDecoration(
                      color: scheme.surfaceContainerHighest.withValues(
                        alpha: 0.24,
                      ),
                      borderRadius: BorderRadius.circular(10),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

String _friendlyErrorMessage(Object error) {
  final message = error.toString().trim();
  if (message.isEmpty) {
    return 'کێشەیەک ڕوویدا لە بارکردنی بابەتەکان.';
  }
  return message;
}

String _descriptionPreview(String? value, {int maxLength = 92}) {
  final text = value?.trim() ?? '';
  if (text.isEmpty) {
    return 'کرتە بکە بۆ خوێندنەوەی بابەتەکە بە تەواوی.';
  }
  if (text.length <= maxLength) {
    return text;
  }
  return '${text.substring(0, maxLength).trim()}...';
}
