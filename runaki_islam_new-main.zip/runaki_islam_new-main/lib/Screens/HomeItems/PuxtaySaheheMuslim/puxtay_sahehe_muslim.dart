import 'package:flutter/material.dart';
import 'package:runaki_islam/Screens/HomeItems/PuxtaySaheheMuslim/p_s_m_lists.dart';

class PuxtaySaheheMuslim extends StatelessWidget {
  final String? sarder;

  const PuxtaySaheheMuslim({super.key, this.sarder});

  @override
  Widget build(BuildContext context) {
    return PSMLists(sarder: sarder);
  }
}
