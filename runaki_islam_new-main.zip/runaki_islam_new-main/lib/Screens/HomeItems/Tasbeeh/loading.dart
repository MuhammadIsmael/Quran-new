import 'package:flutter/material.dart';
import 'package:runaki_islam/util/constans.dart';
import 'package:loading_indicator/loading_indicator.dart';

class LoadingPage extends StatelessWidget {
  const LoadingPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bgColor,
      body:const Center(
        child: Padding(
          padding:  EdgeInsets.all(100.0),
          child: LoadingIndicator(
            indicatorType: Indicator.ballScaleMultiple,
            colors: [Color(0xff7BCBC4)],
          ),
        ),
      ),
    );
  }
}
