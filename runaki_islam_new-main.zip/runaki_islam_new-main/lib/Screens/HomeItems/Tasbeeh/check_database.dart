import 'package:runaki_islam/Screens/HomeItems/Tasbeeh/pages/sebha/items_sebha.dart';
import 'package:runaki_islam/Screens/HomeItems/Tasbeeh/loading.dart';
import 'package:runaki_islam/providers/sections_provider.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

class CheckDatabase extends StatelessWidget {
  const CheckDatabase({super.key});

  @override
  Widget build(BuildContext context) {
    return Consumer<SectionsProvider>(
      builder: (context, sectionProvider, widget) {
        return FutureBuilder<bool>(
          future: sectionProvider.ensureInitialized(context: context),
          builder: (context, result) {
            if (result.connectionState == ConnectionState.waiting) {
              return const LoadingPage();
            }
            return const ItemsSebha();
          },
        );
      },
    );
  }
}
