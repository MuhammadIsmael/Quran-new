import 'dart:math' as math;
import 'dart:ui';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import 'package:runaki_islam/Screens/HomeItems/Tasbeeh/pages/sebha/tasbih_page.dart';
import 'package:runaki_islam/models/sebha_model.dart';
import 'package:runaki_islam/providers/sebha_provider.dart';
import 'package:runaki_islam/providers/settings_provider.dart';
import 'package:runaki_islam/util/animation_helper.dart';
import 'package:runaki_islam/util/background.dart';
import 'package:runaki_islam/util/constans.dart';
import 'package:runaki_islam/widgets/sebha_widget/add_tasbih_dialog.dart';
import 'package:runaki_islam/widgets/sebha_widget/pop_up_menu.dart';

class ItemsSebha extends StatefulWidget {
  const ItemsSebha({super.key});

  @override
  State<ItemsSebha> createState() => _ItemsSebhaState();
}

class _ItemsSebhaState extends State<ItemsSebha> {
  final ScrollController _scrollController = ScrollController();
  bool _showScrollToTop = false;
  int? fontType;

  @override
  void initState() {
    super.initState();
    fontType = Provider.of<SettingsProvider>(
      context,
      listen: false,
    ).getsettingField('font_family');
    _scrollController.addListener(_handleScroll);
  }

  @override
  void dispose() {
    _scrollController.removeListener(_handleScroll);
    _scrollController.dispose();
    super.dispose();
  }

  void _handleScroll() {
    final shouldShow =
        _scrollController.hasClients && _scrollController.offset > 260;
    if (shouldShow == _showScrollToTop) return;
    setState(() {
      _showScrollToTop = shouldShow;
    });
  }

  Future<void> _openAddDialog() {
    return showDialog<void>(
      context: context,
      builder: (BuildContext context) =>
          const AddTasbih(title: 'زیادکردنی تەسبیح'),
    );
  }

  Future<void> _openSebha(SebhaModel tasbih) {
    return Navigator.of(context).push(
      AppMotion.fadeSlidePage<void>(
        begin: const Offset(0.06, 0.02),
        page: SebhaPage(tasbih),
      ),
    );
  }

  Future<void> _showMenu(SebhaModel tasbih) {
    return showModalBottomSheet<void>(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (BuildContext buildContext) {
        return PopUpMenuSebha(tasbih: tasbih, buildContext: context);
      },
    );
  }

  Future<void> _scrollToTop() {
    return _scrollController.animateTo(
      0,
      duration: const Duration(milliseconds: 420),
      curve: Curves.easeOutCubic,
    );
  }

  @override
  Widget build(BuildContext context) {
    final sebhaProvider = context.watch<SebhaProvider>();
    final itemCount = sebhaProvider.length;
    final favoriteCount = _favoriteCountOf(sebhaProvider);
    final mediaPadding = MediaQuery.of(context).padding;
    final scheme = Theme.of(context).colorScheme;
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final overlayStyle =
        (isDark ? SystemUiOverlayStyle.light : SystemUiOverlayStyle.dark)
            .copyWith(
              statusBarColor: Colors.transparent,
              systemNavigationBarColor: Colors.transparent,
              systemNavigationBarDividerColor: Colors.transparent,
              statusBarIconBrightness: isDark
                  ? Brightness.light
                  : Brightness.dark,
              statusBarBrightness: isDark ? Brightness.dark : Brightness.light,
              systemNavigationBarIconBrightness: isDark
                  ? Brightness.light
                  : Brightness.dark,
            );

    return AnnotatedRegion<SystemUiOverlayStyle>(
      value: overlayStyle,
      child: Directionality(
        textDirection: TextDirection.rtl,
        child: Scaffold(
          extendBody: true,
          backgroundColor: Colors.transparent,
          body: Stack(
            children: [
              const _PageBackground(),
              RefreshIndicator(
                color: kActiveIconColor,
                backgroundColor: bgColor,
                onRefresh: () => sebhaProvider.initialAllItemsOfSebha(),
                child: CustomScrollView(
                  controller: _scrollController,
                  physics: const BouncingScrollPhysics(
                    parent: AlwaysScrollableScrollPhysics(),
                  ),
                  slivers: [
                    SliverToBoxAdapter(
                      child: Padding(
                        padding: EdgeInsets.fromLTRB(
                          16,
                          mediaPadding.top + 8,
                          16,
                          10,
                        ),
                        child: _TopBar(
                          fontFamily: fontType?.toString(),
                          onBack: () => Navigator.of(context).pop(),
                          onAdd: _openAddDialog,
                        ),
                      ),
                    ),
                    SliverToBoxAdapter(
                      child: Padding(
                        padding: const EdgeInsets.fromLTRB(16, 0, 16, 12),
                        child: _SebhaHeroCard(
                          totalCount: itemCount,
                          favoriteCount: favoriteCount,
                          fontFamily: fontType?.toString(),
                          onAdd: _openAddDialog,
                        ),
                      ),
                    ),
                    if (itemCount == 0)
                      SliverFillRemaining(
                        hasScrollBody: false,
                        child: _StatePane(
                          title: 'هیچ تەسبیحێک زیاد نەکراوە',
                          message:
                              'زیادکردنی تەسبیحێکی نوێ بکە و دەست بە ژمارەکردن بکە.',
                          actionLabel: 'زیادکردنی تەسبیح',
                          onAction: _openAddDialog,
                          fontFamily: fontType?.toString(),
                        ),
                      )
                    else ...[
                      SliverToBoxAdapter(
                        child: Padding(
                          padding: const EdgeInsets.fromLTRB(16, 2, 16, 10),
                          child: Row(
                            children: [
                              Text(
                                'لیستی تەسبیحەکان',
                                style: TextStyle(
                                  fontFamily: fontType?.toString(),
                                  fontSize: 16.4,
                                  fontWeight: FontWeight.w800,
                                  color: kTextColor,
                                ),
                              ),
                              const Spacer(),
                              Text(
                                '$itemCount بابەت',
                                style: TextStyle(
                                  fontFamily: fontType?.toString(),
                                  fontSize: 13.2,
                                  fontWeight: FontWeight.w700,
                                  color: kActiveIconColor,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                      SliverPadding(
                        padding: const EdgeInsets.fromLTRB(16, 0, 16, 24),
                        sliver: SliverList(
                          delegate: SliverChildBuilderDelegate((
                            context,
                            index,
                          ) {
                            final item = sebhaProvider.getItemSebha(index);
                            return FadeSlideIn(
                              delay: Duration(
                                milliseconds: math.min(index * 45, 260),
                              ),
                              duration: const Duration(milliseconds: 320),
                              offsetY: 18,
                              child: _FriendlySebhaCard(
                                index: index + 1,
                                tasbih: item,
                                fontFamily: fontType?.toString(),
                                onOpen: () => _openSebha(item),
                                onMenu: () => _showMenu(item),
                              ),
                            );
                          }, childCount: itemCount),
                        ),
                      ),
                    ],
                    SliverToBoxAdapter(
                      child: SizedBox(height: mediaPadding.bottom + 18),
                    ),
                  ],
                ),
              ),
              PositionedDirectional(
                start: 16,
                bottom: mediaPadding.bottom + 16,
                child: IgnorePointer(
                  ignoring: !_showScrollToTop,
                  child: AnimatedSlide(
                    duration: AppMotion.fast,
                    curve: AppMotion.curve,
                    offset: _showScrollToTop
                        ? Offset.zero
                        : const Offset(0, 1.2),
                    child: AnimatedOpacity(
                      duration: AppMotion.fast,
                      curve: AppMotion.curve,
                      opacity: _showScrollToTop ? 1 : 0,
                      child: FloatingActionButton.small(
                        heroTag: 'sebha_scroll_top',
                        backgroundColor: scheme.primary,
                        foregroundColor: scheme.onPrimary,
                        onPressed: _scrollToTop,
                        child: const Icon(Icons.keyboard_arrow_up_rounded),
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  int _favoriteCountOf(SebhaProvider sebhaProvider) {
    var count = 0;
    for (var i = 0; i < sebhaProvider.length; i++) {
      if (sebhaProvider.getItemSebha(i).favorite == 1) {
        count++;
      }
    }
    return count;
  }
}

class _PageBackground extends StatelessWidget {
  const _PageBackground();

  @override
  Widget build(BuildContext context) {
    return ClipRect(
      child: ImageFiltered(
        imageFilter: ImageFilter.blur(sigmaX: 2.8, sigmaY: 2.8),
        child: CustomBackground(
          color: bgColor,
          imageColor: bgImageColor.withValues(alpha: 0.2),
        ),
      ),
    );
  }
}

class _TopBar extends StatelessWidget {
  const _TopBar({
    required this.fontFamily,
    required this.onBack,
    required this.onAdd,
  });

  final String? fontFamily;
  final VoidCallback onBack;
  final VoidCallback onAdd;

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        _CircleIconButton(
          icon: Icons.arrow_back_ios_new_rounded,
          tooltip: 'گەڕانەوە',
          onTap: onBack,
        ),
        const Spacer(),
        Text(
          'تەسبیح',
          style: TextStyle(
            fontFamily: fontFamily,
            fontSize: 17,
            fontWeight: FontWeight.w800,
            color: kTextColor,
          ),
        ),
        const Spacer(),
        _CircleIconButton(
          icon: Icons.add_rounded,
          tooltip: 'زیادکردنی تەسبیح',
          onTap: onAdd,
        ),
      ],
    );
  }
}

class _CircleIconButton extends StatelessWidget {
  const _CircleIconButton({
    required this.icon,
    required this.tooltip,
    required this.onTap,
  });

  final IconData icon;
  final String tooltip;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return Tooltip(
      message: tooltip,
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: onTap,
          borderRadius: BorderRadius.circular(18),
          child: Ink(
            width: 46,
            height: 46,
            decoration: BoxDecoration(
              color: scheme.surface.withValues(alpha: 0.72),
              borderRadius: BorderRadius.circular(18),
              border: Border.all(color: scheme.outline.withValues(alpha: 0.12)),
            ),
            child: Icon(icon, size: 21, color: scheme.primary),
          ),
        ),
      ),
    );
  }
}

class _SebhaHeroCard extends StatelessWidget {
  const _SebhaHeroCard({
    required this.totalCount,
    required this.favoriteCount,
    required this.fontFamily,
    required this.onAdd,
  });

  final int totalCount;
  final int favoriteCount;
  final String? fontFamily;
  final VoidCallback onAdd;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return ClipRRect(
      borderRadius: BorderRadius.circular(28),
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 12, sigmaY: 12),
        child: Container(
          padding: const EdgeInsets.fromLTRB(16, 16, 16, 14),
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [
                scheme.primaryContainer.withValues(alpha: 0.64),
                scheme.surface.withValues(alpha: 0.88),
              ],
              begin: Alignment.topRight,
              end: Alignment.bottomLeft,
            ),
            borderRadius: BorderRadius.circular(28),
            border: Border.all(color: scheme.outline.withValues(alpha: 0.14)),
            boxShadow: [
              BoxShadow(
                color: scheme.shadow.withValues(alpha: 0.08),
                blurRadius: 20,
                offset: const Offset(0, 12),
              ),
            ],
          ),
          child: Column(
            children: [
              Row(
                children: [
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'تەسبیحی ئەلیکترۆنی',
                          textAlign: TextAlign.start,
                          style: TextStyle(
                            fontFamily: fontFamily,
                            fontSize: 20,
                            fontWeight: FontWeight.w800,
                            color: scheme.onSurface,
                          ),
                        ),
                        const SizedBox(height: 6),
                        Text(
                          'تەسبیح هەڵبژێرە، ژمارەکردن دەست پێ بکە و بەردەوام بە.',
                          textAlign: TextAlign.start,
                          style: TextStyle(
                            fontFamily: fontFamily,
                            fontSize: 13.2,
                            height: 1.6,
                            color: scheme.onSurfaceVariant,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(width: 10),
                  Image.asset(
                    'assets/icons/tasbeeh.png',
                    width: 94,
                    height: 94,
                    fit: BoxFit.contain,
                  ),
                ],
              ),
              const SizedBox(height: 12),
              Row(
                children: [
                  Expanded(
                    child: _MiniStatPill(
                      label: 'کۆی بابەت',
                      value: '$totalCount',
                      fontFamily: fontFamily,
                    ),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: _MiniStatPill(
                      label: 'دڵخوازەکان',
                      value: '$favoriteCount',
                      fontFamily: fontFamily,
                    ),
                  ),
                  const SizedBox(width: 8),
                  FilledButton.icon(
                    onPressed: onAdd,
                    icon: const Icon(Icons.add_rounded, size: 18),
                    label: Text(
                      'زیادکردن',
                      style: TextStyle(
                        fontFamily: fontFamily,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _MiniStatPill extends StatelessWidget {
  const _MiniStatPill({
    required this.label,
    required this.value,
    required this.fontFamily,
  });

  final String label;
  final String value;
  final String? fontFamily;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
      decoration: BoxDecoration(
        color: scheme.surface.withValues(alpha: 0.65),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: scheme.outline.withValues(alpha: 0.11)),
      ),
      child: Column(
        children: [
          Text(
            value,
            style: TextStyle(
              fontFamily: 'english',
              fontSize: 18,
              fontWeight: FontWeight.w800,
              color: scheme.onSurface,
            ),
          ),
          const SizedBox(height: 2),
          Text(
            label,
            style: TextStyle(
              fontFamily: fontFamily,
              fontSize: 11.2,
              color: scheme.onSurfaceVariant,
              fontWeight: FontWeight.w700,
            ),
          ),
        ],
      ),
    );
  }
}

class _FriendlySebhaCard extends StatelessWidget {
  const _FriendlySebhaCard({
    required this.index,
    required this.tasbih,
    required this.fontFamily,
    required this.onOpen,
    required this.onMenu,
  });

  final int index;
  final SebhaModel tasbih;
  final String? fontFamily;
  final VoidCallback onOpen;
  final VoidCallback onMenu;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final targetLabel = tasbih.counter == 0
        ? 'بێ سنوور'
        : '${tasbih.counter} جار';

    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: onOpen,
          onLongPress: onMenu,
          borderRadius: BorderRadius.circular(24),
          child: Ink(
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              color: scheme.surface.withValues(alpha: 0.9),
              borderRadius: BorderRadius.circular(24),
              border: Border.all(
                color: tasbih.favorite == 1
                    ? scheme.primary.withValues(alpha: 0.38)
                    : scheme.outline.withValues(alpha: 0.12),
              ),
              boxShadow: [
                BoxShadow(
                  color: scheme.shadow.withValues(alpha: 0.06),
                  blurRadius: 16,
                  offset: const Offset(0, 10),
                ),
              ],
            ),
            child: Stack(
              children: [
                PositionedDirectional(
                  end: -12,
                  bottom: -14,
                  child: IgnorePointer(
                    child: Opacity(
                      opacity: 0.08,
                      child: Image.asset(
                        'assets/icons/tasbeeh.png',
                        width: 94,
                        height: 94,
                        fit: BoxFit.contain,
                        color: scheme.primary,
                      ),
                    ),
                  ),
                ),
                Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    _IndexBadge(index: index, fontFamily: fontFamily),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              Expanded(
                                child: Text(
                                  tasbih.name,
                                  maxLines: 2,
                                  overflow: TextOverflow.ellipsis,
                                  textAlign: TextAlign.start,
                                  style: TextStyle(
                                    fontFamily: fontFamily,
                                    fontSize: 16.6,
                                    fontWeight: FontWeight.w800,
                                    color: scheme.onSurface,
                                  ),
                                ),
                              ),
                              if (tasbih.favorite == 1)
                                Container(
                                  padding: const EdgeInsets.symmetric(
                                    horizontal: 8,
                                    vertical: 4,
                                  ),
                                  decoration: BoxDecoration(
                                    color: scheme.primaryContainer.withValues(
                                      alpha: 0.5,
                                    ),
                                    borderRadius: BorderRadius.circular(10),
                                  ),
                                  child: Text(
                                    'دڵخواز',
                                    style: TextStyle(
                                      fontFamily: fontFamily,
                                      fontSize: 10.8,
                                      fontWeight: FontWeight.w700,
                                      color: scheme.primary,
                                    ),
                                  ),
                                ),
                            ],
                          ),
                          const SizedBox(height: 8),
                          Wrap(
                            spacing: 8,
                            runSpacing: 8,
                            children: [
                              _InfoChip(
                                icon: Icons.flag_outlined,
                                label: 'ئامانج: $targetLabel',
                                fontFamily: fontFamily,
                              ),
                              _InfoChip(
                                icon: Icons.touch_app_rounded,
                                label: 'بە کلیک دەستپێبکە',
                                fontFamily: fontFamily,
                              ),
                            ],
                          ),
                          const SizedBox(height: 12),
                          Row(
                            children: [
                              const Spacer(),
                              _ActionIcon(
                                icon: Icons.play_arrow_rounded,
                                tooltip: 'دەستپێکردن',
                                onTap: onOpen,
                              ),
                              const SizedBox(width: 8),
                              _ActionIcon(
                                icon: Icons.more_horiz_rounded,
                                tooltip: 'زیاتر',
                                onTap: onMenu,
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _IndexBadge extends StatelessWidget {
  const _IndexBadge({required this.index, required this.fontFamily});

  final int index;
  final String? fontFamily;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return Container(
      width: 54,
      height: 54,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        gradient: LinearGradient(
          colors: [
            scheme.primary.withValues(alpha: 0.94),
            scheme.primaryContainer.withValues(alpha: 0.8),
          ],
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
        ),
      ),
      child: Center(
        child: Text(
          '$index',
          style: TextStyle(
            fontFamily: fontFamily,
            fontSize: 15,
            fontWeight: FontWeight.w800,
            color: scheme.onPrimary,
          ),
        ),
      ),
    );
  }
}

class _InfoChip extends StatelessWidget {
  const _InfoChip({
    required this.icon,
    required this.label,
    required this.fontFamily,
  });

  final IconData icon;
  final String label;
  final String? fontFamily;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return Container(
      padding: const EdgeInsetsDirectional.fromSTEB(10, 6, 10, 6),
      decoration: BoxDecoration(
        color: scheme.surfaceContainerHighest.withValues(alpha: 0.28),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 15, color: scheme.primary),
          const SizedBox(width: 6),
          Text(
            label,
            style: TextStyle(
              fontFamily: fontFamily,
              fontSize: 12.2,
              fontWeight: FontWeight.w700,
              color: scheme.onSurfaceVariant,
            ),
          ),
        ],
      ),
    );
  }
}

class _ActionIcon extends StatelessWidget {
  const _ActionIcon({
    required this.icon,
    required this.tooltip,
    required this.onTap,
  });

  final IconData icon;
  final String tooltip;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return Tooltip(
      message: tooltip,
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: onTap,
          borderRadius: BorderRadius.circular(14),
          child: Ink(
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              color: scheme.surfaceContainerHighest.withValues(alpha: 0.28),
              borderRadius: BorderRadius.circular(14),
            ),
            child: Icon(icon, size: 18, color: scheme.onSurfaceVariant),
          ),
        ),
      ),
    );
  }
}

class _StatePane extends StatelessWidget {
  const _StatePane({
    required this.title,
    required this.message,
    required this.fontFamily,
    this.actionLabel,
    this.onAction,
  });

  final String title;
  final String message;
  final String? actionLabel;
  final VoidCallback? onAction;
  final String? fontFamily;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return Center(
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 110,
              height: 110,
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                color: scheme.primaryContainer.withValues(alpha: 0.5),
                shape: BoxShape.circle,
              ),
              child: Image.asset(
                'assets/icons/tasbeeh.png',
                fit: BoxFit.contain,
              ),
            ),
            const SizedBox(height: 18),
            Text(
              title,
              textAlign: TextAlign.center,
              style: TextStyle(
                fontFamily: fontFamily,
                fontSize: 20,
                fontWeight: FontWeight.w800,
                color: scheme.onSurface,
              ),
            ),
            const SizedBox(height: 8),
            Text(
              message,
              textAlign: TextAlign.center,
              style: TextStyle(
                fontFamily: fontFamily,
                fontSize: 14.2,
                height: 1.7,
                color: scheme.onSurfaceVariant,
              ),
            ),
            if (actionLabel != null && onAction != null) ...[
              const SizedBox(height: 18),
              FilledButton.icon(
                onPressed: onAction,
                icon: const Icon(Icons.add_rounded),
                label: Text(actionLabel!),
              ),
            ],
          ],
        ),
      ),
    );
  }
}
