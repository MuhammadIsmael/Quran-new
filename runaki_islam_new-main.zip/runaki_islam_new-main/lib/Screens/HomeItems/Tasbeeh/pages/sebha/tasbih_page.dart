import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:runaki_islam/models/sebha_model.dart';
import 'package:runaki_islam/providers/settings_provider.dart';
import 'package:runaki_islam/util/constans.dart';
import 'package:vibration/vibration.dart';

class SebhaPage extends StatefulWidget {
  final SebhaModel _tasbih;

  const SebhaPage(this._tasbih, {super.key});

  @override
  State<SebhaPage> createState() => _SebhaPageState();
}

class _SebhaPageState extends State<SebhaPage> {
  late int currentCounter;
  late int round;
  late double percentage;

  int? fontType;

  @override
  void initState() {
    super.initState();
    fontType = Provider.of<SettingsProvider>(
      context,
      listen: false,
    ).getsettingField('font_family');
    currentCounter = 0;
    round = 0;
    percentage = 0.0;
  }

  Future<void> onTapButton() async {
    final canVibrate = await Vibration.hasVibrator();
    if (canVibrate) {
      Vibration.vibrate(duration: 50);
    }
    setState(() {
      if (widget._tasbih.counter == 0) {
        currentCounter++;
        percentage = 0.0;
      } else {
        if (currentCounter < widget._tasbih.counter) {
          currentCounter++;
        } else {
          currentCounter = 1;
          round++;
        }
        percentage = currentCounter / widget._tasbih.counter;
      }
    });
  }

  int get _totalCounter {
    if (widget._tasbih.counter == 0) return currentCounter;
    return currentCounter + (round * widget._tasbih.counter);
  }

  void _resetCounter() {
    setState(() {
      currentCounter = 0;
      round = 0;
      percentage = 0.0;
    });
  }

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final isDark = Theme.of(context).brightness == Brightness.dark;
    return Scaffold(
      resizeToAvoidBottomInset: false,
      backgroundColor: bgColor,
      appBar: AppBar(
        toolbarHeight: 76,
        backgroundColor: thirdColor,
        title: Text(
          'تەسبیح',
          style: TextStyle(
            fontFamily: fontType.toString(),
            color: kTextColor,
            fontWeight: FontWeight.w800,
          ),
        ),
        centerTitle: true,
        elevation: 0,
        shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(bottom: Radius.circular(20)),
        ),
        leading: IconButton(
          color: iconColor,
          onPressed: () {
            Navigator.pop(context);
          },
          icon: const Icon(Icons.arrow_back_ios_rounded),
        ),
        actions: [
          IconButton(
            tooltip: 'reset',
            onPressed: _resetCounter,
            icon: const Icon(Icons.restart_alt_rounded),
            color: kActiveIconColor,
          ),
        ],
      ),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(14, 12, 14, 14),
          child: Column(
            children: <Widget>[
              _buildHeaderCard(scheme, isDark),
              const SizedBox(height: 10),
              _buildInfoRow(),
              const SizedBox(height: 10),
              Expanded(child: _buildFriendlyCounter(scheme, isDark)),
              const SizedBox(height: 10),
              _buildBottomActions(),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildHeaderCard(ColorScheme scheme, bool isDark) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: scheme.surface.withValues(alpha: isDark ? 0.84 : 0.95),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: strokeColor),
        boxShadow: [
          BoxShadow(
            color: scheme.shadow.withValues(alpha: isDark ? 0.2 : 0.08),
            blurRadius: 12,
            offset: const Offset(0, 6),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.end,
        children: [
          Text(
            widget._tasbih.name,
            textAlign: TextAlign.right,
            style: TextStyle(
              fontFamily: fontType.toString(),
              fontSize: 18,
              fontWeight: FontWeight.w800,
              color: kTextColor,
            ),
          ),
          const SizedBox(height: 6),
          Text(
            'لە ناو بازنەکە دابگرە بۆ زیادکردنی ژمارە',
            textAlign: TextAlign.right,
            style: TextStyle(
              fontFamily: fontType.toString(),
              fontSize: 13,
              color: titleTextColor,
              fontWeight: FontWeight.w600,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildInfoRow() {
    final targetLabel = widget._tasbih.counter == 0
        ? 'بێ سنوور'
        : widget._tasbih.counter.toString();
    return Row(
      children: [
        Expanded(child: _infoChip('کۆی ژمارە', _totalCounter.toString())),
        const SizedBox(width: 8),
        Expanded(child: _infoChip('ئێستا', currentCounter.toString())),
        const SizedBox(width: 8),
        Expanded(child: _infoChip('ئامانج', targetLabel)),
        if (widget._tasbih.counter != 0) ...[
          const SizedBox(width: 8),
          Expanded(child: _infoChip('سوڕانەوە', round.toString())),
        ],
      ],
    );
  }

  Widget _infoChip(String title, String value) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 8),
      decoration: BoxDecoration(
        color: kActiveIconColor.withValues(alpha: 0.10),
        borderRadius: BorderRadius.circular(11),
      ),
      child: Column(
        children: [
          Text(
            value,
            style: const TextStyle(
              fontFamily: 'english',
              fontWeight: FontWeight.w800,
              fontSize: 20,
              color: Color(0xFF134638),
            ),
          ),
          const SizedBox(height: 2),
          Text(
            title,
            textAlign: TextAlign.center,
            style: TextStyle(
              fontFamily: fontType.toString(),
              color: titleTextColor,
              fontWeight: FontWeight.w600,
              fontSize: 12.5,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildFriendlyCounter(ColorScheme scheme, bool isDark) {
    final target = widget._tasbih.counter;
    final progress = target == 0 ? null : percentage.clamp(0.0, 1.0);
    return Stack(
      alignment: Alignment.center,
      children: [
        Container(
          width: double.infinity,
          decoration: BoxDecoration(
            color: scheme.surface.withValues(alpha: isDark ? 0.82 : 0.94),
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: strokeColor),
          ),
        ),
        SizedBox(
          width: 280,
          height: 280,
          child: TweenAnimationBuilder<double>(
            tween: Tween<double>(begin: 0, end: progress ?? 0),
            duration: const Duration(milliseconds: 300),
            curve: Curves.easeInOutCubic,
            builder: (context, value, _) {
              return CircularProgressIndicator(
                value: progress == null ? null : value,
                strokeWidth: 11,
                backgroundColor: kActiveIconColor.withValues(alpha: 0.12),
                color: kActiveIconColor,
              );
            },
          ),
        ),
        Material(
          color: Colors.transparent,
          child: InkWell(
            borderRadius: BorderRadius.circular(999),
            onTap: onTapButton,
            child: Ink(
              width: 238,
              height: 238,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: kActiveIconColor.withValues(alpha: 0.18),
              ),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text(
                    _totalCounter.toString(),
                    style: const TextStyle(
                      color: Color(0xFF113A2E),
                      fontWeight: FontWeight.w800,
                      fontFamily: 'english',
                      fontSize: 58,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    'دابگرە بۆ زیادکردن',
                    style: TextStyle(
                      color: titleTextColor,
                      fontWeight: FontWeight.w700,
                      fontFamily: fontType.toString(),
                      fontSize: 13.5,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildBottomActions() {
    return Row(
      children: [
        Expanded(
          child: FilledButton.tonalIcon(
            onPressed: _resetCounter,
            icon: const Icon(Icons.restart_alt_rounded),
            label: Text(
              'نوێکردنەوە',
              style: TextStyle(fontFamily: fontType.toString()),
            ),
            style: FilledButton.styleFrom(
              padding: const EdgeInsets.symmetric(vertical: 12),
            ),
          ),
        ),
        const SizedBox(width: 10),
        Expanded(
          child: FilledButton.icon(
            onPressed: onTapButton,
            icon: const Icon(Icons.add_rounded),
            label: Text(
              'زیادکردن',
              style: TextStyle(fontFamily: fontType.toString()),
            ),
            style: FilledButton.styleFrom(
              backgroundColor: kActiveIconColor,
              foregroundColor: Colors.white,
              padding: const EdgeInsets.symmetric(vertical: 12),
            ),
          ),
        ),
      ],
    );
  }
}
