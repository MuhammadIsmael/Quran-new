import 'package:bootstrap_icons/bootstrap_icons.dart';
import 'package:clipboard/clipboard.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:provider/provider.dart';
import 'package:runaki_islam/Screens/mainScreens/widget/settings_widget.dart';
import 'package:runaki_islam/providers/settings_provider.dart';
import 'package:runaki_islam/util/animation_helper.dart';
import 'package:runaki_islam/util/constans.dart';
import 'package:share_plus/share_plus.dart';

class TextPageView extends StatefulWidget {
  const TextPageView({
    super.key,
    this.title,
    this.desc,
    this.sarder,
    this.isFarmuda = false,
    this.arab = '',
  });

  final String? sarder;
  final String? title;
  final String? desc;
  final bool isFarmuda;
  final String arab;

  @override
  State<TextPageView> createState() => _TextPageViewState();
}

class _TextPageViewState extends State<TextPageView>
    with SingleTickerProviderStateMixin {
  bool pressed = false;
  bool _fabExpanded = false;

  late final ScrollController _controller;
  late final AnimationController _fabController;
  int? fontType;
  double? fontSize;

  @override
  void initState() {
    super.initState();
    _controller = ScrollController();
    _fabController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 420),
    );
    _syncSettingsFromProvider();
    _applySystemUiStyle();
  }

  @override
  void dispose() {
    _fabController.dispose();
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final settingsProvider = Provider.of<SettingsProvider>(
      context,
      listen: false,
    );
    _applySystemUiStyle();

    return Scaffold(
      backgroundColor: thirdColor,
      appBar: AppBar(
        title: Text(
          widget.sarder ?? '',
          style: TextStyle(
            fontFamily: fontType?.toString(),
            fontSize: 16,
            color: kTextColor.withValues(alpha: 0.6),
          ),
        ),
        centerTitle: true,
        backgroundColor: thirdColor,
        elevation: 0,
        leading: IconButton(
          icon: Icon(Icons.arrow_back_ios_rounded, color: kActiveIconColor),
          onPressed: () {
            Navigator.pop(context);
          },
        ),
      ),
      body: Column(
        children: <Widget>[
          Expanded(
            flex: 12,
            child: Container(
              padding: const EdgeInsets.only(
                top: 30,
                left: 10,
                right: 10,
                bottom: 0,
              ),
              width: double.infinity,
              decoration: BoxDecoration(
                color: bgColor,
                borderRadius: const BorderRadius.only(
                  topLeft: Radius.circular(30),
                  topRight: Radius.circular(30),
                ),
              ),
              child: SingleChildScrollView(
                controller: _controller,
                physics: const BouncingScrollPhysics(),
                child: Padding(
                  padding: const EdgeInsets.only(bottom: 92),
                  child: Column(
                    children: [
                      Text(
                        widget.title ?? '',
                        style: TextStyle(
                          fontFamily: fontType?.toString(),
                          fontSize: fontSize,
                          color: kActiveIconColor,
                        ),
                        textAlign: TextAlign.center,
                      ),
                      Divider(
                        color: kActiveIconColor,
                        endIndent: 4,
                        height: 60,
                        thickness: 1,
                      ),
                      if (widget.isFarmuda)
                        SelectableText(
                          widget.arab,
                          style: TextStyle(
                            fontFamily: fontType?.toString(),
                            fontSize: fontSize,
                            color: titleTextColor,
                          ),
                          textAlign: TextAlign.center,
                        ),
                      if (widget.isFarmuda)
                        Divider(
                          color: kActiveIconColor,
                          endIndent: 4,
                          height: 60,
                          thickness: 1,
                        ),
                      SelectableText(
                        widget.desc ?? '',
                        style: TextStyle(
                          fontFamily: fontType?.toString(),
                          fontSize: fontSize,
                          color: titleTextColor,
                        ),
                        textAlign: TextAlign.center,
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
          if (pressed)
            Expanded(
              flex: 4,
              child: CustomContainer(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    Text(
                      'قەبارەی نووسین',
                      style: TextStyle(
                        color: kActiveIconColor,
                        fontFamily: fontType?.toString(),
                      ),
                    ),
                    const SizedBox(height: 10),
                    Slider(
                      divisions: 26,
                      label: (fontSize ?? 18).toStringAsFixed(0),
                      value: (fontSize ?? 18).clamp(14, 40),
                      activeColor: kActiveIconColor,
                      onChanged: (value) {
                        setState(() {
                          fontSize = value;
                        });
                      },
                      onChangeEnd: (value) {
                        setState(() {
                          pressed = false;
                        });
                        settingsProvider.updateSettings('font_size', value);
                      },
                      min: 14,
                      max: 40,
                    ),
                  ],
                ),
              ),
            ),
        ],
      ),
      floatingActionButtonLocation: FloatingActionButtonLocation.endFloat,
      floatingActionButton: SafeArea(
        minimum: const EdgeInsets.only(right: 4, bottom: 4),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.end,
          children: [
            ..._buildFabActions(),
            const SizedBox(height: 14),
            _buildMainFab(),
          ],
        ),
      ),
    );
  }

  List<Widget> _buildFabActions() {
    final actions = <_MiniFabAction>[
      _MiniFabAction(
        icon: Icons.format_size_rounded,
        label: 'قەبارەی نووسین',
        onPressed: () {
          _closeFab();
          setState(() {
            pressed = !pressed;
          });
        },
      ),
      _MiniFabAction(
        icon: BootstrapIcons.copy,
        label: 'کۆپی دەق',
        onPressed: () {
          _closeFab();
          snackBarUi('کۆپی بوو');
          FlutterClipboard.copy(_pageContent(includeStoreLink: true));
        },
      ),
      _MiniFabAction(
        icon: BootstrapIcons.share_fill,
        label: 'هاوبەشکردن',
        onPressed: () {
          _closeFab();
          SharePlus.instance.share(
            ShareParams(
              text: _pageContent(includeStoreLink: true),
              subject: (widget.title ?? '').trim(),
            ),
          );
        },
      ),
      _MiniFabAction(
        icon: BootstrapIcons.gear_fill,
        label: 'ڕێکخستن',
        onPressed: _openSettings,
      ),
    ];

    return List<Widget>.generate(actions.length, (index) {
      return _buildAnimatedFabAction(
        action: actions[index],
        index: index,
        total: actions.length,
      );
    });
  }

  Widget _buildAnimatedFabAction({
    required _MiniFabAction action,
    required int index,
    required int total,
  }) {
    final start = (index * 0.08).clamp(0.0, 0.35);
    final end = (start + 0.58).clamp(0.0, 1.0);
    final animation = CurvedAnimation(
      parent: _fabController,
      curve: Interval(start, end, curve: Curves.easeOutBack),
      reverseCurve: Curves.easeInCubic,
    );

    return AnimatedBuilder(
      animation: animation,
      builder: (context, child) {
        final value = animation.value;
        final clampedValue = value.clamp(0.0, 1.0).toDouble();
        return IgnorePointer(
          ignoring: clampedValue < 0.2,
          child: ClipRect(
            child: Align(
              alignment: Alignment.centerRight,
              heightFactor: clampedValue,
              child: Opacity(
                opacity: clampedValue,
                child: Transform.translate(
                  offset: Offset((1 - value) * 26, (1 - value) * 10),
                  child: Transform.scale(
                    scale: 0.86 + (value * 0.14),
                    child: child,
                  ),
                ),
              ),
            ),
          ),
        );
      },
      child: Padding(
        padding: EdgeInsets.only(bottom: index == total - 1 ? 0 : 10),
        child: _buildMiniFab(
          icon: action.icon,
          label: action.label,
          onPressed: action.onPressed,
        ),
      ),
    );
  }

  Widget _buildMiniFab({
    required IconData icon,
    required String label,
    required VoidCallback onPressed,
  }) {
    return GestureDetector(
      onTap: onPressed,
      behavior: HitTestBehavior.opaque,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
        decoration: BoxDecoration(
          color: kActiveIconColor,
          borderRadius: BorderRadius.circular(26),
          boxShadow: [
            BoxShadow(
              color: kActiveIconColor.withValues(alpha: 0.22),
              blurRadius: 18,
              offset: const Offset(0, 8),
            ),
          ],
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              label,
              style: TextStyle(
                fontFamily: fontType?.toString(),
                fontSize: 12.8,
                fontWeight: FontWeight.w700,
                color: Colors.white,
              ),
            ),
            const SizedBox(width: 10),
            Container(
              width: 40,
              height: 40,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: Colors.white.withValues(alpha: 0.18),
              ),
              child: Icon(icon, color: Colors.white, size: 18),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildMainFab() {
    return AnimatedBuilder(
      animation: _fabController,
      builder: (context, child) {
        final value = _fabController.value;
        return GestureDetector(
          onTap: _toggleFab,
          behavior: HitTestBehavior.opaque,
          child: Container(
            width: 64,
            height: 64,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: kActiveIconColor,
              boxShadow: [
                BoxShadow(
                  color: kActiveIconColor.withValues(alpha: 0.24),
                  blurRadius: 22,
                  offset: const Offset(0, 12),
                ),
              ],
            ),
            child: Center(
              child: AnimatedRotation(
                duration: AppMotion.fast,
                curve: AppMotion.curve,
                turns: value * 0.125,
                child: Icon(
                  _fabExpanded ? Icons.close_rounded : Icons.menu_rounded,
                  color: Colors.white,
                  size: 28,
                ),
              ),
            ),
          ),
        );
      },
    );
  }

  void _toggleFab() {
    setState(() {
      _fabExpanded = !_fabExpanded;
    });
    if (_fabExpanded) {
      _fabController.forward();
    } else {
      _fabController.reverse();
    }
  }

  void _closeFab() {
    if (!_fabExpanded) return;
    setState(() {
      _fabExpanded = false;
    });
    _fabController.reverse();
  }

  void _syncSettingsFromProvider() {
    final settingsProvider = Provider.of<SettingsProvider>(
      context,
      listen: false,
    );
    fontType = settingsProvider.getsettingField('font_family');
    fontSize = settingsProvider.getsettingField('font_size');
  }

  void _applySystemUiStyle() {
    SystemChrome.setSystemUIOverlayStyle(
      SystemUiOverlayStyle(
        systemNavigationBarColor: bgColor,
        statusBarColor: thirdColor,
      ),
    );
  }

  String _pageContent({required bool includeStoreLink}) {
    final buffer = StringBuffer();
    final title = (widget.title ?? '').trim();
    final arab = widget.arab.trim();
    final description = (widget.desc ?? '').trim();

    if (title.isNotEmpty) {
      buffer.writeln(title);
    }
    if (widget.isFarmuda && arab.isNotEmpty) {
      if (buffer.isNotEmpty) buffer.writeln();
      buffer.writeln(arab);
    }
    if (description.isNotEmpty) {
      if (buffer.isNotEmpty) buffer.writeln();
      buffer.writeln(description);
    }
    if (includeStoreLink) {
      if (buffer.isNotEmpty) buffer.writeln();
      buffer.writeln();
      buffer.write(
        'https://play.google.com/store/apps/details?id=com.amin.runakeislam',
      );
    }

    return buffer.toString().trim();
  }

  Future<void> _openSettings() async {
    _closeFab();
    await Navigator.of(context).push(
      AppMotion.fadeSlidePage<void>(
        begin: const Offset(0.08, 0.02),
        page: Scaffold(
          backgroundColor: bgColor,
          appBar: AppBar(
            centerTitle: true,
            elevation: 0,
            backgroundColor: thirdColor,
            title: Text(
              'ڕێکخستن',
              style: TextStyle(
                fontFamily: fontType?.toString(),
                fontSize: 16,
                color: kTextColor.withValues(alpha: 0.8),
              ),
            ),
            leading: IconButton(
              onPressed: () => Navigator.of(context).pop(),
              icon: Icon(Icons.arrow_back_ios_rounded, color: kActiveIconColor),
            ),
          ),
          body: const SettingsScreen(),
        ),
      ),
    );

    if (!mounted) return;
    setState(_syncSettingsFromProvider);
  }

  void snackBarUi(String description) {
    Get.snackbar(
      '',
      '',
      boxShadows: [BoxShadow(blurRadius: 20, color: thirdColor)],
      icon: Icon(Icons.done, color: kActiveIconColor),
      duration: const Duration(milliseconds: 1000),
      overlayBlur: 4,
      shouldIconPulse: true,
      snackPosition: SnackPosition.BOTTOM,
      snackStyle: SnackStyle.FLOATING,
      titleText: Text(
        description,
        textAlign: TextAlign.right,
        textDirection: TextDirection.rtl,
        style: TextStyle(
          fontFamily: fontType?.toString(),
          fontSize: 16,
          color: kTextColor,
        ),
      ),
      margin: const EdgeInsets.only(bottom: 25, left: 15, right: 15),
      padding: const EdgeInsets.only(bottom: 16, left: 16, right: 16, top: 16),
      borderRadius: 6,
      backgroundColor: bgColor,
    );
  }
}

class CustomContainer extends StatelessWidget {
  const CustomContainer({super.key, required this.child});

  final Widget child;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      margin: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: bgColor.withValues(alpha: 0.96),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: kActiveIconColor.withValues(alpha: 0.22)),
        boxShadow: [
          BoxShadow(
            color: kShadowColor.withValues(alpha: 0.18),
            blurRadius: 12,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: child,
    );
  }
}

class _MiniFabAction {
  const _MiniFabAction({
    required this.icon,
    required this.label,
    required this.onPressed,
  });

  final IconData icon;
  final String label;
  final VoidCallback onPressed;
}
