import 'dart:async';
import 'dart:math' as math;
import 'dart:ui';

import 'package:clipboard/clipboard.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:loading_indicator/loading_indicator.dart';
import 'package:provider/provider.dart';
import 'package:quran_library/quran_library.dart';
import 'package:runaki_islam/Screens/HomeItems/Qurani%20Piroz/data/models/quran_rich_surah.dart';
import 'package:runaki_islam/Screens/HomeItems/Qurani%20Piroz/data/services.dart';
import 'package:runaki_islam/Screens/HomeItems/Qurani%20Piroz/widgets/ayah_action_sheet.dart';
import 'package:runaki_islam/Screens/HomeItems/Qurani%20Piroz/widgets/ayah_card.dart';
import 'package:runaki_islam/Screens/HomeItems/Qurani%20Piroz/widgets/quran_player_full_sheet.dart';
import 'package:runaki_islam/Screens/HomeItems/Qurani%20Piroz/widgets/quran_player_mini_bar.dart';
import 'package:runaki_islam/Screens/HomeItems/Qurani%20Piroz/widgets/reciter_picker_sheet.dart';
import 'package:runaki_islam/Screens/HomeItems/Qurani%20Piroz/widgets/surah_header.dart';
import 'package:runaki_islam/providers/quran_state_provider.dart';
import 'package:runaki_islam/providers/settings_provider.dart';
import 'package:runaki_islam/util/animation_helper.dart';
import 'package:runaki_islam/util/constans.dart';
import 'package:runaki_islam/util/quran_font_registry.dart';
import 'package:share_plus/share_plus.dart';

class QuranViewResult {
  const QuranViewResult({
    required this.surahIndex,
    required this.lastReadAyah,
    required this.surahBookmarked,
  });

  final int surahIndex;
  final int lastReadAyah;
  final bool surahBookmarked;
}

class QuranViewPage extends StatefulWidget {
  const QuranViewPage({
    super.key,
    this.detail,
    this.ayahcount,
    this.indexx,
    this.startAyah = 1,
  });

  final String? detail;
  final String? ayahcount;
  final int? indexx;
  final int startAyah;

  @override
  State<QuranViewPage> createState() => _QuranViewPageState();
}

class _QuranViewPageState extends State<QuranViewPage>
    with TickerProviderStateMixin {
  int? fontType;
  double? fontSize;
  double? speedFactor;
  int? quranFontType;
  double? quranFontSize;

  final ScrollController _scrollController = ScrollController();
  final ValueNotifier<bool> _showFloatingControls = ValueNotifier<bool>(false);
  final AudioPlayer _audioPlayer = AudioPlayer();
  late final TabController _tabController;
  late Future<QuranRichSurah> _surahFuture;
  StreamSubscription<PlayerState>? _playerSub;
  Timer? _autoScrollTimer;

  bool _scrolling = false;
  bool _showMetaBar = true;
  bool _showTranslation = false;
  bool _nightMode = false;
  bool _mushafMode = true;
  bool _tajweedEnabled = true;
  bool _highContrastTajweed = true;
  bool _autoScrollPlayer = true;
  bool _isPlaying = false;
  bool _surahBookmarked = false;
  bool _playbackSequenceEnabled = false;

  int _activeAyah = 1;
  int _currentTab = 0;
  int _ayahTotal = 1;

  double _bottomDragProgress = 0.0;
  bool _isTransitioningSurah = false;
  static const double _nextSurahTrigger = 60.0;

  double _playbackSpeed = 1.0;
  double _lineHeight = 1.8;
  double _tajweedOpacity = 1.0;
  String _repeatLabel = "1x";
  Color _highlightColor = const Color(0xFFBFA05A);

  int _repeatTimes = 1;
  int _repeatCounter = 0;
  bool _repeatInfinite = false;
  int? _repeatRangeStart;
  int? _repeatRangeEnd;

  final Set<int> _bookmarkedAyahs = <int>{};
  final Set<int> _qcfPagesLoading = <int>{};
  final Map<int, GlobalKey> _ayahKeys = <int, GlobalKey>{};
  List<QuranReciter> _reciters = List<QuranReciter>.from(
    ServiceData.defaultReciters,
  );

  String _selectedReciterName = ServiceData.defaultReciters.first.displayName;
  String _selectedReciterId = ServiceData.defaultReciters.first.id;
  QuranRichSurah? _cachedSurah;
  late final int _surahIndex;
  bool _initialAyahScrollScheduled = false;

  @override
  void initState() {
    super.initState();
    final settings = Provider.of<SettingsProvider>(context, listen: false);
    final quranState = Provider.of<QuranStateProvider>(context, listen: false);
    fontSize = settings.getsettingField('font_size');
    speedFactor = settings.getsettingField('speed_factor');
    fontType = settings.getsettingField('font_family');
    quranFontType = normalizeQuranFontFamily(
      settings.getsettingField('quran_font_family'),
    );
    quranFontSize = settings.getsettingField('quran_font_size');

    _surahIndex = widget.indexx ?? 1;
    _activeAyah = widget.startAyah < 1 ? 1 : widget.startAyah;
    _surahBookmarked = quranState.isSurahBookmarked(_surahIndex);
    _bookmarkedAyahs
      ..clear()
      ..addAll(quranState.bookmarkedAyahsForSurah(_surahIndex));

    _tabController = TabController(length: 4, vsync: this);
    _tabController.addListener(() {
      if (_currentTab != _tabController.index) {
        _autoScrollTimer?.cancel();
        setState(() {
          _currentTab = _tabController.index;
          _scrolling = false;
        });
        _showFloatingControls.value = false;
      }
    });
    _scrollController.addListener(_handlePrimaryScroll);

    _surahFuture = _loadSurah();
    _listenToAudio();
    _syncLastRead(_activeAyah);
    unawaited(_loadReciters());
  }

  @override
  void dispose() {
    _autoScrollTimer?.cancel();
    _playerSub?.cancel();
    _scrollController.removeListener(_handlePrimaryScroll);
    _showFloatingControls.dispose();
    _audioPlayer.dispose();
    _tabController.dispose();
    _scrollController.dispose();
    super.dispose();
  }

  Future<QuranRichSurah> _loadSurah() {
    return ServiceData().loadRichSurah(
      _surahIndex,
      reciterId: _selectedReciterId,
    );
  }

  void _ensureQcfPageReady(int? pageNumber) {
    if (pageNumber == null || pageNumber < 1 || pageNumber > 604) return;
    if (QuranFontsService.isPageReady(pageNumber)) return;
    if (_qcfPagesLoading.contains(pageNumber)) return;

    _qcfPagesLoading.add(pageNumber);
    unawaited(() async {
      try {
        await QuranFontsService.ensurePagesLoaded(pageNumber, radius: 0);
      } finally {
        if (!mounted) {
          _qcfPagesLoading.remove(pageNumber);
        } else {
          setState(() {
            _qcfPagesLoading.remove(pageNumber);
          });
        }
      }
    }());
  }

  String? _qcfFontFamilyForPage(int? pageNumber) {
    if (pageNumber == null || pageNumber < 1 || pageNumber > 604) {
      return null;
    }
    if (!QuranFontsService.isPageReady(pageNumber)) return null;

    final pageIndex = pageNumber - 1;
    if (_nightMode) {
      return _tajweedEnabled
          ? QuranFontsService.getDarkFontFamily(pageIndex)
          : QuranFontsService.getNoTajweedDarkFontFamily(pageIndex);
    }
    return _tajweedEnabled
        ? QuranFontsService.getFontFamily(pageIndex)
        : QuranFontsService.getNoTajweedFontFamily(pageIndex);
  }

  Future<void> _loadReciters() async {
    final reciters = await ServiceData().loadAudioReciters();
    if (!mounted || reciters.isEmpty) return;
    setState(() {
      _reciters = reciters;
      if (!_reciters.any((r) => r.id == _selectedReciterId)) {
        _selectedReciterId = _reciters.first.id;
        _selectedReciterName = _reciters.first.displayName;
      } else {
        _selectedReciterName = _reciters
            .firstWhere((r) => r.id == _selectedReciterId)
            .displayName;
      }
    });
  }

  void _listenToAudio() {
    _playerSub = _audioPlayer.playerStateStream.listen((state) {
      if (!mounted) return;
      if (_isPlaying != state.playing) {
        setState(() => _isPlaying = state.playing);
      }
      if (state.processingState == ProcessingState.completed) {
        _onAyahCompleted();
      }
    });
  }

  Future<void> _syncLastRead(int ayahNumber) async {
    final normalized = ayahNumber < 1 ? 1 : ayahNumber;
    await context.read<QuranStateProvider>().setLastRead(
      surahIndex: _surahIndex,
      ayahNumber: normalized,
    );
  }

  Future<void> _toggleSurahBookmark() async {
    final next = !_surahBookmarked;
    setState(() => _surahBookmarked = next);
    await context.read<QuranStateProvider>().setSurahBookmarked(
      _surahIndex,
      next,
    );
  }

  Future<void> _handleBackNavigation() async {
    await _syncLastRead(_activeAyah);
    if (!mounted) return;
    Navigator.of(context).pop(
      QuranViewResult(
        surahIndex: _surahIndex,
        lastReadAyah: _activeAyah,
        surahBookmarked: _surahBookmarked,
      ),
    );
  }

  void _handlePrimaryScroll() {
    if (!_scrollController.hasClients) return;
    if (_currentTab != 0) {
      if (_showFloatingControls.value) {
        _showFloatingControls.value = false;
      }
      return;
    }

    final showFloating = _scrollController.offset > 170;
    if (_showFloatingControls.value != showFloating) {
      _showFloatingControls.value = showFloating;
    }
  }

  double get _headerExpandedHeight {
    final safeTop = MediaQuery.paddingOf(context).top;
    final base = _currentTab == 0 ? 296.0 : 244.0;
    return base + safeTop;
  }

  @override
  Widget build(BuildContext context) {
    final settings = context.watch<SettingsProvider>();
    fontSize = settings.getsettingField('font_size');
    speedFactor = settings.getsettingField('speed_factor');
    fontType = settings.getsettingField('font_family');
    quranFontType = normalizeQuranFontFamily(
      settings.getsettingField('quran_font_family'),
    );
    quranFontSize = settings.getsettingField('quran_font_size');
    final scheme = Theme.of(context).colorScheme;
    final bg = _nightMode ? const Color(0xFF101614) : bgColor;

    SystemChrome.setSystemUIOverlayStyle(
      SystemUiOverlayStyle(systemNavigationBarColor: bg, statusBarColor: bg),
    );

    return PopScope<void>(
      canPop: false,
      onPopInvokedWithResult: (didPop, result) {
        if (didPop) return;
        _handleBackNavigation();
      },
      child: Scaffold(
        backgroundColor: bg,
        body: FutureBuilder<QuranRichSurah>(
          future: _surahFuture,
          builder: (context, snapshot) {
            if (snapshot.connectionState == ConnectionState.waiting &&
                !snapshot.hasData) {
              return Center(
                child: SizedBox(
                  width: 86,
                  child: LoadingIndicator(
                    indicatorType: Indicator.ballSpinFadeLoader,
                    colors: [scheme.primary, scheme.secondary],
                  ),
                ),
              );
            }

            if (snapshot.hasError || !snapshot.hasData) {
              return _buildLoadError();
            }

            final surah = snapshot.data!;
            _cachedSurah = surah;
            _ayahTotal = surah.ayahs.isEmpty ? 1 : surah.ayahs.length;
            if (_activeAyah > _ayahTotal) _activeAyah = _ayahTotal;
            if (!_initialAyahScrollScheduled && _activeAyah > 1) {
              _initialAyahScrollScheduled = true;
              WidgetsBinding.instance.addPostFrameCallback((_) {
                if (!mounted) return;
                unawaited(_scrollToAyah(_activeAyah, animate: false));
              });
            }
            final surahName = widget.detail ?? surah.arabicName;
            final surahSubtitle =
                widget.ayahcount ?? "ژمارەی ئایەت: ${surah.ayahs.length}";

            return Stack(
              children: [
                Positioned.fill(
                  child: IgnorePointer(
                    child: CustomPaint(
                      painter: _IslamicBackdropPainter(
                        color: _nightMode
                            ? Colors.white.withValues(alpha: 0.03)
                            : const Color(0xFFB59358).withValues(alpha: 0.05),
                      ),
                    ),
                  ),
                ),
                Positioned.fill(
                  child: NotificationListener<ScrollNotification>(
                    onNotification: _onScrollNotification,
                    child: CustomScrollView(
                      controller: _scrollController,
                      physics: const BouncingScrollPhysics(
                        parent: AlwaysScrollableScrollPhysics(),
                      ),
                      slivers: [
                        SliverAppBar(
                          floating: true,
                          snap: true,
                          pinned: false,
                          elevation: 0,
                          backgroundColor: Colors.transparent,
                          expandedHeight: _headerExpandedHeight,
                          collapsedHeight: MediaQuery.paddingOf(context).top,
                          toolbarHeight: 0,
                          flexibleSpace: LayoutBuilder(
                            builder: (context, constraints) {
                              final minHeight = MediaQuery.paddingOf(context).top;
                              final visible =
                                  ((constraints.maxHeight - minHeight) /
                                          (_headerExpandedHeight - minHeight))
                                      .clamp(0.0, 1.0);
                              return Opacity(
                                opacity: visible,
                                child: Transform.translate(
                                  offset: Offset(0, (1 - visible) * -20),
                                  child: Column(
                                    children: [
                                      SafeArea(
                                        bottom: false,
                                        child: SurahHeader(
                                          title: surahName,
                                          titleFontFamily: (quranFontType ?? 13)
                                              .toString(),
                                          subtitle: surahSubtitle,
                                          revelationType: _revelationLabel(
                                            surah.revelationType,
                                          ),
                                          heroTag: "surah-title-$_surahIndex",
                                          isBookmarked: _surahBookmarked,
                                          surahNumber: _surahIndex,
                                          onBack: () {
                                            _handleBackNavigation();
                                          },
                                          onSettings: _openQuranSettingsSheet,
                                          onAudio: _openFullPlayer,
                                          onBookmark: () {
                                            _toggleSurahBookmark();
                                          },
                                        ),
                                      ),
                                      _tabSection(context),
                                      if (_currentTab == 0) _quickTools(context),
                                    ],
                                  ),
                                ),
                              );
                            },
                          ),
                        ),
                        ..._tabSlivers(context, surah.ayahs),
                        SliverToBoxAdapter(
                          child: SizedBox(height: _listBottomPadding),
                        ),
                      ],
                    ),
                  ),
                ),
                _floatingReaderControls(context),
                Align(
                  alignment: Alignment.bottomCenter,
                  child: _buildNextSurahHint(context),
                ),
                Align(
                  alignment: Alignment.bottomCenter,
                  child: AnimatedSwitcher(
                    duration: AppMotion.fast,
                    switchInCurve: AppMotion.curve,
                    switchOutCurve: AppMotion.curve,
                    child: QuranPlayerMiniBar(
                      key: ValueKey<String>("${_isPlaying}_$_activeAyah"),
                      surahName: surahName,
                      currentAyah: _activeAyah,
                      isPlaying: _isPlaying,
                      onPlayPause: _togglePlayPause,
                      onPrevious: _previousAyah,
                      onNext: _nextAyah,
                      onExpand: _openFullPlayer,
                    ),
                  ),
                ),
              ],
            );
          },
        ),
      ),
    );
  }

  Widget _buildLoadError() {
    final scheme = Theme.of(context).colorScheme;
    return Center(
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(Icons.error_outline_rounded, color: scheme.error, size: 44),
            const SizedBox(height: 10),
            Text(
              'ئێستا ناتوانرێت ئەم سورتە باربکرێت.',
              style: TextStyle(
                color: scheme.onSurface,
                fontWeight: FontWeight.w700,
                fontSize: 15,
              ),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 12),
            FilledButton.icon(
              onPressed: () {
                setState(() => _surahFuture = _loadSurah());
              },
              icon: const Icon(Icons.refresh_rounded),
              label: const Text('دووبارە هەوڵبدەرەوە'),
            ),
          ],
        ),
      ),
    );
  }

  Widget _tabSection(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return Container(
      margin: const EdgeInsets.fromLTRB(14, 4, 14, 0),
      decoration: BoxDecoration(
        color: scheme.surface.withValues(alpha: 0.92),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: scheme.outline.withValues(alpha: 0.2)),
      ),
      child: TabBar(
        controller: _tabController,
        isScrollable: true,
        tabAlignment: TabAlignment.start,
        dividerColor: Colors.transparent,
        indicatorSize: TabBarIndicatorSize.tab,
        indicator: BoxDecoration(
          color: scheme.primary.withValues(alpha: 0.13),
          borderRadius: BorderRadius.circular(14),
        ),
        labelColor: scheme.primary,
        unselectedLabelColor: scheme.onSurfaceVariant,
        tabs: const [
          Tab(text: "قورئان"),
          Tab(text: "وەرگێڕان"),
          Tab(text: "تەفسیرێ کوردی"),
          Tab(text: "تەفسیرێ عەرەبی"),
        ],
      ),
    );
  }

  Widget _quickTools(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return Padding(
      padding: const EdgeInsets.fromLTRB(14, 8, 14, 6),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Expanded(
            child: SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              physics: const BouncingScrollPhysics(),
              child: Row(
                children: [
                  _toolChip(
                    context,
                    icon: _scrolling
                        ? Icons.pause_rounded
                        : Icons.arrow_downward_rounded,
                    label: _scrolling
                        ? "سکرۆڵی خۆکار: چالاک"
                        : "سکرۆڵی خۆکار: ناچالاک",
                    onTap: _toggleScroll,
                  ),
                  const SizedBox(width: 8),
                  _toolChip(
                    context,
                    icon: _showMetaBar
                        ? Icons.visibility_outlined
                        : Icons.visibility_off_outlined,
                    label: _showMetaBar ? "زانیاری: دیار" : "زانیاری: نەشاراوە",
                    onTap: () => setState(() => _showMetaBar = !_showMetaBar),
                  ),
                  if (_currentTab == 0) ...[
                    const SizedBox(width: 8),
                    _toolChip(
                      context,
                      icon: _tajweedEnabled
                          ? Icons.palette_rounded
                          : Icons.palette_outlined,
                      label: _tajweedEnabled
                          ? "تەجوید: چالاک"
                          : "تەجوید: ناچالاک",
                      onTap: () {
                        setState(() => _tajweedEnabled = !_tajweedEnabled);
                      },
                    ),
                  ],
                ],
              ),
            ),
          ),
          const SizedBox(width: 6),
          IconButton(
            onPressed: _openQuranSettingsSheet,
            icon: Icon(Icons.tune_rounded, color: scheme.onSurfaceVariant),
          ),
        ],
      ),
    );
  }

  Widget _floatingReaderControls(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return ValueListenableBuilder<bool>(
      valueListenable: _showFloatingControls,
      builder: (context, show, child) {
        final visible = show && _currentTab == 0;
        final top = MediaQuery.paddingOf(context).top + 8;
        return PositionedDirectional(
          top: top,
          start: 16,
          end: 16,
          child: IgnorePointer(
            ignoring: !visible,
            child: AnimatedSlide(
              duration: AppMotion.fast,
              curve: AppMotion.curve,
              offset: visible ? Offset.zero : const Offset(0, -0.22),
              child: AnimatedOpacity(
                duration: AppMotion.fast,
                curve: AppMotion.curve,
                opacity: visible ? 1 : 0,
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(18),
                  child: BackdropFilter(
                    filter: ImageFilter.blur(sigmaX: 12, sigmaY: 12),
                    child: Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 12,
                        vertical: 10,
                      ),
                      decoration: BoxDecoration(
                        color: scheme.surface.withValues(alpha: 0.72),
                        borderRadius: BorderRadius.circular(18),
                        border: Border.all(
                          color: scheme.outline.withValues(alpha: 0.18),
                        ),
                        boxShadow: [
                          BoxShadow(
                            color: scheme.shadow.withValues(alpha: 0.12),
                            blurRadius: 16,
                            offset: const Offset(0, 8),
                          ),
                        ],
                      ),
                      child: Row(
                        children: [
                          _floatingButton(
                            icon: _tajweedEnabled
                                ? Icons.palette_rounded
                                : Icons.palette_outlined,
                            tooltip: _tajweedEnabled
                                ? "تەجوید: چالاک"
                                : "تەجوید: ناچالاک",
                            selected: _tajweedEnabled,
                            onTap: () {
                              setState(
                                () => _tajweedEnabled = !_tajweedEnabled,
                              );
                            },
                          ),
                          const SizedBox(width: 8),
                          _floatingButton(
                            icon: _highContrastTajweed
                                ? Icons.contrast_rounded
                                : Icons.tonality_rounded,
                            tooltip: _highContrastTajweed
                                ? "ڕەنگی تەجوید: بەرز"
                                : "ڕەنگی تەجوید: ئاسایی",
                            selected: _tajweedEnabled && _highContrastTajweed,
                            onTap: () {
                              setState(
                                () => _highContrastTajweed =
                                    !_highContrastTajweed,
                              );
                            },
                          ),
                          const SizedBox(width: 8),
                          _floatingButton(
                            icon: _scrolling
                                ? Icons.pause_circle_filled_rounded
                                : Icons.play_circle_fill_rounded,
                            tooltip: _scrolling
                                ? "وەستاندنی سکڕۆڵی خۆکار"
                                : "سکڕۆڵی خۆکار",
                            selected: _scrolling,
                            onTap: _toggleScroll,
                            onLongPress: _openAutoScrollSpeedSheet,
                          ),
                          const SizedBox(width: 8),
                          _floatingButton(
                            icon: _mushafMode
                                ? Icons.chrome_reader_mode_rounded
                                : Icons.menu_book_rounded,
                            tooltip: _mushafMode
                                ? "شێوازی خوێندنەوە: ئایەت بە ئایەت"
                                : "شێوازی خوێندنەوە: دۆخی وەرق",
                            selected: !_mushafMode,
                            onTap: () {
                              setState(() => _mushafMode = !_mushafMode);
                            },
                          ),
                          const SizedBox(width: 8),
                          _floatingButton(
                            icon: Icons.tune_rounded,
                            tooltip: "ڕێکخستنەکانی خوێندنەوە",
                            onTap: _openQuranSettingsSheet,
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ),
        );
      },
    );
  }

  Widget _floatingButton({
    required IconData icon,
    required String tooltip,
    required VoidCallback onTap,
    VoidCallback? onLongPress,
    bool selected = false,
  }) {
    final scheme = Theme.of(context).colorScheme;
    return Tooltip(
      message: tooltip,
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: onTap,
          onLongPress: onLongPress,
          borderRadius: BorderRadius.circular(12),
          child: AnimatedContainer(
            duration: AppMotion.fast,
            curve: AppMotion.curve,
            width: 40,
            height: 40,
            decoration: BoxDecoration(
              color: selected
                  ? scheme.primaryContainer.withValues(alpha: 0.92)
                  : scheme.surfaceContainerHighest.withValues(alpha: 0.5),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(
                color: selected
                    ? scheme.primary.withValues(alpha: 0.28)
                    : scheme.outline.withValues(alpha: 0.16),
              ),
            ),
            child: Icon(
              icon,
              size: 20,
              color: selected ? scheme.onPrimaryContainer : scheme.primary,
            ),
          ),
        ),
      ),
    );
  }

  Widget _toolChip(
    BuildContext context, {
    required IconData icon,
    required String label,
    required VoidCallback onTap,
  }) {
    final scheme = Theme.of(context).colorScheme;
    return Material(
      color: Colors.transparent,
      child: InkWell(
        borderRadius: BorderRadius.circular(11),
        onTap: onTap,
        child: Ink(
          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 7),
          decoration: BoxDecoration(
            color: scheme.surfaceContainerHighest.withValues(alpha: 0.4),
            borderRadius: BorderRadius.circular(11),
            border: Border.all(color: scheme.outline.withValues(alpha: 0.2)),
          ),
          child: Row(
            children: [
              Icon(icon, size: 17, color: scheme.primary),
              const SizedBox(width: 6),
              Text(
                label,
                textDirection: TextDirection.rtl,
                style: TextStyle(
                  color: scheme.onSurface,
                  fontSize: 12.2,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  List<Widget> _tabSlivers(BuildContext context, List<QuranAyahData> ayahs) {
    switch (_currentTab) {
      case 0:
        return _buildArabicSlivers(ayahs);
      case 1:
        return _buildMeaningSlivers(
          ayahs,
          resolver: (ayah) => ayah.kurdishTranslation,
          fallbackText: "وەرگێڕان بۆ ئەم ئایەتە بەردەست نییە.",
        );
      case 2:
        return _buildMeaningSlivers(
          ayahs,
          resolver: (ayah) => ayah.kurdishTafsir,
          fallbackText: "تەفسیرێ کوردی بۆ ئەم ئایەتە بەردەست نییە.",
        );
      default:
        return _buildMeaningSlivers(
          ayahs,
          resolver: (ayah) => ayah.arabicTafsir,
          fallbackText: "تەفسیرێ عەرەبی بۆ ئەم ئایەتە بەردەست نییە.",
          arabic: true,
        );
    }
  }

  List<Widget> _buildArabicSlivers(List<QuranAyahData> ayahs) {
    if (!_mushafMode) {
      return <Widget>[
        SliverPadding(
          padding: const EdgeInsets.fromLTRB(14, 8, 14, 0),
          sliver: SliverToBoxAdapter(child: _buildPaperView(ayahs)),
        ),
      ];
    }

    return <Widget>[
      SliverPadding(
        padding: const EdgeInsets.only(top: 4),
        sliver: SliverList(
          delegate: SliverChildBuilderDelegate((context, index) {
            final ayah = ayahs[index];
            _ensureQcfPageReady(ayah.page);
            final qcfFontFamily = _qcfFontFamilyForPage(ayah.page);
            return AyahCard(
              key: _ayahKeyFor(ayah.numberInSurah),
              ayahNumber: ayah.numberInSurah,
              arabicText: ayah.arabicText,
              fontFamily: quranFontType.toString(),
              fontSize: quranFontSize ?? 24,
              lineHeight: _lineHeight,
              highlightColor: _highlightColor,
              isHighlighted: _isPlaying && _activeAyah == ayah.numberInSurah,
              isBookmarked: _bookmarkedAyahs.contains(ayah.numberInSurah),
              showMetaBar: _showMetaBar && _mushafMode,
              showTranslation: _showTranslation,
              translationText: ayah.kurdishTranslation,
              tajweedText: ayah.tajweedText,
              qpcGlyphText: ayah.qpcGlyphText,
              qcfFontFamily: qcfFontFamily,
              enableTajweedColors: _tajweedEnabled,
              highContrastTajweed: _highContrastTajweed,
              tajweedColors: _activeTajweedColors,
              tajweedOpacity: _tajweedOpacity,
              paperMode: false,
              onTap: () => _onAyahTap(ayah),
              onCopy: () => _copyText(ayah.arabicText),
            );
          }, childCount: ayahs.length),
        ),
      ),
    ];
  }

  Widget _buildPaperView(List<QuranAyahData> ayahs) {
    final scheme = Theme.of(context).colorScheme;
    final surface = _nightMode
        ? const Color(0xFF1C221F)
        : const Color(0xFFF7EEDC);
    final border = _nightMode
        ? scheme.outline.withValues(alpha: 0.4)
        : const Color(0xFFDBC7A1);
    final textColor = _nightMode
        ? const Color(0xFFEFE8D8)
        : const Color(0xFF3E2A14);
    final title = (widget.detail ?? _cachedSurah?.arabicName ?? '').trim();
    final subtitle = (widget.ayahcount ?? 'Ayahs: ${ayahs.length}').trim();
    final bannerTextColor = _nightMode
        ? const Color(0xFFF5D9A8)
        : const Color(0xFF5A4322);

    return Container(
      decoration: BoxDecoration(
        color: surface,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: border),
        boxShadow: [
          BoxShadow(
            color: scheme.shadow.withValues(alpha: 0.12),
            blurRadius: 14,
            offset: const Offset(0, 6),
          ),
        ],
      ),
      child: Stack(
        children: [
          Positioned.fill(
            child: IgnorePointer(
              child: CustomPaint(
                painter: _PaperTexturePainter(
                  color: _nightMode
                      ? Colors.white.withValues(alpha: 0.025)
                      : const Color(0xFFAE8D5E).withValues(alpha: 0.08),
                ),
              ),
            ),
          ),
          PositionedDirectional(
            top: 14,
            start: 10,
            child: Opacity(
              opacity: _nightMode ? 0.18 : 0.28,
              child: SvgPicture.asset(
                'assets/icons/quran/sajdaIcon.svg',
                width: 24,
                height: 24,
                colorFilter: ColorFilter.mode(
                  _nightMode
                      ? const Color(0xFFF7D9A6)
                      : const Color(0xFF9B7A49),
                  BlendMode.srcIn,
                ),
              ),
            ),
          ),
          PositionedDirectional(
            top: 14,
            end: 10,
            child: Opacity(
              opacity: _nightMode ? 0.18 : 0.28,
              child: Transform(
                alignment: Alignment.center,
                transform: Matrix4.diagonal3Values(-1.0, 1.0, 1.0),
                child: SvgPicture.asset(
                  'assets/icons/quran/sajdaIcon.svg',
                  width: 24,
                  height: 24,
                  colorFilter: ColorFilter.mode(
                    _nightMode
                        ? const Color(0xFFF7D9A6)
                        : const Color(0xFF9B7A49),
                    BlendMode.srcIn,
                  ),
                ),
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 12, 16, 20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                SizedBox(
                  height: 48,
                  child: Stack(
                    alignment: Alignment.center,
                    children: [
                      Positioned.fill(
                        child: SvgPicture.asset(
                          'assets/icons/quran/surahSvgBanner.svg',
                          fit: BoxFit.fill,
                        ),
                      ),
                      Text(
                        title.isEmpty ? '$_surahIndex' : title,
                        textDirection: TextDirection.rtl,
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          color: bannerTextColor,
                          fontFamily: (quranFontType ?? 13).toString(),
                          fontSize: 25,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 8),
                Text(
                  subtitle,
                  textDirection: TextDirection.rtl,
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    color: textColor.withValues(alpha: 0.78),
                    fontSize: 12.5,
                    fontWeight: FontWeight.w700,
                  ),
                ),
                const SizedBox(height: 10),
                Container(
                  height: 1,
                  color: border.withValues(alpha: _nightMode ? 0.6 : 0.85),
                ),
                const SizedBox(height: 12),
                SelectableText.rich(
                  TextSpan(
                    style: TextStyle(
                      fontFamily: quranFontType.toString(),
                      fontSize: (quranFontSize ?? 24) + 1,
                      height: _lineHeight + 0.1,
                      color: textColor,
                      fontWeight: FontWeight.w500,
                    ),
                    children: _buildPaperArabicSpans(ayahs, textColor),
                  ),
                  textDirection: TextDirection.rtl,
                  textAlign: TextAlign.center,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  List<InlineSpan> _buildPaperArabicSpans(
    List<QuranAyahData> ayahs,
    Color fallbackColor,
  ) {
    final spans = <InlineSpan>[];
    for (final ayah in ayahs) {
      _ensureQcfPageReady(ayah.page);
      final qcfFontFamily = _qcfFontFamilyForPage(ayah.page);
      spans.addAll(
        _buildTajweedSpans(
          plainText: ayah.arabicText,
          tajweedText: ayah.tajweedText,
          qpcGlyphText: ayah.qpcGlyphText,
          qcfFontFamily: qcfFontFamily,
          fallbackColor: fallbackColor,
        ),
      );

      spans.add(
        WidgetSpan(
          alignment: PlaceholderAlignment.middle,
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 4),
            child: _paperAyahMarker(ayah.numberInSurah),
          ),
        ),
      );
      spans.add(const TextSpan(text: ' '));
    }
    return spans;
  }

  List<InlineSpan> _buildTajweedSpans({
    required String plainText,
    required String? tajweedText,
    required String? qpcGlyphText,
    required String? qcfFontFamily,
    required Color fallbackColor,
  }) {
    final glyphText = qpcGlyphText?.trim() ?? '';
    final glyphFamily = qcfFontFamily?.trim() ?? '';
    final canDrawGlyph = glyphText.isNotEmpty && glyphFamily.isNotEmpty;
    InlineSpan glyphSpan() {
      return TextSpan(
        text: glyphText,
        style: TextStyle(
          fontFamily: glyphFamily,
          fontWeight: FontWeight.w500,
          wordSpacing: -2,
        ),
      );
    }

    if (!_tajweedEnabled) {
      return canDrawGlyph
          ? <InlineSpan>[glyphSpan()]
          : <InlineSpan>[TextSpan(text: plainText)];
    }

    if (!_highContrastTajweed && canDrawGlyph) {
      return <InlineSpan>[glyphSpan()];
    }

    if (tajweedText == null || tajweedText.trim().isEmpty) {
      return canDrawGlyph
          ? <InlineSpan>[glyphSpan()]
          : <InlineSpan>[TextSpan(text: plainText)];
    }

    final normalizedOpacity = _tajweedOpacity.clamp(0.35, 1.0);
    final segments = _parseTajweedMarkup(tajweedText);
    if (segments.isEmpty) {
      return canDrawGlyph
          ? <InlineSpan>[glyphSpan()]
          : <InlineSpan>[TextSpan(text: plainText)];
    }

    final hasTaggedRules = segments.any((segment) {
      final code = segment.ruleCode?.trim();
      return code != null && code.isNotEmpty;
    });
    if (!hasTaggedRules) {
      if (canDrawGlyph) {
        return <InlineSpan>[glyphSpan()];
      }
      final fallback = _activeTajweedColors.values.isEmpty
          ? fallbackColor
          : _activeTajweedColors.values.first;
      return <InlineSpan>[
        TextSpan(
          text: plainText,
          style: _tajweedSpanStyle(fallback, normalizedOpacity),
        ),
      ];
    }

    return segments.map((segment) {
      final code = segment.ruleCode;
      if (code == null) return TextSpan(text: segment.text);

      final key = code.toLowerCase();
      final color =
          _activeTajweedColors[key] ??
          _activeTajweedColors[code] ??
          fallbackColor;
      return TextSpan(
        text: segment.text,
        style: _tajweedSpanStyle(color, normalizedOpacity),
      );
    }).toList();
  }

  List<_TajweedMarkupSegment> _parseTajweedMarkup(String input) {
    final bracket = _parseBracketTajweed(input);
    if (bracket.isNotEmpty) return bracket;

    final html = _parseHtmlTajweed(input);
    if (html.isNotEmpty) return html;

    return <_TajweedMarkupSegment>[_TajweedMarkupSegment(text: input)];
  }

  List<_TajweedMarkupSegment> _parseBracketTajweed(String input) {
    final pattern = RegExp(r'\[([A-Za-z_]+)(?::\d+)?\[([^\]]*)\]');
    final matches = pattern.allMatches(input).toList();
    if (matches.isEmpty) return <_TajweedMarkupSegment>[];

    final result = <_TajweedMarkupSegment>[];
    int cursor = 0;
    for (final match in matches) {
      if (match.start > cursor) {
        result.add(
          _TajweedMarkupSegment(text: input.substring(cursor, match.start)),
        );
      }

      final code = match.group(1);
      final text = match.group(2);
      if (text != null && text.isNotEmpty) {
        result.add(_TajweedMarkupSegment(text: text, ruleCode: code));
      }
      cursor = match.end;
    }

    if (cursor < input.length) {
      result.add(_TajweedMarkupSegment(text: input.substring(cursor)));
    }

    return result;
  }

  List<_TajweedMarkupSegment> _parseHtmlTajweed(String input) {
    final pattern = RegExp(
      "<(?:tajweed|span)[^>]*class=[\"']?([A-Za-z_]+)[\"']?[^>]*>(.*?)<\\/(?:tajweed|span)>",
      caseSensitive: false,
      dotAll: true,
    );
    final matches = pattern.allMatches(input).toList();
    if (matches.isEmpty) return <_TajweedMarkupSegment>[];

    final result = <_TajweedMarkupSegment>[];
    int cursor = 0;
    for (final match in matches) {
      if (match.start > cursor) {
        result.add(
          _TajweedMarkupSegment(
            text: _stripMarkupTags(input.substring(cursor, match.start)),
          ),
        );
      }

      final code = match.group(1);
      final text = _stripMarkupTags(match.group(2) ?? "");
      if (text.isNotEmpty) {
        result.add(_TajweedMarkupSegment(text: text, ruleCode: code));
      }
      cursor = match.end;
    }

    if (cursor < input.length) {
      result.add(
        _TajweedMarkupSegment(text: _stripMarkupTags(input.substring(cursor))),
      );
    }

    return result;
  }

  String _stripMarkupTags(String value) {
    return value.replaceAll(RegExp(r'<[^>]+>'), '');
  }

  String _toArabicDigits(int value) {
    const western = '0123456789';
    const eastern =
        '\u0660\u0661\u0662\u0663\u0664\u0665\u0666\u0667\u0668\u0669';
    return value.toString().split('').map((digit) {
      final index = western.indexOf(digit);
      return index == -1 ? digit : eastern[index];
    }).join();
  }

  Widget _paperAyahMarker(int ayahNumber) {
    return SizedBox(
      width: 31,
      height: 31,
      child: Stack(
        alignment: Alignment.center,
        children: [
          SvgPicture.asset(
            'assets/icons/quran/suraNum.svg',
            colorFilter: ColorFilter.mode(Color(0xffCD9974), BlendMode.srcIn),
            width: 31,
            height: 31,
          ),
          Text(
            _toArabicDigits(ayahNumber),
            style: TextStyle(
              color: _nightMode
                  ? const Color(0xFFF9F2E5)
                  : Colors.white.withValues(alpha: 0.98),
              fontWeight: FontWeight.w800,
              fontSize: 10.4,
            ),
          ),
        ],
      ),
    );
  }

  TextStyle _tajweedSpanStyle(Color color, double opacity) {
    final effective = color.withValues(alpha: opacity);
    final darkShadow = Colors.black.withValues(
      alpha: _highContrastTajweed
          ? (_nightMode ? 0.62 : 0.40)
          : (_nightMode ? 0.40 : 0.26),
    );
    final lightShadow = Colors.white.withValues(
      alpha: _highContrastTajweed
          ? (_nightMode ? 0.08 : 0.34)
          : (_nightMode ? 0.05 : 0.18),
    );

    return TextStyle(
      color: effective,
      fontWeight: _highContrastTajweed ? FontWeight.w800 : FontWeight.w700,
      shadows: <Shadow>[
        Shadow(color: darkShadow, blurRadius: _highContrastTajweed ? 1.8 : 1.0),
        Shadow(
          color: lightShadow,
          blurRadius: _highContrastTajweed ? 1.2 : 0.7,
        ),
      ],
    );
  }

  Map<String, Color> get _activeTajweedColors {
    if (_highContrastTajweed) {
      return <String, Color>{
        'a': const Color(0xFFE0005A),
        'b': const Color(0xFF7A00FF),
        'c': const Color(0xFF008BFF),
        'd': const Color(0xFF00A884),
        'f': const Color(0xFFFF6D00),
        'g': const Color(0xFF14A800),
        'h': const Color(0xFF0052FF),
        'i': const Color(0xFFC700D9),
        'l': const Color(0xFF8B4D00),
        'm': const Color(0xFF00A33A),
        'n': const Color(0xFFC40000),
        'o': const Color(0xFF008A7A),
        'p': const Color(0xFF00A57A),
        'q': const Color(0xFF304FFE),
        's': const Color(0xFFFF3D00),
        'u': const Color(0xFF0066FF),
        'w': const Color(0xFF7E2CFF),
        'ghn': const Color(0xFFD100D2),
        'slnt': const Color(0xFF5F6D7A),
        'qlq': const Color(0xFF3959FF),
        'madda_normal': const Color(0xFF00A57A),
        'madda_permissible': const Color(0xFF00B9A4),
        'madda_necessary': const Color(0xFF00A800),
        'madda_obligatory': const Color(0xFF36B700),
        'madda_substitute': const Color(0xFF6CB500),
        'ham_wasl': const Color(0xFF0A63FF),
        'laam_shamsiyah': const Color(0xFFFF2B6A),
        'ikhf': const Color(0xFFFF5A00),
        'ikhf_shafawi': const Color(0xFFFF3D00),
        'idgham_shafawi': const Color(0xFFAB00FF),
        'iqlab': const Color(0xFF1F6F80),
        'idgh_ghn': const Color(0xFFD600F0),
        'idgh_w_ghn': const Color(0xFF7D45FF),
        'idgh_mus': const Color(0xFF5B3BFF),
      };
    }

    return <String, Color>{
      'a': const Color(0xFFC1005A),
      'b': const Color(0xFF6D28FF),
      'c': const Color(0xFF168BFF),
      'd': const Color(0xFF00A087),
      'f': const Color(0xFFF05A00),
      'g': const Color(0xFF2E9E00),
      'h': const Color(0xFF0066D6),
      'i': const Color(0xFFAA26C8),
      'l': const Color(0xFF8D6E63),
      'm': const Color(0xFF2E8C34),
      'n': const Color(0xFFD32F2F),
      'o': const Color(0xFF00A8B5),
      'p': const Color(0xFF24A879),
      'q': const Color(0xFF5C6BFF),
      's': const Color(0xFFE65100),
      'u': const Color(0xFF1E88E5),
      'w': const Color(0xFF7B1FD3),
      'ghn': const Color(0xFFAA26C8),
      'slnt': const Color(0xFF6C7A89),
      'qlq': const Color(0xFF5C6BFF),
      'ikhf': const Color(0xFFF4511E),
      'iqlab': const Color(0xFF607D8B),
      'idgh_ghn': const Color(0xFF9C27B0),
      'idgh_w_ghn': const Color(0xFF7E57C2),
      'idgh_mus': const Color(0xFF5E35B1),
    };
  }

  double get _listBottomPadding {
    return 120 + MediaQuery.paddingOf(context).bottom;
  }

  List<Widget> _buildMeaningSlivers(
    List<QuranAyahData> ayahs, {
    required String? Function(QuranAyahData ayah) resolver,
    required String fallbackText,
    bool arabic = false,
  }) {
    final scheme = Theme.of(context).colorScheme;
    return <Widget>[
      SliverPadding(
        padding: const EdgeInsets.fromLTRB(14, 8, 14, 0),
        sliver: SliverList(
          delegate: SliverChildBuilderDelegate((context, index) {
            final ayah = ayahs[index];
            final text = resolver(ayah) ?? "";
            return Container(
              margin: const EdgeInsets.only(bottom: 10),
              padding: const EdgeInsets.fromLTRB(12, 12, 12, 12),
              decoration: BoxDecoration(
                color: scheme.surface.withValues(alpha: 0.9),
                borderRadius: BorderRadius.circular(14),
                border: Border.all(
                  color: scheme.outline.withValues(alpha: 0.2),
                ),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  Row(
                    children: [
                      IconButton(
                        visualDensity: VisualDensity.compact,
                        icon: Icon(
                          Icons.more_horiz_rounded,
                          color: scheme.primary,
                        ),
                        onPressed: () => _onAyahTap(ayah),
                      ),
                      const Spacer(),
                      SizedBox(
                        width: 38,
                        height: 38,
                        child: Stack(
                          alignment: Alignment.center,
                          children: [
                            SvgPicture.asset(
                              'assets/icons/quran/suraNum.svg',
                              width: 38,
                              height: 38,
                              colorFilter: ColorFilter.mode(
                                scheme.primary.withValues(alpha: 0.15),
                                BlendMode.srcIn,
                              ),
                            ),
                            Text(
                              "${ayah.numberInSurah}",
                              style: const TextStyle(
                                color: Colors.white,
                                fontFamily: 'english',
                                fontWeight: FontWeight.w700,
                                fontSize: 12,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 6),
                  Text(
                    text.trim().isNotEmpty ? text : fallbackText,
                    textDirection: TextDirection.rtl,
                    textAlign: TextAlign.right,
                    style: TextStyle(
                      fontFamily: arabic
                          ? quranFontType.toString()
                          : fontType.toString(),
                      fontSize: arabic
                          ? (quranFontSize ?? 24) - 4
                          : (fontSize ?? 16),
                      height: arabic ? _lineHeight : 1.75,
                      color: scheme.onSurface,
                    ),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    "عەرەبی",
                    textDirection: TextDirection.rtl,
                    style: TextStyle(
                      color: scheme.primary,
                      fontWeight: FontWeight.w700,
                      fontSize: 12.5,
                    ),
                  ),
                  const SizedBox(height: 2),
                  Text(
                    ayah.arabicText,
                    textDirection: TextDirection.rtl,
                    textAlign: TextAlign.right,
                    style: TextStyle(
                      fontFamily: quranFontType.toString(),
                      fontSize: (quranFontSize ?? 24) - 6,
                      height: 1.8,
                      color: scheme.onSurfaceVariant,
                    ),
                  ),
                ],
              ),
            );
          }, childCount: ayahs.length),
        ),
      ),
    ];
  }

  GlobalKey _ayahKeyFor(int ayahNumber) {
    return _ayahKeys.putIfAbsent(
      ayahNumber,
      () => GlobalKey(debugLabel: 'ayah-$_surahIndex-$ayahNumber'),
    );
  }

  Future<void> _ensureAyahVisible(
    GlobalKey key, {
    required bool animate,
  }) async {
    if (!_scrollController.hasClients) return;
    final renderObject = key.currentContext?.findRenderObject();
    if (renderObject == null) return;
    await _scrollController.position.ensureVisible(
      renderObject,
      duration: animate ? AppMotion.page : Duration.zero,
      curve: AppMotion.curve,
      alignment: 0.08,
    );
  }

  void _toggleScroll() {
    if (_scrolling) {
      _stopAutoScroll();
      return;
    }
    _startAutoScroll();
  }

  void _startAutoScroll() {
    _autoScrollTimer?.cancel();
    if (mounted) {
      setState(() => _scrolling = true);
    } else {
      _scrolling = true;
    }
    _autoScrollTimer = Timer.periodic(const Duration(milliseconds: 16), (_) {
      if (!_scrollController.hasClients) return;
      final position = _scrollController.position;
      final maxExtent = position.maxScrollExtent;
      final currentOffset = position.pixels;
      if (currentOffset >= maxExtent) {
        _stopAutoScroll();
        return;
      }

      final factor = (speedFactor ?? 10).clamp(2, 25).toDouble();
      final nextOffset = math.min(currentOffset + (factor * 0.58), maxExtent);
      _scrollController.jumpTo(nextOffset);
    });
  }

  void _stopAutoScroll() {
    _autoScrollTimer?.cancel();
    _autoScrollTimer = null;
    if (mounted) {
      if (_scrolling) {
        setState(() => _scrolling = false);
      }
      return;
    }
    _scrolling = false;
  }

  Future<void> _openAutoScrollSpeedSheet() async {
    final scheme = Theme.of(context).colorScheme;
    double localSpeed = (speedFactor ?? 10).clamp(2, 25).toDouble();
    await showModalBottomSheet<void>(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (_) => SafeArea(
        top: false,
        child: StatefulBuilder(
          builder: (context, modalSetState) {
            return Container(
              margin: const EdgeInsets.fromLTRB(10, 0, 10, 10),
              padding: const EdgeInsets.fromLTRB(14, 12, 14, 14),
              decoration: BoxDecoration(
                color: scheme.surface.withValues(alpha: 0.98),
                borderRadius: BorderRadius.circular(20),
                border: Border.all(
                  color: scheme.outline.withValues(alpha: 0.2),
                ),
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  Container(
                    width: 54,
                    height: 4,
                    decoration: BoxDecoration(
                      color: scheme.outline.withValues(alpha: 0.4),
                      borderRadius: BorderRadius.circular(99),
                    ),
                  ),
                  const SizedBox(height: 10),
                  Text(
                    "خێرایی سکڕۆڵی خۆکار",
                    textDirection: TextDirection.rtl,
                    style: TextStyle(
                      color: scheme.onSurface,
                      fontWeight: FontWeight.w800,
                      fontSize: 16,
                    ),
                  ),
                  const SizedBox(height: 6),
                  Slider(
                    value: localSpeed,
                    min: 2,
                    max: 25,
                    divisions: 23,
                    label: localSpeed.toStringAsFixed(0),
                    onChanged: (v) {
                      modalSetState(() => localSpeed = v);
                      setState(() => speedFactor = v);
                    },
                    onChangeEnd: (v) async {
                      await context.read<SettingsProvider>().updateSettings(
                        'speed_factor',
                        v,
                      );
                    },
                  ),
                ],
              ),
            );
          },
        ),
      ),
    );
  }

  Future<void> _scrollToAyah(int ayahNumber, {bool animate = true}) async {
    if (!_scrollController.hasClients) return;

    final normalizedAyah = ayahNumber.clamp(1, _ayahTotal);
    final maxExtent = _scrollController.position.maxScrollExtent;
    final ratio = _ayahTotal <= 1
        ? 0.0
        : (normalizedAyah - 1) / (_ayahTotal - 1);
    final estimatedOffset = (maxExtent * ratio).clamp(0.0, maxExtent);

    if (_currentTab == 0 && _mushafMode) {
      final targetKey = _ayahKeyFor(normalizedAyah);
      if (targetKey.currentContext != null) {
        await _ensureAyahVisible(targetKey, animate: animate);
        return;
      }
    }

    if (animate) {
      await _scrollController.animateTo(
        estimatedOffset,
        duration: AppMotion.page,
        curve: AppMotion.curve,
      );
    } else {
      _scrollController.jumpTo(estimatedOffset);
    }

    if (!mounted || !_scrollController.hasClients) return;
    if (_currentTab != 0 || !_mushafMode) return;

    await Future<void>.delayed(const Duration(milliseconds: 16));
    if (!mounted) return;

    final targetKey = _ayahKeyFor(normalizedAyah);
    if (targetKey.currentContext == null) return;

    await _ensureAyahVisible(targetKey, animate: animate);
  }

  bool get _hasNextSurah => _surahIndex < 114;

  bool _onScrollNotification(ScrollNotification notification) {
    if (_isTransitioningSurah) return false;
    if (!_hasNextSurah) {
      if (_bottomDragProgress > 0 && mounted) {
        setState(() => _bottomDragProgress = 0);
      }
      return false;
    }

    final metrics = notification.metrics;
    final isNearBottom = metrics.pixels >= metrics.maxScrollExtent - 6;
    final overscrollAmount = (metrics.pixels - metrics.maxScrollExtent).clamp(
      0.0,
      140.0,
    );

    if ((notification is OverscrollNotification &&
            notification.overscroll > 0) ||
        (notification is ScrollUpdateNotification && isNearBottom)) {
      final nextProgress =
          (overscrollAmount > 0
                  ? overscrollAmount
                  : (_bottomDragProgress +
                        (notification is OverscrollNotification
                            ? notification.overscroll
                            : 0)))
              .clamp(0.0, _nextSurahTrigger);
      if (nextProgress != _bottomDragProgress && mounted) {
        setState(() => _bottomDragProgress = nextProgress);
      }
      if (nextProgress >= _nextSurahTrigger) {
        _navigateToNextSurah();
      }
      return false;
    }

    if (notification is ScrollEndNotification) {
      if (_bottomDragProgress > 0 && mounted) {
        setState(() => _bottomDragProgress = 0);
      }
    }

    if (notification is ScrollUpdateNotification &&
        metrics.pixels < metrics.maxScrollExtent - 24 &&
        _bottomDragProgress > 0 &&
        mounted) {
      setState(() => _bottomDragProgress = 0);
    }

    return false;
  }

  Widget _buildNextSurahHint(BuildContext context) {
    if (!_hasNextSurah || _bottomDragProgress <= 0) {
      return const SizedBox.shrink();
    }

    final scheme = Theme.of(context).colorScheme;
    final progress = (_bottomDragProgress / _nextSurahTrigger).clamp(0.0, 1.0);
    final isReady = progress >= 1.0;
    final liquidHeight = 8.0 + (progress * 24.0);
    final bubbleTravel = 10.0 + (progress * 10.0);

    return Padding(
      padding: const EdgeInsets.fromLTRB(18, 0, 18, 104),
      child: IgnorePointer(
        child: AnimatedOpacity(
          duration: AppMotion.fast,
          curve: AppMotion.curve,
          opacity: 0.72 + (progress * 0.28),
          child: AnimatedSlide(
            duration: AppMotion.fast,
            curve: AppMotion.curve,
            offset: Offset(0, 0.18 * (1 - progress)),
            child: Align(
              alignment: Alignment.bottomCenter,
              child: ConstrainedBox(
                constraints: const BoxConstraints(maxWidth: 320),
                child: DecoratedBox(
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(999),
                    color: _nightMode
                        ? const Color(0xFF121B2B).withValues(alpha: 0.96)
                        : const Color(0xFFFFF6E3).withValues(alpha: 0.97),
                    border: Border.all(
                      color: scheme.primary.withValues(alpha: 0.15 + (progress * 0.18)),
                    ),
                    boxShadow: [
                      BoxShadow(
                        color: scheme.shadow.withValues(alpha: 0.08 + (progress * 0.05)),
                        blurRadius: 18,
                        offset: const Offset(0, 8),
                      ),
                    ],
                  ),
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 10),
                    child: Row(
                      children: [
                        Container(
                          width: 44,
                          height: 44,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            color: scheme.primary.withValues(alpha: 0.10),
                            border: Border.all(
                              color: scheme.primary.withValues(alpha: 0.16),
                            ),
                          ),
                          child: Stack(
                            alignment: Alignment.center,
                            children: [
                              SizedBox(
                                width: 44,
                                height: 44,
                                child: CircularProgressIndicator(
                                  value: progress,
                                  strokeWidth: 3.0,
                                  color: scheme.primary,
                                  backgroundColor: scheme.primary.withValues(alpha: 0.10),
                                ),
                              ),
                              Icon(
                                isReady
                                    ? Icons.auto_awesome_rounded
                                    : Icons.keyboard_arrow_up_rounded,
                                color: scheme.primary,
                                size: 22,
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(width: 10),
                        Expanded(
                          child: Column(
                            mainAxisSize: MainAxisSize.min,
                            crossAxisAlignment: CrossAxisAlignment.end,
                            children: [
                              Text(
                                isReady
                                    ? 'ئامادەیە بۆ سوڕەی داهاتوو'
                                    : 'بکێشە بۆ سوڕەی داهاتوو',
                                textDirection: TextDirection.rtl,
                                textAlign: TextAlign.right,
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                                style: TextStyle(
                                  fontFamily: fontType.toString(),
                                  color: scheme.onSurface,
                                  fontWeight: FontWeight.w800,
                                  fontSize: 13,
                                ),
                              ),
                              const SizedBox(height: 8),
                              ClipRRect(
                                borderRadius: BorderRadius.circular(999),
                                child: SizedBox(
                                  height: 22,
                                  child: Stack(
                                    children: [
                                      Positioned.fill(
                                        child: DecoratedBox(
                                          decoration: BoxDecoration(
                                            color: scheme.primary.withValues(alpha: 0.08),
                                            borderRadius: BorderRadius.circular(999),
                                          ),
                                        ),
                                      ),
                                      AnimatedPositioned(
                                        duration: AppMotion.fast,
                                        curve: Curves.easeOut,
                                        left: 0,
                                        right: 0,
                                        bottom: 0,
                                        height: liquidHeight,
                                        child: DecoratedBox(
                                          decoration: BoxDecoration(
                                            color: scheme.primary.withValues(alpha: 0.86),
                                            borderRadius: BorderRadius.circular(999),
                                          ),
                                        ),
                                      ),
                                      AnimatedPositioned(
                                        duration: AppMotion.page,
                                        curve: Curves.easeInOut,
                                        left: 22 + (progress * 70),
                                        bottom: 8 + bubbleTravel,
                                        child: Container(
                                          width: 9,
                                          height: 9,
                                          decoration: BoxDecoration(
                                            color: Colors.white.withValues(alpha: 0.45),
                                            shape: BoxShape.circle,
                                          ),
                                        ),
                                      ),
                                      AnimatedPositioned(
                                        duration: AppMotion.page,
                                        curve: Curves.easeInOut,
                                        right: 18 + (progress * 62),
                                        bottom: 4 + (bubbleTravel * 0.55),
                                        child: Container(
                                          width: 6,
                                          height: 6,
                                          decoration: BoxDecoration(
                                            color: Colors.white.withValues(alpha: 0.34),
                                            shape: BoxShape.circle,
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  Future<void> _navigateToNextSurah() async {
    if (_isTransitioningSurah || !_hasNextSurah || !mounted) return;
    _isTransitioningSurah = true;
    setState(() => _bottomDragProgress = 0);
    await Future<void>.delayed(const Duration(milliseconds: 220));
    if (!mounted) {
      _isTransitioningSurah = false;
      return;
    }

    final nextIndex = _surahIndex + 1;
    try {
      await context.read<QuranStateProvider>().setLastRead(
        surahIndex: nextIndex,
        ayahNumber: 1,
      );
    } catch (_) {}
    if (!mounted) {
      _isTransitioningSurah = false;
      return;
    }

    await Navigator.of(context).pushReplacement(
      PageRouteBuilder(
        transitionDuration: const Duration(milliseconds: 520),
        reverseTransitionDuration: const Duration(milliseconds: 420),
        pageBuilder: (context, animation, secondaryAnimation) =>
            QuranViewPage(indexx: nextIndex, startAyah: 1),
        transitionsBuilder: (context, animation, secondaryAnimation, child) {
          final curved = CurvedAnimation(
            parent: animation,
            curve: Curves.easeOutCubic,
          );
          return SlideTransition(
            position: Tween<Offset>(
              begin: const Offset(0, 0.14),
              end: Offset.zero,
            ).animate(curved),
            child: FadeTransition(
              opacity: animation,
              child: child,
            ),
          );
        },
      ),
    );

    _isTransitioningSurah = false;
  }

  QuranAyahData? _ayahByNumber(int number) {
    final surah = _cachedSurah;
    if (surah == null) return null;
    try {
      return surah.ayahs.firstWhere((e) => e.numberInSurah == number);
    } catch (_) {
      return null;
    }
  }

  String _resolveAudioUrl(QuranAyahData ayah) {
    return ServiceData().buildAyahAudioUrl(
      reciterId: _selectedReciterId,
      globalAyahNumber: ayah.globalNumber,
      surahNumber: _surahIndex,
      ayahNumber: ayah.numberInSurah,
    );
  }

  Future<void> _playAyah(int ayahNumber) async {
    final ayah = _ayahByNumber(ayahNumber);
    if (ayah == null) {
      _snack("ئایەت نەدۆزرایەوە.");
      return;
    }
    final url = _resolveAudioUrl(ayah);
    try {
      _playbackSequenceEnabled = true;
      await _audioPlayer.setSpeed(_playbackSpeed);
      await _audioPlayer.setUrl(url);
      await _audioPlayer.play();
      setState(() {
        _activeAyah = ayahNumber;
        _isPlaying = true;
      });
      await _syncLastRead(ayahNumber);
      if (_autoScrollPlayer) await _scrollToAyah(ayahNumber);
    } catch (_) {
      _snack("نەتوانرا دەنگی ئەم ئایەتە لێبدرێت.");
    }
  }

  Future<void> _togglePlayPause() async {
    if (_isPlaying) {
      _playbackSequenceEnabled = false;
      _repeatCounter = 0;
      await _audioPlayer.pause();
      return;
    }
    await _playAyah(_activeAyah);
  }

  Future<void> _nextAyah() async {
    if (_activeAyah < _ayahTotal) {
      await _playAyah(_activeAyah + 1);
      return;
    }
    if (_hasNextSurah) {
      await _navigateToNextSurah();
    }
  }

  Future<void> _previousAyah() async {
    final previous = (_activeAyah - 1).clamp(1, _ayahTotal);
    await _playAyah(previous);
  }

  Future<void> _onAyahCompleted() async {
    if (!_playbackSequenceEnabled) {
      _repeatCounter = 0;
      return;
    }
    if (_repeatInfinite) {
      await _playAyah(_activeAyah);
      return;
    }
    if (_repeatCounter < _repeatTimes - 1) {
      _repeatCounter += 1;
      await _playAyah(_activeAyah);
      return;
    }

    _repeatCounter = 0;
    int nextAyah = _activeAyah + 1;
    if (_repeatRangeStart != null && _repeatRangeEnd != null) {
      if (_activeAyah >= _repeatRangeEnd!) {
        nextAyah = _repeatRangeStart!;
      } else {
        nextAyah = _activeAyah + 1;
      }
    }

    if (nextAyah <= _ayahTotal) {
      await _playAyah(nextAyah);
    } else {
      _playbackSequenceEnabled = false;
      setState(() => _isPlaying = false);
    }
  }

  Future<void> _openFullPlayer() async {
    double localSpeed = _playbackSpeed;
    bool localAuto = _autoScrollPlayer;
    String localRepeat = _repeatLabel;
    String localReciter = _selectedReciterName;

    await showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) => FractionallySizedBox(
        heightFactor: 0.72,
        child: StatefulBuilder(
          builder: (context, modalSetState) {
            return QuranPlayerFullSheet(
              surahName: widget.detail ?? _cachedSurah?.arabicName ?? "",
              currentAyah: _activeAyah,
              isPlaying: _isPlaying,
              selectedReciter: localReciter,
              speed: localSpeed,
              autoScroll: localAuto,
              repeatLabel: localRepeat,
              onPlayPause: () {
                _togglePlayPause().whenComplete(() {
                  if (mounted) modalSetState(() {});
                });
              },
              onNext: () {
                _nextAyah().whenComplete(() {
                  if (mounted) modalSetState(() {});
                });
              },
              onPrevious: () {
                _previousAyah().whenComplete(() {
                  if (mounted) modalSetState(() {});
                });
              },
              onSelectReciter: () async {
                final result = await ReciterPickerSheet.show(
                  context,
                  reciters: _reciters.map((e) => e.displayName).toList(),
                  selectedReciter: localReciter,
                );
                if (result == null) return;
                final selected = _reciters.firstWhere(
                  (e) => e.displayName == result,
                  orElse: () => _reciters.first,
                );
                modalSetState(() => localReciter = selected.displayName);
                setState(() {
                  _selectedReciterName = selected.displayName;
                  _selectedReciterId = selected.id;
                });
                if (_isPlaying) {
                  await _playAyah(_activeAyah);
                  if (mounted) modalSetState(() {});
                }
              },
              onRepeatTap: () async {
                final result = await _showRepeatOptions(context);
                if (result != null) {
                  modalSetState(() => localRepeat = result);
                  setState(() => _repeatLabel = result);
                  _applyRepeatOption(result);
                }
              },
              onAutoScrollChanged: (value) {
                modalSetState(() => localAuto = value);
                setState(() => _autoScrollPlayer = value);
              },
              onSpeedChanged: (value) async {
                modalSetState(() => localSpeed = value);
                setState(() => _playbackSpeed = value);
                await _audioPlayer.setSpeed(value);
              },
              onDownloadTap: _openOfflinePackSheet,
            );
          },
        ),
      ),
    );
  }

  Future<String?> _showRepeatOptions(BuildContext context) async {
    final options = <String>["1x", "3x", "10x", "بێکۆتا", "ئایەت 5-20"];
    final scheme = Theme.of(context).colorScheme;
    return showModalBottomSheet<String>(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (_) => SafeArea(
        top: false,
        child: Container(
          margin: const EdgeInsets.fromLTRB(10, 0, 10, 10),
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            color: scheme.surface.withValues(alpha: 0.98),
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: scheme.outline.withValues(alpha: 0.2)),
          ),
          child: Wrap(
            spacing: 8,
            runSpacing: 8,
            children: options.map((e) {
              return ActionChip(
                label: Text(e),
                onPressed: () => Navigator.of(context).pop(e),
              );
            }).toList(),
          ),
        ),
      ),
    );
  }

  Future<void> _openOfflinePackSheet() async {
    final surah = _cachedSurah;
    if (surah == null || surah.ayahs.isEmpty) {
      _snack("سەرەتا سورتەکە بکەرەوە.");
      return;
    }

    final service = ServiceData();
    final initialStatus = await service.getOfflinePackStatus(
      reciterId: _selectedReciterId,
      surahIndex: _surahIndex,
      ayahNumbers: surah.ayahs.map((e) => e.numberInSurah).toList(),
    );

    if (!mounted) return;

    await showModalBottomSheet<void>(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (sheetContext) {
        bool downloading = false;
        bool deleting = false;
        bool forceRedownload = false;
        bool cancelRequested = false;
        OfflineAudioPackStatus status = initialStatus;

        return StatefulBuilder(
          builder: (context, modalSetState) {
            final scheme = Theme.of(context).colorScheme;
            final progress = status.progress.clamp(0.0, 1.0);

            Future<void> refreshStatus() async {
              final latest = await service.getOfflinePackStatus(
                reciterId: _selectedReciterId,
                surahIndex: _surahIndex,
                ayahNumbers: surah.ayahs.map((e) => e.numberInSurah).toList(),
              );
              if (!sheetContext.mounted) return;
              modalSetState(() => status = latest);
            }

            Future<void> startDownload() async {
              if (downloading || deleting) return;
              modalSetState(() {
                downloading = true;
                cancelRequested = false;
              });
              try {
                final result = await service.downloadOfflineSurahPack(
                  reciterId: _selectedReciterId,
                  surahIndex: _surahIndex,
                  ayahs: surah.ayahs,
                  forceRedownload: forceRedownload,
                  isCancelled: () => cancelRequested,
                  onProgress: (next) {
                    if (!sheetContext.mounted) return;
                    modalSetState(() => status = next);
                  },
                );
                if (sheetContext.mounted) {
                  modalSetState(() => status = result);
                }
                if (mounted) {
                  if (result.downloadedCount == result.totalCount &&
                      result.failedCount == 0) {
                    _snack("پەکی دەنگ بە سەرکەوتوویی تەواو بوو.");
                  } else if (cancelRequested) {
                    _snack("دابەزاندن وەستێنرا.");
                  } else {
                    _snack(
                      "تەواوبوو: ${result.downloadedCount}/${result.totalCount}",
                    );
                  }
                }
              } finally {
                if (sheetContext.mounted) {
                  modalSetState(() => downloading = false);
                }
              }
            }

            Future<void> deletePack() async {
              if (downloading || deleting) return;
              modalSetState(() => deleting = true);
              try {
                await service.deleteOfflineSurahPack(
                  reciterId: _selectedReciterId,
                  surahIndex: _surahIndex,
                );
                await refreshStatus();
                if (mounted) {
                  _snack("پەکی دابەزێنراو سڕایەوە.");
                }
              } finally {
                if (sheetContext.mounted) {
                  modalSetState(() => deleting = false);
                }
              }
            }

            return SafeArea(
              top: false,
              child: Container(
                margin: const EdgeInsets.fromLTRB(10, 0, 10, 10),
                padding: const EdgeInsets.fromLTRB(14, 12, 14, 16),
                decoration: BoxDecoration(
                  color: scheme.surface.withValues(alpha: 0.98),
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(
                    color: scheme.outline.withValues(alpha: 0.2),
                  ),
                ),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    Center(
                      child: Container(
                        width: 54,
                        height: 4,
                        margin: const EdgeInsets.only(bottom: 12),
                        decoration: BoxDecoration(
                          color: scheme.outline.withValues(alpha: 0.4),
                          borderRadius: BorderRadius.circular(99),
                        ),
                      ),
                    ),
                    Text(
                      "دابەزاندنی پەکی دەنگی سورەت",
                      textDirection: TextDirection.rtl,
                      style: TextStyle(
                        color: scheme.onSurface,
                        fontWeight: FontWeight.w800,
                        fontSize: 16,
                      ),
                    ),
                    const SizedBox(height: 8),
                    Text(
                      _selectedReciterName,
                      textDirection: TextDirection.rtl,
                      style: TextStyle(
                        color: scheme.primary,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                    const SizedBox(height: 10),
                    ClipRRect(
                      borderRadius: BorderRadius.circular(999),
                      child: LinearProgressIndicator(
                        minHeight: 8,
                        value: progress == 0 ? 0 : progress,
                        backgroundColor: scheme.surfaceContainerHighest,
                      ),
                    ),
                    const SizedBox(height: 8),
                    Row(
                      children: [
                        Text(
                          "${(progress * 100).toStringAsFixed(0)}%",
                          style: TextStyle(
                            color: scheme.primary,
                            fontWeight: FontWeight.w700,
                            fontFamily: "english",
                          ),
                        ),
                        const Spacer(),
                        Text(
                          "${status.downloadedCount}/${status.totalCount}",
                          style: TextStyle(
                            color: scheme.onSurfaceVariant,
                            fontWeight: FontWeight.w600,
                            fontFamily: "english",
                          ),
                        ),
                      ],
                    ),
                    if (status.failedCount > 0) ...[
                      const SizedBox(height: 4),
                      Text(
                        "هەڵەی دابەزاندن: ${status.failedCount}",
                        textDirection: TextDirection.rtl,
                        style: TextStyle(
                          color: scheme.error,
                          fontWeight: FontWeight.w600,
                          fontFamily: "english",
                        ),
                      ),
                    ],
                    const SizedBox(height: 10),
                    Row(
                      children: [
                        Checkbox(
                          value: forceRedownload,
                          onChanged: downloading || deleting
                              ? null
                              : (v) => modalSetState(
                                  () => forceRedownload = v ?? false,
                                ),
                        ),
                        Expanded(
                          child: Text(
                            "هەموو فایلەکان نوێ دابەزێنەوە",
                            textDirection: TextDirection.rtl,
                            textAlign: TextAlign.right,
                            style: TextStyle(color: scheme.onSurfaceVariant),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 8),
                    Wrap(
                      spacing: 8,
                      runSpacing: 8,
                      alignment: WrapAlignment.end,
                      children: [
                        ElevatedButton.icon(
                          onPressed: downloading || deleting
                              ? null
                              : startDownload,
                          icon: Icon(
                            downloading
                                ? Icons.downloading_rounded
                                : Icons.download_rounded,
                          ),
                          label: Text(
                            downloading
                                ? "دابەزاندن..."
                                : "دەستپێکردنی دابەزاندن",
                          ),
                        ),
                        OutlinedButton.icon(
                          onPressed: downloading || deleting
                              ? null
                              : refreshStatus,
                          icon: const Icon(Icons.refresh_rounded),
                          label: const Text("نوێکردنەوە"),
                        ),
                        OutlinedButton.icon(
                          onPressed: downloading || deleting
                              ? null
                              : deletePack,
                          icon: deleting
                              ? const SizedBox(
                                  width: 14,
                                  height: 14,
                                  child: CircularProgressIndicator(
                                    strokeWidth: 2,
                                  ),
                                )
                              : const Icon(Icons.delete_outline_rounded),
                          label: const Text("سڕینەوە"),
                        ),
                        TextButton.icon(
                          onPressed: downloading
                              ? () =>
                                    modalSetState(() => cancelRequested = true)
                              : null,
                          icon: const Icon(Icons.close_rounded),
                          label: const Text("وەستاندن"),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            );
          },
        );
      },
    );
  }

  void _applyRepeatOption(String option) {
    _repeatRangeStart = null;
    _repeatRangeEnd = null;
    _repeatCounter = 0;
    _repeatInfinite = false;

    switch (option) {
      case '3x':
        _repeatTimes = 3;
        break;
      case '10x':
        _repeatTimes = 10;
        break;
      case 'بێکۆتا':
        _repeatTimes = 1;
        _repeatInfinite = true;
        break;
      case 'ئایەت 5-20':
        _repeatTimes = 1;
        _repeatRangeStart = 5;
        _repeatRangeEnd = _ayahTotal >= 20 ? 20 : _ayahTotal;
        _activeAyah = _repeatRangeStart!;
        _syncLastRead(_activeAyah);
        break;
      default:
        _repeatTimes = 1;
    }
  }

  Future<void> _onAyahTap(QuranAyahData ayah) async {
    if (_activeAyah != ayah.numberInSurah) {
      setState(() => _activeAyah = ayah.numberInSurah);
    }
    await _syncLastRead(ayah.numberInSurah);
    if (!mounted) return;

    final action = await AyahActionSheet.show(
      context,
      ayahNumber: ayah.numberInSurah,
      translationVisible: _showTranslation,
      isBookmarked: _bookmarkedAyahs.contains(ayah.numberInSurah),
    );
    if (!mounted || action == null) return;

    switch (action) {
      case AyahActionType.play:
        await _playAyah(ayah.numberInSurah);
        break;
      case AyahActionType.repeat:
        _repeatLabel = "3x";
        _applyRepeatOption(_repeatLabel);
        _snack("دۆخی دووبارەکردنەوە بۆ 3x دانرا.");
        break;
      case AyahActionType.bookmark:
        final added = await context
            .read<QuranStateProvider>()
            .toggleAyahBookmark(_surahIndex, ayah.numberInSurah);
        setState(() {
          if (added) {
            _bookmarkedAyahs.add(ayah.numberInSurah);
          } else {
            _bookmarkedAyahs.remove(ayah.numberInSurah);
          }
        });
        _snack(added ? "نیشانە زیادکرا." : "نیشانە سڕایەوە.");
        break;
      case AyahActionType.copyArabic:
        _copyText(ayah.arabicText);
        break;
      case AyahActionType.copyKurdish:
        _copyText(ayah.kurdishTranslation ?? "وەرگێڕان بەردەست نییە.");
        break;
      case AyahActionType.share:
        final text =
            "${ayah.arabicText}\n\n"
            "${ayah.kurdishTranslation ?? "وەرگێڕان بەردەست نییە."}\n\n"
            "https://play.google.com/store/apps/details?id=com.amin.runakeislam";
        SharePlus.instance.share(ShareParams(text: text));
        break;
      case AyahActionType.tafsir:
        _tabController.animateTo(2);
        break;
      case AyahActionType.toggleTranslation:
        setState(() => _showTranslation = !_showTranslation);
        if (_showTranslation) _tabController.animateTo(1);
        break;
    }
  }

  Future<void> _copyText(String text) async {
    await FlutterClipboard.copy(text);
    _snack("کۆپی کرا.");
  }

  void _snack(String text) {
    final scheme = Theme.of(context).colorScheme;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          text,
          textDirection: TextDirection.rtl,
          style: TextStyle(fontFamily: fontType.toString()),
        ),
        backgroundColor: scheme.primary,
        duration: const Duration(milliseconds: 1100),
      ),
    );
  }

  Future<void> _openQuranSettingsSheet() async {
    final settingsProvider = Provider.of<SettingsProvider>(
      context,
      listen: false,
    );
    double localFontSize = quranFontSize ?? 24;
    int localFontFamily = normalizeQuranFontFamily(quranFontType);
    bool localShowTranslation = _showTranslation;
    bool localNight = _nightMode;
    bool localMushaf = _mushafMode;
    bool localTajweedEnabled = _tajweedEnabled;
    bool localHighContrast = _highContrastTajweed;
    double localTajweedOpacity = _tajweedOpacity;
    double localLineHeight = _lineHeight;
    Color localHighlight = _highlightColor;
    final colors = <Color>[
      const Color(0xFFBFA05A),
      const Color(0xFF69A197),
      const Color(0xFFB784C2),
      const Color(0xFF5F8FC4),
      const Color(0xFFE4A86A),
    ];

    await showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) => StatefulBuilder(
        builder: (context, modalSetState) {
          final scheme = Theme.of(context).colorScheme;
          final mediaQuery = MediaQuery.of(context);
          return SafeArea(
            top: false,
            child: AnimatedPadding(
              duration: AppMotion.fast,
              curve: AppMotion.curve,
              padding: EdgeInsets.only(bottom: mediaQuery.viewInsets.bottom),
              child: Directionality(
                textDirection: TextDirection.rtl,
                child: Container(
                  margin: const EdgeInsets.fromLTRB(10, 0, 10, 10),
                  constraints: BoxConstraints(
                    maxHeight: mediaQuery.size.height * 0.88,
                  ),
                  padding: const EdgeInsets.fromLTRB(14, 12, 14, 18),
                  decoration: BoxDecoration(
                    color: scheme.surface.withValues(alpha: 0.98),
                    borderRadius: BorderRadius.circular(20),
                    border: Border.all(
                      color: scheme.outline.withValues(alpha: 0.2),
                    ),
                  ),
                  child: SingleChildScrollView(
                    physics: const BouncingScrollPhysics(),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        Align(
                          alignment: Alignment.center,
                          child: Container(
                            width: 54,
                            height: 4,
                            margin: const EdgeInsets.only(bottom: 12),
                            decoration: BoxDecoration(
                              color: scheme.outline.withValues(alpha: 0.4),
                              borderRadius: BorderRadius.circular(99),
                            ),
                          ),
                        ),
                        Text(
                          "ڕێکخستنەکانی خوێندنەوەی قورئان",
                          textAlign: TextAlign.right,
                          style: TextStyle(
                            color: scheme.onSurface,
                            fontSize: 18,
                            fontWeight: FontWeight.w800,
                          ),
                        ),
                        const SizedBox(height: 4),
                        Text(
                          "هەڵبژاردەکان بە شێوەی بەشکراو پیشان دراون تاکو زوو بتوانیت شێوازی خوێندنەوەکەت بگۆڕیت.",
                          textAlign: TextAlign.right,
                          style: TextStyle(
                            color: scheme.onSurfaceVariant,
                            fontSize: 12.8,
                            height: 1.45,
                          ),
                        ),
                        const SizedBox(height: 12),
                        _settingsSectionCard(
                          context: context,
                          title: "نووسین و فۆنت",
                          subtitle:
                              "قەبارە و جۆری فۆنت دیاری بکە بۆ خوێندنەوەی ڕوونتر.",
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.stretch,
                            children: [
                              Text(
                                "قەبارەی فۆنتی عەرەبی",
                                textAlign: TextAlign.right,
                                style: TextStyle(color: scheme.onSurface),
                              ),
                              Slider(
                                value: localFontSize,
                                min: 16,
                                max: 46,
                                divisions: 30,
                                label: localFontSize.toStringAsFixed(0),
                                onChanged: (v) {
                                  modalSetState(() => localFontSize = v);
                                  setState(() => quranFontSize = v);
                                },
                                onChangeEnd: (v) {
                                  settingsProvider.updateSettings(
                                    'quran_font_size',
                                    v,
                                  );
                                },
                              ),
                              Text(
                                "خێزانی فۆنتی عەرەبی",
                                textAlign: TextAlign.right,
                                style: TextStyle(color: scheme.onSurface),
                              ),
                              const SizedBox(height: 8),
                              Wrap(
                                alignment: WrapAlignment.end,
                                spacing: 10,
                                runSpacing: 10,
                                children: kQuranFontOptions.map((option) {
                                  final selected =
                                      localFontFamily == option.familyId;
                                  return ChoiceChip(
                                    selected: selected,
                                    label: Column(
                                      mainAxisSize: MainAxisSize.min,
                                      crossAxisAlignment:
                                          CrossAxisAlignment.end,
                                      children: [
                                        Text(
                                          option.label,
                                          textAlign: TextAlign.right,
                                          style: TextStyle(
                                            fontFamily: fontType?.toString(),
                                          ),
                                        ),
                                        const SizedBox(height: 4),
                                        Text(
                                          option.preview,
                                          textAlign: TextAlign.right,
                                          style: TextStyle(
                                            fontFamily: option.family,
                                          ),
                                        ),
                                      ],
                                    ),
                                    onSelected: (_) async {
                                      modalSetState(
                                        () => localFontFamily = option.familyId,
                                      );
                                      setState(
                                        () => quranFontType = option.familyId,
                                      );
                                      await settingsProvider.updateSettings(
                                        'quran_font_family',
                                        option.familyId,
                                      );
                                    },
                                  );
                                }).toList(),
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(height: 12),
                        _settingsSectionCard(
                          context: context,
                          title: "شێوازی خوێندنەوە",
                          subtitle:
                              "دۆخی خوێندنەوە و زانیارییە سەرەکییەکان لێرە کۆکراونەتەوە.",
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.stretch,
                            children: [
                              _switchRow(
                                title: "پیشاندانی وەرگێڕان",
                                subtitle:
                                    "وەرگێڕانی کوردی لە خوارەوەی ئایەتەکان پیشان بدە.",
                                icon: Icons.translate_rounded,
                                value: localShowTranslation,
                                onChanged: (v) {
                                  modalSetState(() => localShowTranslation = v);
                                  setState(() => _showTranslation = v);
                                },
                              ),
                              const SizedBox(height: 8),
                              _switchRow(
                                title: "دۆخی شەو",
                                subtitle:
                                    "ڕووکاری تۆختر بۆ خوێندنەوەی ئارامتر لە شوێنە تاریکەکان.",
                                icon: Icons.dark_mode_rounded,
                                value: localNight,
                                onChanged: (v) {
                                  modalSetState(() => localNight = v);
                                  setState(() => _nightMode = v);
                                },
                              ),
                              const SizedBox(height: 12),
                              Text(
                                "شێوازی خوێندنەوە",
                                textAlign: TextAlign.right,
                                style: TextStyle(color: scheme.onSurface),
                              ),
                              const SizedBox(height: 8),
                              Wrap(
                                alignment: WrapAlignment.end,
                                spacing: 8,
                                runSpacing: 8,
                                children: [
                                  ChoiceChip(
                                    selected: localMushaf,
                                    label: const Text("ئایەت بە ئایەت"),
                                    onSelected: (_) {
                                      modalSetState(() => localMushaf = true);
                                      setState(() => _mushafMode = true);
                                    },
                                  ),
                                  ChoiceChip(
                                    selected: !localMushaf,
                                    label: const Text("پەڕەی یەکگرتوو"),
                                    onSelected: (_) {
                                      modalSetState(() => localMushaf = false);
                                      setState(() => _mushafMode = false);
                                    },
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(height: 12),
                        _settingsSectionCard(
                          context: context,
                          title: "تەجوید و نیشانکردن",
                          subtitle:
                              "ڕەنگکردن و نیشانەکان بە شێوەیەکی سادەتر لێرە ڕێکدەخرێن.",
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.stretch,
                            children: [
                              _switchRow(
                                title: "ڕەنگکردنی تەجوید",
                                subtitle:
                                    "وشەکان بە ڕەنگی تەجویدی پیشان بدە بۆ خوێندنەوەی وردتر.",
                                icon: Icons.palette_rounded,
                                value: localTajweedEnabled,
                                onChanged: (v) {
                                  modalSetState(() => localTajweedEnabled = v);
                                  setState(() => _tajweedEnabled = v);
                                },
                              ),
                              const SizedBox(height: 8),
                              AnimatedOpacity(
                                duration: AppMotion.fast,
                                curve: AppMotion.curve,
                                opacity: localTajweedEnabled ? 1.0 : 0.45,
                                child: IgnorePointer(
                                  ignoring: !localTajweedEnabled,
                                  child: Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.stretch,
                                    children: [
                                      _switchRow(
                                        title: "کۆنتراستی بەرز بۆ تەجوید",
                                        subtitle:
                                            "ڕەنگی تەجوید توندتر بکە بۆ بینینی باشتر.",
                                        icon: Icons.contrast_rounded,
                                        value: localHighContrast,
                                        onChanged: (v) {
                                          modalSetState(
                                            () => localHighContrast = v,
                                          );
                                          setState(
                                            () => _highContrastTajweed = v,
                                          );
                                        },
                                      ),
                                      const SizedBox(height: 12),
                                      Text(
                                        "ڕووناکی/توندی ڕەنگی تەجوید",
                                        textAlign: TextAlign.right,
                                        style: TextStyle(
                                          color: scheme.onSurface,
                                        ),
                                      ),
                                      Slider(
                                        value: localTajweedOpacity,
                                        min: 0.35,
                                        max: 1.0,
                                        divisions: 13,
                                        label:
                                            "${(localTajweedOpacity * 100).toStringAsFixed(0)}%",
                                        onChanged: (v) {
                                          modalSetState(
                                            () => localTajweedOpacity = v,
                                          );
                                          setState(() => _tajweedOpacity = v);
                                        },
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                              const SizedBox(height: 8),
                              Text(
                                "بەرزی هێڵ",
                                textAlign: TextAlign.right,
                                style: TextStyle(color: scheme.onSurface),
                              ),
                              Slider(
                                value: localLineHeight,
                                min: 1.2,
                                max: 2.4,
                                divisions: 12,
                                onChanged: (v) {
                                  modalSetState(() => localLineHeight = v);
                                  setState(() => _lineHeight = v);
                                },
                              ),
                              const SizedBox(height: 4),
                              Text(
                                "ڕەنگی دیاریکردن",
                                textAlign: TextAlign.right,
                                style: TextStyle(color: scheme.onSurface),
                              ),
                              const SizedBox(height: 8),
                              Wrap(
                                alignment: WrapAlignment.end,
                                spacing: 10,
                                runSpacing: 10,
                                children: colors.map((c) {
                                  final selected = localHighlight == c;
                                  return GestureDetector(
                                    onTap: () {
                                      modalSetState(() => localHighlight = c);
                                      setState(() => _highlightColor = c);
                                    },
                                    child: AnimatedContainer(
                                      duration: AppMotion.fast,
                                      curve: AppMotion.curve,
                                      width: selected ? 38 : 34,
                                      height: selected ? 38 : 34,
                                      decoration: BoxDecoration(
                                        color: c,
                                        shape: BoxShape.circle,
                                        border: Border.all(
                                          color: selected
                                              ? scheme.surface
                                              : c.withValues(alpha: 0.5),
                                          width: selected ? 3 : 2,
                                        ),
                                      ),
                                      child: selected
                                          ? Icon(
                                              Icons.check_rounded,
                                              color: scheme.surface,
                                              size: 18,
                                            )
                                          : null,
                                    ),
                                  );
                                }).toList(),
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(height: 14),
                        FilledButton.icon(
                          onPressed: () => Navigator.of(context).pop(),
                          icon: const Icon(Icons.check_rounded),
                          label: const Text("تەواو"),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          );
        },
      ),
    );
  }

  Widget _switchRow({
    required String title,
    String? subtitle,
    IconData? icon,
    required bool value,
    required ValueChanged<bool> onChanged,
  }) {
    final scheme = Theme.of(context).colorScheme;
    return AnimatedContainer(
      duration: AppMotion.fast,
      curve: AppMotion.curve,
      padding: const EdgeInsets.fromLTRB(12, 10, 12, 10),
      decoration: BoxDecoration(
        color: value
            ? scheme.primaryContainer.withValues(alpha: 0.5)
            : scheme.surfaceContainerHighest.withValues(alpha: 0.24),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: value
              ? scheme.primary.withValues(alpha: 0.22)
              : scheme.outline.withValues(alpha: 0.14),
        ),
      ),
      child: Row(
        children: [
          if (icon != null) ...[
            Container(
              width: 38,
              height: 38,
              decoration: BoxDecoration(
                color: scheme.surface.withValues(alpha: 0.78),
                borderRadius: BorderRadius.circular(12),
              ),
              child: Icon(icon, color: scheme.primary, size: 19),
            ),
            const SizedBox(width: 12),
          ],
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                Text(
                  title,
                  textAlign: TextAlign.right,
                  style: TextStyle(
                    color: scheme.onSurface,
                    fontSize: 14,
                    fontWeight: FontWeight.w700,
                  ),
                ),
                if (subtitle != null) ...[
                  const SizedBox(height: 3),
                  Text(
                    subtitle,
                    textAlign: TextAlign.right,
                    style: TextStyle(
                      color: scheme.onSurfaceVariant,
                      fontSize: 12.4,
                      height: 1.4,
                    ),
                  ),
                ],
              ],
            ),
          ),
          const SizedBox(width: 12),
          Switch(value: value, onChanged: onChanged),
        ],
      ),
    );
  }

  Widget _settingsSectionCard({
    required BuildContext context,
    required String title,
    String? subtitle,
    required Widget child,
  }) {
    final scheme = Theme.of(context).colorScheme;
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: scheme.surfaceContainerHighest.withValues(alpha: 0.2),
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: scheme.outline.withValues(alpha: 0.16)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Text(
            title,
            textAlign: TextAlign.right,
            style: TextStyle(
              color: scheme.onSurface,
              fontSize: 15,
              fontWeight: FontWeight.w800,
            ),
          ),
          if (subtitle != null) ...[
            const SizedBox(height: 4),
            Text(
              subtitle,
              textAlign: TextAlign.right,
              style: TextStyle(
                color: scheme.onSurfaceVariant,
                fontSize: 12.6,
                height: 1.45,
              ),
            ),
          ],
          const SizedBox(height: 14),
          child,
        ],
      ),
    );
  }

  String _revelationLabel(String type) {
    final normalized = type.toLowerCase();
    if (normalized.contains('meccan') || normalized.contains('makki')) {
      return "مەککی";
    }
    if (normalized.contains('medinan') || normalized.contains('madani')) {
      return "مەدەنی";
    }
    return "نەزانراو";
  }
}

class _TajweedMarkupSegment {
  const _TajweedMarkupSegment({required this.text, this.ruleCode});

  final String text;
  final String? ruleCode;
}

class _IslamicBackdropPainter extends CustomPainter {
  const _IslamicBackdropPainter({required this.color});

  final Color color;

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = color
      ..style = PaintingStyle.stroke
      ..strokeWidth = 0.9;

    const step = 84.0;
    for (double y = -step; y < size.height + step; y += step) {
      for (double x = -step; x < size.width + step; x += step) {
        final rect = Rect.fromCenter(
          center: Offset(x, y),
          width: 30,
          height: 30,
        );
        canvas.drawRRect(
          RRect.fromRectAndRadius(rect, const Radius.circular(8)),
          paint,
        );
        canvas.drawCircle(Offset(x, y), 6.5, paint);
      }
    }
  }

  @override
  bool shouldRepaint(covariant _IslamicBackdropPainter oldDelegate) {
    return oldDelegate.color != color;
  }
}

class _PaperTexturePainter extends CustomPainter {
  const _PaperTexturePainter({required this.color});

  final Color color;

  @override
  void paint(Canvas canvas, Size size) {
    final linePaint = Paint()
      ..color = color
      ..style = PaintingStyle.stroke
      ..strokeWidth = 0.8;
    const rowGap = 20.0;
    for (double y = rowGap; y < size.height; y += rowGap) {
      final sway = math.sin(y / 34.0) * 1.6;
      canvas.drawLine(
        Offset(0, y + sway),
        Offset(size.width, y - sway),
        linePaint,
      );
    }

    final dotPaint = Paint()
      ..color = color.withValues(alpha: 0.22)
      ..style = PaintingStyle.fill;
    const dotGap = 28.0;
    for (double y = 12; y < size.height; y += dotGap) {
      for (double x = 10; x < size.width; x += dotGap) {
        final radius = 0.35 + (((x + y) ~/ dotGap) % 3) * 0.15;
        canvas.drawCircle(Offset(x, y), radius, dotPaint);
      }
    }
  }

  @override
  bool shouldRepaint(covariant _PaperTexturePainter oldDelegate) {
    return oldDelegate.color != color;
  }
}
