import 'dart:convert';
import 'dart:io';

import 'package:dio/dio.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart';
import 'package:path_provider/path_provider.dart';
import 'package:quran_library/quran_library.dart';
import 'package:runaki_islam/Screens/HomeItems/Qurani%20Piroz/data/models/allsurah.dart';
import 'package:runaki_islam/Screens/HomeItems/Qurani%20Piroz/data/models/quran_meta.dart';
import 'package:runaki_islam/Screens/HomeItems/Qurani%20Piroz/data/models/quran_rich_surah.dart';
import 'package:runaki_islam/Screens/HomeItems/Qurani%20Piroz/data/models/surahinfo.dart';

class QuranReciter {
  const QuranReciter({
    required this.id,
    required this.englishName,
    required this.nativeName,
    required this.languageCode,
    required this.audioBaseUrl,
    required this.readerPath,
    required this.usesGlobalAyahNumber,
  });

  final String id;
  final String englishName;
  final String nativeName;
  final String languageCode;
  final String audioBaseUrl;
  final String readerPath;
  final bool usesGlobalAyahNumber;

  String get displayName {
    if (nativeName.trim().isNotEmpty) return nativeName.trim();
    if (englishName.trim().isNotEmpty) return englishName.trim();
    return id;
  }
}

class OfflineAudioPackStatus {
  const OfflineAudioPackStatus({
    required this.totalCount,
    required this.downloadedCount,
    this.failedCount = 0,
  });

  final int totalCount;
  final int downloadedCount;
  final int failedCount;

  double get progress {
    if (totalCount < 1) return 0;
    return downloadedCount / totalCount;
  }
}

class QuranAyahSearchResult {
  const QuranAyahSearchResult({
    required this.surahNumber,
    required this.surahName,
    required this.ayahNumber,
    required this.arabicText,
  });

  final int surahNumber;
  final String surahName;
  final int ayahNumber;
  final String arabicText;
}

class ServiceData {
  final Dio _dio = Dio();
  final QuranRepository _quranRepository = QuranRepository();
  final QuranLibrary _quranLibrary = QuranLibrary();
  static const String _bundledKurdishTranslationAsset =
      'assets/quran/ku.json.gz';

  static const QuranReciter _hardcodedFallbackReciter = QuranReciter(
    id: 'qlib_fallback_alafasy',
    englishName: 'Alafasy',
    nativeName: 'Alafasy',
    languageCode: 'ar',
    audioBaseUrl: 'https://cdn.islamic.network/quran/audio/',
    readerPath: '128/ar.alafasy',
    usesGlobalAyahNumber: true,
  );

  static QuranMetaData? _metaCache;
  static List<QuranReciter>? _reciterCache;
  static List<SurahNamesModel>? _surahNamesCache;
  static Map<int, SurahModel>? _surahMapCache;
  static Future<void>? _quranLibraryInitFuture;
  static Future<void>? _kurdishTranslationInitFuture;
  static Map<int, Map<int, String>>? _kurdishTranslationCache;
  static Future<void>? _arabicTafsirInitFuture;
  static Map<int, Map<int, String>>? _arabicTafsirCache;
  static Future<QpcV4AssetsStore>? _qpcV4StoreFuture;
  static final Map<int, Map<int, String>> _qpcGlyphBySurahCache =
      <int, Map<int, String>>{};

  static final List<QuranReciter> defaultReciters = _buildDefaultReciters();

  static List<QuranReciter> _buildDefaultReciters() {
    final readers = ReadersConstants.activeAyahReaders;
    if (readers.isEmpty) {
      return <QuranReciter>[_hardcodedFallbackReciter];
    }

    return readers
        .map((reader) {
          return QuranReciter(
            id: _reciterIdForReader(reader),
            englishName: reader.name,
            nativeName: reader.name,
            languageCode: 'ar',
            audioBaseUrl: reader.url,
            readerPath: reader.readerNamePath,
            usesGlobalAyahNumber: reader.url == ReadersConstants.ayahs1stSource,
          );
        })
        .toList(growable: false);
  }

  static String _reciterIdForReader(ReaderInfo reader) {
    final normalized = reader.readerNamePath
        .toLowerCase()
        .replaceAll(RegExp(r'[^a-z0-9]+'), '_')
        .replaceAll(RegExp(r'^_+'), '')
        .replaceAll(RegExp(r'_+$'), '');
    final suffix = normalized.isEmpty ? 'reader' : normalized;
    return 'qlib_${reader.index}_$suffix';
  }

  Future<List<SurahNamesModel>> _loadLibrarySurahNames() async {
    final cached = _surahNamesCache;
    if (cached != null && cached.isNotEmpty) return cached;

    final response = await _quranRepository.getSurahs();
    final parsed = SurahResponseModel.fromJson(response);
    final sorted = List<SurahNamesModel>.from(parsed.surahs)
      ..sort((a, b) => a.number.compareTo(b.number));
    _surahNamesCache = sorted;
    return sorted;
  }

  Future<Map<int, SurahModel>> _loadLibrarySurahMap() async {
    final cached = _surahMapCache;
    if (cached != null && cached.isNotEmpty) return cached;

    final response = await _quranRepository.getQuranDataV3();
    final map = <int, SurahModel>{};
    for (final item in response) {
      if (item is! Map) continue;
      final surah = SurahModel.fromDownloadedFontsJson(
        Map<String, dynamic>.from(item),
      );
      map[surah.surahNumber] = surah;
    }
    _surahMapCache = map;
    return map;
  }

  Future<SurahModel?> _loadLibrarySurah(int number) async {
    final all = await _loadLibrarySurahMap();
    return all[number];
  }

  Future<void> _ensureQuranLibraryInitialized() async {
    _quranLibraryInitFuture ??= QuranLibrary.init();
    try {
      await _quranLibraryInitFuture;
    } catch (_) {
      _quranLibraryInitFuture = null;
      rethrow;
    }
  }

  Future<void> _ensureKurdishTranslationCache() async {
    if (_kurdishTranslationCache != null) return;
    _kurdishTranslationInitFuture ??= () async {
      final bundled = await _loadBundledKurdishTranslation();
      if (bundled.isNotEmpty) {
        _kurdishTranslationCache = bundled;
        return;
      }

      _kurdishTranslationCache = await _loadKurdishTranslationFromLibrary();
    }();

    try {
      await _kurdishTranslationInitFuture;
    } catch (_) {
      _kurdishTranslationInitFuture = null;
      _kurdishTranslationCache = <int, Map<int, String>>{};
    }
  }

  Future<Map<int, String>> _loadKurdishTranslationForSurah(
    int surahNumber,
  ) async {
    await _ensureKurdishTranslationCache();
    return _kurdishTranslationCache?[surahNumber] ?? const <int, String>{};
  }

  Future<Map<int, Map<int, String>>> _loadBundledKurdishTranslation() async {
    try {
      final bytes = await rootBundle.load(_bundledKurdishTranslationAsset);
      final raw = bytes.buffer.asUint8List(
        bytes.offsetInBytes,
        bytes.lengthInBytes,
      );
      final decoded = _decodeMaybeGzip(raw);
      final jsonValue = jsonDecode(utf8.decode(decoded));
      return _parseTranslationMap(jsonValue);
    } catch (error, stackTrace) {
      debugPrint(
        'Bundled Kurdish translation load failed: $error\n$stackTrace',
      );
      return const <int, Map<int, String>>{};
    }
  }

  Future<Map<int, Map<int, String>>>
  _loadKurdishTranslationFromLibrary() async {
    await _ensureQuranLibraryInitialized();

    final items = _quranLibrary.tafsirAndTraslationsCollection;
    final kuIndex = items.indexWhere(
      (item) =>
          item.isTranslation &&
          (item.fileName.toLowerCase() == 'ku' ||
              item.bookName.toLowerCase() == 'ku'),
    );
    if (kuIndex < 0) {
      return const <int, Map<int, String>>{};
    }

    _quranLibrary.changeTafsirSwitch(kuIndex);
    await _quranLibrary.fetchTranslation();

    final map = <int, Map<int, String>>{};
    for (final item in _quranLibrary.translationList) {
      final text = item.cleanText.trim();
      if (text.isEmpty) continue;
      map.putIfAbsent(
        item.surahNumber,
        () => <int, String>{},
      )[item.ayahNumber] = text;
    }
    return map;
  }

  Future<void> _ensureArabicTafsirCache() async {
    if (_arabicTafsirCache != null) return;
    _arabicTafsirInitFuture ??= () async {
      try {
        final bytes = await rootBundle.load(
          'packages/quran_library/assets/saadi.json.gz',
        );
        final compressed = bytes.buffer.asUint8List(
          bytes.offsetInBytes,
          bytes.lengthInBytes,
        );
        final decoded = gzip.decode(compressed);
        final jsonValue = jsonDecode(utf8.decode(decoded));

        final map = <int, Map<int, String>>{};
        if (jsonValue is List) {
          for (final item in jsonValue) {
            if (item is! Map) continue;
            final row = Map<String, dynamic>.from(item);
            final surah =
                _asNullableInt(row['sura']) ?? _asNullableInt(row['surah']);
            final ayah =
                _asNullableInt(row['aya']) ?? _asNullableInt(row['ayah']);
            final text = row['text']?.toString().trim() ?? '';
            if (surah == null || surah < 1) continue;
            if (ayah == null || ayah < 1) continue;
            if (text.isEmpty) continue;
            map.putIfAbsent(surah, () => <int, String>{})[ayah] = text;
          }
        }

        _arabicTafsirCache = map;
      } catch (_) {
        _arabicTafsirCache = <int, Map<int, String>>{};
      }
    }();

    try {
      await _arabicTafsirInitFuture;
    } catch (_) {
      _arabicTafsirInitFuture = null;
      _arabicTafsirCache = <int, Map<int, String>>{};
    }
  }

  Future<Map<int, String>> _loadArabicTafsirForSurah(int surahNumber) async {
    await _ensureArabicTafsirCache();
    return _arabicTafsirCache?[surahNumber] ?? const <int, String>{};
  }

  Future<List<QuranAyahSearchResult>> searchAyahs(String query) async {
    final normalizedQuery = _normalizeArabicSearchText(query);
    if (normalizedQuery.isEmpty) return const <QuranAyahSearchResult>[];

    final surahMap = await _loadLibrarySurahMap();
    final results = <QuranAyahSearchResult>[];

    for (final surah in surahMap.values) {
      final surahName = surah.arabicName;
      for (final ayah in surah.ayahs) {
        final ayahText = ayah.text.trim();
        if (ayahText.isEmpty) continue;
        if (_normalizeArabicSearchText(ayahText).contains(normalizedQuery)) {
          results.add(
            QuranAyahSearchResult(
              surahNumber: surah.surahNumber,
              surahName: surahName,
              ayahNumber: ayah.ayahNumber,
              arabicText: ayahText,
            ),
          );
        }
      }
    }

    return results;
  }

  String _normalizeArabicSearchText(String value) {
    return value
        .replaceAll(RegExp(r'[ًٌٍَُِّْٰـ]'), '')
        .replaceAll(RegExp(r'\s+'), '')
        .trim();
  }

  Uint8List _decodeMaybeGzip(Uint8List bytes) {
    if (bytes.length >= 2 && bytes[0] == 0x1f && bytes[1] == 0x8b) {
      return Uint8List.fromList(gzip.decode(bytes));
    }
    return bytes;
  }

  Map<int, Map<int, String>> _parseTranslationMap(dynamic jsonValue) {
    final map = <int, Map<int, String>>{};
    if (jsonValue is! Map) return map;

    final referencedText = <String, String>{};
    for (final entry in jsonValue.entries) {
      final key = entry.key.toString();
      final value = entry.value;
      if (value is! Map) continue;
      final text =
          value['t']?.toString().trim() ??
          value['text']?.toString().trim() ??
          '';
      if (text.isEmpty) continue;
      referencedText[key] = text;
    }

    for (final entry in jsonValue.entries) {
      final key = entry.key.toString();
      final ref = key.split(':');
      if (ref.length != 2) continue;

      final surah = int.tryParse(ref[0]);
      final ayah = int.tryParse(ref[1]);
      if (surah == null || surah < 1 || ayah == null || ayah < 1) continue;

      final value = entry.value;
      String text = '';
      if (value is Map) {
        text =
            value['t']?.toString().trim() ??
            value['text']?.toString().trim() ??
            '';
      } else if (value is String) {
        text = referencedText[value]?.trim() ?? value.trim();
      }
      if (text.isEmpty) continue;

      map.putIfAbsent(surah, () => <int, String>{})[ayah] = text;
    }

    return map;
  }

  Future<QpcV4AssetsStore?> _loadQpcV4Store() async {
    _qpcV4StoreFuture ??= QpcV4AssetsLoader.load();
    try {
      return await _qpcV4StoreFuture;
    } catch (_) {
      _qpcV4StoreFuture = null;
      return null;
    }
  }

  Future<Map<int, String>> _loadQpcGlyphTextForSurah(int surahNumber) async {
    final cached = _qpcGlyphBySurahCache[surahNumber];
    if (cached != null) return cached;

    final store = await _loadQpcV4Store();
    if (store == null) return const <int, String>{};

    final wordsByAyah = <int, List<QpcV4Word>>{};
    for (final word in store.wordsById.values) {
      if (word.surah != surahNumber) continue;
      wordsByAyah.putIfAbsent(word.ayah, () => <QpcV4Word>[]).add(word);
    }

    final map = <int, String>{};
    for (final entry in wordsByAyah.entries) {
      final words = entry.value;
      if (words.isEmpty) continue;
      words.sort((a, b) => a.wordIndex.compareTo(b.wordIndex));

      // In qpc-v4 data the highest word index is the ayah-number ornament.
      int maxWordIndex = 0;
      for (final word in words) {
        if (word.wordIndex > maxWordIndex) maxWordIndex = word.wordIndex;
      }

      final glyphParts = <String>[];
      for (final word in words) {
        if (word.wordIndex == maxWordIndex) continue;
        if (word.text.isEmpty) continue;
        glyphParts.add(word.text);
      }

      if (glyphParts.isNotEmpty) {
        map[entry.key] = glyphParts.join('\u202F');
      }
    }

    _qpcGlyphBySurahCache[surahNumber] = map;
    return map;
  }

  QuranReciter _resolveReciterById(String reciterId) {
    final reciters = _reciterCache ?? defaultReciters;
    for (final reciter in reciters) {
      if (reciter.id == reciterId) return reciter;
    }
    if (reciters.isNotEmpty) return reciters.first;
    return _hardcodedFallbackReciter;
  }

  Future<List<SurahInfo>> loadInfo() async {
    final surahs = await _loadLibrarySurahNames();
    return surahs
        .map(
          (surah) => SurahInfo(
            arabic: surah.name,
            latin: surah.englishName,
            translation: surah.englishNameTranslation,
            ayahCount: surah.ayahsNumber,
            index: surah.number,
            opening: surah.revelationType,
            closing: surah.surahNamesFromBook,
          ),
        )
        .toList();
  }

  Future<AllSurah> loadSurah(int number) async {
    final surah = await _loadLibrarySurah(number);
    if (surah == null) {
      throw Exception('Surah $number not found in quran_library');
    }

    final ayahText = <String, String>{};
    for (final ayah in surah.ayahs) {
      ayahText[ayah.ayahNumber.toString()] = ayah.text;
    }

    return AllSurah(
      number: surah.surahNumber.toString(),
      name: surah.arabicName,
      nameLatin: surah.englishName,
      numberOfAyah: surah.ayahs.length.toString(),
      text: ayahText,
    );
  }

  Future<QuranMetaData> loadMeta() async {
    final cached = _metaCache;
    if (cached != null) return cached;

    try {
      final surahMap = await _loadLibrarySurahMap();
      final ordered = surahMap.values.toList()
        ..sort((a, b) => a.surahNumber.compareTo(b.surahNumber));

      final juzRefs = <int, QuranMetaReference>{};
      final hizbRefs = <int, QuranMetaReference>{};
      final pageRefs = <int, QuranMetaReference>{};

      for (final surah in ordered) {
        for (final ayah in surah.ayahs) {
          final ref = QuranMetaReference(
            surah: surah.surahNumber,
            ayah: ayah.ayahNumber,
          );

          if (ayah.juz > 0) {
            juzRefs.putIfAbsent(ayah.juz, () => ref);
          }

          final hizb = ayah.hizb;
          if (hizb != null && hizb > 0) {
            hizbRefs.putIfAbsent(hizb, () => ref);
          }

          if (ayah.page > 0) {
            pageRefs.putIfAbsent(ayah.page, () => ref);
          }
        }
      }

      _metaCache = QuranMetaData(
        juzReferences: _sortMetaReferences(juzRefs),
        hizbQuarterReferences: _sortMetaReferences(hizbRefs),
        pageReferences: _sortMetaReferences(pageRefs),
      );
      return _metaCache!;
    } catch (_) {
      return const QuranMetaData();
    }
  }

  Future<List<QuranReciter>> loadAudioReciters() async {
    final cached = _reciterCache;
    if (cached != null && cached.isNotEmpty) return cached;

    final reciters = List<QuranReciter>.from(defaultReciters);
    _reciterCache = reciters;
    return reciters;
  }

  Future<QuranRichSurah> loadRichSurah(
    int number, {
    String reciterId = 'qlib_fallback_alafasy',
  }) async {
    final librarySurah = await _loadLibrarySurah(number);
    if (librarySurah == null) {
      throw Exception('Surah $number not found in quran_library');
    }

    Map<int, String> kuTranslations = const <int, String>{};
    Map<int, String> arTafsir = const <int, String>{};
    Map<int, String> qpcGlyphByAyah = const <int, String>{};

    try {
      kuTranslations = await _loadKurdishTranslationForSurah(number);
    } catch (_) {}

    try {
      arTafsir = await _loadArabicTafsirForSurah(number);
    } catch (_) {}

    try {
      qpcGlyphByAyah = await _loadQpcGlyphTextForSurah(number);
    } catch (_) {}

    final reciter = _resolveReciterById(reciterId);

    final ayahs = librarySurah.ayahs
        .map(
          (ayah) => QuranAyahData(
            numberInSurah: ayah.ayahNumber,
            globalNumber: ayah.ayahUQNumber,
            arabicText: ayah.text,
            // quran_library data is plain Arabic text; keep same text so the
            // tajweed toggle still has a consistent visual mode in list view.
            tajweedText: ayah.text,
            qpcGlyphText: qpcGlyphByAyah[ayah.ayahNumber],
            kurdishTranslation: kuTranslations[ayah.ayahNumber],
            kurdishTafsir: kuTranslations[ayah.ayahNumber],
            arabicTafsir: arTafsir[ayah.ayahNumber],
            audioUrl: buildAyahAudioUrl(
              reciterId: reciter.id,
              globalAyahNumber: ayah.ayahUQNumber,
              surahNumber: number,
              ayahNumber: ayah.ayahNumber,
            ),
            juz: ayah.juz,
            hizbQuarter: ayah.hizb,
            page: ayah.page,
          ),
        )
        .toList(growable: false);

    return QuranRichSurah(
      number: librarySurah.surahNumber,
      arabicName: librarySurah.arabicName,
      englishName: librarySurah.englishName,
      revelationType: librarySurah.revelationType ?? '',
      ayahs: ayahs,
      fromRemote: false,
    );
  }

  String buildAyahAudioUrl({
    required String reciterId,
    required int globalAyahNumber,
    int? surahNumber,
    int? ayahNumber,
  }) {
    final reciter = _resolveReciterById(reciterId);
    final normalizedBase = reciter.audioBaseUrl.endsWith('/')
        ? reciter.audioBaseUrl
        : '${reciter.audioBaseUrl}/';
    final normalizedPath = reciter.readerPath
        .replaceAll('\\', '/')
        .replaceAll(RegExp(r'^/+'), '')
        .replaceAll(RegExp(r'/+$'), '');

    final fileName =
        reciter.usesGlobalAyahNumber ||
            surahNumber == null ||
            ayahNumber == null
        ? '$globalAyahNumber.mp3'
        : "${surahNumber.toString().padLeft(3, '0')}${ayahNumber.toString().padLeft(3, '0')}.mp3";

    if (normalizedPath.isEmpty) {
      return '$normalizedBase$fileName';
    }
    return '$normalizedBase$normalizedPath/$fileName';
  }

  Future<String?> findOfflineAyahPath({
    required String reciterId,
    required int surahIndex,
    required int ayahNumber,
  }) async {
    final path = await _offlineAyahPath(
      reciterId: reciterId,
      surahIndex: surahIndex,
      ayahNumber: ayahNumber,
    );
    final file = File(path);
    if (!file.existsSync()) return null;
    if (await file.length() < 512) return null;
    return path;
  }

  Future<OfflineAudioPackStatus> getOfflinePackStatus({
    required String reciterId,
    required int surahIndex,
    required List<int> ayahNumbers,
  }) async {
    int downloaded = 0;
    for (final ayah in ayahNumbers) {
      final path = await _offlineAyahPath(
        reciterId: reciterId,
        surahIndex: surahIndex,
        ayahNumber: ayah,
      );
      final file = File(path);
      if (file.existsSync() && await file.length() > 512) {
        downloaded += 1;
      }
    }
    return OfflineAudioPackStatus(
      totalCount: ayahNumbers.length,
      downloadedCount: downloaded,
    );
  }

  Future<OfflineAudioPackStatus> downloadOfflineSurahPack({
    required String reciterId,
    required int surahIndex,
    required List<QuranAyahData> ayahs,
    required void Function(OfflineAudioPackStatus status) onProgress,
    bool forceRedownload = false,
    bool Function()? isCancelled,
  }) async {
    int downloaded = 0;
    int failed = 0;

    final total = ayahs.length;
    if (total < 1) {
      return const OfflineAudioPackStatus(totalCount: 0, downloadedCount: 0);
    }

    for (final ayah in ayahs) {
      if (isCancelled?.call() ?? false) {
        break;
      }

      final path = await _offlineAyahPath(
        reciterId: reciterId,
        surahIndex: surahIndex,
        ayahNumber: ayah.numberInSurah,
      );
      final file = File(path);
      final hasValid =
          file.existsSync() && (await file.length()) > 512 && !forceRedownload;
      if (!hasValid) {
        final url = buildAyahAudioUrl(
          reciterId: reciterId,
          globalAyahNumber: ayah.globalNumber,
          surahNumber: surahIndex,
          ayahNumber: ayah.numberInSurah,
        );
        try {
          await _dio.download(
            url,
            path,
            deleteOnError: true,
            options: Options(
              sendTimeout: const Duration(seconds: 20),
              receiveTimeout: const Duration(seconds: 30),
            ),
          );
        } catch (_) {
          failed += 1;
        }
      }
      if (file.existsSync() && await file.length() > 512) {
        downloaded += 1;
      }
      onProgress(
        OfflineAudioPackStatus(
          totalCount: total,
          downloadedCount: downloaded,
          failedCount: failed,
        ),
      );
    }

    return OfflineAudioPackStatus(
      totalCount: total,
      downloadedCount: downloaded,
      failedCount: failed,
    );
  }

  Future<void> deleteOfflineSurahPack({
    required String reciterId,
    required int surahIndex,
  }) async {
    final base = await _offlineSurahDir(
      reciterId: reciterId,
      surahIndex: surahIndex,
    );
    if (base.existsSync()) {
      await base.delete(recursive: true);
    }
  }

  Future<String> _offlineAyahPath({
    required String reciterId,
    required int surahIndex,
    required int ayahNumber,
  }) async {
    final directory = await _offlineSurahDir(
      reciterId: reciterId,
      surahIndex: surahIndex,
    );
    if (!directory.existsSync()) {
      await directory.create(recursive: true);
    }
    return '${directory.path}${Platform.pathSeparator}$ayahNumber.mp3';
  }

  Future<Directory> _offlineSurahDir({
    required String reciterId,
    required int surahIndex,
  }) async {
    final appDir = await getApplicationDocumentsDirectory();
    final reciterDir = _safeReciterDirectoryName(reciterId);
    return Directory(
      '${appDir.path}${Platform.pathSeparator}quran_audio'
      '${Platform.pathSeparator}$reciterDir'
      '${Platform.pathSeparator}$surahIndex',
    );
  }

  String _safeReciterDirectoryName(String reciterId) {
    return reciterId.replaceAll(RegExp(r'[^a-zA-Z0-9._-]'), '_');
  }

  List<QuranMetaReference> _sortMetaReferences(
    Map<int, QuranMetaReference> source,
  ) {
    final orderedKeys = source.keys.toList()..sort();
    return orderedKeys.map((key) => source[key]!).toList();
  }

  static int? _asNullableInt(dynamic value) {
    if (value is int) return value;
    if (value is num) return value.toInt();
    if (value is String) return int.tryParse(value);
    return null;
  }
}
