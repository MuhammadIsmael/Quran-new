import 'package:runaki_islam/Screens/HomeItems/Qurani%20Piroz/data/models/allsurah.dart';

class QuranAyahData {
  QuranAyahData({
    required this.numberInSurah,
    required this.globalNumber,
    required this.arabicText,
    this.tajweedText,
    this.qpcGlyphText,
    this.kurdishTranslation,
    this.kurdishTafsir,
    this.arabicTafsir,
    this.audioUrl,
    this.juz,
    this.hizbQuarter,
    this.page,
  });

  final int numberInSurah;
  final int globalNumber;
  final String arabicText;
  final String? tajweedText;
  final String? qpcGlyphText;
  final String? kurdishTranslation;
  final String? kurdishTafsir;
  final String? arabicTafsir;
  final String? audioUrl;
  final int? juz;
  final int? hizbQuarter;
  final int? page;
}

class QuranRichSurah {
  QuranRichSurah({
    required this.number,
    required this.arabicName,
    required this.englishName,
    required this.revelationType,
    required this.ayahs,
    required this.fromRemote,
  });

  final int number;
  final String arabicName;
  final String englishName;
  final String revelationType;
  final List<QuranAyahData> ayahs;
  final bool fromRemote;

  factory QuranRichSurah.fromLocal({
    required int number,
    required AllSurah local,
  }) {
    final textEntries = (local.text ?? <String, String>{}).entries.toList();
    final ayahs = <QuranAyahData>[];
    for (int i = 0; i < textEntries.length; i++) {
      final entry = textEntries[i];
      final inSurah = int.tryParse(entry.key) ?? (i + 1);
      ayahs.add(
        QuranAyahData(
          numberInSurah: inSurah,
          globalNumber: inSurah,
          arabicText: entry.value,
          tajweedText: null,
          qpcGlyphText: null,
        ),
      );
    }

    return QuranRichSurah(
      number: number,
      arabicName: local.name ?? '',
      englishName: local.nameLatin ?? '',
      revelationType: '',
      ayahs: ayahs,
      fromRemote: false,
    );
  }
}
