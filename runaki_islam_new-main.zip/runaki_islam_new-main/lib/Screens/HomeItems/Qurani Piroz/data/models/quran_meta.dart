class QuranMetaReference {
  const QuranMetaReference({required this.surah, required this.ayah});

  final int surah;
  final int ayah;

  factory QuranMetaReference.fromJson(Map<String, dynamic> json) {
    return QuranMetaReference(
      surah: _asInt(json['surah']),
      ayah: _asInt(json['ayah']),
    );
  }

  static int _asInt(dynamic value) {
    if (value is int) return value;
    if (value is num) return value.toInt();
    if (value is String) return int.tryParse(value) ?? 1;
    return 1;
  }
}

class QuranMetaData {
  const QuranMetaData({
    this.juzReferences = const <QuranMetaReference>[],
    this.hizbQuarterReferences = const <QuranMetaReference>[],
    this.pageReferences = const <QuranMetaReference>[],
  });

  final List<QuranMetaReference> juzReferences;
  final List<QuranMetaReference> hizbQuarterReferences;
  final List<QuranMetaReference> pageReferences;

  bool get hasAnyData {
    return juzReferences.isNotEmpty ||
        hizbQuarterReferences.isNotEmpty ||
        pageReferences.isNotEmpty;
  }

  factory QuranMetaData.fromMetaJson(Map<String, dynamic> json) {
    final juz = _parseReferences(json['juzs']);
    final hizb = _parseReferences(json['hizbQuarters']);
    final pages = _parseReferences(json['pages']);
    return QuranMetaData(
      juzReferences: juz,
      hizbQuarterReferences: hizb,
      pageReferences: pages,
    );
  }

  static List<QuranMetaReference> _parseReferences(dynamic node) {
    if (node is! Map<String, dynamic>) return const <QuranMetaReference>[];
    final refs = node['references'];
    if (refs is! List) return const <QuranMetaReference>[];
    final result = <QuranMetaReference>[];
    for (final item in refs) {
      if (item is Map<String, dynamic>) {
        result.add(QuranMetaReference.fromJson(item));
      } else if (item is Map) {
        result.add(
          QuranMetaReference.fromJson(Map<String, dynamic>.from(item)),
        );
      }
    }
    return result;
  }
}
