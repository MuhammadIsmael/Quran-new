import 'dart:convert';

List<Map<String, AllSurah>> allSurahFromJson(String str) =>
    List<Map<String, AllSurah>>.from(json.decode(str).map((x) => Map.from(x)
        .map((k, v) => MapEntry<String, AllSurah>(k, AllSurah.fromJson(v)))));

String allSurahToJson(List<Map<String, AllSurah>> data) =>
    json.encode(List<dynamic>.from(data.map((x) =>
        Map.from(x).map((k, v) => MapEntry<String, dynamic>(k, v.toJson())))));

class AllSurah {
  String? number;
  String? name;
  String? nameLatin;
  String? numberOfAyah;
  Map<String, String>? text;
  AllSurah({
    this.number,
    this.name,
    this.nameLatin,
    this.numberOfAyah,
    this.text,
  });

  factory AllSurah.fromJson(Map<String, dynamic> json) => AllSurah(
        number: json["number"],
        name: json["name"],
        nameLatin: json["name_latin"],
        numberOfAyah:
            json["number_of_ayah"] ,
        text: json["text"] == null
            ? null
            : Map.from(json["text"])
                .map((k, v) => MapEntry<String, String>(k, v)),
      );

  Map<String, dynamic> toJson() => {
        "number": number ,
        "name": name,
        "name_latin": nameLatin,
        "number_of_ayah": numberOfAyah ,
        "text": text == null
            ? null
            : Map.from(text!).map((k, v) => MapEntry<String, dynamic>(k, v)),
      };
}
