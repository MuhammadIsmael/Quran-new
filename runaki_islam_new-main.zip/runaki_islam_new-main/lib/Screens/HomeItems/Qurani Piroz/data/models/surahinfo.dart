import 'dart:convert';

List<SurahInfo> surahInfoFromJson(String str) =>
    List<SurahInfo>.from(json.decode(str).map((x) => SurahInfo.fromJson(x)));

String surahInfoToJson(List<SurahInfo> data) =>
    json.encode(List<dynamic>.from(data.map((x) => x.toJson())));

class SurahInfo {
  String? arabic;
  String? latin;
  String? translation;
  int? ayahCount;
  int? index;
  String? opening;
  String? closing;

  SurahInfo({
    this.arabic,
    this.latin,
    this.translation,
    this.ayahCount,
    this.index,
    this.opening,
    this.closing,
  });

  factory SurahInfo.fromJson(Map<String, dynamic> json) => SurahInfo(
    arabic: json["arabic"],
    latin: json["latin"],
    translation: json["translation"],
    ayahCount: json["ayah_count"],
    index: json["index"],
    opening: json["opening"],
    closing: json["closing"],
  );

  Map<String, dynamic> toJson() => {
    "arabic": arabic,
    "latin": latin,
    "translation": translation,
    "ayah_count": ayahCount,
    "index": index,
    "opening": opening,
    "closing": closing,
  };
}
