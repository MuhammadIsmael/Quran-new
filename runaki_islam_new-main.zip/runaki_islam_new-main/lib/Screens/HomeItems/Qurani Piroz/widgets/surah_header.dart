import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';

class SurahHeader extends StatelessWidget {
  const SurahHeader({
    super.key,
    required this.title,
    this.titleFontFamily,
    required this.subtitle,
    required this.revelationType,
    required this.onBack,
    required this.onSettings,
    required this.onAudio,
    required this.onBookmark,
    this.isBookmarked = false,
    this.surahNumber,
    this.heroTag,
  });

  final String title;
  final String? titleFontFamily;
  final String subtitle;
  final String revelationType;
  final VoidCallback onBack;
  final VoidCallback onSettings;
  final VoidCallback onAudio;
  final VoidCallback onBookmark;
  final bool isBookmarked;
  final int? surahNumber;
  final String? heroTag;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;

    return Container(
      width: double.infinity,
      margin: const EdgeInsets.fromLTRB(14, 10, 14, 8),
      padding: const EdgeInsets.fromLTRB(14, 12, 14, 12),
      decoration: BoxDecoration(
        color: scheme.surface.withValues(alpha: 0.95),
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: scheme.outline.withValues(alpha: 0.2)),
        boxShadow: [
          BoxShadow(
            color: scheme.shadow.withValues(alpha: 0.10),
            blurRadius: 16,
            offset: const Offset(0, 6),
          ),
        ],
      ),
      child: Column(
        children: [
          Row(
            children: [
              _iconButton(
                icon: Icons.arrow_back_ios_new_rounded,
                onTap: onBack,
              ),
              const Spacer(),
              _iconButton(icon: Icons.settings_outlined, onTap: onSettings),
              const SizedBox(width: 8),
              _iconButton(icon: Icons.graphic_eq_rounded, onTap: onAudio),
            ],
          ),
          const SizedBox(height: 8),
          Row(
            children: [
              _iconButton(
                icon: isBookmarked
                    ? Icons.bookmark_rounded
                    : Icons.bookmark_border_rounded,
                onTap: onBookmark,
              ),
              if (surahNumber != null) ...[
                const SizedBox(width: 8),
                SizedBox(
                  width: 40,
                  height: 40,
                  child: Stack(
                    alignment: Alignment.center,
                    children: [
                      SvgPicture.asset(
                        'assets/icons/quran/suraNum.svg',
                        width: 40,
                        height: 40,
                      ),
                      Text(
                        surahNumber.toString(),
                        style: const TextStyle(
                          color: Colors.white,
                          fontFamily: 'english',
                          fontWeight: FontWeight.w800,
                          fontSize: 12.5,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    SizedBox(
                      height: 40,
                      child: Center(
                        child: heroTag != null
                            ? Hero(
                                tag: heroTag!,
                                child: Material(
                                  color: Colors.transparent,
                                  child: Text(
                                    title,
                                    textDirection: TextDirection.rtl,
                                    textAlign: TextAlign.center,
                                    style: TextStyle(
                                      fontSize: 28,
                                      fontWeight: FontWeight.w700,
                                      color: const Color(0xFF5A4322),
                                      fontFamily: titleFontFamily,
                                    ),
                                  ),
                                ),
                              )
                            : Text(
                                title,
                                textDirection: TextDirection.rtl,
                                textAlign: TextAlign.center,
                                style: TextStyle(
                                  fontSize: 28,
                                  fontWeight: FontWeight.w700,
                                  color: const Color(0xFF5A4322),
                                  fontFamily: titleFontFamily,
                                ),
                              ),
                      ),
                    ),
                    const SizedBox(height: 4),
                    Wrap(
                      alignment: WrapAlignment.end,
                      spacing: 8,
                      runSpacing: 8,
                      children: [
                        _badge(context, subtitle),
                        _badge(context, revelationType),
                      ],
                    ),
                  ],
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _iconButton({required IconData icon, required VoidCallback onTap}) {
    return Builder(
      builder: (context) {
        final scheme = Theme.of(context).colorScheme;
        return Material(
          color: Colors.transparent,
          child: InkWell(
            borderRadius: BorderRadius.circular(12),
            onTap: onTap,
            child: Ink(
              width: 40,
              height: 40,
              decoration: BoxDecoration(
                color: scheme.surfaceContainerHighest.withValues(alpha: 0.5),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(
                  color: scheme.outline.withValues(alpha: 0.2),
                ),
              ),
              child: Icon(icon, size: 20, color: scheme.onSurfaceVariant),
            ),
          ),
        );
      },
    );
  }

  Widget _badge(BuildContext context, String text) {
    final scheme = Theme.of(context).colorScheme;
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
      decoration: BoxDecoration(
        color: scheme.primary.withValues(alpha: 0.10),
        borderRadius: BorderRadius.circular(10),
      ),
      child: Text(
        text,
        textDirection: TextDirection.rtl,
        style: TextStyle(
          color: scheme.primary,
          fontSize: 12.5,
          fontWeight: FontWeight.w600,
        ),
      ),
    );
  }
}
