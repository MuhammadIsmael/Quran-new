import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';

class AyahCard extends StatelessWidget {
  const AyahCard({
    super.key,
    required this.ayahNumber,
    required this.arabicText,
    required this.fontFamily,
    required this.fontSize,
    required this.lineHeight,
    required this.highlightColor,
    required this.isHighlighted,
    required this.isBookmarked,
    required this.showMetaBar,
    required this.showTranslation,
    required this.translationText,
    required this.onTap,
    required this.onCopy,
    this.tajweedText,
    this.qpcGlyphText,
    this.qcfFontFamily,
    this.enableTajweedColors = false,
    this.highContrastTajweed = false,
    this.tajweedColors = const <String, Color>{},
    this.tajweedOpacity = 1.0,
    this.paperMode = false,
  });

  final int ayahNumber;
  final String arabicText;
  final String fontFamily;
  final double fontSize;
  final double lineHeight;
  final Color highlightColor;
  final bool isHighlighted;
  final bool isBookmarked;
  final bool showMetaBar;
  final bool showTranslation;
  final String? translationText;
  final VoidCallback onTap;
  final VoidCallback onCopy;
  final String? tajweedText;
  final String? qpcGlyphText;
  final String? qcfFontFamily;
  final bool enableTajweedColors;
  final bool highContrastTajweed;
  final Map<String, Color> tajweedColors;
  final double tajweedOpacity;
  final bool paperMode;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final brightness = Theme.of(context).brightness;
    final baseSurface = paperMode
        ? (brightness == Brightness.dark
              ? scheme.surfaceContainerHighest.withValues(alpha: 0.45)
              : const Color(0xFFF7EEDC))
        : scheme.surface.withValues(alpha: 0.88);
    final baseBorder = paperMode
        ? (brightness == Brightness.dark
              ? scheme.outline.withValues(alpha: 0.4)
              : const Color(0xFFDBC7A1))
        : scheme.outline.withValues(alpha: 0.18);
    final highlightFill = paperMode
        ? highlightColor.withValues(alpha: 0.33)
        : highlightColor.withValues(alpha: 0.25);

    return AnimatedContainer(
      duration: const Duration(milliseconds: 220),
      curve: Curves.easeInOut,
      margin: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
      decoration: BoxDecoration(
        color: isHighlighted ? highlightFill : baseSurface,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: isHighlighted
              ? highlightColor.withValues(alpha: 0.7)
              : baseBorder,
        ),
        boxShadow: [
          BoxShadow(
            color: scheme.shadow.withValues(alpha: isHighlighted ? 0.14 : 0.06),
            blurRadius: 14,
            offset: const Offset(0, 5),
          ),
        ],
      ),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          borderRadius: BorderRadius.circular(16),
          onTap: onTap,
          child: Padding(
            padding: const EdgeInsets.fromLTRB(14, 12, 14, 12),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                if (showMetaBar) ...[
                  Row(
                    children: [
                      if (isBookmarked)
                        Padding(
                          padding: const EdgeInsets.only(left: 2),
                          child: SvgPicture.asset(
                            'assets/icons/quran/ayahBookmarked.svg',
                            width: 19,
                            height: 19,
                          ),
                        ),
                      if (isBookmarked) const SizedBox(width: 2),
                      IconButton(
                        visualDensity: VisualDensity.compact,
                        icon: Icon(
                          Icons.content_copy_rounded,
                          size: 20,
                          color: scheme.primary,
                        ),
                        onPressed: onCopy,
                      ),
                      const Spacer(),
                      SizedBox(
                        width: 40,
                        height: 40,
                        child: Stack(
                          alignment: Alignment.center,
                          children: [
                            SvgPicture.asset(
                              'assets/icons/quran/suraNum.svg',
                              width: 40,
                              height: 40,
                            ),
                            Text(
                              _toArabicDigits(ayahNumber),
                              style: const TextStyle(
                                color: Colors.white,
                                fontWeight: FontWeight.w700,
                                fontSize: 11.2,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 4),
                ],
                SelectableText.rich(
                  TextSpan(
                    style: TextStyle(
                      fontFamily: fontFamily,
                      fontSize: fontSize,
                      height: lineHeight,
                      color: scheme.onSurface,
                      fontWeight: FontWeight.w500,
                    ),
                    children: _buildArabicSpans(),
                  ),
                  textAlign: TextAlign.right,
                  textDirection: TextDirection.rtl,
                ),
                if (showTranslation) ...[
                  const SizedBox(height: 12),
                  Container(
                    width: double.infinity,
                    padding: const EdgeInsets.symmetric(
                      horizontal: 12,
                      vertical: 10,
                    ),
                    decoration: BoxDecoration(
                      color: scheme.surfaceContainerHighest.withValues(
                        alpha: 0.45,
                      ),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Text(
                      (translationText != null &&
                              translationText!.trim().isNotEmpty)
                          ? translationText!
                          : "وەرگێڕان بەردەست نییە.",
                      textDirection: TextDirection.rtl,
                      textAlign: TextAlign.right,
                      style: TextStyle(
                        color: scheme.onSurfaceVariant,
                        fontSize: 14,
                        height: 1.6,
                      ),
                    ),
                  ),
                ],
              ],
            ),
          ),
        ),
      ),
    );
  }

  List<InlineSpan> _buildArabicSpans() {
    final glyphText = qpcGlyphText?.trim() ?? '';
    final glyphFamily = qcfFontFamily?.trim() ?? '';
    final canDrawGlyph = glyphText.isNotEmpty && glyphFamily.isNotEmpty;
    InlineSpan glyphSpan() {
      return TextSpan(
        text: glyphText,
        style: TextStyle(
          fontFamily: glyphFamily,
          fontSize: fontSize,
          height: lineHeight,
          fontWeight: FontWeight.w500,
          wordSpacing: -2,
        ),
      );
    }

    if (!enableTajweedColors) {
      return canDrawGlyph
          ? <InlineSpan>[glyphSpan()]
          : <InlineSpan>[TextSpan(text: arabicText)];
    }

    if (!highContrastTajweed && canDrawGlyph) {
      return <InlineSpan>[glyphSpan()];
    }

    if (tajweedText == null || tajweedText!.trim().isEmpty) {
      return canDrawGlyph
          ? <InlineSpan>[glyphSpan()]
          : <InlineSpan>[TextSpan(text: arabicText)];
    }

    final normalizedOpacity = tajweedOpacity.clamp(0.35, 1.0);
    final segments = _parseTajweedMarkup(tajweedText!);
    if (segments.isEmpty) {
      return canDrawGlyph
          ? <InlineSpan>[glyphSpan()]
          : <InlineSpan>[TextSpan(text: arabicText)];
    }

    final hasTaggedRules = segments.any((segment) {
      final code = segment.ruleCode?.trim();
      return code != null && code.isNotEmpty;
    });
    if (!hasTaggedRules) {
      if (canDrawGlyph) {
        return <InlineSpan>[glyphSpan()];
      }
      final fallback = tajweedColors.values.isEmpty
          ? const Color(0xFF00695C)
          : tajweedColors.values.first;
      return <InlineSpan>[
        TextSpan(
          text: arabicText,
          style: _tajweedSpanStyle(fallback, normalizedOpacity),
        ),
      ];
    }

    return segments.map((segment) {
      if (segment.ruleCode == null) {
        return TextSpan(text: segment.text);
      }
      final code = segment.ruleCode!;
      final color = tajweedColors[code.toLowerCase()] ?? tajweedColors[code];
      if (color == null) {
        return TextSpan(text: segment.text);
      }
      return TextSpan(
        text: segment.text,
        style: _tajweedSpanStyle(color, normalizedOpacity),
      );
    }).toList();
  }

  TextStyle _tajweedSpanStyle(Color color, double opacity) {
    final effective = color.withValues(alpha: opacity);
    final darkShadow = Colors.black.withValues(
      alpha: highContrastTajweed ? 0.48 : 0.30,
    );
    final lightShadow = Colors.white.withValues(
      alpha: highContrastTajweed ? 0.26 : 0.14,
    );

    return TextStyle(
      color: effective,
      fontWeight: highContrastTajweed ? FontWeight.w800 : FontWeight.w700,
      shadows: <Shadow>[
        Shadow(color: darkShadow, blurRadius: highContrastTajweed ? 1.6 : 1.0),
        Shadow(color: lightShadow, blurRadius: highContrastTajweed ? 1.0 : 0.6),
      ],
    );
  }

  List<_TajweedSegment> _parseTajweedMarkup(String input) {
    final bracket = _parseBracketTajweed(input);
    if (bracket.isNotEmpty) return bracket;

    final html = _parseHtmlTajweed(input);
    if (html.isNotEmpty) return html;

    return <_TajweedSegment>[_TajweedSegment(text: input)];
  }

  List<_TajweedSegment> _parseBracketTajweed(String input) {
    final pattern = RegExp(r'\[([A-Za-z_]+)(?::\d+)?\[([^\]]*)\]');
    final matches = pattern.allMatches(input).toList();
    if (matches.isEmpty) return <_TajweedSegment>[];

    final result = <_TajweedSegment>[];
    int cursor = 0;
    for (final match in matches) {
      if (match.start > cursor) {
        result.add(_TajweedSegment(text: input.substring(cursor, match.start)));
      }
      final code = match.group(1);
      final text = match.group(2);
      if (text != null && text.isNotEmpty) {
        result.add(_TajweedSegment(text: text, ruleCode: code));
      }
      cursor = match.end;
    }

    if (cursor < input.length) {
      result.add(_TajweedSegment(text: input.substring(cursor)));
    }
    return result;
  }

  List<_TajweedSegment> _parseHtmlTajweed(String input) {
    final pattern = RegExp(
      "<(?:tajweed|span)[^>]*class=[\"']?([A-Za-z_]+)[\"']?[^>]*>(.*?)<\\/(?:tajweed|span)>",
      caseSensitive: false,
      dotAll: true,
    );
    final matches = pattern.allMatches(input).toList();
    if (matches.isEmpty) return <_TajweedSegment>[];

    final result = <_TajweedSegment>[];
    int cursor = 0;
    for (final match in matches) {
      if (match.start > cursor) {
        result.add(
          _TajweedSegment(
            text: _stripMarkupTags(input.substring(cursor, match.start)),
          ),
        );
      }
      final code = match.group(1);
      final text = _stripMarkupTags(match.group(2) ?? "");
      if (text.isNotEmpty) {
        result.add(_TajweedSegment(text: text, ruleCode: code));
      }
      cursor = match.end;
    }

    if (cursor < input.length) {
      result.add(
        _TajweedSegment(text: _stripMarkupTags(input.substring(cursor))),
      );
    }
    return result;
  }

  String _stripMarkupTags(String value) {
    return value.replaceAll(RegExp(r'<[^>]+>'), '');
  }

  String _toArabicDigits(int value) {
    const western = '0123456789';
    const eastern =
        '\u0660\u0661\u0662\u0663\u0664\u0665\u0666\u0667\u0668\u0669';
    return value.toString().split('').map((digit) {
      final index = western.indexOf(digit);
      return index == -1 ? digit : eastern[index];
    }).join();
  }
}

class _TajweedSegment {
  const _TajweedSegment({required this.text, this.ruleCode});

  final String text;
  final String? ruleCode;
}
