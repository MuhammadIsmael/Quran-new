import 'package:flutter/material.dart';

enum AyahActionType {
  play,
  repeat,
  bookmark,
  copyArabic,
  copyKurdish,
  share,
  tafsir,
  toggleTranslation,
}

class AyahActionSheet extends StatelessWidget {
  const AyahActionSheet({
    super.key,
    required this.ayahNumber,
    required this.translationVisible,
    required this.isBookmarked,
  });

  final int ayahNumber;
  final bool translationVisible;
  final bool isBookmarked;

  static Future<AyahActionType?> show(
    BuildContext context, {
    required int ayahNumber,
    required bool translationVisible,
    required bool isBookmarked,
  }) {
    return showModalBottomSheet<AyahActionType>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (_) {
        return AyahActionSheet(
          ayahNumber: ayahNumber,
          translationVisible: translationVisible,
          isBookmarked: isBookmarked,
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return SafeArea(
      top: false,
      child: Container(
        margin: const EdgeInsets.fromLTRB(10, 0, 10, 10),
        padding: const EdgeInsets.fromLTRB(14, 12, 14, 14),
        decoration: BoxDecoration(
          color: scheme.surface.withValues(alpha: 0.98),
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: scheme.outline.withValues(alpha: 0.2)),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 54,
              height: 4,
              decoration: BoxDecoration(
                color: scheme.outline.withValues(alpha: 0.4),
                borderRadius: BorderRadius.circular(99),
              ),
            ),
            const SizedBox(height: 10),
            Text(
              "ئایەت $ayahNumber",
              style: TextStyle(
                color: scheme.onSurface,
                fontSize: 16,
                fontWeight: FontWeight.w700,
              ),
            ),
            const SizedBox(height: 12),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: [
                _actionItem(
                  context,
                  label: "لێدان",
                  icon: Icons.play_circle_outline_rounded,
                  type: AyahActionType.play,
                ),
                _actionItem(
                  context,
                  label: "دووبارەکردنەوە",
                  icon: Icons.repeat_rounded,
                  type: AyahActionType.repeat,
                ),
                _actionItem(
                  context,
                  label: isBookmarked ? "سڕینەوەی نیشانە" : "نیشانەکردن",
                  icon: isBookmarked
                      ? Icons.bookmark_remove_rounded
                      : Icons.bookmark_border_rounded,
                  type: AyahActionType.bookmark,
                ),
                _actionItem(
                  context,
                  label: "کۆپی عەرەبی",
                  icon: Icons.content_copy_rounded,
                  type: AyahActionType.copyArabic,
                ),
                _actionItem(
                  context,
                  label: "کۆپی وەرگێڕان",
                  icon: Icons.translate_rounded,
                  type: AyahActionType.copyKurdish,
                ),
                _actionItem(
                  context,
                  label: "هاوبەشکردن",
                  icon: Icons.ios_share_rounded,
                  type: AyahActionType.share,
                ),
                _actionItem(
                  context,
                  label: "تەفسیر",
                  icon: Icons.menu_book_rounded,
                  type: AyahActionType.tafsir,
                ),
                _actionItem(
                  context,
                  label: translationVisible
                      ? "شاردنەوەی وەرگێڕان"
                      : "پیشاندانی وەرگێڕان",
                  icon: translationVisible
                      ? Icons.visibility_off_outlined
                      : Icons.visibility_outlined,
                  type: AyahActionType.toggleTranslation,
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _actionItem(
    BuildContext context, {
    required String label,
    required IconData icon,
    required AyahActionType type,
  }) {
    final scheme = Theme.of(context).colorScheme;
    return SizedBox(
      width: (MediaQuery.of(context).size.width - 56) / 2,
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          borderRadius: BorderRadius.circular(14),
          onTap: () => Navigator.of(context).pop(type),
          child: Ink(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 11),
            decoration: BoxDecoration(
              color: scheme.surfaceContainerHighest.withValues(alpha: 0.45),
              borderRadius: BorderRadius.circular(14),
              border: Border.all(color: scheme.outline.withValues(alpha: 0.2)),
            ),
            child: Row(
              children: [
                Icon(icon, size: 18, color: scheme.primary),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(
                    label,
                    textAlign: TextAlign.right,
                    textDirection: TextDirection.rtl,
                    style: TextStyle(
                      color: scheme.onSurface,
                      fontWeight: FontWeight.w600,
                      fontSize: 13,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
