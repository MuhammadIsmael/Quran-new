import 'package:flutter/material.dart';

class QuranPlayerFullSheet extends StatelessWidget {
  const QuranPlayerFullSheet({
    super.key,
    required this.surahName,
    required this.currentAyah,
    required this.isPlaying,
    required this.selectedReciter,
    required this.speed,
    required this.autoScroll,
    required this.repeatLabel,
    required this.onPlayPause,
    required this.onNext,
    required this.onPrevious,
    required this.onSelectReciter,
    required this.onRepeatTap,
    required this.onAutoScrollChanged,
    required this.onSpeedChanged,
    required this.onDownloadTap,
  });

  final String surahName;
  final int currentAyah;
  final bool isPlaying;
  final String selectedReciter;
  final double speed;
  final bool autoScroll;
  final String repeatLabel;
  final VoidCallback onPlayPause;
  final VoidCallback onNext;
  final VoidCallback onPrevious;
  final VoidCallback onSelectReciter;
  final VoidCallback onRepeatTap;
  final ValueChanged<bool> onAutoScrollChanged;
  final ValueChanged<double> onSpeedChanged;
  final VoidCallback onDownloadTap;

  static Future<void> show(
    BuildContext context, {
    required QuranPlayerFullSheet child,
  }) {
    return showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (_) => child,
    );
  }

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return SafeArea(
      top: false,
      child: Container(
        width: double.infinity,
        margin: const EdgeInsets.fromLTRB(10, 0, 10, 10),
        padding: const EdgeInsets.fromLTRB(14, 12, 14, 14),
        decoration: BoxDecoration(
          color: scheme.surface.withValues(alpha: 0.98),
          borderRadius: BorderRadius.circular(24),
          border: Border.all(color: scheme.outline.withValues(alpha: 0.2)),
          boxShadow: [
            BoxShadow(
              color: scheme.shadow.withValues(alpha: 0.2),
              blurRadius: 24,
              offset: const Offset(0, 10),
            ),
          ],
        ),
        child: Column(
          children: [
            Container(
              width: 54,
              height: 4,
              decoration: BoxDecoration(
                color: scheme.outline.withValues(alpha: 0.4),
                borderRadius: BorderRadius.circular(99),
              ),
            ),
            const SizedBox(height: 14),
            Expanded(
              child: SingleChildScrollView(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    Text(
                      surahName,
                      textDirection: TextDirection.rtl,
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        color: scheme.onSurface,
                        fontSize: 24,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      'ئایەت: $currentAyah',
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        color: scheme.onSurfaceVariant,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    const SizedBox(height: 14),
                    _playerHero(context),
                    const SizedBox(height: 14),
                    Row(
                      children: [
                        _actionChip(
                          context,
                          label: selectedReciter,
                          icon: Icons.record_voice_over_rounded,
                          onTap: onSelectReciter,
                        ),
                        const SizedBox(width: 8),
                        _actionChip(
                          context,
                          label: repeatLabel,
                          icon: Icons.repeat_rounded,
                          onTap: onRepeatTap,
                        ),
                        const SizedBox(width: 8),
                        _iconOnly(
                          context,
                          icon: Icons.download_rounded,
                          onTap: onDownloadTap,
                        ),
                      ],
                    ),
                    const SizedBox(height: 16),
                    Row(
                      children: [
                        Text(
                          'خێرایی لێدان',
                          style: TextStyle(
                            color: scheme.onSurface,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                        const Spacer(),
                        Text(
                          '${speed.toStringAsFixed(2)}x',
                          style: TextStyle(
                            color: scheme.primary,
                            fontWeight: FontWeight.w700,
                            fontFamily: 'english',
                          ),
                        ),
                      ],
                    ),
                    Slider(
                      value: speed,
                      min: 0.75,
                      max: 1.5,
                      divisions: 3,
                      onChanged: onSpeedChanged,
                    ),
                    const SizedBox(height: 4),
                    Row(
                      children: [
                        Text(
                          'سکرۆڵی خۆکار',
                          style: TextStyle(
                            color: scheme.onSurface,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                        const Spacer(),
                        Switch(
                          value: autoScroll,
                          onChanged: onAutoScrollChanged,
                          activeThumbColor: Colors.white,
                          activeTrackColor: scheme.primary,
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 8),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                _roundButton(
                  context,
                  icon: Icons.skip_previous_rounded,
                  onTap: onPrevious,
                ),
                const SizedBox(width: 14),
                _roundButton(
                  context,
                  icon: isPlaying
                      ? Icons.pause_circle_rounded
                      : Icons.play_circle_rounded,
                  isPrimary: true,
                  onTap: onPlayPause,
                ),
                const SizedBox(width: 14),
                _roundButton(
                  context,
                  icon: Icons.skip_next_rounded,
                  onTap: onNext,
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _playerHero(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return Container(
      height: 220,
      decoration: BoxDecoration(
        color: scheme.surfaceContainerHighest.withValues(alpha: 0.38),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: scheme.outline.withValues(alpha: 0.2)),
      ),
      child: Center(
        child: Icon(Icons.graphic_eq_rounded, color: scheme.primary, size: 92),
      ),
    );
  }

  Widget _actionChip(
    BuildContext context, {
    required String label,
    required IconData icon,
    required VoidCallback onTap,
  }) {
    final scheme = Theme.of(context).colorScheme;
    return Expanded(
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          borderRadius: BorderRadius.circular(12),
          onTap: onTap,
          child: Ink(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 10),
            decoration: BoxDecoration(
              color: scheme.surfaceContainerHighest.withValues(alpha: 0.45),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: scheme.outline.withValues(alpha: 0.2)),
            ),
            child: Row(
              children: [
                Icon(icon, size: 16, color: scheme.primary),
                const SizedBox(width: 6),
                Expanded(
                  child: Text(
                    label,
                    textDirection: TextDirection.rtl,
                    textAlign: TextAlign.right,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(
                      color: scheme.onSurface,
                      fontSize: 12.5,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _iconOnly(
    BuildContext context, {
    required IconData icon,
    required VoidCallback onTap,
  }) {
    final scheme = Theme.of(context).colorScheme;
    return Material(
      color: Colors.transparent,
      child: InkWell(
        borderRadius: BorderRadius.circular(12),
        onTap: onTap,
        child: Ink(
          width: 40,
          height: 40,
          decoration: BoxDecoration(
            color: scheme.surfaceContainerHighest.withValues(alpha: 0.45),
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: scheme.outline.withValues(alpha: 0.2)),
          ),
          child: Icon(icon, color: scheme.primary, size: 20),
        ),
      ),
    );
  }

  Widget _roundButton(
    BuildContext context, {
    required IconData icon,
    required VoidCallback onTap,
    bool isPrimary = false,
  }) {
    final scheme = Theme.of(context).colorScheme;
    return Material(
      color: Colors.transparent,
      child: InkWell(
        borderRadius: BorderRadius.circular(99),
        onTap: onTap,
        child: Ink(
          width: isPrimary ? 64 : 52,
          height: isPrimary ? 64 : 52,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: isPrimary
                ? scheme.primary.withValues(alpha: 0.16)
                : scheme.surfaceContainerHighest.withValues(alpha: 0.45),
            border: Border.all(
              color: isPrimary
                  ? scheme.primary.withValues(alpha: 0.35)
                  : scheme.outline.withValues(alpha: 0.2),
            ),
          ),
          child: Icon(
            icon,
            color: isPrimary ? scheme.primary : scheme.onSurfaceVariant,
            size: isPrimary ? 38 : 28,
          ),
        ),
      ),
    );
  }
}
