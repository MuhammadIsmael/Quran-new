import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:loading_indicator/loading_indicator.dart';
import 'package:provider/provider.dart';
import 'package:runaki_islam/Screens/HomeItems/Qurani%20Piroz/data/models/quran_meta.dart';
import 'package:runaki_islam/Screens/HomeItems/Qurani%20Piroz/data/models/surahinfo.dart';
import 'package:runaki_islam/Screens/HomeItems/Qurani%20Piroz/data/services.dart';
import 'package:runaki_islam/Screens/HomeItems/Qurani%20Piroz/ui/detail_surah.dart';
import 'package:runaki_islam/providers/quran_state_provider.dart';
import 'package:runaki_islam/providers/settings_provider.dart';
import 'package:runaki_islam/util/animation_helper.dart';
import 'package:runaki_islam/util/constans.dart';
import 'package:runaki_islam/util/quran_font_registry.dart';

class QuranPage extends StatefulWidget {
  const QuranPage({super.key, this.isTabMode = false});

  final bool isTabMode;

  @override
  State<QuranPage> createState() => _QuranPageState();
}

class _QuranPageState extends State<QuranPage>
    with AutomaticKeepAliveClientMixin {
  static const String _allFilterValue = 'هەموو';

  final TextEditingController _searchController = TextEditingController();
  final ServiceData _serviceData = ServiceData();
  late final Future<List<SurahInfo>> _surahFuture;

  Map<int, Set<int>> _juzBySurah = <int, Set<int>>{};
  Map<int, Set<int>> _hizbBySurah = <int, Set<int>>{};
  Map<int, Set<int>> _pageBySurah = <int, Set<int>>{};

  int _lastReadAyah = 1;
  int? fontType;
  int? quranFontType;

  String _searchQuery = '';
  String _selectedRevelation = _allFilterValue;
  String _selectedJuz = _allFilterValue;
  String _selectedHizb = _allFilterValue;
  String _selectedPage = _allFilterValue;

  final List<QuranAyahSearchResult> _ayahSearchResults =
      <QuranAyahSearchResult>[];
  bool _ayahSearchLoading = false;
  String? _ayahSearchError;
  Timer? _ayahSearchDebounce;

  @override
  void initState() {
    super.initState();
    fontType = Provider.of<SettingsProvider>(
      context,
      listen: false,
    ).getsettingField('font_family');
    quranFontType = Provider.of<SettingsProvider>(
      context,
      listen: false,
    ).getsettingField('quran_font_family');
    quranFontType = normalizeQuranFontFamily(quranFontType);
    _surahFuture = _serviceData.loadInfo();
    _prepareFilterIndexes();
    _searchController.addListener(() {
      final nextQuery = _searchController.text.trim();
      setState(() {
        _searchQuery = nextQuery;
      });
      _scheduleAyahSearch(nextQuery);
    });
  }

  @override
  void dispose() {
    _searchController.dispose();
    _ayahSearchDebounce?.cancel();
    super.dispose();
  }

  bool get _shouldShowAyahSearchSection {
    if (_searchQuery.isEmpty) return false;
    if (_searchQuery.contains(':')) return false;
    return _searchQuery.length > 1;
  }

  void _scheduleAyahSearch(String query) {
    _ayahSearchDebounce?.cancel();
    if (!_shouldShowAyahSearchSection) {
      setState(() {
        _ayahSearchLoading = false;
        _ayahSearchError = null;
        _ayahSearchResults.clear();
      });
      return;
    }

    _ayahSearchDebounce = Timer(const Duration(milliseconds: 380), () {
      _executeAyahSearch(query);
    });
  }

  Future<void> _executeAyahSearch(String query) async {
    setState(() {
      _ayahSearchLoading = true;
      _ayahSearchError = null;
    });

    try {
      final results = await _serviceData.searchAyahs(query);
      if (!mounted) return;
      setState(() {
        _ayahSearchResults
          ..clear()
          ..addAll(results);
        _ayahSearchLoading = false;
      });
    } catch (_) {
      if (!mounted) return;
      setState(() {
        _ayahSearchError = 'نەتوانرا گەڕانت انجام بدرێت.';
        _ayahSearchLoading = false;
      });
    }
  }

  Widget _ayahSearchResultsSection(BuildContext context, List<SurahInfo> data) {
    final scheme = Theme.of(context).colorScheme;
    final results = _ayahSearchResults;
    final hasResults = results.isNotEmpty;

    return Container(
      margin: const EdgeInsets.fromLTRB(14, 10, 14, 0),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: scheme.surface.withValues(alpha: 0.92),
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: scheme.outline.withValues(alpha: 0.18)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.end,
        children: [
          Row(
            children: [
              Expanded(
                child: Text(
                  'ئەنجامەکانی گەڕان',
                  textDirection: TextDirection.rtl,
                  style: TextStyle(
                    fontFamily: fontType.toString(),
                    color: scheme.onSurface,
                    fontSize: 16,
                    fontWeight: FontWeight.w800,
                  ),
                ),
              ),
              if (_ayahSearchLoading)
                SizedBox(
                  width: 20,
                  height: 20,
                  child: CircularProgressIndicator(
                    strokeWidth: 2.2,
                    color: scheme.primary,
                  ),
                ),
            ],
          ),
          const SizedBox(height: 12),
          if (_ayahSearchLoading)
            Text(
              'ئەم کاتە گەڕان دەکرێت …',
              textDirection: TextDirection.rtl,
              style: TextStyle(
                fontFamily: fontType.toString(),
                color: scheme.onSurfaceVariant,
              ),
            )
          else if (_ayahSearchError != null)
            Text(
              _ayahSearchError!,
              textDirection: TextDirection.rtl,
              style: TextStyle(
                fontFamily: fontType.toString(),
                color: scheme.error,
              ),
            )
          else if (!hasResults)
            Text(
              'هیچ ئەیەتێک نەدۆزرایەوە. تکایە وشەیەک بچوکیتر یان وردتر بنووسە.',
              textDirection: TextDirection.rtl,
              style: TextStyle(
                fontFamily: fontType.toString(),
                color: scheme.onSurfaceVariant,
              ),
            )
          else
            Column(
              children: results
                  .take(8)
                  .map(
                    (result) => Padding(
                      padding: const EdgeInsets.only(bottom: 10),
                      child: Material(
                        color: Colors.transparent,
                        child: InkWell(
                          borderRadius: BorderRadius.circular(16),
                          onTap: () {
                            final surah = _findByIndex(
                              data,
                              result.surahNumber,
                            );
                            if (surah != null) {
                              _openSurah(surah, forcedAyah: result.ayahNumber);
                            }
                          },
                          child: Ink(
                            padding: const EdgeInsets.all(14),
                            decoration: BoxDecoration(
                              color: scheme.surfaceContainerHighest.withValues(
                                alpha: 0.45,
                              ),
                              borderRadius: BorderRadius.circular(16),
                              border: Border.all(
                                color: scheme.outline.withValues(alpha: 0.15),
                              ),
                            ),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.end,
                              children: [
                                Row(
                                  children: [
                                    Expanded(
                                      child: Text(
                                        'سوڕە ${result.surahNumber} — ${result.surahName}',
                                        textDirection: TextDirection.rtl,
                                        textAlign: TextAlign.right,
                                        style: TextStyle(
                                          fontFamily: fontType.toString(),
                                          color: scheme.onSurface,
                                          fontWeight: FontWeight.w700,
                                        ),
                                      ),
                                    ),
                                    const SizedBox(width: 8),
                                    Container(
                                      padding: const EdgeInsets.symmetric(
                                        horizontal: 10,
                                        vertical: 6,
                                      ),
                                      decoration: BoxDecoration(
                                        color: scheme.primary.withValues(
                                          alpha: 0.14,
                                        ),
                                        borderRadius: BorderRadius.circular(12),
                                      ),
                                      child: Text(
                                        'ئایەت ${result.ayahNumber}',
                                        textDirection: TextDirection.rtl,
                                        style: TextStyle(
                                          fontFamily: "english",
                                          color: scheme.primary,
                                          fontWeight: FontWeight.w700,
                                          fontSize: 12,
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                                const SizedBox(height: 10),
                                _buildHighlightedAyahSnippet(
                                  result.arabicText,
                                  _searchQuery,
                                  TextStyle(
                                    fontFamily: (quranFontType ?? 13)
                                        .toString(),
                                    color: scheme.onSurfaceVariant,
                                    height: 1.65,
                                  ),
                                  TextStyle(
                                    fontFamily: (quranFontType ?? 13)
                                        .toString(),
                                    color: scheme.onSurface,
                                    height: 1.65,
                                    backgroundColor: scheme.primary.withValues(
                                      alpha: 0.18,
                                    ),
                                    fontWeight: FontWeight.w700,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                    ),
                  )
                  .toList(),
            ),
        ],
      ),
    );
  }

  String _truncateAyahSnippet(String value) {
    final normalized = value.replaceAll(RegExp(r'\s+'), ' ').trim();
    if (normalized.length <= 72) return normalized;
    return '${normalized.substring(0, 72).trimRight()}...';
  }

  Widget _buildHighlightedAyahSnippet(
    String value,
    String query,
    TextStyle baseStyle,
    TextStyle highlightStyle,
  ) {
    final normalizedQuery = query.trim();
    final snippet = _truncateAyahSnippet(value);
    if (normalizedQuery.isEmpty) {
      return Text(
        snippet,
        textDirection: TextDirection.rtl,
        textAlign: TextAlign.right,
        style: baseStyle,
      );
    }

    final pattern = RegExp(
      RegExp.escape(normalizedQuery),
      caseSensitive: false,
      unicode: true,
    );
    final matches = pattern.allMatches(snippet).toList();
    if (matches.isEmpty) {
      return Text(
        snippet,
        textDirection: TextDirection.rtl,
        textAlign: TextAlign.right,
        style: baseStyle,
      );
    }

    final spans = <InlineSpan>[];
    var lastMatchEnd = 0;
    for (final match in matches) {
      if (match.start > lastMatchEnd) {
        spans.add(
          TextSpan(
            text: snippet.substring(lastMatchEnd, match.start),
            style: baseStyle,
          ),
        );
      }
      spans.add(
        TextSpan(
          text: snippet.substring(match.start, match.end),
          style: highlightStyle,
        ),
      );
      lastMatchEnd = match.end;
    }
    if (lastMatchEnd < snippet.length) {
      spans.add(
        TextSpan(text: snippet.substring(lastMatchEnd), style: baseStyle),
      );
    }

    return RichText(
      textDirection: TextDirection.rtl,
      textAlign: TextAlign.right,
      text: TextSpan(children: spans),
      maxLines: 3,
      overflow: TextOverflow.ellipsis,
    );
  }

  @override
  Widget build(BuildContext context) {
    super.build(context);
    final settings = context.watch<SettingsProvider>();
    fontType = settings.getsettingField('font_family');
    quranFontType = normalizeQuranFontFamily(
      settings.getsettingField('quran_font_family'),
    );
    final scheme = Theme.of(context).colorScheme;
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final quranState = context.watch<QuranStateProvider>();

    return Scaffold(
      backgroundColor: bgColor,
      body: Stack(
        children: [
          Positioned.fill(
            child: CustomPaint(
              painter: _IslamicPatternPainter(
                color: scheme.primary.withValues(alpha: isDark ? 0.05 : 0.035),
              ),
            ),
          ),
          SafeArea(
            child: FutureBuilder<List<SurahInfo>>(
              future: _surahFuture,
              builder: (context, snapshot) {
                if (!snapshot.hasData) {
                  return _loadingView(context);
                }

                final data = snapshot.data!;
                final filtered = _applyFilters(data);
                _lastReadAyah = quranState.lastReadAyah;
                final lastRead = _findByIndex(
                  data,
                  quranState.lastReadSurahIndex,
                );
                final favoriteIndexes = quranState.favoriteSurahs;
                final bookmarkIndexes = quranState.bookmarkedSurahs;
                final favorites = data
                    .where((item) => favoriteIndexes.contains(item.index))
                    .toList();
                final bookmarked = data
                    .where((item) => bookmarkIndexes.contains(item.index))
                    .toList();

                return Column(
                  children: [
                    _topBar(context),
                    Expanded(
                      child: CustomScrollView(
                        physics: const BouncingScrollPhysics(
                          parent: AlwaysScrollableScrollPhysics(),
                        ),
                        slivers: [
                          SliverToBoxAdapter(
                            child: FadeSlideIn(
                              child: _continueReadingCard(
                                context: context,
                                data: data,
                                lastRead: lastRead,
                              ),
                            ),
                          ),
                          SliverToBoxAdapter(
                            child: FadeSlideIn(
                              delay: const Duration(milliseconds: 40),
                              child: _searchAndFilterSection(context),
                            ),
                          ),
                          if (_searchQuery.contains(":"))
                            SliverToBoxAdapter(
                              child: FadeSlideIn(
                                delay: const Duration(milliseconds: 60),
                                child: _ayahSearchHint(context),
                              ),
                            ),
                          if (_shouldShowAyahSearchSection)
                            SliverToBoxAdapter(
                              child: FadeSlideIn(
                                delay: const Duration(milliseconds: 60),
                                child: _ayahSearchResultsSection(context, data),
                              ),
                            ),
                          if (favorites.isNotEmpty || bookmarked.isNotEmpty)
                            SliverToBoxAdapter(
                              child: FadeSlideIn(
                                delay: const Duration(milliseconds: 70),
                                child: _favoriteSection(
                                  context,
                                  favorites: favorites,
                                  bookmarks: bookmarked,
                                ),
                              ),
                            ),
                          SliverToBoxAdapter(
                            child: _listHeader(context, filtered.length),
                          ),
                          SliverPadding(
                            padding: const EdgeInsets.fromLTRB(12, 0, 12, 110),
                            sliver: SliverList.builder(
                              itemCount: filtered.length,
                              itemBuilder: (context, index) {
                                final surah = filtered[index];
                                return FadeSlideIn(
                                  delay: Duration(
                                    milliseconds: 30 + (index.clamp(0, 6) * 20),
                                  ),
                                  offsetY: 8,
                                  child: _SurahLibraryCard(
                                    surah: surah,
                                    fontFamily: fontType.toString(),
                                    quranFontFamily: (quranFontType ?? 13)
                                        .toString(),
                                    isFavorite: favoriteIndexes.contains(
                                      surah.index,
                                    ),
                                    isBookmarked: bookmarkIndexes.contains(
                                      surah.index,
                                    ),
                                    revelationType: _revelationLabel(surah),
                                    onFavoriteTap: () {
                                      final surahIndex = surah.index;
                                      if (surahIndex == null) return;
                                      quranState.toggleFavoriteSurah(
                                        surahIndex,
                                      );
                                    },
                                    onBookmarkTap: () {
                                      final surahIndex = surah.index;
                                      if (surahIndex == null) return;
                                      quranState.toggleSurahBookmark(
                                        surahIndex,
                                      );
                                    },
                                    onTap: () => _openSurah(surah),
                                  ),
                                );
                              },
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  Widget _loadingView(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return Column(
      children: [
        _topBar(context),
        Expanded(
          child: Center(
            child: SizedBox(
              width: 86,
              child: LoadingIndicator(
                indicatorType: Indicator.ballSpinFadeLoader,
                colors: [scheme.primary, scheme.secondary],
              ),
            ),
          ),
        ),
      ],
    );
  }

  Widget _topBar(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return Padding(
      padding: const EdgeInsets.fromLTRB(14, 8, 14, 4),
      child: Container(
        height: 56,
        padding: const EdgeInsets.symmetric(horizontal: 8),
        decoration: BoxDecoration(
          color: scheme.surface.withValues(alpha: 0.92),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: scheme.outline.withValues(alpha: 0.18)),
          boxShadow: [
            BoxShadow(
              color: scheme.shadow.withValues(alpha: 0.10),
              blurRadius: 14,
              offset: const Offset(0, 6),
            ),
          ],
        ),
        child: Row(
          children: [
            if (!widget.isTabMode)
              _topIcon(
                context,
                icon: Icons.arrow_back_ios_new_rounded,
                onTap: () => Navigator.pop(context),
              )
            else
              const SizedBox(width: 40),
            Expanded(
              child: Text(
                "القرآن الكريم",
                textAlign: TextAlign.center,
                textDirection: TextDirection.rtl,
                style: TextStyle(
                  fontFamily: fontType.toString(),
                  fontSize: 24,
                  color: scheme.onSurface,
                  fontWeight: FontWeight.w700,
                ),
              ),
            ),
            const SizedBox(width: 40),
          ],
        ),
      ),
    );
  }

  Widget _topIcon(
    BuildContext context, {
    required IconData icon,
    required VoidCallback onTap,
  }) {
    final scheme = Theme.of(context).colorScheme;
    return Material(
      color: Colors.transparent,
      child: InkWell(
        borderRadius: BorderRadius.circular(12),
        onTap: onTap,
        child: Ink(
          width: 40,
          height: 40,
          decoration: BoxDecoration(
            color: scheme.surfaceContainerHighest.withValues(alpha: 0.38),
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: scheme.outline.withValues(alpha: 0.2)),
          ),
          child: Icon(icon, color: scheme.onSurfaceVariant, size: 20),
        ),
      ),
    );
  }

  Widget _listHeader(BuildContext context, int count) {
    final scheme = Theme.of(context).colorScheme;
    return Padding(
      padding: const EdgeInsets.fromLTRB(14, 14, 14, 8),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 5),
            decoration: BoxDecoration(
              color: scheme.primary.withValues(alpha: 0.1),
              borderRadius: BorderRadius.circular(10),
            ),
            child: Text(
              count.toString(),
              style: TextStyle(
                fontFamily: "english",
                color: scheme.primary,
                fontWeight: FontWeight.w700,
              ),
            ),
          ),
          const Spacer(),
          Text(
            "لیستی سوڕەکان",
            textDirection: TextDirection.rtl,
            style: TextStyle(
              fontFamily: fontType.toString(),
              color: scheme.onSurface,
              fontSize: 18,
              fontWeight: FontWeight.w800,
            ),
          ),
        ],
      ),
    );
  }

  Widget _continueReadingCard({
    required BuildContext context,
    required List<SurahInfo> data,
    required SurahInfo? lastRead,
  }) {
    final scheme = Theme.of(context).colorScheme;
    final SurahInfo? fallback = data.isNotEmpty ? data.first : null;
    final current = lastRead ?? fallback;

    return Container(
      margin: const EdgeInsets.fromLTRB(14, 10, 14, 0),
      padding: const EdgeInsets.fromLTRB(14, 14, 14, 14),
      decoration: BoxDecoration(
        color: scheme.surface.withValues(alpha: 0.92),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: scheme.outline.withValues(alpha: 0.2)),
        boxShadow: [
          BoxShadow(
            color: scheme.shadow.withValues(alpha: 0.1),
            blurRadius: 16,
            offset: const Offset(0, 6),
          ),
        ],
      ),
      child: Row(
        children: [
          SizedBox(
            width: 44,
            height: 44,
            child: Stack(
              alignment: Alignment.center,
              children: [
                SvgPicture.asset(
                  'assets/icons/quran/suraNum.svg',
                  width: 44,
                  height: 44,
                ),
                Text(
                  (current?.index ?? '-').toString(),
                  style: const TextStyle(
                    color: Colors.white,
                    fontFamily: 'english',
                    fontWeight: FontWeight.w800,
                    fontSize: 12.5,
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                Text(
                  "بەردەوامبوون لە خوێندنەوە",
                  textDirection: TextDirection.rtl,
                  style: TextStyle(
                    fontFamily: fontType.toString(),
                    color: scheme.onSurface,
                    fontWeight: FontWeight.w800,
                    fontSize: 16,
                  ),
                ),
                const SizedBox(height: 6),
                if (current != null) ...[
                  SizedBox(
                    height: 36,
                    child: Stack(
                      alignment: Alignment.center,
                      children: [
                        // Positioned.fill(
                        //   child: SvgPicture.asset(
                        //     'assets/icons/quran/surahSvgBanner.svg',
                        //     fit: BoxFit.fill,
                        //   ),
                        // ),
                        Text(
                          current.arabic ?? "",
                          textDirection: TextDirection.rtl,
                          textAlign: TextAlign.center,
                          style: TextStyle(
                            color: Color(0xFF5A4322),
                            fontFamily: (quranFontType ?? 13).toString(),
                            fontWeight: FontWeight.w700,
                            fontSize: 19,
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 3),
                ],
                Text(
                  current == null
                      ? "دوایین شوێنی خوێندنەوە بەردەست نییە"
                      : "ئایەت: $_lastReadAyah",
                  textDirection: TextDirection.rtl,
                  style: TextStyle(
                    fontFamily: fontType.toString(),
                    color: scheme.onSurfaceVariant,
                    fontWeight: FontWeight.w600,
                    fontSize: 13,
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(width: 8),
          FilledButton.tonal(
            onPressed: current == null
                ? null
                : () => _openSurah(current, forcedAyah: _lastReadAyah),
            child: Text(
              "خوێندنەوە",
              style: TextStyle(fontFamily: fontType.toString()),
            ),
          ),
        ],
      ),
    );
  }

  Widget _searchAndFilterSection(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return Container(
      margin: const EdgeInsets.fromLTRB(14, 12, 14, 0),
      padding: const EdgeInsets.fromLTRB(12, 12, 12, 12),
      decoration: BoxDecoration(
        color: scheme.surface.withValues(alpha: 0.9),
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: scheme.outline.withValues(alpha: 0.18)),
      ),
      child: Column(
        children: [
          TextField(
            controller: _searchController,
            textDirection: TextDirection.rtl,
            style: TextStyle(fontFamily: fontType.toString()),
            decoration: InputDecoration(
              hintText: "گەڕان بە ناوی سوڕە یان وشەی ئایەت",
              hintTextDirection: TextDirection.rtl,
              prefixIcon: const Icon(Icons.search_rounded),
              filled: true,
              fillColor: scheme.surfaceContainerHighest.withValues(alpha: 0.38),
              contentPadding: const EdgeInsets.symmetric(
                horizontal: 12,
                vertical: 12,
              ),
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(14),
                borderSide: BorderSide(
                  color: scheme.outline.withValues(alpha: 0.2),
                ),
              ),
              enabledBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(14),
                borderSide: BorderSide(
                  color: scheme.outline.withValues(alpha: 0.2),
                ),
              ),
            ),
          ),
          const SizedBox(height: 10),
          SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            physics: const BouncingScrollPhysics(),
            child: Row(
              children: [
                _filterChip(
                  context,
                  label: "جوز: $_selectedJuz",
                  onTap: () => _showJuzFilterSheet(context),
                ),
                const SizedBox(width: 8),
                _filterChip(
                  context,
                  label: "حزب: $_selectedHizb",
                  onTap: () => _showHizbFilterSheet(context),
                ),
                const SizedBox(width: 8),
                _filterChip(
                  context,
                  label: "لاپەڕە: $_selectedPage",
                  onTap: () => _showPageFilterSheet(context),
                ),
                const SizedBox(width: 8),
                _filterChip(
                  context,
                  label: "دابەزین: $_selectedRevelation",
                  onTap: () => _showRevelationFilterSheet(context),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _ayahSearchHint(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return Container(
      margin: const EdgeInsets.fromLTRB(14, 10, 14, 0),
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
      decoration: BoxDecoration(
        color: scheme.secondary.withValues(alpha: 0.16),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Text(
        _buildAyahSearchHintText(),
        textDirection: TextDirection.rtl,
        textAlign: TextAlign.right,
        style: TextStyle(
          fontFamily: fontType.toString(),
          color: scheme.onSurface,
          fontSize: 12.8,
          fontWeight: FontWeight.w600,
        ),
      ),
    );
  }

  Widget _favoriteSection(
    BuildContext context, {
    required List<SurahInfo> favorites,
    required List<SurahInfo> bookmarks,
  }) {
    final scheme = Theme.of(context).colorScheme;
    final entries = <_PinnedEntry>[
      ...favorites.map((e) => _PinnedEntry(title: "دڵخواز", surah: e)),
      ...bookmarks.map((e) => _PinnedEntry(title: "نیشانەکراو", surah: e)),
    ];

    return Container(
      margin: const EdgeInsets.fromLTRB(14, 10, 14, 0),
      padding: const EdgeInsets.fromLTRB(12, 12, 12, 12),
      decoration: BoxDecoration(
        color: scheme.surface.withValues(alpha: 0.9),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: scheme.outline.withValues(alpha: 0.2)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.end,
        children: [
          Text(
            "دڵخواز و نیشانەکراوەکان",
            textDirection: TextDirection.rtl,
            style: TextStyle(
              fontFamily: fontType.toString(),
              color: scheme.onSurface,
              fontWeight: FontWeight.w800,
              fontSize: 16,
            ),
          ),
          const SizedBox(height: 10),
          SizedBox(
            height: 114,
            child: ListView.separated(
              reverse: true,
              scrollDirection: Axis.horizontal,
              physics: const BouncingScrollPhysics(),
              itemBuilder: (context, index) {
                final entry = entries[index];
                return Material(
                  color: Colors.transparent,
                  child: InkWell(
                    borderRadius: BorderRadius.circular(14),
                    onTap: () => _openSurah(entry.surah),
                    child: Ink(
                      width: 188,
                      padding: const EdgeInsets.all(10),
                      decoration: BoxDecoration(
                        color: scheme.surfaceContainerHighest.withValues(
                          alpha: 0.4,
                        ),
                        borderRadius: BorderRadius.circular(14),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.end,
                        children: [
                          Row(
                            children: [
                              SizedBox(
                                width: 30,
                                height: 30,
                                child: Stack(
                                  alignment: Alignment.center,
                                  children: [
                                    SvgPicture.asset(
                                      'assets/icons/quran/suraNum.svg',
                                      width: 30,
                                      height: 30,
                                    ),
                                    Text(
                                      (entry.surah.index ?? '-').toString(),
                                      style: const TextStyle(
                                        color: Colors.white,
                                        fontFamily: 'english',
                                        fontWeight: FontWeight.w700,
                                        fontSize: 10.5,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              const Spacer(),
                              Text(
                                entry.title,
                                textDirection: TextDirection.rtl,
                                style: TextStyle(
                                  fontFamily: fontType.toString(),
                                  color: scheme.primary,
                                  fontSize: 12.5,
                                  fontWeight: FontWeight.w700,
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(height: 5),
                          SizedBox(
                            height: 32,
                            child: Stack(
                              alignment: Alignment.center,
                              children: [
                                // Positioned.fill(
                                //   child: SvgPicture.asset(
                                //     'assets/icons/quran/surahSvgBanner.svg',
                                //     fit: BoxFit.fill,
                                //   ),
                                // ),
                                Text(
                                  entry.surah.arabic ?? "",
                                  textDirection: TextDirection.rtl,
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                  style: const TextStyle(
                                    color: Color(0xFF5A4322),
                                    fontSize: 16,
                                    fontWeight: FontWeight.w700,
                                  ),
                                ),
                              ],
                            ),
                          ),
                          const Spacer(),
                          Text(
                            "ژمارە: ${entry.surah.index ?? "-"}",
                            style: TextStyle(
                              color: scheme.onSurfaceVariant,
                              fontSize: 12,
                              fontFamily: "english",
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                );
              },
              separatorBuilder: (context, index) => const SizedBox(width: 8),
              itemCount: entries.length,
            ),
          ),
        ],
      ),
    );
  }

  Widget _filterChip(
    BuildContext context, {
    required String label,
    required VoidCallback onTap,
  }) {
    final scheme = Theme.of(context).colorScheme;
    return Material(
      color: Colors.transparent,
      child: InkWell(
        borderRadius: BorderRadius.circular(11),
        onTap: onTap,
        child: Ink(
          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
          decoration: BoxDecoration(
            color: scheme.surfaceContainerHighest.withValues(alpha: 0.45),
            borderRadius: BorderRadius.circular(11),
            border: Border.all(color: scheme.outline.withValues(alpha: 0.2)),
          ),
          child: Text(
            label,
            textDirection: TextDirection.rtl,
            style: TextStyle(
              fontFamily: fontType.toString(),
              color: scheme.onSurface,
              fontSize: 12.8,
              fontWeight: FontWeight.w600,
            ),
          ),
        ),
      ),
    );
  }

  List<SurahInfo> _applyFilters(List<SurahInfo> data) {
    final ayahAddress = _extractSurahAyahFromQuery(_searchQuery);
    return data.where((surah) {
      final query = _searchQuery.toLowerCase().trim();
      final arabic = (surah.arabic ?? '').toLowerCase();
      final latin = (surah.latin ?? '').toLowerCase();
      final translation = (surah.translation ?? '').toLowerCase();
      final index = (surah.index ?? 0).toString();
      final surahIndex = surah.index;

      final queryMatch = ayahAddress != null
          ? surahIndex == ayahAddress.surah
          : query.isEmpty ||
                arabic.contains(query) ||
                latin.contains(query) ||
                translation.contains(query) ||
                index.contains(query);

      final revelationLabel = _revelationLabel(surah);
      final revelationMatch =
          _selectedRevelation == _allFilterValue ||
          revelationLabel == _selectedRevelation;

      final selectedJuz = int.tryParse(_selectedJuz);
      final selectedHizb = int.tryParse(_selectedHizb);
      final selectedPage = int.tryParse(_selectedPage);

      final juzMatch = _matchesSegmentFilter(
        _juzBySurah,
        surahIndex,
        selectedJuz,
      );
      final hizbMatch = _matchesSegmentFilter(
        _hizbBySurah,
        surahIndex,
        selectedHizb,
      );
      final pageMatch = _matchesSegmentFilter(
        _pageBySurah,
        surahIndex,
        selectedPage,
      );

      return queryMatch &&
          revelationMatch &&
          juzMatch &&
          hizbMatch &&
          pageMatch;
    }).toList();
  }

  bool _matchesSegmentFilter(
    Map<int, Set<int>> segmentMap,
    int? surahIndex,
    int? selectedSegment,
  ) {
    if (selectedSegment == null) return true;
    if (surahIndex == null) return false;
    if (segmentMap.isEmpty) return true;
    return segmentMap[surahIndex]?.contains(selectedSegment) ?? false;
  }

  String _revelationLabel(SurahInfo surah) {
    final source = (surah.opening ?? '').toLowerCase();
    if (source.contains('madaniyyah') ||
        source.contains('madinah') ||
        source.contains('medinan') ||
        source.contains('مدني') ||
        source.contains('مدنية')) {
      return 'مەدەنی';
    }
    if (source.contains('makkiyyah') ||
        source.contains('meccan') ||
        source.contains('mekah') ||
        source.contains('makkah') ||
        source.contains('مكي') ||
        source.contains('مكية')) {
      return 'مەککی';
    }
    return 'نەزانراو';
  }

  SurahInfo? _findByIndex(List<SurahInfo> items, int? index) {
    if (index == null) return null;
    try {
      return items.firstWhere((e) => e.index == index);
    } catch (_) {
      return null;
    }
  }

  Future<void> _openSurah(SurahInfo surah, {int? forcedAyah}) async {
    final surahIndex = surah.index;
    if (surahIndex == null) return;

    final quranState = context.read<QuranStateProvider>();
    final queryAddress = _extractSurahAyahFromQuery(_searchQuery);

    int startAyah = forcedAyah ?? 1;
    if (forcedAyah == null &&
        queryAddress != null &&
        queryAddress.surah == surahIndex) {
      startAyah = queryAddress.ayah;
    }

    final ayahCount = surah.ayahCount ?? 1;
    startAyah = startAyah.clamp(1, ayahCount).toInt();
    await quranState.setLastRead(surahIndex: surahIndex, ayahNumber: startAyah);
    if (!mounted) return;

    final result = await Navigator.push<QuranViewResult>(
      context,
      MaterialPageRoute(
        builder: (context) => QuranViewPage(
          detail: surah.arabic,
          ayahcount: "ژمارەی ئایەت: ${surah.ayahCount.toString()}",
          indexx: surahIndex,
          startAyah: startAyah,
        ),
      ),
    );

    if (!mounted) return;

    if (result != null) {
      await quranState.setLastRead(
        surahIndex: result.surahIndex,
        ayahNumber: result.lastReadAyah,
      );
    }
  }

  _AyahAddress? _extractSurahAyahFromQuery(String query) {
    final match = RegExp(r'^\s*(\d+)\s*[:.]\s*(\d+)\s*$').firstMatch(query);
    if (match == null) return null;
    final surah = int.tryParse(match.group(1)!);
    final ayah = int.tryParse(match.group(2)!);
    if (surah == null || ayah == null || surah < 1 || ayah < 1) return null;
    return _AyahAddress(surah: surah, ayah: ayah);
  }

  String _buildAyahSearchHintText() {
    final address = _extractSurahAyahFromQuery(_searchQuery);
    if (address == null) {
      return "بۆ چوونە ناو ئایەت، بە شێوەی (2:255) بنووسە.";
    }
    return "گەڕان چالاکە بۆ سوڕەی ${address.surah}، ئایەتی ${address.ayah}.";
  }

  Future<void> _showRevelationFilterSheet(BuildContext context) async {
    final values = <String>[_allFilterValue, 'مەککی', 'مەدەنی', 'نەزانراو'];
    final selected = await showModalBottomSheet<String>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (_) => _SimpleFilterSheet(
        title: 'فلتەری دابەزین',
        values: values,
        selected: _selectedRevelation,
      ),
    );
    if (selected != null) {
      setState(() => _selectedRevelation = selected);
    }
  }

  Future<void> _showJuzFilterSheet(BuildContext context) async {
    final values = _availableSegmentValues(_juzBySurah, maxValue: 30);
    final selected = await _showNumericFilterSheet(
      context,
      title: 'فلتەری جوز',
      values: values,
      selected: _selectedJuz,
    );
    if (selected != null) {
      setState(() => _selectedJuz = selected);
    }
  }

  Future<void> _showHizbFilterSheet(BuildContext context) async {
    final values = _availableSegmentValues(_hizbBySurah, maxValue: 60);
    final selected = await _showNumericFilterSheet(
      context,
      title: 'فلتەری حزب',
      values: values,
      selected: _selectedHizb,
    );
    if (selected != null) {
      setState(() => _selectedHizb = selected);
    }
  }

  Future<void> _showPageFilterSheet(BuildContext context) async {
    final controller = TextEditingController(
      text: _selectedPage == _allFilterValue ? '' : _selectedPage,
    );
    final selected = await showModalBottomSheet<String>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (_) {
        final scheme = Theme.of(context).colorScheme;
        final viewInsets = MediaQuery.viewInsetsOf(context).bottom;
        final maxHeight = MediaQuery.sizeOf(context).height * 0.56;
        return SafeArea(
          top: false,
          child: Padding(
            padding: EdgeInsets.only(bottom: viewInsets),
            child: Container(
              margin: const EdgeInsets.fromLTRB(10, 0, 10, 10),
              padding: const EdgeInsets.fromLTRB(14, 12, 14, 14),
              decoration: BoxDecoration(
                color: scheme.surface.withValues(alpha: 0.98),
                borderRadius: BorderRadius.circular(20),
                border: Border.all(
                  color: scheme.outline.withValues(alpha: 0.2),
                ),
              ),
              child: ConstrainedBox(
                constraints: BoxConstraints(maxHeight: maxHeight),
                child: SingleChildScrollView(
                  physics: const BouncingScrollPhysics(),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: [
                      Container(
                        width: 54,
                        height: 4,
                        decoration: BoxDecoration(
                          color: scheme.outline.withValues(alpha: 0.4),
                          borderRadius: BorderRadius.circular(99),
                        ),
                      ),
                      const SizedBox(height: 12),
                      Text(
                        'فلتەری لاپەڕە',
                        style: TextStyle(
                          color: scheme.onSurface,
                          fontWeight: FontWeight.w700,
                          fontSize: 16,
                        ),
                      ),
                      const SizedBox(height: 10),
                      TextField(
                        controller: controller,
                        keyboardType: TextInputType.number,
                        decoration: const InputDecoration(
                          hintText: 'ژمارەی لاپەڕە بنووسە (1-604)',
                        ),
                      ),
                      const SizedBox(height: 12),
                      Row(
                        children: [
                          TextButton(
                            onPressed: () =>
                                Navigator.of(context).pop(_allFilterValue),
                            child: const Text('پاککردنەوە'),
                          ),
                          const Spacer(),
                          FilledButton(
                            onPressed: () {
                              final value = int.tryParse(
                                controller.text.trim(),
                              );
                              if (value == null || value < 1 || value > 604) {
                                Navigator.of(context).pop(_allFilterValue);
                                return;
                              }
                              Navigator.of(context).pop(value.toString());
                            },
                            child: const Text('جێبەجێکردن'),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        );
      },
    );
    controller.dispose();
    if (selected != null) {
      setState(() => _selectedPage = selected);
    }
  }

  Future<String?> _showNumericFilterSheet(
    BuildContext context, {
    required String title,
    required List<String> values,
    required String selected,
  }) async {
    return showModalBottomSheet<String>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (_) =>
          _SimpleFilterSheet(title: title, values: values, selected: selected),
    );
  }

  List<String> _availableSegmentValues(
    Map<int, Set<int>> source, {
    required int maxValue,
  }) {
    final values = <int>{};
    for (final entry in source.values) {
      values.addAll(entry);
    }
    final sorted = values.toList()..sort();
    final fallback = List<int>.generate(maxValue, (index) => index + 1);
    final result = sorted.isEmpty ? fallback : sorted;
    return <String>[
      _allFilterValue,
      ...result.map((value) => value.toString()),
    ];
  }

  Future<void> _prepareFilterIndexes() async {
    try {
      final surahData = await _surahFuture;
      final ayahCounts = _buildAyahCountMap(surahData);
      final meta = await _serviceData.loadMeta();

      final hasMeta = meta.hasAnyData;
      final juz = hasMeta
          ? _buildSegmentIndex(meta.juzReferences, ayahCounts)
          : _buildApproximateSegmentIndex(ayahCounts, segmentCount: 30);
      final hizb = hasMeta
          ? _buildSegmentIndex(meta.hizbQuarterReferences, ayahCounts)
          : _buildApproximateSegmentIndex(ayahCounts, segmentCount: 60);
      final pages = hasMeta
          ? _buildSegmentIndex(meta.pageReferences, ayahCounts)
          : _buildApproximateSegmentIndex(ayahCounts, segmentCount: 604);

      if (!mounted) return;
      setState(() {
        _juzBySurah = juz;
        _hizbBySurah = hizb;
        _pageBySurah = pages;
      });
    } catch (_) {}
  }

  Map<int, int> _buildAyahCountMap(List<SurahInfo> data) {
    final result = <int, int>{};
    for (final surah in data) {
      final index = surah.index;
      final ayahCount = surah.ayahCount;
      if (index == null || ayahCount == null || ayahCount < 1) continue;
      result[index] = ayahCount;
    }
    return result;
  }

  Map<int, Set<int>> _buildSegmentIndex(
    List<QuranMetaReference> references,
    Map<int, int> ayahCounts,
  ) {
    if (references.isEmpty || ayahCounts.isEmpty) return <int, Set<int>>{};

    final ordered = List<QuranMetaReference>.from(references)
      ..sort(
        (a, b) => _AyahPointer.compare(
          _AyahPointer(a.surah, a.ayah),
          _AyahPointer(b.surah, b.ayah),
        ),
      );

    final result = <int, Set<int>>{};
    final surahIndexes = ayahCounts.keys.toList()..sort();

    for (int i = 0; i < ordered.length; i++) {
      final segment = i + 1;
      final start = _AyahPointer(ordered[i].surah, ordered[i].ayah);
      final end = i + 1 < ordered.length
          ? _AyahPointer(ordered[i + 1].surah, ordered[i + 1].ayah)
          : const _AyahPointer(115, 1);

      for (final surah in surahIndexes) {
        final ayahCount = ayahCounts[surah]!;
        final surahStart = _AyahPointer(surah, 1);
        final surahEnd = _AyahPointer(surah, ayahCount + 1);
        if (_AyahPointer.overlaps(start, end, surahStart, surahEnd)) {
          result.putIfAbsent(surah, () => <int>{}).add(segment);
        }
      }
    }
    return result;
  }

  Map<int, Set<int>> _buildApproximateSegmentIndex(
    Map<int, int> ayahCounts, {
    required int segmentCount,
  }) {
    final result = <int, Set<int>>{};
    if (ayahCounts.isEmpty || segmentCount < 1) return result;

    final surahIndexes = ayahCounts.keys.toList()..sort();
    final totalAyahs = ayahCounts.values.fold<int>(
      0,
      (sum, item) => sum + item,
    );
    final segmentSize = totalAyahs / segmentCount;
    if (segmentSize <= 0) return result;

    int runningAyah = 0;
    for (final surah in surahIndexes) {
      final count = ayahCounts[surah]!;
      final startAyah = runningAyah + 1;
      final endAyah = runningAyah + count;
      final startSegment = ((startAyah - 1) / segmentSize).floor() + 1;
      final endSegment = ((endAyah - 1) / segmentSize).floor() + 1;
      for (int segment = startSegment; segment <= endSegment; segment++) {
        if (segment < 1 || segment > segmentCount) continue;
        result.putIfAbsent(surah, () => <int>{}).add(segment);
      }
      runningAyah = endAyah;
    }

    return result;
  }

  @override
  bool get wantKeepAlive => true;
}

class _AyahAddress {
  const _AyahAddress({required this.surah, required this.ayah});

  final int surah;
  final int ayah;
}

class _AyahPointer {
  const _AyahPointer(this.surah, this.ayah);

  final int surah;
  final int ayah;

  static int compare(_AyahPointer a, _AyahPointer b) {
    if (a.surah != b.surah) return a.surah.compareTo(b.surah);
    return a.ayah.compareTo(b.ayah);
  }

  static bool overlaps(
    _AyahPointer startA,
    _AyahPointer endA,
    _AyahPointer startB,
    _AyahPointer endB,
  ) {
    return compare(startA, endB) < 0 && compare(startB, endA) < 0;
  }
}

class _PinnedEntry {
  _PinnedEntry({required this.title, required this.surah});

  final String title;
  final SurahInfo surah;
}

class _SurahLibraryCard extends StatelessWidget {
  const _SurahLibraryCard({
    required this.surah,
    required this.fontFamily,
    required this.quranFontFamily,
    required this.revelationType,
    required this.isFavorite,
    required this.isBookmarked,
    required this.onFavoriteTap,
    required this.onBookmarkTap,
    required this.onTap,
  });

  final SurahInfo surah;
  final String fontFamily;
  final String quranFontFamily;
  final String revelationType;
  final bool isFavorite;
  final bool isBookmarked;
  final VoidCallback onFavoriteTap;
  final VoidCallback onBookmarkTap;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final kurdishName = _maybeKurdishName(surah.translation);

    return Material(
      color: Colors.transparent,
      child: Padding(
        padding: const EdgeInsets.only(bottom: 10),
        child: InkWell(
          borderRadius: BorderRadius.circular(18),
          onTap: onTap,
          child: Ink(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: scheme.surface.withValues(alpha: 0.92),
              borderRadius: BorderRadius.circular(18),
              border: Border.all(color: scheme.outline.withValues(alpha: 0.18)),
              boxShadow: [
                BoxShadow(
                  color: scheme.shadow.withValues(alpha: 0.08),
                  blurRadius: 12,
                  offset: const Offset(0, 5),
                ),
              ],
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                Row(
                  children: [
                    _smallIcon(
                      context,
                      icon: isFavorite
                          ? Icons.favorite_rounded
                          : Icons.favorite_border_rounded,
                      onTap: onFavoriteTap,
                    ),
                    const SizedBox(width: 6),
                    _smallIcon(
                      context,
                      icon: isBookmarked
                          ? Icons.bookmark_rounded
                          : Icons.bookmark_border_rounded,
                      onTap: onBookmarkTap,
                    ),
                    const Spacer(),
                    SizedBox(
                      width: 40,
                      height: 40,
                      child: Stack(
                        alignment: Alignment.center,
                        children: [
                          SvgPicture.asset(
                            'assets/icons/quran/suraNum.svg',
                            width: 40,
                            height: 40,
                          ),
                          Text(
                            (surah.index ?? "-").toString(),
                            style: const TextStyle(
                              fontFamily: "english",
                              color: Colors.white,
                              fontWeight: FontWeight.w800,
                              fontSize: 12.5,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 8),
                SizedBox(
                  height: 44,
                  child: Stack(
                    alignment: Alignment.center,
                    children: [
                      // Positioned.fill(
                      //   child: SvgPicture.asset(
                      //     'assets/icons/quran/surahSvgBanner.svg',
                      //     fit: BoxFit.fill,
                      //   ),
                      // ),
                      Hero(
                        tag: "surah-title-${surah.index}",
                        child: Material(
                          color: Colors.transparent,
                          child: Text(
                            surah.arabic ?? "",
                            textDirection: TextDirection.rtl,
                            textAlign: TextAlign.center,
                            style: TextStyle(
                              color: Color(0xFF5A4322),
                              fontFamily: quranFontFamily,
                              fontWeight: FontWeight.w700,
                              fontSize: 22,
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  surah.latin ?? "",
                  textAlign: TextAlign.right,
                  style: TextStyle(
                    fontFamily: "english",
                    color: scheme.onSurfaceVariant,
                    fontWeight: FontWeight.w600,
                    fontSize: 13,
                  ),
                ),
                const SizedBox(height: 7),
                Row(
                  children: [
                    _metaChip(
                      context,
                      label: revelationType,
                      icon: Icons.layers_outlined,
                    ),
                    const SizedBox(width: 8),
                    _metaChip(
                      context,
                      label: "ئایەت: ${surah.ayahCount ?? "-"}",
                      icon: Icons.format_list_numbered_rounded,
                    ),
                    const Spacer(),
                  ],
                ),
                const SizedBox(height: 8),
                Text(
                  kurdishName ??
                      (surah.translation ?? "ناوی کوردی بەردەست نییە"),
                  textDirection: TextDirection.rtl,
                  textAlign: TextAlign.right,
                  style: TextStyle(
                    fontFamily: fontFamily,
                    color: scheme.onSurfaceVariant,
                    fontSize: 12.8,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _smallIcon(
    BuildContext context, {
    required IconData icon,
    required VoidCallback onTap,
  }) {
    final scheme = Theme.of(context).colorScheme;
    return Material(
      color: Colors.transparent,
      child: InkWell(
        borderRadius: BorderRadius.circular(10),
        onTap: onTap,
        child: Ink(
          width: 34,
          height: 34,
          decoration: BoxDecoration(
            color: scheme.surfaceContainerHighest.withValues(alpha: 0.45),
            borderRadius: BorderRadius.circular(10),
          ),
          child: Icon(icon, size: 18, color: scheme.primary),
        ),
      ),
    );
  }

  Widget _metaChip(
    BuildContext context, {
    required String label,
    required IconData icon,
  }) {
    final scheme = Theme.of(context).colorScheme;
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 6),
      decoration: BoxDecoration(
        color: scheme.surfaceContainerHighest.withValues(alpha: 0.4),
        borderRadius: BorderRadius.circular(10),
      ),
      child: Row(
        children: [
          Icon(icon, size: 13, color: scheme.primary),
          const SizedBox(width: 4),
          Text(
            label,
            style: TextStyle(
              color: scheme.onSurfaceVariant,
              fontSize: 12,
              fontWeight: FontWeight.w600,
            ),
          ),
        ],
      ),
    );
  }

  String? _maybeKurdishName(String? value) {
    if (value == null || value.trim().isEmpty) return null;
    final text = value.trim();
    final hasKurdish = RegExp(r'[ەێۆڕڵڤچژگپ]').hasMatch(text);
    return hasKurdish ? text : null;
  }
}

class _SimpleFilterSheet extends StatelessWidget {
  const _SimpleFilterSheet({
    required this.title,
    required this.values,
    required this.selected,
  });

  final String title;
  final List<String> values;
  final String selected;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final viewInsets = MediaQuery.viewInsetsOf(context).bottom;
    final maxHeight = MediaQuery.sizeOf(context).height * 0.72;
    return SafeArea(
      top: false,
      child: Padding(
        padding: EdgeInsets.only(bottom: viewInsets),
        child: Container(
          margin: const EdgeInsets.fromLTRB(10, 0, 10, 10),
          padding: const EdgeInsets.fromLTRB(14, 12, 14, 14),
          decoration: BoxDecoration(
            color: scheme.surface.withValues(alpha: 0.98),
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: scheme.outline.withValues(alpha: 0.2)),
          ),
          child: ConstrainedBox(
            constraints: BoxConstraints(maxHeight: maxHeight),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Align(
                  child: Container(
                    width: 54,
                    height: 4,
                    decoration: BoxDecoration(
                      color: scheme.outline.withValues(alpha: 0.4),
                      borderRadius: BorderRadius.circular(99),
                    ),
                  ),
                ),
                const SizedBox(height: 12),
                Text(
                  title,
                  textDirection: TextDirection.rtl,
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    color: scheme.onSurface,
                    fontWeight: FontWeight.w700,
                    fontSize: 16,
                  ),
                ),
                const SizedBox(height: 12),
                Expanded(
                  child: SingleChildScrollView(
                    physics: const BouncingScrollPhysics(),
                    child: Wrap(
                      spacing: 8,
                      runSpacing: 8,
                      children: values.map((value) {
                        final isSelected = value == selected;
                        return ChoiceChip(
                          selected: isSelected,
                          label: Text(value, textDirection: TextDirection.rtl),
                          onSelected: (_) => Navigator.of(context).pop(value),
                        );
                      }).toList(),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _IslamicPatternPainter extends CustomPainter {
  _IslamicPatternPainter({required this.color});

  final Color color;

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = color
      ..style = PaintingStyle.stroke
      ..strokeWidth = 0.8;

    const step = 36.0;
    for (double x = -step; x < size.width + step; x += step) {
      for (double y = -step; y < size.height + step; y += step) {
        final rect = Rect.fromCenter(center: Offset(x, y), width: 9, height: 9);
        canvas.drawRRect(
          RRect.fromRectAndRadius(rect, const Radius.circular(2)),
          paint,
        );
      }
    }
  }

  @override
  bool shouldRepaint(covariant _IslamicPatternPainter oldDelegate) {
    return oldDelegate.color != color;
  }
}
