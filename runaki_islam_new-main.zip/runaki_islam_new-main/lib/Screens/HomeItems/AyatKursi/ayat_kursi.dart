import 'dart:ui';

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:runaki_islam/providers/settings_provider.dart';
import 'package:runaki_islam/util/background.dart';
import 'package:runaki_islam/util/constans.dart';

class AyatKursi extends StatefulWidget {
  final String? sarder;

  const AyatKursi({super.key, this.sarder});
  @override
  State<AyatKursi> createState() => _AyatKursiState();
}

class _AyatKursiState extends State<AyatKursi> {
  String setting = "ayat";
  bool _revealed = false;

  String ayatKursiText =
      "اللّهُ لاَ إِلَهَ إِلاَّ هُوَ الْحَیُّ الْقَیُّومُ لاَ تَأْخُذُهُ سِنَهٌ وَ لاَ نَوْمٌ لَّهُ مَا فِی السَّمَاوَاتِ وَمَا فِی الأَرْضِ مَن ذَا الَّذِی یَشْفَعُ عِنْدَهُ إِلاَّ بِإِذْنِهِ یَعْلَمُ مَا بَیْنَ أَیْدِیهِمْ وَمَا خَلْفَهُمْ وَ لاَ یُحِیطُونَ بِشَیْءٍ مِّنْ عِلْمِهِ إِلاَّ بِمَا شَاء وَسِعَ کُرْسِیُّهُ السَّمَاوَاتِ وَ الأَرْضَ وَ لاَ یَۆُودُهُ حِفْظُهُمَا وَ هُوَ الْعَلِیُّ الْعَظِیمُ";

  String mana =
      "خوا زاتێکه جگه ئه‌و هیچ خوایه‌کی ترنیه که شایه‌نی په‌رستن بێت و ئه‌و هه‌میشه زیندووه و ڕاگرو سه‌رپه‌رشتیاری (هه‌موو دروست کراوه‌کانیه‌تی)، نه وه‌نه‌وز ده‌یگرێت و نه خه‌و (چونکه ڕاگرو سه‌رپه‌رشتیاری بوونه‌وه‌ره‌)، هه‌رچی له ئاسمانه‌کان و هه‌رچی له زه‌ویدا هه‌یه هه‌ر ئه‌وزاته خاوه‌نیانه‌، کێ یه ئه‌وه‌ی (ده‌توانێت) تکا بکات له لای ئه‌و، به‌بێ مۆڵه‌تی خۆی، ده‌شزانێت چی له ئێستاو داهاتوو و ڕابووردودا ڕوویداوه‌و ڕووده‌دات، هیچ کام له دروستکراوانی زانست و زانیاری ته‌واویان نیه ده‌رباره‌ی زانیاری و زانسته‌کانی ئه‌و، مه‌گه‌ر به‌وه‌ی که خۆی بیه‌وێت فێریان بکات (ئه‌م پێشکه‌وتن و زانسته‌ی سه‌رده‌م به‌شێکی که‌من له به‌خششه‌کانی خوا)، فه‌رمانڕه‌وایی و ده‌سه‌ڵات و زانینی ئه‌وزاته هه‌موو ئاسمانه‌کان و زه‌وی گرتۆته‌وه و پارێزگاریان به‌لای خواوه هیچ گران نیه و ماندووی ناکات و هه‌ر ئه‌و خوایه‌کی به‌رزو بڵند و گه‌وره‌یه‌";
  String sudakan =
      "١: بیخوێنه‌وه‌ له‌ كاتی چونه‌ ده‌ر له‌ ماڵ، ٧٠.٠٠٠ فریشته‌ ده‌تپارێزن له‌ هه‌مو لایه‌كانه‌وه‌.\n٢: بیخوێنه‌ له‌ كاتی چونه‌وه‌ ماڵ، هه‌ژاری ڕو له‌ ماڵه‌ ناكات.\n٣: بیخوێنه‌ له‌ دوای ده‌ستنوێژ، ٧٠ پله‌ له‌ خوات نزیك ده‌كاته‌وه‌\n٤: بیخوێنه‌ به‌ر له‌ خه‌وتن فریشته‌یه‌ك تا به‌یانی ده‌تپارێزێ.\n٥: بیخوێنه‌ له‌ داوی نوێژه‌كان، تاكه‌ شت ڕێگر ده‌بێت له‌ نێوان تۆ و به‌هه‌شت، مردنه‌..تائیستا زانیوتە… بۆچی ناوی ئایەت الکورسیە؟\nچەند دەقەیەک لە کاتت بگرە بۆ زانینی واتاکەی..!\n.\n– ژمارەی وشەكان : 50 وشەیە\n– بناغەی ئاینی ئیسلام كە یەكتاپەرستییە لەخۆی گرتووە\n– بە پیرۆزترین و گەورەترین ئایەتی قورئان دانراوە\n-17 ناوی پیرۆزی خوای گەورەی تێدایە\n– ئایەتەكە بەشەو دابەزیووه\nبۆچی ناوی ئایەتـی كورسیە؟\n– كورسی بناغەی دەسەڵات و نیشانەی فەرمانڕەواییە و تێیدا بناغەی ئةولەهیەتی خوای گەورەی تێدایە\n– خوای گـــەورە ئەو ئایەتەی بە (الله) دەستپێكردووە و بە (العلی العظیم) كۆتایی پێ هێناوە.\n– هەر كەس پێوەی پابەند بێت خوای گــەورە پلە و پایەی بەرز دەكاتەوە.\nپێغەمبەری خوا (صلی الله عليه وسلم) دەربارەی ئایەتی الكورسـی چی فەرمووە ؟\n– وَالَّذِي نَفْسِي بِيَدِهِ إِنَّ لَهَا لِسَانًا وَشَفَتَيْنِ تُقَدِّسُ الْمَلِكَ عِنْدَ سَاقِ الْعَرْشِ .\nواتە: سوێند بەو كەسەی منی بەدەستە، ئەو ئایەتە زمان و لێوی هەیە، تەقدیســی خوای گەورە دەكات لەژێر عەرشەكەیدا.\nپاداشتی خوێندنی ئەو ئایەتە:\nئایەتی كورسی پاداشتی گەورە دەبةخشێتە ئەو كەسەی دەیخوێنێ، لە دنیا و لە رۆژی دواییش:\n-لــــــــــــــــــــە دنیادا ئەوەی بیخوێنێ لە هەرچوارلای ماڵەكەی، خوای گەورە لە شەیتان دەیپارێزێ.\n-هەر كەســـــــــــــــــــێ پێش ئەوەی سەفەر بكات بیخوێنێ بەسەر ماڵەكەیدا، خوای گەورە لە چەتە و هەموو بەڵایەك ماڵەكەی دەپارێزێت.\n-ئەوەی شەو بیخوێنـێ، خوای گەورە لە شەیتان بەدووری دەخاتە هەتا رۆژ دەبێتەوە.\n-هەر كەس پێش ئەوەی بخەوێت، بەسەر خۆی مـنداڵەكانیدا بیخوێنێ، خوای گەورە لە شەیتان دەیانپارێزێت و خەوی ناخۆش نابينن";

  int? fontType;
  double? fontSize;
  int? quranFontType;
  double? quranFontSize;

  @override
  void initState() {
    super.initState();
    fontType = Provider.of<SettingsProvider>(context, listen: false)
        .getsettingField('font_family');
    fontSize = Provider.of<SettingsProvider>(context, listen: false)
        .getsettingField('font_size');

    quranFontType = Provider.of<SettingsProvider>(context, listen: false)
        .getsettingField('quran_font_family');

    quranFontSize = Provider.of<SettingsProvider>(context, listen: false)
        .getsettingField('quran_font_size');

    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!mounted) {
        return;
      }
      setState(() {
        _revealed = true;
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        backgroundColor: Colors.transparent,
        body: Stack(
          children: <Widget>[
            ClipRect(
              child: ImageFiltered(
                imageFilter: ImageFilter.blur(sigmaX: 3, sigmaY: 3),
                child: CustomBackground(
                  color: bgColor,
                  imageColor: bgImageColor.withValues(alpha: 0.22),
                ),
              ),
            ),
            Container(
              color: backgroundColor.withValues(alpha: 0.55),
            ),
            SafeArea(
              child: Column(
                children: <Widget>[
                  _buildTopBar(context),
                  AnimatedSlide(
                    duration: const Duration(milliseconds: 480),
                    curve: Curves.easeOutCubic,
                    offset: _revealed ? Offset.zero : const Offset(0, -0.1),
                    child: AnimatedOpacity(
                      duration: const Duration(milliseconds: 460),
                      opacity: _revealed ? 1 : 0,
                      child: _buildHeroCard(),
                    ),
                  ),
                  const SizedBox(height: 10),
                  _buildButtonsRow(),
                  const SizedBox(height: 10),
                  Expanded(child: _buildContentCard()),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildTopBar(BuildContext context) {
    return SizedBox(
      height: 58,
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 10),
        child: Row(
          children: <Widget>[
            Container(
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: backgroundColor.withValues(alpha: 0.86),
                border: Border.all(color: strokeColor.withValues(alpha: 0.45)),
              ),
              child: IconButton(
                icon: const Icon(Icons.arrow_back_ios_new_rounded),
                color: kActiveIconColor,
                onPressed: () => Navigator.pop(context),
              ),
            ),
            Expanded(
              child: Text(
                widget.sarder ?? "ئایەتی کورسی",
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontFamily: fontType.toString(),
                  color: kTextColor,
                  fontWeight: FontWeight.w800,
                  fontSize: 17,
                ),
              ),
            ),
            const SizedBox(width: 48),
          ],
        ),
      ),
    );
  }

  Widget _buildHeroCard() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 12),
      child: Container(
        padding: const EdgeInsets.fromLTRB(16, 14, 16, 14),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(24),
          color: backgroundColor.withValues(alpha: 0.95),
          border: Border.all(color: strokeColor.withValues(alpha: 0.38)),
          boxShadow: <BoxShadow>[
            BoxShadow(
              color: kShadowColor.withValues(alpha: 0.14),
              blurRadius: 20,
              offset: const Offset(0, 10),
            ),
          ],
        ),
        child: Row(
          children: <Widget>[
            Container(
              width: 44,
              height: 44,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: kActiveIconColor,
              ),
              child: const Icon(
                Icons.auto_stories_rounded,
                color: Colors.white,
                size: 22,
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  Text(
                    "خوێندنەوە و تێگەیشتن",
                    style: simpleTextStyle.copyWith(
                      fontFamily: fontType.toString(),
                      color: descriptionTectColor,
                      fontSize: 13,
                    ),
                  ),
                  const SizedBox(height: 4),
                  AnimatedSwitcher(
                    duration: const Duration(milliseconds: 280),
                    transitionBuilder: (Widget child, Animation<double> anim) {
                      return FadeTransition(opacity: anim, child: child);
                    },
                    child: Text(
                      _titleForSetting(setting),
                      key: ValueKey<String>(setting),
                      style: bigTextStyle.copyWith(
                        fontFamily: fontType.toString(),
                        color: kTextColor,
                        fontSize: 17,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildButtonsRow() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 12),
      child: Container(
        padding: const EdgeInsets.all(6),
        decoration: BoxDecoration(
          color: backgroundColor.withValues(alpha: 0.86),
          borderRadius: BorderRadius.circular(18),
          border: Border.all(color: strokeColor.withValues(alpha: 0.34)),
        ),
        child: Row(
          children: <Widget>[
            Expanded(
              child: _buildSectionButton(
                label: "ئایەتی کورسی",
                icon: Icons.menu_book_rounded,
                selected: setting == "ayat",
                onTap: () => setState(() => setting = "ayat"),
              ),
            ),
            const SizedBox(width: 6),
            Expanded(
              child: _buildSectionButton(
                label: "سوودەکانی",
                icon: Icons.auto_awesome_rounded,
                selected: setting == "sudakan",
                onTap: () => setState(() => setting = "sudakan"),
              ),
            ),
            const SizedBox(width: 6),
            Expanded(
              child: _buildSectionButton(
                label: "ماناکەی",
                icon: Icons.translate_rounded,
                selected: setting == "mana",
                onTap: () => setState(() => setting = "mana"),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildSectionButton({
    required String label,
    required IconData icon,
    required bool selected,
    required VoidCallback onTap,
  }) {
    return AnimatedContainer(
      duration: const Duration(milliseconds: 260),
      curve: Curves.easeOutCubic,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(14),
        color: selected ? kActiveIconColor : Colors.transparent,
        border: Border.all(
          color: selected ? Colors.transparent : strokeColor.withValues(alpha: 0.34),
        ),
        boxShadow: selected
            ? <BoxShadow>[
                BoxShadow(
                  color: kActiveIconColor.withValues(alpha: 0.24),
                  blurRadius: 12,
                  offset: const Offset(0, 4),
                ),
              ]
            : null,
      ),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          borderRadius: BorderRadius.circular(14),
          onTap: onTap,
          child: Padding(
            padding: const EdgeInsets.symmetric(vertical: 10),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
                Icon(
                  icon,
                  size: 16,
                  color: selected ? Colors.white : kActiveIconColor,
                ),
                const SizedBox(width: 5),
                Flexible(
                  child: Text(
                    label,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: simpleTextStyle.copyWith(
                      color: selected ? Colors.white : kActiveIconColor,
                      fontFamily: fontType.toString(),
                      fontSize: 12.3,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildContentCard() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(10, 0, 10, 10),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(24),
        child: BackdropFilter(
          filter: ImageFilter.blur(sigmaX: 14, sigmaY: 14),
          child: Container(
            decoration: BoxDecoration(
              color: backgroundColor.withValues(alpha: 0.9),
              borderRadius: BorderRadius.circular(24),
              border: Border.all(color: strokeColor.withValues(alpha: 0.36)),
              boxShadow: <BoxShadow>[
                BoxShadow(
                  color: kShadowColor.withValues(alpha: 0.14),
                  blurRadius: 20,
                  offset: const Offset(0, 12),
                ),
              ],
            ),
            child: Column(
              children: <Widget>[
                Padding(
                  padding: const EdgeInsets.fromLTRB(16, 14, 16, 12),
                  child: Row(
                    children: <Widget>[
                      Icon(_iconForSetting(setting), color: kActiveIconColor, size: 22),
                      const SizedBox(width: 8),
                      Expanded(
                        child: AnimatedSwitcher(
                          duration: const Duration(milliseconds: 280),
                          transitionBuilder:
                              (Widget child, Animation<double> animation) {
                            return FadeTransition(opacity: animation, child: child);
                          },
                          child: Text(
                            _titleForSetting(setting),
                            key: ValueKey<String>('title-$setting'),
                            style: bigTextStyle.copyWith(
                              fontFamily: fontType.toString(),
                              fontSize: 16,
                              fontWeight: FontWeight.w700,
                              color: kTextColor,
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                Divider(
                  color: strokeColor.withValues(alpha: 0.4),
                  height: 1,
                  thickness: 1,
                ),
                Expanded(
                  child: SingleChildScrollView(
                    padding: const EdgeInsets.fromLTRB(14, 18, 14, 80),
                    physics: const BouncingScrollPhysics(
                      parent: AlwaysScrollableScrollPhysics(),
                    ),
                    child: AnimatedSwitcher(
                      duration: const Duration(milliseconds: 420),
                      switchInCurve: Curves.easeOutCubic,
                      switchOutCurve: Curves.easeInCubic,
                      transitionBuilder: _sectionTransition,
                      layoutBuilder:
                          (Widget? currentChild, List<Widget> previousChildren) {
                        return Stack(
                          alignment: Alignment.topCenter,
                          children: <Widget>[
                            ...previousChildren,
                            if (currentChild case final Widget child) child,
                          ],
                        );
                      },
                      child: SelectableText(
                        _textForSetting(setting),
                        key: ValueKey<String>(setting),
                        style: _styleForSetting(setting),
                        textAlign:
                            setting == "ayat" ? TextAlign.center : TextAlign.justify,
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _sectionTransition(Widget child, Animation<double> animation) {
    final Animation<double> curved = CurvedAnimation(
      parent: animation,
      curve: Curves.easeOutCubic,
    );

    return FadeTransition(
      opacity: curved,
      child: SlideTransition(
        position: Tween<Offset>(
          begin: const Offset(0.08, 0.02),
          end: Offset.zero,
        ).animate(curved),
        child: child,
      ),
    );
  }

  String _textForSetting(String value) {
    if (value == "ayat") {
      return ayatKursiText;
    }
    if (value == "sudakan") {
      return sudakan;
    }
    return mana;
  }

  TextStyle _styleForSetting(String value) {
    if (value == "ayat") {
      return quranStyle.copyWith(
        fontSize: (quranFontSize ?? 24) + 2,
        fontFamily: quranFontType.toString(),
        height: 2,
        color: kActiveIconColor,
      );
    }
    return simpleTextStyle.copyWith(
      fontSize: (fontSize ?? 17) + 0.2,
      fontFamily: fontType.toString(),
      color: kTextColor,
      height: 1.9,
    );
  }

  String _titleForSetting(String value) {
    if (value == "ayat") {
      return "ئایەتی کورسی";
    }
    if (value == "sudakan") {
      return "سوودەکانی ئایەتی کورسی";
    }
    return "مانای ئایەتی کورسی";
  }

  IconData _iconForSetting(String value) {
    if (value == "ayat") {
      return Icons.menu_book_rounded;
    }
    if (value == "sudakan") {
      return Icons.auto_awesome_rounded;
    }
    return Icons.translate_rounded;
  }
}
