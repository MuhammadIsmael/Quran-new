import 'dart:convert';
import 'package:runaki_islam/Screens/HomeItems/Pexambarman/page_view.dart';
import 'package:flutter/material.dart';
import 'package:runaki_islam/models/qyamat_model.dart';
import 'package:runaki_islam/util/background.dart';
import 'package:runaki_islam/util/constans.dart';
import 'package:runaki_islam/util/item_list.dart';
import 'package:loading_indicator/loading_indicator.dart';
import 'package:page_transition/page_transition.dart';
import 'package:runaki_islam/providers/sections_provider.dart';
import 'package:runaki_islam/providers/settings_provider.dart';
import 'package:provider/provider.dart';

class PrsyarList extends StatefulWidget {
  final String? sarder;
  final String? bash;

  const PrsyarList({super.key, this.sarder, required this.bash});
  @override
  State<StatefulWidget> createState() => _TawanaGawrakanState();
}

class _TawanaGawrakanState extends State<PrsyarList> {
  final List<QyamatModel> _list = [];
  var loading = false;
  Future<String> loadNoteAsset() async {
    return Provider.of<SectionsProvider>(
      context,
      listen: false,
    ).loadLegacyJsonAsset('assets/data/content/prsyar_rozhe_dway.json');
  }

  int? fontType;

  Future fetchData() async {
    setState(() {
      loading = true;
    });
    _list.clear();

    String response = await loadNoteAsset();

    final data = jsonDecode(response);
    setState(() {
      for (Map<String, dynamic> i in data) {
        _list.add(QyamatModel.formJson(i));
        loading = false;
      }
    });
  }

  @override
  void initState() {
    super.initState();
    fontType = Provider.of<SettingsProvider>(
      context,
      listen: false,
    ).getsettingField('font_family');
    fetchData();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bgColor,
      appBar: AppBar(
        toolbarHeight: 80,
        backgroundColor: thirdColor,
        title: Text(
          "${widget.sarder}",
          style: simpleTextStyle.copyWith(fontFamily: fontType.toString()),
        ),
        shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(bottom: Radius.circular(20)),
        ),
        centerTitle: true,
        elevation: 0,
        leading: IconButton(
          color: iconColor,
          onPressed: () => Navigator.pop(context),
          icon: Icon(Icons.arrow_back_ios_rounded, color: iconColor),
        ),
      ),
      body: loading
          ? Center(
              child: Padding(
                padding: const EdgeInsets.all(120.0),
                child: LoadingIndicator(
                  indicatorType: Indicator.ballSpinFadeLoader,
                  colors: [splashColor],
                ),
              ),
            )
          : Stack(
              children: [
                const Background(),
                Column(
                  children: [
                    Expanded(
                      child: Padding(
                        padding: const EdgeInsets.only(top: 20),
                        child: ListView.builder(
                          physics: const BouncingScrollPhysics(),
                          scrollDirection: Axis.vertical,
                          itemCount: _list.length,
                          itemBuilder: (context, i) {
                            final a = _list[i];

                            return a.bash == widget.bash
                                ? ItemCard2(
                                    title: a.sarder,
                                    count: "${i + 1}",
                                    onPress: () {
                                      getItemNavigate(
                                        a.sarder!,
                                        a.drezha!,
                                        context,
                                      );
                                    },
                                  )
                                : const SizedBox();
                          },
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
    );
  }

  void getItemNavigate(String title, String desc, BuildContext context) {
    Navigator.push(
      context,
      PageTransition(
        child: TextPageView(title: title, sarder: widget.sarder!, desc: desc),
        type: PageTransitionType.leftToRightWithFade,
      ),
    );
  }
}
