import 'dart:async';
import 'dart:convert';
import 'package:background_app_bar/background_app_bar.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:runaki_islam/Screens/HomeItems/Pexambarman/page_view.dart';
import 'package:runaki_islam/models/zhayanama_model.dart';
import 'package:runaki_islam/util/background.dart';
import 'package:runaki_islam/util/constans.dart';
import 'package:runaki_islam/util/item_list.dart';
import 'package:loading_indicator/loading_indicator.dart';
import 'package:page_transition/page_transition.dart';
import 'package:runaki_islam/providers/sections_provider.dart';
import 'package:runaki_islam/providers/settings_provider.dart';
import 'package:provider/provider.dart';

const appBarSize = 250.0;

class ZyanNamayPexambaran extends StatefulWidget {
  final String? sarder;

  const ZyanNamayPexambaran({super.key, this.sarder});
  @override
  State<StatefulWidget> createState() => _ZyanNamayPexambaranState();
}

class _ZyanNamayPexambaranState extends State<ZyanNamayPexambaran> {
  final List<ZhyanamaData> _list = [];
  final List<ZhyanamaData> _search = [];
  var loading = false;

  int? fontType;

  Future<String> loadNoteAsset() async {
    return Provider.of<SectionsProvider>(
      context,
      listen: false,
    ).loadLegacyJsonAsset('assets/data/content/zhyan_namay_pexambaran.json');
  }

  Future fetchData() async {
    setState(() {
      loading = true;
    });
    _list.clear();

    String response = await loadNoteAsset();

    final data = jsonDecode(response);
    setState(() {
      for (Map<String, dynamic> i in data) {
        _list.add(ZhyanamaData.formJson(i));
        loading = false;
      }
    });
  }

  //second way

  TextEditingController controller = TextEditingController();

  Future<void> onSearch(String text) async {
    _search.clear();
    if (text.isEmpty) {
      setState(() {});
      return;
    }

    for (var f in _list) {
      if (f.title!.contains(text)) _search.add(f);
    }

    setState(() {});
  }

  @override
  void initState() {
    SystemChrome.restoreSystemUIOverlays();
    super.initState();
    fontType = Provider.of<SettingsProvider>(
      context,
      listen: false,
    ).getsettingField('font_family');
    fetchData();
  }

  @override
  Widget build(BuildContext context) {
    SystemChrome.restoreSystemUIOverlays();
    return Scaffold(
      backgroundColor: bgColor,
      body: NestedScrollView(
        physics: const BouncingScrollPhysics(),
        headerSliverBuilder: (_, _) => <Widget>[
          SliverAppBar(
            expandedHeight: appBarSize,
            elevation: 0.0,
            leading: IconButton(
              color: iconColor,
              icon: const Icon(Icons.arrow_back_ios_new_rounded),
              onPressed: () {
                Navigator.pop(context);
              },
            ),
            backgroundColor: Colors.transparent,
            flexibleSpace: BackgroundFlexibleSpaceBar(
              collapseMode: CollapseMode.parallax,
              centerTitle: true,
              background: Container(
                alignment: Alignment.bottomCenter,
                width: double.infinity,
                padding: const EdgeInsets.only(
                  left: 8,
                  right: 8,
                  bottom: 30,
                  top: 30,
                ),
                decoration: BoxDecoration(
                  color: thirdColor,
                  borderRadius: const BorderRadius.only(
                    bottomLeft: Radius.circular(25),
                    bottomRight: Radius.circular(25),
                  ),
                ),
                child: Column(
                  children: <Widget>[
                    const SizedBox(height: 40),
                    Text(
                      widget.sarder!,
                      style: TextStyle(
                        fontFamily: fontType.toString(),
                        color: kTextColor,
                        fontSize: 25,
                      ),
                    ),
                    const SizedBox(height: 40),
                    Container(
                      margin: const EdgeInsets.only(left: 15, right: 15),
                      width: double.infinity,
                      padding: const EdgeInsets.only(left: 8, right: 8),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(8),
                        color: Colors.white,
                      ),
                      child: TextField(
                        controller: controller,
                        onChanged: onSearch,
                        keyboardType: TextInputType.text,
                        maxLines: 1,
                        scrollPhysics: const BouncingScrollPhysics(),
                        textAlign: TextAlign.right,
                        cursorColor: kActiveIconColor,
                        textDirection: TextDirection.rtl,
                        decoration: InputDecoration(
                          border: InputBorder.none,
                          hintText: "گەڕان",
                          hintStyle: TextStyle(
                            fontFamily: fontType.toString(),
                            color: const Color(0xff9e9e9e),
                          ),
                          icon: const Icon(Icons.search),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
        body: loading
            ? Center(
                child: Padding(
                  padding: const EdgeInsets.all(120.0),
                  child: LoadingIndicator(
                    indicatorType: Indicator.ballSpinFadeLoader,
                    colors: [thirdColor],
                  ),
                ),
              )
            : Stack(
                children: [
                  const Background(),
                  Column(
                    children: [
                      Expanded(
                        child: _search.isNotEmpty || controller.text.isNotEmpty
                            ? ListView.builder(
                                physics: const BouncingScrollPhysics(),
                                scrollDirection: Axis.vertical,
                                itemCount: _search.length,
                                itemBuilder: (context, i) {
                                  final b = _search[i];
                                  return ItemCard2(
                                    title: b.title,
                                    count: "${i + 1}",
                                    onPress: () {
                                      getItemNavigate(
                                        b.title!,
                                        b.desc!,
                                        context,
                                      );
                                    },
                                  );
                                },
                              )
                            : Padding(
                                padding: const EdgeInsets.only(bottom: 40),
                                child: ListView.builder(
                                  physics: const BouncingScrollPhysics(),
                                  scrollDirection: Axis.vertical,
                                  itemCount: _list.length,
                                  itemBuilder: (context, i) {
                                    final a = _list[i];
                                    return ItemCard2(
                                      title: a.title,
                                      count: "${i + 1}",
                                      onPress: () {
                                        getItemNavigate(
                                          a.title!,
                                          a.desc!,
                                          context,
                                        );
                                      },
                                    );
                                  },
                                ),
                              ),
                      ),
                    ],
                  ),
                ],
              ),
      ),
    );
  }
}

void getItemNavigate(String title, String description, BuildContext context) {
  Navigator.push(
    context,
    PageTransition(
      child: TextPageView(
        title: title,
        desc: description,
        sarder: "ژیاننامەی پێغەمبەران",
      ),
      type: PageTransitionType.leftToRightWithFade,
    ),
  );
}
