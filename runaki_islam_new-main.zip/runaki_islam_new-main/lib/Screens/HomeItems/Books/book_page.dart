import 'package:carousel_slider/carousel_slider.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:runaki_islam/Screens/HomeItems/Books/book_detail_page.dart';
import 'package:runaki_islam/models/book_model.dart';
import 'package:runaki_islam/providers/settings_provider.dart';
import 'package:runaki_islam/services/book_file_service.dart';
import 'package:runaki_islam/services/book_repository.dart';
import 'package:runaki_islam/util/animation_helper.dart';
import 'package:runaki_islam/util/background.dart';
import 'package:runaki_islam/util/constans.dart';
import 'package:runaki_islam/util/navigate_between_pages/size_route.dart';

const String _allBooksFilter = '__all_books__';
const String _downloadedBooksFilter = '__downloaded_books__';

class BookPage extends StatefulWidget {
  const BookPage({super.key});

  @override
  State<BookPage> createState() => _BookPageState();
}

class _BookPageState extends State<BookPage> {
  final BookRepository _repository = BookRepository();
  final BookFileService _fileService = BookFileService();
  final TextEditingController _searchController = TextEditingController();

  List<Book> _books = const <Book>[];
  List<Book> _cachedDownloadedBooks = const <Book>[];
  Set<String> _downloadedKeys = <String>{};
  String _selectedFilter = _allBooksFilter;
  String _searchQuery = '';
  int _recommendedIndex = 0;
  bool _loading = true;
  String? _errorMessage;
  String? _fontFamily;

  @override
  void initState() {
    super.initState();
    final fontSetting = Provider.of<SettingsProvider>(
      context,
      listen: false,
    ).getsettingField('font_family');
    _fontFamily = fontSetting?.toString();
    _searchController.addListener(_handleSearchChanged);
    _loadBooks();
  }

  @override
  void dispose() {
    _searchController
      ..removeListener(_handleSearchChanged)
      ..dispose();
    super.dispose();
  }

  bool get _isDownloadedOnly => _selectedFilter == _downloadedBooksFilter;

  bool get _isDiscoverMode {
    return _searchQuery.isEmpty && !_isDownloadedOnly;
  }

  List<Book> get _visibleBooks {
    final source = _isDownloadedOnly ? _cachedDownloadedBooks : _books;
    final results = source.where((book) => book.matchesQuery(_searchQuery));
    return results.toList(growable: false);
  }

  List<Book> get _recommendedBooks {
    final source = _books.where((book) => book.hasPdfUrl);
    return source.take(6).toList(growable: false);
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        backgroundColor: bgColor,
        appBar: AppBar(
          elevation: 0,
          scrolledUnderElevation: 0,
          centerTitle: true,
          backgroundColor: thirdColor,
          foregroundColor: iconColor,
          surfaceTintColor: Colors.transparent,
          title: Text(
            'کتێبەکان',
            style: TextStyle(
              fontFamily: _fontFamily,
              color: kTextColor,
              fontSize: 19,
              fontWeight: FontWeight.w800,
            ),
          ),
          actions: [
            IconButton(
              onPressed: _loading ? null : _refreshBooks,
              icon: const Icon(Icons.refresh_rounded),
              tooltip: 'نوێکردنەوە',
            ),
          ],
        ),
        body: Stack(
          children: [
            const Background(),
            RefreshIndicator(
              onRefresh: _refreshBooks,
              color: kActiveIconColor,
              child: CustomScrollView(
                physics: const BouncingScrollPhysics(
                  parent: AlwaysScrollableScrollPhysics(),
                ),
                slivers: [
                  const SliverToBoxAdapter(child: SizedBox(height: 12)),
                  SliverToBoxAdapter(
                    child: _BooksSearchField(
                      controller: _searchController,
                      fontFamily: _fontFamily,
                    ),
                  ),
                  SliverToBoxAdapter(
                    child: _BooksTabBar(
                      selectedFilter: _selectedFilter,
                      fontFamily: _fontFamily,
                      onChanged: _selectFilter,
                    ),
                  ),
                  if (_books.isNotEmpty)
                    SliverToBoxAdapter(
                      child: _BooksStatsRow(
                        totalCount: _books.length,
                        downloadedCount: _downloadedKeys.length,
                        fontFamily: _fontFamily,
                      ),
                    ),
                  ..._buildContentSlivers(),
                  const SliverToBoxAdapter(child: SizedBox(height: 24)),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  List<Widget> _buildContentSlivers() {
    if (_loading) {
      return <Widget>[
        SliverFillRemaining(
          hasScrollBody: false,
          child: _FeedbackCard(
            icon: Icons.auto_stories_rounded,
            title: 'کتێبەکان ئامادە دەکرێن',
            message: 'چاوەڕێ بکە تا زانیارییەکان بار دەبن.',
            fontFamily: _fontFamily,
            isLoading: true,
          ),
        ),
      ];
    }

    final errorMessage = _errorMessage;
    final canShowOfflineDownloaded =
        _isDownloadedOnly && _cachedDownloadedBooks.isNotEmpty;
    if (errorMessage != null && !canShowOfflineDownloaded) {
      return <Widget>[
        SliverFillRemaining(
          hasScrollBody: false,
          child: _FeedbackCard(
            icon: Icons.cloud_off_rounded,
            title: 'بارکردنی کتێبەکان سەرکەوتوو نەبوو',
            message: errorMessage,
            buttonText: 'دووبارە هەوڵبدە',
            onPressed: _refreshBooks,
            fontFamily: _fontFamily,
          ),
        ),
      ];
    }

    final books = _visibleBooks;
    if (books.isEmpty) {
      return <Widget>[
        SliverFillRemaining(
          hasScrollBody: false,
          child: _FeedbackCard(
            icon: _isDownloadedOnly
                ? Icons.download_done_rounded
                : Icons.search_off_rounded,
            title: _isDownloadedOnly
                ? 'هیچ کتێبێکی دابەزێندراو نییە'
                : 'هیچ کتێبێک نەدۆزرایەوە',
            message: _isDownloadedOnly
                ? 'هێشتا هیچ کتێبێکت بۆ خوێندنەوەی ئۆفلاین دابەزاندووە.'
                : 'وشەیەکی تر تاقی بکەوە یان گەڕان پاک بکەرەوە.',
            buttonText: _isDownloadedOnly ? 'بینینی هەموو' : 'پاککردنەوە',
            onPressed: () {
              if (_isDownloadedOnly) {
                _selectFilter(_allBooksFilter);
                return;
              }
              _searchController.clear();
            },
            fontFamily: _fontFamily,
          ),
        ),
      ];
    }

    if (_isDiscoverMode) {
      final recommended = _recommendedBooks;
      final activeRecommendedIndex =
          recommended.isEmpty || _recommendedIndex >= recommended.length
          ? 0
          : _recommendedIndex;
      return <Widget>[
        if (recommended.isNotEmpty)
          SliverToBoxAdapter(
            child: _SectionHeader(
              title: 'پێشنیارکراو',
              subtitle: 'دەستپێکی باش بۆ دۆزینەوەی کتێبی گونجاو',
              fontFamily: _fontFamily,
            ),
          ),
        if (recommended.isNotEmpty)
          SliverToBoxAdapter(
            child: _RecommendedShelf(
              books: recommended,
              downloadedKeys: _downloadedKeys,
              fontFamily: _fontFamily,
              currentIndex: activeRecommendedIndex,
              onPageChanged: (index) {
                if (_recommendedIndex == index) {
                  return;
                }
                setState(() {
                  _recommendedIndex = index;
                });
              },
              onTap: _openBookDetails,
            ),
          ),
        SliverToBoxAdapter(
          child: _SectionHeader(
            title: 'هەموو کتێبەکان',
            subtitle: '${books.length} کتێب لەبەردەستن',
            fontFamily: _fontFamily,
          ),
        ),
        SliverPadding(
          padding: const EdgeInsets.fromLTRB(12, 0, 12, 0),
          sliver: _BooksList(
            books: books,
            downloadedKeys: _downloadedKeys,
            fontFamily: _fontFamily,
            onTap: _openBookDetails,
          ),
        ),
      ];
    }

    final title = _isDownloadedOnly ? 'کتێبە دابەزێندراوەکان' : 'ئەنجامی گەڕان';
    final subtitle = _isDownloadedOnly
        ? '${books.length} کتێب بۆ خوێندنەوەی ئۆفلاین ئامادەن'
        : '${books.length} کتێب دۆزرایەوە';

    return <Widget>[
      SliverToBoxAdapter(
        child: _SectionHeader(
          title: title,
          subtitle: subtitle,
          fontFamily: _fontFamily,
        ),
      ),
      SliverPadding(
        padding: const EdgeInsets.fromLTRB(12, 0, 12, 0),
        sliver: _BooksList(
          books: books,
          downloadedKeys: _downloadedKeys,
          fontFamily: _fontFamily,
          onTap: _openBookDetails,
        ),
      ),
    ];
  }

  Future<void> _loadBooks() async {
    setState(() {
      _loading = true;
      _errorMessage = null;
    });

    try {
      final cachedDownloadedBooks = await _fileService.loadDownloadedBooks();
      final books = await _repository.fetchBooks();
      final mergedBooks = _mergeBooks(books, cachedDownloadedBooks);
      final downloadedKeys = await _lookupDownloadedKeys(mergedBooks);
      if (!mounted) {
        return;
      }
      setState(() {
        _books = mergedBooks;
        _cachedDownloadedBooks = cachedDownloadedBooks;
        _downloadedKeys = downloadedKeys;
        _loading = false;
      });
    } catch (error) {
      final cachedDownloadedBooks = await _fileService.loadDownloadedBooks();
      if (!mounted) {
        return;
      }
      setState(() {
        _books = cachedDownloadedBooks;
        _cachedDownloadedBooks = cachedDownloadedBooks;
        _downloadedKeys = cachedDownloadedBooks.map(_bookIdentity).toSet();
        _loading = false;
        _errorMessage = _friendlyErrorMessage(error);
      });
    }
  }

  Future<void> _refreshBooks() async {
    await _loadBooks();
  }

  Future<Set<String>> _lookupDownloadedKeys(List<Book> books) async {
    final entries = await Future.wait(
      books.map((book) async {
        final downloaded = await _fileService.isDownloaded(book);
        return MapEntry<String, bool>(_bookIdentity(book), downloaded);
      }),
    );

    return entries
        .where((entry) => entry.value)
        .map((entry) => entry.key)
        .toSet();
  }

  Future<void> _refreshDownloadedState() async {
    final cachedDownloadedBooks = await _fileService.loadDownloadedBooks();
    final mergedBooks = _mergeBooks(_books, cachedDownloadedBooks);
    if (mergedBooks.isEmpty) {
      return;
    }
    final downloadedKeys = await _lookupDownloadedKeys(mergedBooks);
    if (!mounted) {
      return;
    }
    setState(() {
      _books = mergedBooks;
      _cachedDownloadedBooks = cachedDownloadedBooks;
      _downloadedKeys = downloadedKeys;
    });
  }

  Future<void> _openBookDetails(Book book) async {
    await Navigator.push(context, SizeRoute(page: BookDetailPage(book: book)));
    await _refreshDownloadedState();
  }

  void _handleSearchChanged() {
    final query = _searchController.text.trim();
    if (_searchQuery == query) {
      return;
    }
    setState(() {
      _searchQuery = query;
    });
  }

  void _selectFilter(String filter) {
    if (_selectedFilter == filter) {
      return;
    }
    setState(() {
      _selectedFilter = filter;
    });
  }

  List<Book> _mergeBooks(List<Book> primary, List<Book> secondary) {
    final mergedByKey = <String, Book>{};
    for (final book in secondary) {
      mergedByKey[_bookIdentity(book)] = book;
    }
    for (final book in primary) {
      mergedByKey[_bookIdentity(book)] = book;
    }
    return mergedByKey.values.toList(growable: false);
  }
}

class _BooksSearchField extends StatelessWidget {
  const _BooksSearchField({required this.controller, required this.fontFamily});

  final TextEditingController controller;
  final String? fontFamily;

  @override
  Widget build(BuildContext context) {
    final hasText = controller.text.trim().isNotEmpty;

    return Padding(
      padding: const EdgeInsets.fromLTRB(12, 0, 12, 10),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
        decoration: BoxDecoration(
          color: Theme.of(context).cardColor.withValues(alpha: 0.96),
          borderRadius: BorderRadius.circular(26),
          border: Border.all(color: strokeColor),
          boxShadow: [
            BoxShadow(
              color: kShadowColor.withValues(alpha: 0.08),
              blurRadius: 22,
              offset: const Offset(0, 10),
            ),
          ],
        ),
        child: TextField(
          controller: controller,
          textAlign: TextAlign.right,
          textDirection: TextDirection.rtl,
          decoration: InputDecoration(
            border: InputBorder.none,
            hintText: 'گەڕان بە ناونیشان یان ناوەڕۆک',
            hintStyle: TextStyle(fontFamily: fontFamily, color: titleTextColor),
            prefixIcon: Icon(Icons.search_rounded, color: kActiveIconColor),
            suffixIcon: hasText
                ? IconButton(
                    onPressed: controller.clear,
                    icon: const Icon(Icons.close_rounded),
                  )
                : null,
          ),
          style: TextStyle(
            fontFamily: fontFamily,
            fontSize: 15,
            color: kTextColor,
          ),
        ),
      ),
    );
  }
}

class _BooksTabBar extends StatelessWidget {
  const _BooksTabBar({
    required this.selectedFilter,
    required this.fontFamily,
    required this.onChanged,
  });

  final String selectedFilter;
  final String? fontFamily;
  final ValueChanged<String> onChanged;

  @override
  Widget build(BuildContext context) {
    final selectedIndex = selectedFilter == _downloadedBooksFilter ? 1 : 0;

    return DefaultTabController(
      length: 2,
      initialIndex: selectedIndex,
      child: Padding(
        padding: const EdgeInsets.fromLTRB(12, 0, 12, 6),
        child: Container(
          padding: const EdgeInsets.all(6),
          decoration: BoxDecoration(
            color: Theme.of(context).cardColor.withValues(alpha: 0.96),
            borderRadius: BorderRadius.circular(26),
            border: Border.all(color: strokeColor),
            boxShadow: [
              BoxShadow(
                color: kShadowColor.withValues(alpha: 0.07),
                blurRadius: 18,
                offset: const Offset(0, 10),
              ),
            ],
          ),
          child: Directionality(
            textDirection: TextDirection.rtl,
            child: TabBar(
              onTap: (index) {
                onChanged(
                  index == 0 ? _allBooksFilter : _downloadedBooksFilter,
                );
              },
              indicator: BoxDecoration(
                color: kActiveIconColor,
                borderRadius: BorderRadius.circular(20),
                boxShadow: [
                  BoxShadow(
                    color: kActiveIconColor.withValues(alpha: 0.18),
                    blurRadius: 14,
                    offset: const Offset(0, 6),
                  ),
                ],
              ),
              indicatorSize: TabBarIndicatorSize.tab,
              dividerColor: Colors.transparent,
              overlayColor: WidgetStateProperty.all(Colors.transparent),
              labelColor: Colors.white,
              unselectedLabelColor: kTextColor,
              labelStyle: TextStyle(
                fontFamily: fontFamily,
                fontSize: 13,
                fontWeight: FontWeight.w800,
              ),
              unselectedLabelStyle: TextStyle(
                fontFamily: fontFamily,
                fontSize: 13,
                fontWeight: FontWeight.w700,
              ),
              tabs: const [
                Tab(text: 'هەموو'),
                Tab(text: 'دابەزێندراو'),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _BooksStatsRow extends StatelessWidget {
  const _BooksStatsRow({
    required this.totalCount,
    required this.downloadedCount,
    required this.fontFamily,
  });

  final int totalCount;
  final int downloadedCount;
  final String? fontFamily;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(12, 2, 12, 4),
      child: Row(
        textDirection: TextDirection.rtl,
        children: [
          Expanded(
            child: _StatCard(
              label: 'هەموو کتێب',
              value: '$totalCount',
              icon: Icons.auto_stories_rounded,
              fontFamily: fontFamily,
            ),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: _StatCard(
              label: 'ئۆفلاین',
              value: '$downloadedCount',
              icon: Icons.download_done_rounded,
              fontFamily: fontFamily,
              highlighted: true,
            ),
          ),
        ],
      ),
    );
  }
}

class _StatCard extends StatelessWidget {
  const _StatCard({
    required this.label,
    required this.value,
    required this.icon,
    required this.fontFamily,
    this.highlighted = false,
  });

  final String label;
  final String value;
  final IconData icon;
  final String? fontFamily;
  final bool highlighted;

  @override
  Widget build(BuildContext context) {
    final background = highlighted
        ? kActiveIconColor.withValues(alpha: 0.10)
        : Theme.of(context).cardColor.withValues(alpha: 0.92);

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
      decoration: BoxDecoration(
        color: background,
        borderRadius: BorderRadius.circular(22),
        border: Border.all(
          color: highlighted
              ? kActiveIconColor.withValues(alpha: 0.22)
              : strokeColor,
        ),
      ),
      child: Row(
        textDirection: TextDirection.rtl,
        children: [
          Container(
            width: 40,
            height: 40,
            decoration: BoxDecoration(
              color: highlighted ? kActiveIconColor : backgroundColor,
              borderRadius: BorderRadius.circular(14),
            ),
            child: Icon(
              icon,
              size: 20,
              color: highlighted ? Colors.white : kActiveIconColor,
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Text(
                  value,
                  textAlign: TextAlign.right,
                  style: TextStyle(
                    fontFamily: fontFamily,
                    fontSize: 18,
                    fontWeight: FontWeight.w800,
                    color: kTextColor,
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  label,
                  textAlign: TextAlign.right,
                  style: TextStyle(
                    fontFamily: fontFamily,
                    fontSize: 12,
                    color: titleTextColor,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _SectionHeader extends StatelessWidget {
  const _SectionHeader({
    required this.title,
    required this.subtitle,
    required this.fontFamily,
  });

  final String title;
  final String subtitle;
  final String? fontFamily;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(12, 14, 12, 10),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Text(
            title,
            textAlign: TextAlign.right,
            style: TextStyle(
              fontFamily: fontFamily,
              fontSize: 20,
              fontWeight: FontWeight.w800,
              color: kTextColor,
            ),
          ),
          const SizedBox(height: 4),
          Text(
            subtitle,
            textAlign: TextAlign.right,
            style: TextStyle(
              fontFamily: fontFamily,
              fontSize: 12,
              color: titleTextColor,
            ),
          ),
        ],
      ),
    );
  }
}

class _RecommendedShelf extends StatelessWidget {
  const _RecommendedShelf({
    required this.books,
    required this.downloadedKeys,
    required this.fontFamily,
    required this.currentIndex,
    required this.onPageChanged,
    required this.onTap,
  });

  final List<Book> books;
  final Set<String> downloadedKeys;
  final String? fontFamily;
  final int currentIndex;
  final ValueChanged<int> onPageChanged;
  final ValueChanged<Book> onTap;

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        SizedBox(
          height: 312,
          child: Directionality(
            textDirection: TextDirection.rtl,
            child: CarouselSlider.builder(
              itemCount: books.length,
              itemBuilder: (context, index, realIndex) {
                final book = books[index];
                return Padding(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 6,
                    vertical: 4,
                  ),
                  child: _RecommendedBookCard(
                    book: book,
                    fontFamily: fontFamily,
                    isDownloaded: downloadedKeys.contains(_bookIdentity(book)),
                    cardWidth: double.infinity,
                    onTap: () => onTap(book),
                  ),
                );
              },
              options: CarouselOptions(
                height: 312,
                viewportFraction: 0.62,
                enlargeCenterPage: true,
                enlargeStrategy: CenterPageEnlargeStrategy.height,
                enableInfiniteScroll: books.length > 1,
                autoPlay: books.length > 1 && !AppMotion.reduceMotion,
                autoPlayInterval: const Duration(seconds: 4),
                autoPlayAnimationDuration: const Duration(milliseconds: 420),
                onPageChanged: (index, reason) => onPageChanged(index),
              ),
            ),
          ),
        ),
        if (books.length > 1) ...[
          const SizedBox(height: 8),
          Row(
            textDirection: TextDirection.rtl,
            mainAxisAlignment: MainAxisAlignment.center,
            children: List<Widget>.generate(books.length, (index) {
              final isActive = index == currentIndex;
              return AnimatedContainer(
                duration: const Duration(milliseconds: 220),
                margin: const EdgeInsets.symmetric(horizontal: 4),
                width: isActive ? 18 : 8,
                height: 8,
                decoration: BoxDecoration(
                  color: isActive
                      ? kActiveIconColor
                      : kActiveIconColor.withValues(alpha: 0.22),
                  borderRadius: BorderRadius.circular(999),
                ),
              );
            }),
          ),
        ],
      ],
    );
  }
}

class _BooksList extends StatelessWidget {
  const _BooksList({
    required this.books,
    required this.downloadedKeys,
    required this.fontFamily,
    required this.onTap,
  });

  final List<Book> books;
  final Set<String> downloadedKeys;
  final String? fontFamily;
  final ValueChanged<Book> onTap;

  @override
  Widget build(BuildContext context) {
    return SliverList(
      delegate: SliverChildBuilderDelegate((context, index) {
        final book = books[index];
        return Padding(
          padding: EdgeInsets.only(bottom: index == books.length - 1 ? 0 : 14),
          child: _BookListCard(
            book: book,
            fontFamily: fontFamily,
            isDownloaded: downloadedKeys.contains(_bookIdentity(book)),
            onTap: () => onTap(book),
          ),
        );
      }, childCount: books.length),
    );
  }
}

class _RecommendedBookCard extends StatelessWidget {
  const _RecommendedBookCard({
    required this.book,
    required this.fontFamily,
    required this.isDownloaded,
    this.cardWidth,
    required this.onTap,
  });

  final Book book;
  final String? fontFamily;
  final bool isDownloaded;
  final double? cardWidth;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: cardWidth ?? 188,
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          borderRadius: BorderRadius.circular(26),
          onTap: onTap,
          child: Ink(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: Theme.of(context).cardColor.withValues(alpha: 0.97),
              borderRadius: BorderRadius.circular(26),
              border: Border.all(color: strokeColor),
              boxShadow: [
                BoxShadow(
                  color: kShadowColor.withValues(alpha: 0.10),
                  blurRadius: 24,
                  offset: const Offset(0, 14),
                ),
              ],
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Row(
                  textDirection: TextDirection.rtl,
                  children: [
                    _MetaPill(
                      label: _bookCategoryLabel(book),
                      fontFamily: fontFamily,
                    ),
                    const Spacer(),
                    if (isDownloaded) const _StatusPill(label: 'ئۆفلاین'),
                  ],
                ),
                const SizedBox(height: 12),
                Center(
                  child: _BookCover(
                    title: book.title,
                    imageUrl: book.coverImageUrl,
                    width: 104,
                    height: 148,
                    radius: 18,
                  ),
                ),
                const SizedBox(height: 10),
                Align(
                  alignment: Alignment.centerRight,
                  child: Text(
                    book.title,
                    textAlign: TextAlign.right,
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(
                      fontFamily: fontFamily,
                      fontSize: 15,
                      height: 1.35,
                      fontWeight: FontWeight.w800,
                      color: kTextColor,
                    ),
                  ),
                ),
                const SizedBox(height: 6),
                Align(
                  alignment: Alignment.centerRight,
                  child: Text(
                    _descriptionPreview(book),
                    textAlign: TextAlign.right,
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(
                      fontFamily: fontFamily,
                      fontSize: 11,
                      height: 1.4,
                      color: titleTextColor,
                    ),
                  ),
                ),
                const Spacer(),
                Row(
                  textDirection: TextDirection.rtl,
                  children: [
                    Text(
                      'بینینی زیاتر',
                      style: TextStyle(
                        fontFamily: fontFamily,
                        fontSize: 12,
                        fontWeight: FontWeight.w700,
                        color: kActiveIconColor,
                      ),
                    ),
                    const Spacer(),
                    Container(
                      width: 32,
                      height: 32,
                      decoration: BoxDecoration(
                        color: kActiveIconColor,
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: const Icon(
                        Icons.arrow_back_rounded,
                        color: Colors.white,
                        size: 16,
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _BookListCard extends StatelessWidget {
  const _BookListCard({
    required this.book,
    required this.fontFamily,
    required this.isDownloaded,
    required this.onTap,
  });

  final Book book;
  final String? fontFamily;
  final bool isDownloaded;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        borderRadius: BorderRadius.circular(28),
        onTap: onTap,
        child: Ink(
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            color: Theme.of(context).cardColor.withValues(alpha: 0.97),
            borderRadius: BorderRadius.circular(28),
            border: Border.all(color: strokeColor),
            boxShadow: [
              BoxShadow(
                color: kShadowColor.withValues(alpha: 0.08),
                blurRadius: 20,
                offset: const Offset(0, 10),
              ),
            ],
          ),
          child: Row(
            textDirection: TextDirection.rtl,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Hero(
                tag: _bookHeroTag(book),
                child: _BookCover(
                  title: book.title,
                  imageUrl: book.coverImageUrl,
                  width: 94,
                  height: 132,
                  radius: 22,
                ),
              ),
              const SizedBox(width: 14),
              Expanded(
                child: SizedBox(
                  height: 132,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      Row(
                        textDirection: TextDirection.rtl,
                        children: [
                          _MetaPill(
                            label: _bookCategoryLabel(book),
                            fontFamily: fontFamily,
                          ),
                          const Spacer(),
                          if (isDownloaded) const _StatusPill(label: 'ئۆفلاین'),
                        ],
                      ),
                      const SizedBox(height: 10),
                      Align(
                        alignment: Alignment.centerRight,
                        child: Text(
                          book.title,
                          textAlign: TextAlign.right,
                          maxLines: 2,
                          overflow: TextOverflow.ellipsis,
                          style: TextStyle(
                            fontFamily: fontFamily,
                            fontSize: 16,
                            height: 1.4,
                            fontWeight: FontWeight.w800,
                            color: kTextColor,
                          ),
                        ),
                      ),
                      const SizedBox(height: 8),
                      Align(
                        alignment: Alignment.centerRight,
                        child: Text(
                          _descriptionPreview(book),
                          textAlign: TextAlign.right,
                          maxLines: 2,
                          overflow: TextOverflow.ellipsis,
                          style: TextStyle(
                            fontFamily: fontFamily,
                            fontSize: 12,
                            height: 1.45,
                            color: titleTextColor,
                          ),
                        ),
                      ),
                      const Spacer(),
                      Row(
                        textDirection: TextDirection.rtl,
                        children: [
                          Text(
                            'چوون بۆ وردەکاری',
                            style: TextStyle(
                              fontFamily: fontFamily,
                              fontSize: 12,
                              fontWeight: FontWeight.w700,
                              color: kActiveIconColor,
                            ),
                          ),
                          const Spacer(),
                          Container(
                            width: 34,
                            height: 34,
                            decoration: BoxDecoration(
                              color: backgroundColor,
                              borderRadius: BorderRadius.circular(12),
                              border: Border.all(color: strokeColor),
                            ),
                            child: Icon(
                              Icons.arrow_back_rounded,
                              size: 18,
                              color: iconColor,
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _BookCover extends StatelessWidget {
  const _BookCover({
    required this.title,
    required this.imageUrl,
    required this.width,
    required this.height,
    this.radius = 20,
  });

  final String title;
  final String? imageUrl;
  final double width;
  final double height;
  final double radius;

  @override
  Widget build(BuildContext context) {
    final trimmedUrl = imageUrl?.trim() ?? '';

    return Container(
      width: width,
      height: height,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(radius),
        boxShadow: [
          BoxShadow(
            color: kShadowColor.withValues(alpha: 0.16),
            blurRadius: 16,
            offset: const Offset(0, 10),
          ),
        ],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(radius),
        child: trimmedUrl.isEmpty
            ? _CoverPlaceholder(title: title)
            : Image.network(
                trimmedUrl,
                fit: BoxFit.cover,
                cacheWidth: (width * 3).round(),
                errorBuilder: (context, error, stackTrace) =>
                    _CoverPlaceholder(title: title),
                loadingBuilder: (context, child, progress) {
                  if (progress == null) {
                    return child;
                  }
                  return const _CoverPlaceholder();
                },
              ),
      ),
    );
  }
}

class _CoverPlaceholder extends StatelessWidget {
  const _CoverPlaceholder({this.title});

  final String? title;

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(color: kActiveIconColor),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(
            Icons.menu_book_rounded,
            size: 28,
            color: Colors.white.withValues(alpha: 0.92),
          ),
          const SizedBox(height: 8),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 10),
            child: Text(
              _titleInitials(title),
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
              textAlign: TextAlign.center,
              style: const TextStyle(
                color: Colors.white,
                fontSize: 12,
                fontWeight: FontWeight.w800,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _StatusPill extends StatelessWidget {
  const _StatusPill({required this.label});

  final String label;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
      decoration: BoxDecoration(
        color: kActiveIconColor.withValues(alpha: 0.12),
        borderRadius: BorderRadius.circular(999),
      ),
      child: Row(
        textDirection: TextDirection.rtl,
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(Icons.download_done_rounded, size: 14, color: kActiveIconColor),
          const SizedBox(width: 4),
          Text(
            label,
            textAlign: TextAlign.right,
            style: TextStyle(
              fontSize: 11,
              fontWeight: FontWeight.w700,
              color: kActiveIconColor,
            ),
          ),
        ],
      ),
    );
  }
}

class _MetaPill extends StatelessWidget {
  const _MetaPill({required this.label, required this.fontFamily});

  final String label;
  final String? fontFamily;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
      decoration: BoxDecoration(
        color: backgroundColor.withValues(alpha: 0.96),
        borderRadius: BorderRadius.circular(999),
        border: Border.all(color: strokeColor),
      ),
      child: Text(
        label,
        maxLines: 1,
        overflow: TextOverflow.ellipsis,
        textAlign: TextAlign.right,
        style: TextStyle(
          fontFamily: fontFamily,
          fontSize: 11,
          color: kTextColor,
        ),
      ),
    );
  }
}

class _FeedbackCard extends StatelessWidget {
  const _FeedbackCard({
    required this.icon,
    required this.title,
    required this.message,
    required this.fontFamily,
    this.buttonText,
    this.onPressed,
    this.isLoading = false,
  });

  final IconData icon;
  final String title;
  final String message;
  final String? fontFamily;
  final String? buttonText;
  final VoidCallback? onPressed;
  final bool isLoading;

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Container(
          padding: const EdgeInsets.all(22),
          decoration: BoxDecoration(
            color: Theme.of(context).cardColor.withValues(alpha: 0.95),
            borderRadius: BorderRadius.circular(28),
            border: Border.all(color: strokeColor),
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              if (isLoading)
                SizedBox(
                  width: 36,
                  height: 36,
                  child: CircularProgressIndicator(color: kActiveIconColor),
                )
              else
                Icon(icon, size: 42, color: kActiveIconColor),
              const SizedBox(height: 14),
              Text(
                title,
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontFamily: fontFamily,
                  fontSize: 18,
                  fontWeight: FontWeight.w800,
                  color: kTextColor,
                ),
              ),
              const SizedBox(height: 8),
              Text(
                message,
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontFamily: fontFamily,
                  fontSize: 13,
                  height: 1.55,
                  color: titleTextColor,
                ),
              ),
              if (buttonText != null && onPressed != null) ...[
                const SizedBox(height: 18),
                ElevatedButton(
                  onPressed: onPressed,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: kActiveIconColor,
                    foregroundColor: Colors.white,
                    padding: const EdgeInsets.symmetric(
                      horizontal: 18,
                      vertical: 12,
                    ),
                  ),
                  child: Text(
                    buttonText!,
                    style: TextStyle(
                      fontFamily: fontFamily,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }
}

String _friendlyErrorMessage(Object error) {
  final message = error.toString().trim();
  if (message.isEmpty) {
    return 'نەتوانرا کتێبەکان بار بکرێن.';
  }
  return message;
}

String _bookIdentity(Book book) =>
    '${book.id ?? book.slug ?? book.pdfUrl.trim()}';

String _bookHeroTag(Book book) =>
    'book-cover-${book.id ?? book.slug ?? book.pdfUrl.trim()}';

String _bookCategoryLabel(Book book) {
  final category = book.category?.trim() ?? '';
  if (category.isNotEmpty) {
    return category;
  }
  return 'PDF';
}

String _descriptionPreview(Book book) {
  final description = book.description.trim();
  if (description.isEmpty) {
    return 'وردەکاری بۆ ئەم کتێبە بەردەست نییە.';
  }
  if (description.length <= 88) {
    return description;
  }
  return '${description.substring(0, 88).trim()}...';
}

String _titleInitials(String? title) {
  final words = (title ?? '').trim().split(RegExp(r'\s+'));
  final letters = <String>[];
  for (final word in words) {
    if (word.isEmpty) {
      continue;
    }
    letters.add(word.characters.first);
    if (letters.length == 2) {
      break;
    }
  }
  return letters.isEmpty ? 'کتێب' : letters.join(' ');
}
