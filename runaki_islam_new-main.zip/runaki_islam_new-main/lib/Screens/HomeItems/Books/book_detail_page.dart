import 'dart:io';

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:runaki_islam/Screens/HomeItems/Books/book_view.dart';
import 'package:runaki_islam/models/book_model.dart';
import 'package:runaki_islam/providers/settings_provider.dart';
import 'package:runaki_islam/services/book_file_service.dart';
import 'package:runaki_islam/util/background.dart';
import 'package:runaki_islam/util/constans.dart';
import 'package:share_plus/share_plus.dart';

class BookDetailPage extends StatefulWidget {
  const BookDetailPage({super.key, required this.book});

  final Book book;

  @override
  State<BookDetailPage> createState() => _BookDetailPageState();
}

class _BookDetailPageState extends State<BookDetailPage> {
  final BookFileService _fileService = BookFileService();

  bool _isDownloaded = false;
  bool _isChecking = true;
  bool _isDownloading = false;
  bool _isOpening = false;
  double _downloadProgress = 0;
  String? _fontFamily;

  @override
  void initState() {
    super.initState();
    final fontSetting = Provider.of<SettingsProvider>(
      context,
      listen: false,
    ).getsettingField('font_family');
    _fontFamily = fontSetting?.toString();
    _refreshDownloadState();
  }

  @override
  Widget build(BuildContext context) {
    final category = widget.book.category?.trim() ?? '';
    final createdAt = widget.book.createdAt;
    final tags = _displayTags(widget.book);
    final description = _descriptionPreview(widget.book);

    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        backgroundColor: bgColor,
        appBar: AppBar(
          elevation: 0,
          scrolledUnderElevation: 0,
          centerTitle: true,
          backgroundColor: thirdColor,
          foregroundColor: iconColor,
          surfaceTintColor: Colors.transparent,
          title: Text(
            'وردەکاریی کتێب',
            style: TextStyle(
              fontFamily: _fontFamily,
              color: kTextColor,
              fontSize: 18,
              fontWeight: FontWeight.w700,
            ),
          ),
          actions: [
            IconButton(
              onPressed: _shareBook,
              icon: const Icon(Icons.share_outlined),
              tooltip: 'هاوبەشکردن',
            ),
          ],
        ),
        body: Stack(
          children: [
            const Background(),
            SingleChildScrollView(
              physics: const BouncingScrollPhysics(),
              padding: const EdgeInsets.fromLTRB(16, 16, 16, 120),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Center(
                    child: Hero(
                      tag: _bookHeroTag(widget.book),
                      child: _DetailBookCover(
                        title: widget.book.title,
                        imageUrl: widget.book.coverImageUrl,
                      ),
                    ),
                  ),
                  const SizedBox(height: 18),
                  Text(
                    widget.book.title,
                    textAlign: TextAlign.right,
                    style: TextStyle(
                      fontFamily: _fontFamily,
                      fontSize: 24,
                      height: 1.35,
                      fontWeight: FontWeight.w700,
                      color: kTextColor,
                    ),
                  ),
                  if (category.isNotEmpty) ...[
                    const SizedBox(height: 8),
                    Text(
                      category,
                      textAlign: TextAlign.right,
                      style: TextStyle(
                        fontFamily: _fontFamily,
                        fontSize: 14,
                        color: titleTextColor,
                      ),
                    ),
                  ],
                  const SizedBox(height: 16),
                  Wrap(
                    alignment: WrapAlignment.end,
                    textDirection: TextDirection.rtl,
                    spacing: 8,
                    runSpacing: 8,
                    children: [
                      _DetailBadge(
                        icon: _isDownloaded
                            ? Icons.download_done_rounded
                            : Icons.cloud_download_outlined,
                        label: _isDownloaded ? 'ئۆفلاین' : 'ئامادەی دابەزاندن',
                        fontFamily: _fontFamily,
                      ),
                      if (_isChecking)
                        _DetailBadge(
                          icon: Icons.sync_rounded,
                          label: 'دۆخی دابەزاندن',
                          fontFamily: _fontFamily,
                        ),
                      ...tags.map(
                        (tag) =>
                            _DetailTag(label: tag, fontFamily: _fontFamily),
                      ),
                    ],
                  ),
                  const SizedBox(height: 18),
                  _InfoPanel(
                    title: 'دەربارەی کتێب',
                    fontFamily: _fontFamily,
                    child: Text(
                      description,
                      textAlign: TextAlign.right,
                      style: TextStyle(
                        fontFamily: _fontFamily,
                        fontSize: 15,
                        height: 1.7,
                        color: widget.book.description.trim().isEmpty
                            ? titleTextColor
                            : kTextColor,
                      ),
                    ),
                  ),
                  const SizedBox(height: 14),
                  _InfoPanel(
                    title: 'زانیاری',
                    fontFamily: _fontFamily,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        _InfoRow(
                          label: 'ژمارەی تاگەکان',
                          value: '${tags.length}',
                          fontFamily: _fontFamily,
                        ),
                        _InfoRow(
                          label: 'دۆخی فایل',
                          value: widget.book.hasPdfUrl
                              ? 'ئامادەی دابەزاندن'
                              : 'فایل نەدۆزرایەوە',
                          fontFamily: _fontFamily,
                        ),
                        if (createdAt != null)
                          _InfoRow(
                            label: 'بەروار',
                            value:
                                '${createdAt.year}/${createdAt.month.toString().padLeft(2, '0')}/${createdAt.day.toString().padLeft(2, '0')}',
                            fontFamily: _fontFamily,
                          ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
        bottomNavigationBar: SafeArea(
          top: false,
          child: Padding(
            padding: const EdgeInsets.fromLTRB(12, 8, 12, 12),
            child: Row(
              textDirection: TextDirection.rtl,
              children: [
                Expanded(
                  child: OutlinedButton.icon(
                    onPressed: _shareBook,
                    icon: const Icon(Icons.ios_share_rounded),
                    label: Text(
                      'هاوبەشکردن',
                      style: TextStyle(
                        fontFamily: _fontFamily,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                    style: OutlinedButton.styleFrom(
                      foregroundColor: kTextColor,
                      side: BorderSide(color: strokeColor),
                      backgroundColor: Theme.of(
                        context,
                      ).cardColor.withValues(alpha: 0.94),
                      padding: const EdgeInsets.symmetric(vertical: 14),
                    ),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  flex: 2,
                  child: ElevatedButton.icon(
                    onPressed: (_isDownloading || _isOpening || _isChecking)
                        ? null
                        : _openReader,
                    icon: Icon(
                      _isOpening
                          ? Icons.hourglass_top_rounded
                          : _isDownloaded
                          ? Icons.menu_book_rounded
                          : Icons.download_rounded,
                    ),
                    label: Text(
                      _primaryButtonLabel,
                      style: TextStyle(
                        fontFamily: _fontFamily,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: kActiveIconColor,
                      foregroundColor: Colors.white,
                      disabledBackgroundColor: kActiveIconColor.withValues(
                        alpha: 0.48,
                      ),
                      padding: const EdgeInsets.symmetric(vertical: 14),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  String get _primaryButtonLabel {
    if (_isOpening) {
      return 'ئامادەکردن...';
    }
    if (_isDownloading) {
      final percent = (_downloadProgress * 100).round();
      return percent <= 0 ? 'دابەزاندن...' : 'دابەزاندن $percent%';
    }
    if (_isDownloaded) {
      return 'خوێندنەوە';
    }
    return 'دابەزاندن و خوێندنەوە';
  }

  Future<void> _refreshDownloadState() async {
    final downloaded = await _fileService.isDownloaded(widget.book);
    if (downloaded) {
      await _fileService.rememberDownloadedBook(widget.book);
    }
    if (!mounted) {
      return;
    }
    setState(() {
      _isDownloaded = downloaded;
      _isChecking = false;
    });
  }

  Future<File?> _ensureBookReady({required bool openAfter}) async {
    if (!widget.book.hasPdfUrl) {
      _showSnack('فایلی PDF بۆ ئەم کتێبە بەردەست نییە.');
      return null;
    }

    setState(() {
      if (openAfter) {
        _isOpening = true;
      } else {
        _isDownloading = true;
      }
      _downloadProgress = 0;
    });

    try {
      final file = await _fileService.ensureDownloaded(
        widget.book,
        onProgress: (progress) {
          if (!mounted) {
            return;
          }
          setState(() {
            _downloadProgress = progress;
          });
        },
      );

      if (!mounted) {
        return file;
      }

      await _fileService.rememberDownloadedBook(widget.book);
      setState(() {
        _isDownloaded = true;
        _isDownloading = false;
        _isOpening = false;
        _downloadProgress = 0;
      });
      return file;
    } catch (_) {
      if (!mounted) {
        return null;
      }
      setState(() {
        _isDownloading = false;
        _isOpening = false;
        _downloadProgress = 0;
      });
      _showSnack('نەتوانرا کتێبەکە دابەزێندرێت.');
      return null;
    }
  }

  Future<void> _openReader() async {
    final file = await _ensureBookReady(openAfter: true);
    if (file == null || !mounted) {
      return;
    }

    await Navigator.of(context).push(
      MaterialPageRoute<void>(
        builder: (_) => BookView(book: widget.book, initialFile: file),
      ),
    );

    if (!mounted) {
      return;
    }
    await _refreshDownloadState();
  }

  Future<void> _shareBook() async {
    final buffer = StringBuffer(widget.book.title.trim());
    final description = widget.book.description.trim();
    if (description.isNotEmpty) {
      buffer
        ..writeln()
        ..writeln()
        ..write(description);
    }
    if (widget.book.pdfUrl.trim().isNotEmpty) {
      buffer
        ..writeln()
        ..writeln()
        ..write(widget.book.pdfUrl.trim());
    }

    await SharePlus.instance.share(
      ShareParams(
        text: buffer.toString().trim(),
        subject: widget.book.title.trim(),
      ),
    );
  }

  void _showSnack(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          message,
          textDirection: TextDirection.rtl,
          style: TextStyle(fontFamily: _fontFamily),
        ),
        behavior: SnackBarBehavior.floating,
      ),
    );
  }
}

class _DetailBookCover extends StatelessWidget {
  const _DetailBookCover({required this.title, required this.imageUrl});

  final String title;
  final String? imageUrl;

  @override
  Widget build(BuildContext context) {
    final url = imageUrl?.trim() ?? '';

    return Container(
      width: 198,
      height: 284,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(24),
        boxShadow: [
          BoxShadow(
            color: kShadowColor.withValues(alpha: 0.2),
            blurRadius: 24,
            offset: const Offset(0, 14),
          ),
        ],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(24),
        child: url.isEmpty
            ? _DetailCoverPlaceholder(title: title)
            : Image.network(
                url,
                fit: BoxFit.cover,
                cacheWidth: 600,
                errorBuilder: (context, error, stackTrace) =>
                    _DetailCoverPlaceholder(title: title),
                loadingBuilder: (context, child, loadingProgress) {
                  if (loadingProgress == null) {
                    return child;
                  }
                  return _DetailCoverPlaceholder(title: title);
                },
              ),
      ),
    );
  }
}

class _DetailCoverPlaceholder extends StatelessWidget {
  const _DetailCoverPlaceholder({required this.title});

  final String title;

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(color: kActiveIconColor),
      padding: const EdgeInsets.all(18),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(
            Icons.menu_book_rounded,
            size: 44,
            color: Colors.white.withValues(alpha: 0.9),
          ),
          const SizedBox(height: 12),
          Text(
            title,
            maxLines: 4,
            overflow: TextOverflow.ellipsis,
            textAlign: TextAlign.center,
            style: const TextStyle(
              color: Colors.white,
              fontSize: 18,
              height: 1.4,
              fontWeight: FontWeight.w700,
            ),
          ),
        ],
      ),
    );
  }
}

class _DetailBadge extends StatelessWidget {
  const _DetailBadge({
    required this.icon,
    required this.label,
    required this.fontFamily,
  });

  final IconData icon;
  final String label;
  final String? fontFamily;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      decoration: BoxDecoration(
        color: Theme.of(context).cardColor.withValues(alpha: 0.95),
        borderRadius: BorderRadius.circular(999),
        border: Border.all(color: strokeColor),
      ),
      child: Row(
        textDirection: TextDirection.rtl,
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 16, color: kActiveIconColor),
          const SizedBox(width: 6),
          Text(
            label,
            textAlign: TextAlign.right,
            style: TextStyle(
              fontFamily: fontFamily,
              fontSize: 12,
              fontWeight: FontWeight.w700,
              color: kTextColor,
            ),
          ),
        ],
      ),
    );
  }
}

class _DetailTag extends StatelessWidget {
  const _DetailTag({required this.label, required this.fontFamily});

  final String label;
  final String? fontFamily;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 7),
      decoration: BoxDecoration(
        color: thirdColor.withValues(alpha: 0.94),
        borderRadius: BorderRadius.circular(999),
      ),
      child: Text(
        label,
        textAlign: TextAlign.right,
        style: TextStyle(
          fontFamily: fontFamily,
          fontSize: 12,
          color: kTextColor,
        ),
      ),
    );
  }
}

class _InfoPanel extends StatelessWidget {
  const _InfoPanel({
    required this.title,
    required this.fontFamily,
    required this.child,
  });

  final String title;
  final String? fontFamily;
  final Widget child;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Theme.of(context).cardColor.withValues(alpha: 0.95),
        borderRadius: BorderRadius.circular(22),
        border: Border.all(color: strokeColor),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Text(
            title,
            textAlign: TextAlign.right,
            style: TextStyle(
              fontFamily: fontFamily,
              fontSize: 17,
              fontWeight: FontWeight.w700,
              color: kTextColor,
            ),
          ),
          const SizedBox(height: 12),
          child,
        ],
      ),
    );
  }
}

class _InfoRow extends StatelessWidget {
  const _InfoRow({
    required this.label,
    required this.value,
    required this.fontFamily,
  });

  final String label;
  final String value;
  final String? fontFamily;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: Row(
        textDirection: TextDirection.rtl,
        children: [
          Text(
            label,
            textAlign: TextAlign.right,
            style: TextStyle(
              fontFamily: fontFamily,
              fontSize: 14,
              fontWeight: FontWeight.w700,
              color: kTextColor,
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Text(
              value,
              textAlign: TextAlign.right,
              style: TextStyle(
                fontFamily: fontFamily,
                fontSize: 13,
                color: titleTextColor,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

String _bookHeroTag(Book book) =>
    'book-cover-${book.id ?? book.slug ?? book.pdfUrl}';

List<String> _displayTags(Book book) {
  final values = <String>[];
  final category = book.category?.trim() ?? '';
  if (category.isNotEmpty) {
    values.add(category);
  }
  for (final tag in book.tags) {
    final value = tag.trim();
    if (value.isNotEmpty && !values.contains(value)) {
      values.add(value);
    }
  }
  return values.take(6).toList(growable: false);
}

String _descriptionPreview(Book book) {
  final text = book.description.trim();
  if (text.isNotEmpty) {
    return text;
  }
  return 'وردەکاری بۆ ئەم کتێبە زیاد نەکراوە.';
}
