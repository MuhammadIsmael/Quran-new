import 'dart:io';

import 'package:flutter/material.dart';
import 'package:pdfx/pdfx.dart';
import 'package:provider/provider.dart';
import 'package:runaki_islam/models/book_model.dart';
import 'package:runaki_islam/providers/settings_provider.dart';
import 'package:runaki_islam/services/book_file_service.dart';
import 'package:runaki_islam/util/background.dart';
import 'package:runaki_islam/util/constans.dart';
import 'package:share_plus/share_plus.dart';

class BookView extends StatefulWidget {
  const BookView({super.key, required this.book, this.initialFile});

  final Book book;
  final File? initialFile;

  @override
  State<BookView> createState() => _BookViewState();
}

class _BookViewState extends State<BookView> {
  final BookFileService _fileService = BookFileService();

  PdfController? _pdfController;
  int _currentPage = 1;
  int _pageCount = 0;
  bool _horizontalMode = false;
  bool _loading = true;
  double _downloadProgress = 0;
  String? _errorMessage;
  String? _fontFamily;

  @override
  void initState() {
    super.initState();
    final fontSetting = Provider.of<SettingsProvider>(
      context,
      listen: false,
    ).getsettingField('font_family');
    _fontFamily = fontSetting?.toString();
    _openDocument();
  }

  @override
  void dispose() {
    _pdfController?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final bottomBar = _buildBottomBar();

    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        backgroundColor: bgColor,
        appBar: AppBar(
          elevation: 0,
          scrolledUnderElevation: 0,
          centerTitle: true,
          backgroundColor: thirdColor,
          foregroundColor: iconColor,
          surfaceTintColor: Colors.transparent,
          title: Text(
            widget.book.title,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: TextStyle(
              fontFamily: _fontFamily,
              color: kTextColor,
              fontSize: 17,
              fontWeight: FontWeight.w700,
            ),
          ),
          actions: [
            IconButton(
              onPressed: _shareBook,
              icon: const Icon(Icons.share_outlined),
              tooltip: 'هاوبەشکردن',
            ),
            IconButton(
              onPressed: _loading ? null : _openDocument,
              icon: const Icon(Icons.refresh_rounded),
              tooltip: 'دووبارەکردنەوە',
            ),
          ],
        ),
        body: Stack(
          children: [
            const Background(),
            Padding(
              padding: EdgeInsets.fromLTRB(
                12,
                12,
                12,
                bottomBar == null ? 12 : 94,
              ),
              child: _buildBody(),
            ),
            if (bottomBar != null)
              Positioned(right: 12, left: 12, bottom: 12, child: bottomBar),
          ],
        ),
      ),
    );
  }

  Widget _buildBody() {
    if (_loading) {
      return _ReaderFeedbackCard(
        icon: Icons.download_rounded,
        title: 'ئامادەکردنی کتێب',
        message: _downloadProgress <= 0
            ? 'چاوەڕێ بکە تا فایلەکە ئامادە دەکرێت.'
            : 'پێشکەوتن: ${(_downloadProgress * 100).round()}%',
        fontFamily: _fontFamily,
        isLoading: true,
      );
    }

    if (_errorMessage != null) {
      return _ReaderFeedbackCard(
        icon: Icons.error_outline_rounded,
        title: 'کردنەوەی کتێب سەرکەوتوو نەبوو',
        message: _errorMessage!,
        buttonText: 'دووبارە هەوڵبدە',
        onPressed: _openDocument,
        fontFamily: _fontFamily,
      );
    }

    final controller = _pdfController;
    if (controller == null) {
      return _ReaderFeedbackCard(
        icon: Icons.picture_as_pdf_outlined,
        title: 'فایلی PDF نەدۆزرایەوە',
        message: 'کتێبەکە ناتوانرێت پیشان بدرێت.',
        buttonText: 'دووبارە هەوڵبدە',
        onPressed: _openDocument,
        fontFamily: _fontFamily,
      );
    }

    return Container(
      decoration: BoxDecoration(
        color: Theme.of(context).cardColor.withValues(alpha: 0.94),
        borderRadius: BorderRadius.circular(24),
        border: Border.all(color: strokeColor),
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(24),
        child: Directionality(
          textDirection: TextDirection.ltr,
          child: PdfView(
            key: ValueKey(
              '${widget.book.pdfUrl}-${_horizontalMode ? 'h' : 'v'}',
            ),
            controller: controller,
            reverse: false,
            scrollDirection: _horizontalMode ? Axis.horizontal : Axis.vertical,
            physics: const BouncingScrollPhysics(),
            backgroundDecoration: const BoxDecoration(color: Colors.white),
            builders: PdfViewBuilders<DefaultBuilderOptions>(
              options: const DefaultBuilderOptions(
                loaderSwitchDuration: Duration(milliseconds: 250),
              ),
              documentLoaderBuilder: (context) =>
                  const Center(child: CircularProgressIndicator()),
              pageLoaderBuilder: (context) => const Center(
                child: SizedBox(
                  width: 26,
                  height: 26,
                  child: CircularProgressIndicator(strokeWidth: 2.2),
                ),
              ),
              errorBuilder: (context, error) => _ReaderFeedbackCard(
                icon: Icons.picture_as_pdf_outlined,
                title: 'پێشاندانی PDF سەرکەوتوو نەبوو',
                message: error.toString(),
                buttonText: 'دووبارە هەوڵبدە',
                onPressed: _openDocument,
                fontFamily: _fontFamily,
              ),
            ),
            onDocumentLoaded: (document) {
              if (!mounted) {
                return;
              }
              setState(() {
                _pageCount = document.pagesCount;
                _currentPage = controller.page;
              });
            },
            onPageChanged: (page) {
              if (!mounted) {
                return;
              }
              setState(() {
                _currentPage = page;
              });
            },
          ),
        ),
      ),
    );
  }

  Widget? _buildBottomBar() {
    if (_loading || _errorMessage != null || _pdfController == null) {
      return null;
    }

    return SafeArea(
      top: false,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 6),
        decoration: BoxDecoration(
          color: Theme.of(context).cardColor.withValues(alpha: 0.96),
          borderRadius: BorderRadius.circular(18),
          border: Border.all(color: strokeColor),
          boxShadow: [
            BoxShadow(
              color: kShadowColor.withValues(alpha: 0.08),
              blurRadius: 16,
              offset: const Offset(0, 8),
            ),
          ],
        ),
        child: Row(
          textDirection: TextDirection.rtl,
          children: [
            IconButton(
              onPressed: _currentPage > 1 ? _goPreviousPage : null,
              icon: const Icon(Icons.chevron_right_rounded),
              iconSize: 20,
              constraints: const BoxConstraints.tightFor(width: 40, height: 40),
              tooltip: 'پەڕەی پێشوو',
            ),
            Expanded(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(
                    'پەڕە $_currentPage لە ${_pageCount == 0 ? '--' : _pageCount}',
                    style: TextStyle(
                      fontFamily: _fontFamily,
                      fontSize: 13,
                      fontWeight: FontWeight.w700,
                      color: kTextColor,
                    ),
                  ),
                  const SizedBox(height: 2),
                  Text(
                    _horizontalMode ? 'شێوازی ئاسۆیی' : 'شێوازی ستوونی',
                    style: TextStyle(
                      fontFamily: _fontFamily,
                      fontSize: 11,
                      color: titleTextColor,
                    ),
                  ),
                ],
              ),
            ),
            IconButton(
              onPressed: (_pageCount > 0 && _currentPage < _pageCount)
                  ? _goNextPage
                  : null,
              icon: const Icon(Icons.chevron_left_rounded),
              iconSize: 20,
              constraints: const BoxConstraints.tightFor(width: 40, height: 40),
              tooltip: 'پەڕەی داهاتوو',
            ),
            const VerticalDivider(width: 10, thickness: 0.8),
            IconButton(
              onPressed: _toggleScrollMode,
              icon: Icon(
                _horizontalMode
                    ? Icons.swap_vert_rounded
                    : Icons.swap_horiz_rounded,
              ),
              iconSize: 18,
              constraints: const BoxConstraints.tightFor(width: 38, height: 38),
              tooltip: 'گۆڕینی شێوازی خوێندنەوە',
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _openDocument() async {
    setState(() {
      _loading = true;
      _errorMessage = null;
      _downloadProgress = 0;
    });

    try {
      final file =
          widget.initialFile ??
          await _fileService.ensureDownloaded(
            widget.book,
            onProgress: (progress) {
              if (!mounted) {
                return;
              }
              setState(() {
                _downloadProgress = progress;
              });
            },
          );

      final controller = PdfController(
        document: PdfDocument.openFile(file.path),
      );

      if (!mounted) {
        controller.dispose();
        return;
      }

      final previous = _pdfController;
      setState(() {
        _pdfController = controller;
        _loading = false;
        _pageCount = 0;
        _currentPage = 1;
      });
      previous?.dispose();
    } catch (_) {
      if (!mounted) {
        return;
      }
      setState(() {
        _loading = false;
        _errorMessage = 'نەتوانرا فایلی PDF بکرێتەوە.';
      });
    }
  }

  Future<void> _goPreviousPage() async {
    final controller = _pdfController;
    if (controller == null || _currentPage <= 1) {
      return;
    }
    await controller.previousPage(
      duration: const Duration(milliseconds: 220),
      curve: Curves.easeOutCubic,
    );
  }

  Future<void> _goNextPage() async {
    final controller = _pdfController;
    if (controller == null || (_pageCount > 0 && _currentPage >= _pageCount)) {
      return;
    }
    await controller.nextPage(
      duration: const Duration(milliseconds: 220),
      curve: Curves.easeOutCubic,
    );
  }

  void _toggleScrollMode() {
    setState(() {
      _horizontalMode = !_horizontalMode;
    });
    WidgetsBinding.instance.addPostFrameCallback((_) {
      final controller = _pdfController;
      if (!mounted || controller == null) {
        return;
      }
      controller.jumpToPage(_currentPage);
    });
  }

  Future<void> _shareBook() async {
    final buffer = StringBuffer(widget.book.title.trim());
    if (widget.book.pdfUrl.trim().isNotEmpty) {
      buffer
        ..writeln()
        ..writeln()
        ..write(widget.book.pdfUrl.trim());
    }

    await SharePlus.instance.share(
      ShareParams(
        text: buffer.toString().trim(),
        subject: widget.book.title.trim(),
      ),
    );
  }
}

class _ReaderFeedbackCard extends StatelessWidget {
  const _ReaderFeedbackCard({
    required this.icon,
    required this.title,
    required this.message,
    required this.fontFamily,
    this.buttonText,
    this.onPressed,
    this.isLoading = false,
  });

  final IconData icon;
  final String title;
  final String message;
  final String? fontFamily;
  final String? buttonText;
  final VoidCallback? onPressed;
  final bool isLoading;

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Container(
          width: double.infinity,
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(
            color: Theme.of(context).cardColor.withValues(alpha: 0.95),
            borderRadius: BorderRadius.circular(22),
            border: Border.all(color: strokeColor),
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              if (isLoading)
                CircularProgressIndicator(color: kActiveIconColor)
              else
                Icon(icon, size: 40, color: kActiveIconColor),
              const SizedBox(height: 14),
              Text(
                title,
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontFamily: fontFamily,
                  fontSize: 18,
                  fontWeight: FontWeight.w700,
                  color: kTextColor,
                ),
              ),
              const SizedBox(height: 8),
              Text(
                message,
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontFamily: fontFamily,
                  fontSize: 13,
                  height: 1.5,
                  color: titleTextColor,
                ),
              ),
              if (buttonText != null && onPressed != null) ...[
                const SizedBox(height: 16),
                ElevatedButton(
                  onPressed: onPressed,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: kActiveIconColor,
                    foregroundColor: Colors.white,
                    padding: const EdgeInsets.symmetric(
                      horizontal: 18,
                      vertical: 12,
                    ),
                  ),
                  child: Text(
                    buttonText!,
                    style: TextStyle(
                      fontFamily: fontFamily,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }
}
