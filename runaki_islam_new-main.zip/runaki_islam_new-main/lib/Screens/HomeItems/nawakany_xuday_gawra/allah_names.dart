import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:runaki_islam/database/database_helper.dart';
import 'package:runaki_islam/models/allah_names_model.dart';
import 'package:runaki_islam/providers/settings_provider.dart';
import 'package:runaki_islam/util/background.dart';
import 'package:runaki_islam/util/constans.dart';

enum _AllahNamesViewMode { names, meanings }

class AllahNames extends StatefulWidget {
  final String? sarder;
  final String initialSearchTerm;

  const AllahNames({super.key, this.sarder, this.initialSearchTerm = ''});

  @override
  State<AllahNames> createState() => _AllahNamesState();
}

class _AllahNamesState extends State<AllahNames> {
  late Future<List<AllahNamesdata>> _namesFuture;
  final TextEditingController _searchController = TextEditingController();

  _AllahNamesViewMode _viewMode = _AllahNamesViewMode.names;
  String _searchTerm = '';
  int? _fontType;

  @override
  void initState() {
    super.initState();
    _fontType = Provider.of<SettingsProvider>(
      context,
      listen: false,
    ).getsettingField('font_family');
    _namesFuture = QueryCtr().getAllFruits();
    _searchTerm = widget.initialSearchTerm.trim();
    if (_searchTerm.isNotEmpty) {
      _searchController.text = _searchTerm;
    }
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bgColor,
      appBar: AppBar(
        toolbarHeight: 78,
        elevation: 0,
        centerTitle: true,
        backgroundColor: thirdColor,
        shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(bottom: Radius.circular(20)),
        ),
        leading: IconButton(
          onPressed: () => Navigator.pop(context),
          icon: Icon(Icons.arrow_back_ios_rounded, color: iconColor),
        ),
        title: Text(
          widget.sarder ?? 'ناوەکانی خودای گەورە',
          style: simpleTextStyle.copyWith(
            fontFamily: _fontType.toString(),
            fontWeight: FontWeight.w700,
          ),
        ),
      ),
      body: Stack(
        children: [
          const Background(),
          FutureBuilder<List<AllahNamesdata>>(
            future: _namesFuture,
            builder: (context, snapshot) {
              if (snapshot.connectionState == ConnectionState.waiting) {
                return _buildLoadingState();
              }

              if (snapshot.hasError) {
                return _buildErrorState('${snapshot.error}');
              }

              final allNames = snapshot.data ?? const <AllahNamesdata>[];
              if (allNames.isEmpty) {
                return _buildEmptyState();
              }

              final filteredNames = _filterNames(allNames);
              return Directionality(
                textDirection: TextDirection.rtl,
                child: Column(
                  children: [
                    _buildTopControls(
                      totalCount: allNames.length,
                      filteredCount: filteredNames.length,
                    ),
                    Expanded(
                      child: AnimatedSwitcher(
                        duration: const Duration(milliseconds: 250),
                        switchInCurve: Curves.easeOutCubic,
                        switchOutCurve: Curves.easeInCubic,
                        child: _viewMode == _AllahNamesViewMode.names
                            ? _buildNamesGrid(filteredNames)
                            : _buildMeaningsList(filteredNames),
                      ),
                    ),
                  ],
                ),
              );
            },
          ),
        ],
      ),
    );
  }

  Widget _buildTopControls({
    required int totalCount,
    required int filteredCount,
  }) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(14, 14, 14, 10),
      child: Container(
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: backgroundColor.withValues(alpha: 0.94),
          borderRadius: BorderRadius.circular(18),
          border: Border.all(color: strokeColor),
          boxShadow: [
            BoxShadow(
              color: kShadowColor,
              blurRadius: 16,
              offset: const Offset(0, 8),
            ),
          ],
        ),
        child: Column(
          children: [
            Row(
              children: [
                Expanded(
                  child: _ModeChip(
                    title: 'ناوەکان',
                    isSelected: _viewMode == _AllahNamesViewMode.names,
                    onTap: () {
                      setState(() {
                        _viewMode = _AllahNamesViewMode.names;
                      });
                    },
                    fontType: _fontType,
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: _ModeChip(
                    title: 'ماناکان',
                    isSelected: _viewMode == _AllahNamesViewMode.meanings,
                    onTap: () {
                      setState(() {
                        _viewMode = _AllahNamesViewMode.meanings;
                      });
                    },
                    fontType: _fontType,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 10),
            Container(
              decoration: BoxDecoration(
                color: Colors.white.withValues(alpha: 0.86),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: const Color(0x22000000)),
              ),
              child: TextField(
                controller: _searchController,
                textDirection: TextDirection.rtl,
                style: TextStyle(
                  fontFamily: _fontType.toString(),
                  fontSize: 14.8,
                  color: kTextColor,
                ),
                decoration: InputDecoration(
                  isDense: true,
                  border: InputBorder.none,
                  contentPadding: const EdgeInsets.symmetric(
                    horizontal: 12,
                    vertical: 12,
                  ),
                  hintText: 'گەڕان لە ناو یان ماناکەدا...',
                  hintStyle: TextStyle(
                    fontFamily: _fontType.toString(),
                    color: captionTextColor.withValues(alpha: 0.8),
                  ),
                  prefixIcon: Icon(
                    Icons.search_rounded,
                    color: iconColor,
                    size: 22,
                  ),
                  suffixIcon: _searchTerm.isEmpty
                      ? null
                      : IconButton(
                          onPressed: () {
                            _searchController.clear();
                            setState(() {
                              _searchTerm = '';
                            });
                          },
                          icon: Icon(Icons.close_rounded, color: iconColor),
                        ),
                ),
                onChanged: (value) {
                  setState(() {
                    _searchTerm = value.trim();
                  });
                },
              ),
            ),
            const SizedBox(height: 8),
            Align(
              alignment: Alignment.centerRight,
              child: Text(
                filteredCount == totalCount
                    ? 'کۆی ناوەکان: $totalCount'
                    : 'ئەنجامی گەڕان: $filteredCount لە $totalCount',
                style: TextStyle(
                  fontFamily: _fontType.toString(),
                  color: titleTextColor,
                  fontSize: 13.2,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildNamesGrid(List<AllahNamesdata> items) {
    if (items.isEmpty) {
      return _buildNoResultState();
    }

    return LayoutBuilder(
      key: const ValueKey('names-grid'),
      builder: (context, constraints) {
        final width = constraints.maxWidth;
        final crossAxisCount = width >= 900
            ? 4
            : width >= 700
            ? 3
            : 2;
        return GridView.builder(
          padding: const EdgeInsets.fromLTRB(14, 0, 14, 16),
          physics: const BouncingScrollPhysics(),
          itemCount: items.length,
          gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: crossAxisCount,
            mainAxisSpacing: 10,
            crossAxisSpacing: 10,
            childAspectRatio: 1.18,
          ),
          itemBuilder: (context, index) {
            final item = items[index];
            return _AllahNameCard(
              index: index + 1,
              name: item.t1,
              meaning: item.t2,
              fontType: _fontType,
            );
          },
        );
      },
    );
  }

  Widget _buildMeaningsList(List<AllahNamesdata> items) {
    if (items.isEmpty) {
      return _buildNoResultState();
    }

    return ListView.separated(
      key: const ValueKey('meanings-list'),
      padding: const EdgeInsets.fromLTRB(14, 0, 14, 16),
      physics: const BouncingScrollPhysics(),
      itemCount: items.length,
      separatorBuilder: (_, index) => const SizedBox(height: 10),
      itemBuilder: (context, index) {
        final item = items[index];
        return Container(
          decoration: BoxDecoration(
            color: backgroundColor.withValues(alpha: 0.92),
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: strokeColor),
            boxShadow: [
              BoxShadow(
                color: kShadowColor,
                blurRadius: 12,
                offset: const Offset(0, 6),
              ),
            ],
          ),
          child: ExpansionTile(
            tilePadding: const EdgeInsetsDirectional.only(start: 14, end: 10),
            childrenPadding: const EdgeInsets.fromLTRB(14, 0, 14, 14),
            iconColor: kActiveIconColor,
            collapsedIconColor: titleTextColor,
            leading: CircleAvatar(
              radius: 16,
              backgroundColor: primaryColor.withValues(alpha: 0.12),
              child: Text(
                '${index + 1}',
                style: TextStyle(
                  fontFamily: _fontType.toString(),
                  color: kActiveIconColor,
                  fontSize: 12.5,
                  fontWeight: FontWeight.w700,
                ),
              ),
            ),
            title: Text(
              item.t1,
              textAlign: TextAlign.right,
              style: TextStyle(
                fontFamily: _fontType.toString(),
                color: kTextColor,
                fontWeight: FontWeight.w800,
                fontSize: 17.5,
              ),
            ),
            subtitle: Text(
              item.t2,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              textAlign: TextAlign.right,
              style: TextStyle(
                fontFamily: _fontType.toString(),
                color: titleTextColor,
                fontSize: 13.4,
              ),
            ),
            children: [
              Align(
                alignment: Alignment.centerRight,
                child: Text(
                  item.t2,
                  textAlign: TextAlign.right,
                  style: TextStyle(
                    fontFamily: _fontType.toString(),
                    color: kTextColor.withValues(alpha: 0.93),
                    height: 1.6,
                    fontSize: 16.2,
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _buildLoadingState() {
    return const Center(
      child: SizedBox(
        width: 34,
        height: 34,
        child: CircularProgressIndicator(strokeWidth: 2.2),
      ),
    );
  }

  Widget _buildErrorState(String error) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(18),
        child: Container(
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            color: backgroundColor.withValues(alpha: 0.94),
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: const Color(0x33B00020)),
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Icon(Icons.error_outline_rounded, color: Color(0xFFB00020)),
              const SizedBox(height: 10),
              Text(
                'هەڵەیەک ڕوویدا لە بارکردنی ناوەکان.',
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontFamily: _fontType.toString(),
                  fontSize: 16,
                  fontWeight: FontWeight.w700,
                  color: kTextColor,
                ),
              ),
              const SizedBox(height: 6),
              Text(
                error,
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontFamily: _fontType.toString(),
                  fontSize: 12.5,
                  color: captionTextColor,
                ),
              ),
              const SizedBox(height: 10),
              OutlinedButton.icon(
                onPressed: () {
                  setState(() {
                    _namesFuture = QueryCtr().getAllFruits();
                  });
                },
                icon: const Icon(Icons.refresh_rounded),
                label: Text(
                  'دووبارە هەوڵبدەوە',
                  style: TextStyle(fontFamily: _fontType.toString()),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildEmptyState() {
    return Center(
      child: Text(
        'هیچ ناوێک نەدۆزرایەوە.',
        style: TextStyle(
          fontFamily: _fontType.toString(),
          color: captionTextColor,
          fontSize: 15.5,
          fontWeight: FontWeight.w600,
        ),
      ),
    );
  }

  Widget _buildNoResultState() {
    return Center(
      child: Text(
        'ئەنجامێک بۆ گەڕانەکەت نەدۆزرایەوە.',
        style: TextStyle(
          fontFamily: _fontType.toString(),
          color: captionTextColor,
          fontSize: 15.5,
          fontWeight: FontWeight.w600,
        ),
      ),
    );
  }

  List<AllahNamesdata> _filterNames(List<AllahNamesdata> names) {
    final term = _searchTerm.trim().toLowerCase();
    if (term.isEmpty) {
      return names;
    }

    return names.where((item) {
      final name = item.t1.toLowerCase();
      final meaning = item.t2.toLowerCase();
      return name.contains(term) || meaning.contains(term);
    }).toList();
  }
}

class _ModeChip extends StatelessWidget {
  final String title;
  final bool isSelected;
  final VoidCallback onTap;
  final int? fontType;

  const _ModeChip({
    required this.title,
    required this.isSelected,
    required this.onTap,
    required this.fontType,
  });

  @override
  Widget build(BuildContext context) {
    return AnimatedContainer(
      duration: const Duration(milliseconds: 200),
      curve: Curves.easeOut,
      decoration: BoxDecoration(
        color: isSelected
            ? primaryColor.withValues(alpha: 0.15)
            : Colors.white.withValues(alpha: 0.6),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: isSelected
              ? primaryColor.withValues(alpha: 0.38)
              : strokeColor,
        ),
      ),
      child: InkWell(
        borderRadius: BorderRadius.circular(12),
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 10),
          child: Center(
            child: Text(
              title,
              style: TextStyle(
                fontFamily: fontType.toString(),
                color: isSelected ? kActiveIconColor : titleTextColor,
                fontWeight: FontWeight.w700,
                fontSize: 14.5,
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class _AllahNameCard extends StatelessWidget {
  final int index;
  final String name;
  final String meaning;
  final int? fontType;

  const _AllahNameCard({
    required this.index,
    required this.name,
    required this.meaning,
    required this.fontType,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: backgroundColor.withValues(alpha: 0.94),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: strokeColor),
        boxShadow: [
          BoxShadow(
            color: kShadowColor,
            blurRadius: 10,
            offset: const Offset(0, 6),
          ),
        ],
      ),
      child: Stack(
        children: [
          Positioned(
            top: 10,
            left: 10,
            child: Icon(
              Icons.auto_awesome_rounded,
              color: primaryColor.withValues(alpha: 0.18),
              size: 40,
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(12),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                Row(
                  children: [
                    CircleAvatar(
                      radius: 14,
                      backgroundColor: primaryColor.withValues(alpha: 0.14),
                      child: Text(
                        '$index',
                        style: TextStyle(
                          fontFamily: fontType.toString(),
                          color: kActiveIconColor,
                          fontWeight: FontWeight.w700,
                          fontSize: 11.5,
                        ),
                      ),
                    ),
                    const Spacer(),
                    Icon(
                      Icons.stars_rounded,
                      size: 16,
                      color: secondColor.withValues(alpha: 0.95),
                    ),
                  ],
                ),
                const Spacer(),
                Text(
                  name,
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  textAlign: TextAlign.right,
                  style: TextStyle(
                    fontFamily: fontType.toString(),
                    color: kTextColor,
                    fontSize: 19,
                    height: 1.3,
                    fontWeight: FontWeight.w800,
                  ),
                ),
                const SizedBox(height: 6),
                Text(
                  meaning,
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  textAlign: TextAlign.right,
                  style: TextStyle(
                    fontFamily: fontType.toString(),
                    color: titleTextColor,
                    fontSize: 13.3,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
