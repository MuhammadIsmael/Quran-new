import 'package:flutter/material.dart';
import 'package:hijri/hijri_calendar.dart';
import 'package:runaki_islam/util/background.dart';
import 'package:runaki_islam/util/constans.dart';
import 'package:analog_clock/analog_clock.dart';
import 'package:runaki_islam/util/scale_in.dart';
import 'package:runaki_islam/providers/settings_provider.dart';
import 'package:provider/provider.dart';

class HijriCalendarPage extends StatefulWidget {
  final String? sarder;

  const HijriCalendarPage({super.key, this.sarder});
  @override
  State<StatefulWidget> createState() => _HijriCalendarPageState();
}

class _HijriCalendarPageState extends State<HijriCalendarPage> {
  final HijriCalendar _today = HijriCalendar.now();

  int? fontType;

  Color myColor = splashColor;
  Color iColor = const Color(0xff6a7885);
  Color tColor = const Color(0xff4d5351);

  @override
  void initState() {
    super.initState();
    fontType = Provider.of<SettingsProvider>(context, listen: false)
        .getsettingField('font_family');
    HijriCalendar.setLocal('ar');
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        backgroundColor: bgColor,
        appBar: AppBar(
          toolbarHeight: 80,
          backgroundColor: thirdColor,
          title: Text(
            "${widget.sarder}",
            style: simpleTextStyle.copyWith(
              fontFamily: fontType.toString(),
            ),
          ),
          shape: const RoundedRectangleBorder(
              borderRadius: BorderRadius.vertical(bottom: Radius.circular(20))),
          centerTitle: true,
          elevation: 0,
          leading: IconButton(
            color: iconColor,
            onPressed: () => Navigator.pop(context),
            icon: Icon(
              Icons.arrow_back_ios_rounded,
              color: iconColor,
            ),
          ),
        ),
        body: Stack(
          children: <Widget>[
            const Background(),
            SingleChildScrollView(
              physics: const BouncingScrollPhysics(),
              padding: const EdgeInsets.only(bottom: 80, top: 20),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                  AnalogClock(
                    decoration: BoxDecoration(
                        border: Border.all(width: 2.0, color: kActiveIconColor),
                        color: Colors.transparent,
                        shape: BoxShape.circle),
                    width: 150.0,
                    height: 150,
                    isLive: true,
                    hourHandColor: titleTextColor,
                    minuteHandColor: titleTextColor,
                    showSecondHand: true,
                    numberColor: descriptionTectColor,
                    showNumbers: true,
                    textScaleFactor: 1.4,
                    showTicks: true,
                    showAllNumbers: true,
                    datetime: DateTime.now(),
                    secondHandColor: kActiveIconColor,
                    showDigitalClock: false,
                  ),
                  const SizedBox(height: 20),
                  ScaleIn(
                      duration: 2000,
                      child: Container(
                        width: double.infinity,
                        margin: const EdgeInsets.symmetric(horizontal: 15),
                        padding: const EdgeInsets.all(8),
                        decoration: BoxDecoration(
                            color: kActiveIconColor.withValues(alpha: 0.6),
                            borderRadius: BorderRadius.circular(20)),
                        child: Column(
                          children: [
                            Text(
                              "$_today",
                              style: TextStyle(
                                  fontFamily: fontType.toString(),
                                  color: Colors.white,
                                  fontSize: 25),
                            )
                          ],
                        ),
                      )),
                  const SizedBox(height: 15),
                  ScaleIn(
                      duration: 4000,
                      child: Container(
                        width: double.infinity,
                        margin: const EdgeInsets.symmetric(horizontal: 15),
                        padding: const EdgeInsets.all(8),
                        decoration: BoxDecoration(
                            color: kActiveIconColor.withValues(alpha: 0.6),
                            borderRadius: BorderRadius.circular(20)),
                        child: Column(
                          children: [
                            Text(
                              "مانگی ${_today.longMonthName}",
                              style: TextStyle(
                                  fontFamily: fontType.toString(),
                                  color: Colors.white,
                                  fontSize: 25),
                            ),
                            const SizedBox(height: 10),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                const SizedBox(),
                                Column(
                                  children: [
                                    Text(
                                      "${_today.hDay}",
                                      style: TextStyle(
                                          fontFamily: fontType.toString(),
                                          color: Colors.white,
                                          fontSize: 25),
                                    ),
                                    Text(
                                      "ڕۆژ",
                                      style: TextStyle(
                                          fontFamily: fontType.toString(),
                                          color: Colors.white,
                                          fontSize: 20),
                                    ),
                                  ],
                                ),
                                Column(
                                  children: [
                                    Text(
                                      "${_today.hMonth}",
                                      style: TextStyle(
                                          fontFamily: fontType.toString(),
                                          color: Colors.white,
                                          fontSize: 25),
                                    ),
                                    Text(
                                      "مانگ",
                                      style: TextStyle(
                                          fontFamily: fontType.toString(),
                                          color: Colors.white,
                                          fontSize: 20),
                                    ),
                                  ],
                                ),
                                Column(
                                  children: [
                                    Text(
                                      "${_today.hYear}",
                                      style: TextStyle(
                                          fontFamily: fontType.toString(),
                                          color: Colors.white,
                                          fontSize: 25),
                                    ),
                                    Text(
                                      "ساڵ",
                                      style: TextStyle(
                                          fontFamily: fontType.toString(),
                                          color: Colors.white,
                                          fontSize: 20),
                                    ),
                                  ],
                                ),
                                const SizedBox(),
                              ],
                            ),
                          ],
                        ),
                      )),
                  const SizedBox(height: 15),
                  ScaleIn(
                      duration: 6000,
                      child: Container(
                        width: double.infinity,
                        margin: const EdgeInsets.symmetric(horizontal: 15),
                        padding: const EdgeInsets.all(8),
                        decoration: BoxDecoration(
                            color: kActiveIconColor.withValues(alpha: 0.6),
                            borderRadius: BorderRadius.circular(20)),
                        child: Column(
                          children: [
                            Text(
                              widget.sarder!,
                              style: TextStyle(
                                  fontFamily: fontType.toString(),
                                  color: Colors.white,
                                  fontSize: 20),
                            ),
                            myContainer(": ڕۆژ", "${_today.hDay}"),
                            myContainer(": مانگ", "${_today.hMonth}"),
                            myContainer(": ساڵ", "${_today.hYear}"),
                            myContainer(
                                "ڕۆژەکانی مانگ", "${_today.lengthOfMonth}"),
                            myContainer(": ناوی مانگ", _today.longMonthName)
                          ],
                        ),
                      )),
                ],
              ),
            )
          ],
        ));
  }

  Widget myContainer(String title, String desc) {
    return Container(
      margin: const EdgeInsets.only(top: 10),
      padding: const EdgeInsets.only(right: 10),
      decoration: BoxDecoration(
        border: Border.all(color: Colors.white),
        borderRadius: const BorderRadius.only(
            topLeft: Radius.circular(20),
            bottomLeft: Radius.circular(20),
            topRight: Radius.circular(10),
            bottomRight: Radius.circular(10)),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Container(
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(20), color: Colors.white),
            child: Text(
              desc,
              style: TextStyle(
                  fontFamily: fontType.toString(),
                  color: kActiveIconColor,
                  fontSize: 20),
            ),
          ),
          Text(
            title,
            style: TextStyle(
                fontFamily: fontType.toString(),
                color: Colors.white,
                fontSize: 20),
          )
        ],
      ),
    );
  }
}
