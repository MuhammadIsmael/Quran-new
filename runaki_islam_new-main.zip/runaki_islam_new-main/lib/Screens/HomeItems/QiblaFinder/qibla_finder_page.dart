import 'dart:async';
import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:flutter_compass/flutter_compass.dart';
import 'package:geolocator/geolocator.dart';
import 'package:provider/provider.dart';
import 'package:runaki_islam/providers/settings_provider.dart';
import 'package:runaki_islam/util/animation_helper.dart';
import 'package:runaki_islam/util/constans.dart';

class QiblaFinderPage extends StatefulWidget {
  const QiblaFinderPage({super.key});

  @override
  State<QiblaFinderPage> createState() => _QiblaFinderPageState();
}

class _QiblaFinderPageState extends State<QiblaFinderPage> {
  static const double _kaabaLat = 21.4225;
  static const double _kaabaLon = 39.8262;

  int? _fontType;
  Position? _position;
  double? _heading;
  double? _qiblaBearing;
  String? _errorText;
  bool _isLoadingLocation = true;
  bool _isCompassAvailable = true;

  StreamSubscription<CompassEvent>? _compassSub;
  double _needleTurns = 0.0;
  bool _needleInitialized = false;

  @override
  void initState() {
    super.initState();
    _fontType = Provider.of<SettingsProvider>(
      context,
      listen: false,
    ).getsettingField('font_family');
    _startCompass();
    unawaited(_refreshLocation());
  }

  @override
  void dispose() {
    _compassSub?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final relative = _relativeQiblaDirection();
    final distanceKm = _distanceToKaabaKm();
    final isReady =
        _position != null &&
        _heading != null &&
        _qiblaBearing != null &&
        _isCompassAvailable;

    return Scaffold(
      backgroundColor: bgColor,
      appBar: AppBar(
        toolbarHeight: 76,
        backgroundColor: thirdColor,
        centerTitle: true,
        elevation: 0,
        shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(bottom: Radius.circular(20)),
        ),
        leading: IconButton(
          color: iconColor,
          onPressed: () => Navigator.pop(context),
          icon: const Icon(Icons.arrow_back_ios_rounded),
        ),
        title: Text(
          'قیبلە نواندەر',
          style: simpleTextStyle.copyWith(fontFamily: _fontType.toString()),
        ),
      ),
      body: SafeArea(
        top: false,
        child: RefreshIndicator(
          onRefresh: _refreshLocation,
          child: ListView(
            physics: const AlwaysScrollableScrollPhysics(
              parent: BouncingScrollPhysics(),
            ),
            padding: const EdgeInsets.fromLTRB(14, 14, 14, 120),
            children: [
              FadeSlideIn(
                child: _glassCard(
                  child: Directionality(
                    textDirection: TextDirection.rtl,
                    child: Column(
                      children: [
                        Row(
                          children: [
                            Icon(
                              Icons.location_on_outlined,
                              color: kActiveIconColor,
                            ),
                            const SizedBox(width: 8),
                            Expanded(
                              child: Text(
                                _position == null
                                    ? 'شوێن دیاری نەکراوە'
                                    : 'Lat ${_format(_position!.latitude)}  •  Lon ${_format(_position!.longitude)}',
                                textAlign: TextAlign.right,
                                style: TextStyle(
                                  fontFamily: _fontType.toString(),
                                  fontWeight: FontWeight.w700,
                                  color: kTextColor.withValues(alpha: 0.86),
                                ),
                              ),
                            ),
                            const SizedBox(width: 8),
                            IconButton.filledTonal(
                              onPressed: _isLoadingLocation
                                  ? null
                                  : () => unawaited(_refreshLocation()),
                              style: IconButton.styleFrom(
                                backgroundColor: kActiveIconColor.withValues(
                                  alpha: 0.12,
                                ),
                              ),
                              icon: _isLoadingLocation
                                  ? const SizedBox(
                                      width: 18,
                                      height: 18,
                                      child: CircularProgressIndicator(
                                        strokeWidth: 2.2,
                                      ),
                                    )
                                  : const Icon(Icons.refresh_rounded),
                            ),
                          ],
                        ),
                        if (_errorText != null) ...[
                          const SizedBox(height: 8),
                          Container(
                            width: double.infinity,
                            padding: const EdgeInsets.symmetric(
                              horizontal: 12,
                              vertical: 10,
                            ),
                            decoration: BoxDecoration(
                              color: const Color(0xFFFFECE8),
                              borderRadius: BorderRadius.circular(12),
                              border: Border.all(
                                color: const Color(
                                  0xFFED8E7A,
                                ).withValues(alpha: 0.45),
                              ),
                            ),
                            child: Text(
                              _errorText!,
                              textAlign: TextAlign.right,
                              style: TextStyle(
                                fontFamily: _fontType.toString(),
                                color: const Color(0xFF9D3C25),
                                fontWeight: FontWeight.w700,
                              ),
                            ),
                          ),
                        ],
                      ],
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 12),
              FadeSlideIn(
                delay: const Duration(milliseconds: 60),
                child: _glassCard(
                  padding: const EdgeInsets.fromLTRB(14, 14, 14, 18),
                  child: Column(
                    children: [
                      Directionality(
                        textDirection: TextDirection.rtl,
                        child: Row(
                          children: [
                            _headerBadge(
                              icon: Icons.explore_rounded,
                              label: isReady ? 'ئامادەیە' : 'چاوەڕوانی',
                              color: isReady
                                  ? const Color(0xFF0F9464)
                                  : const Color(0xFFB0862D),
                            ),
                            const Spacer(),
                            Text(
                              'ئاراستەی قیبلە',
                              style: TextStyle(
                                fontFamily: _fontType.toString(),
                                fontSize: 18,
                                fontWeight: FontWeight.w800,
                                color: kTextColor,
                              ),
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(height: 14),
                      _compassArea(scheme: scheme, relative: relative),
                      const SizedBox(height: 12),
                      if (isReady) _directionHint(relative),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 12),
              FadeSlideIn(
                delay: const Duration(milliseconds: 100),
                child: Directionality(
                  textDirection: TextDirection.rtl,
                  child: Row(
                    children: [
                      Expanded(
                        child: _metricTile(
                          title: 'ئاراستەی قیبلە',
                          value: _qiblaBearing == null
                              ? '--°'
                              : '${_qiblaBearing!.round()}°',
                          icon: Icons.travel_explore_rounded,
                        ),
                      ),
                      const SizedBox(width: 10),
                      Expanded(
                        child: _metricTile(
                          title: 'ئاراستەی ئێستا',
                          value: _heading == null
                              ? '--°'
                              : '${_heading!.round()}°',
                          icon: Icons.navigation_rounded,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 10),
              FadeSlideIn(
                delay: const Duration(milliseconds: 120),
                child: Directionality(
                  textDirection: TextDirection.rtl,
                  child: _metricTile(
                    title: 'دووری تا مەککە',
                    value: distanceKm == null
                        ? '-- km'
                        : '${_format(distanceKm)} km',
                    icon: Icons.route_rounded,
                  ),
                ),
              ),
              const SizedBox(height: 12),
              FadeSlideIn(
                delay: const Duration(milliseconds: 140),
                child: Directionality(
                  textDirection: TextDirection.rtl,
                  child: _glassCard(
                    child: Text(
                      'تێبینی: باشترین ئەنجام بۆ قیبلە، مۆبایلەکەت لە دوو-سێ جار بە شێوەی 8 بجوڵێنە بۆ کالیبرەکردنی سنسەری کۆمپا.',
                      textAlign: TextAlign.right,
                      style: TextStyle(
                        fontFamily: _fontType.toString(),
                        color: titleTextColor,
                        height: 1.5,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _compassArea({
    required ColorScheme scheme,
    required double? relative,
  }) {
    return SizedBox(
      height: 300,
      child: Stack(
        alignment: Alignment.center,
        children: [
          Container(
            width: 286,
            height: 286,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: scheme.surface,
              border: Border.all(color: strokeColor),
            ),
            child: CustomPaint(painter: _CompassTicksPainter(scheme)),
          ),
          Container(
            width: 220,
            height: 220,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              border: Border.all(
                color: kActiveIconColor.withValues(alpha: 0.30),
                width: 1.7,
              ),
            ),
          ),
          ..._cardinalMarks(),
          if (_isCompassAvailable && relative != null)
            AnimatedRotation(
              turns: _needleTurns,
              duration: const Duration(milliseconds: 240),
              curve: Curves.easeInOutCubic,
              child: _needle(),
            )
          else
            Icon(
              Icons.warning_amber_rounded,
              size: 40,
              color: const Color(0xFFB6573C),
            ),
          Container(
            width: 58,
            height: 58,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: Colors.white,
              border: Border.all(
                color: kActiveIconColor.withValues(alpha: 0.35),
              ),
              boxShadow: [
                BoxShadow(
                  color: scheme.shadow.withValues(alpha: 0.14),
                  blurRadius: 12,
                  offset: const Offset(0, 5),
                ),
              ],
            ),
            child: Icon(
              Icons.mosque_rounded,
              color: kActiveIconColor,
              size: 28,
            ),
          ),
        ],
      ),
    );
  }

  Widget _needle() {
    return SizedBox(
      width: 30,
      height: 210,
      child: Column(
        children: [
          Container(
            width: 30,
            height: 30,
            decoration: const BoxDecoration(
              shape: BoxShape.circle,
              color: Color(0xFF0E7A5B),
            ),
            child: const Icon(
              Icons.place_rounded,
              size: 16,
              color: Colors.white,
            ),
          ),
          Expanded(
            child: Container(
              width: 6,
              decoration: BoxDecoration(
                color: const Color(0xFF0E7A5B),
                borderRadius: BorderRadius.circular(99),
                boxShadow: const [
                  BoxShadow(
                    color: Color(0x330E7A5B),
                    blurRadius: 12,
                    offset: Offset(0, 6),
                  ),
                ],
              ),
            ),
          ),
          const Icon(
            Icons.arrow_drop_down_rounded,
            size: 36,
            color: Color(0xFF0E7A5B),
          ),
        ],
      ),
    );
  }

  List<Widget> _cardinalMarks() {
    const marks = <_CompassMark>[
      _CompassMark('N', Alignment(0, -0.90)),
      _CompassMark('E', Alignment(0.90, 0)),
      _CompassMark('S', Alignment(0, 0.90)),
      _CompassMark('W', Alignment(-0.90, 0)),
    ];

    return marks
        .map(
          (mark) => Align(
            alignment: mark.alignment,
            child: Text(
              mark.label,
              style: const TextStyle(
                fontFamily: 'english',
                fontWeight: FontWeight.w800,
                color: Color(0xFF2B3F37),
                fontSize: 16,
              ),
            ),
          ),
        )
        .toList();
  }

  Widget _directionHint(double? relative) {
    if (relative == null) return const SizedBox.shrink();
    final rounded = relative.round();
    final close = rounded <= 8 || rounded >= 352;
    final turnRight = rounded <= 180;
    final turnAmount = turnRight ? rounded : 360 - rounded;
    final text = close
        ? 'ئێستا لە ئاراستەی قیبلەدایت'
        : turnRight
        ? 'بسوڕە بۆ ڕاست $turnAmount°'
        : 'بسوڕە بۆ چەپ $turnAmount°';

    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
      decoration: BoxDecoration(
        color: close
            ? const Color(0xFF18A874).withValues(alpha: 0.14)
            : const Color(0xFFF3C45D).withValues(alpha: 0.18),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Text(
        text,
        textAlign: TextAlign.center,
        style: TextStyle(
          fontFamily: _fontType.toString(),
          fontWeight: FontWeight.w800,
          color: close ? const Color(0xFF0C8B5E) : const Color(0xFF8A651E),
        ),
      ),
    );
  }

  Widget _headerBadge({
    required IconData icon,
    required String label,
    required Color color,
  }) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
      decoration: BoxDecoration(
        color: color.withValues(alpha: 0.16),
        borderRadius: BorderRadius.circular(99),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 16, color: color),
          const SizedBox(width: 6),
          Text(
            label,
            style: TextStyle(
              fontFamily: _fontType.toString(),
              fontWeight: FontWeight.w800,
              color: color,
            ),
          ),
        ],
      ),
    );
  }

  Widget _metricTile({
    required String title,
    required String value,
    required IconData icon,
  }) {
    return _glassCard(
      child: Row(
        children: [
          Container(
            width: 36,
            height: 36,
            decoration: BoxDecoration(
              color: kActiveIconColor.withValues(alpha: 0.12),
              borderRadius: BorderRadius.circular(10),
            ),
            child: Icon(icon, size: 19, color: kActiveIconColor),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                Text(
                  title,
                  textAlign: TextAlign.right,
                  style: TextStyle(
                    fontFamily: _fontType.toString(),
                    fontSize: 13,
                    fontWeight: FontWeight.w600,
                    color: titleTextColor,
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  value,
                  textAlign: TextAlign.right,
                  style: const TextStyle(
                    fontFamily: 'english',
                    fontSize: 20,
                    fontWeight: FontWeight.w700,
                    color: Color(0xFF123D31),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _glassCard({required Widget child, EdgeInsets? padding}) {
    final scheme = Theme.of(context).colorScheme;
    final isDark = Theme.of(context).brightness == Brightness.dark;
    return Container(
      padding: padding ?? const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: scheme.surface.withValues(alpha: isDark ? 0.82 : 0.94),
        borderRadius: BorderRadius.circular(18),
        border: Border.all(
          color: scheme.outline.withValues(alpha: isDark ? 0.30 : 0.18),
        ),
        boxShadow: [
          BoxShadow(
            color: scheme.shadow.withValues(alpha: isDark ? 0.22 : 0.10),
            blurRadius: 20,
            offset: const Offset(0, 8),
          ),
        ],
      ),
      child: child,
    );
  }

  Future<void> _refreshLocation() async {
    setState(() {
      _isLoadingLocation = true;
      _errorText = null;
    });

    try {
      final serviceEnabled = await Geolocator.isLocationServiceEnabled();
      if (!serviceEnabled) {
        setState(() {
          _errorText = 'تکایە GPS بکەرەوە بۆ دیاریکردنی قیبلە.';
          _isLoadingLocation = false;
        });
        return;
      }

      var permission = await Geolocator.checkPermission();
      if (permission == LocationPermission.denied) {
        permission = await Geolocator.requestPermission();
      }
      if (permission == LocationPermission.denied) {
        setState(() {
          _errorText = 'مۆڵەتی شوێن پێویستە بۆ Qibla Finder.';
          _isLoadingLocation = false;
        });
        return;
      }
      if (permission == LocationPermission.deniedForever) {
        setState(() {
          _errorText =
              'مۆڵەتی شوێن قەدەغە کراوە. لە settings مۆڵەت بدە بۆ بەردەوامبوون.';
          _isLoadingLocation = false;
        });
        return;
      }

      final position = await Geolocator.getCurrentPosition(
        desiredAccuracy: LocationAccuracy.bestForNavigation,
      );
      final qibla = _calculateQiblaBearing(
        position.latitude,
        position.longitude,
      );
      setState(() {
        _position = position;
        _qiblaBearing = qibla;
        _isLoadingLocation = false;
      });
      _updateNeedleTurns();
    } catch (_) {
      setState(() {
        _errorText = 'هەڵە ڕوویدا لە وەرگرتنی شوێن.';
        _isLoadingLocation = false;
      });
    }
  }

  void _startCompass() {
    final stream = FlutterCompass.events;
    if (stream == null) {
      setState(() {
        _isCompassAvailable = false;
        _errorText = 'ئەم ئامێرە سنسەری کۆمپا نێیە.';
      });
      return;
    }

    _compassSub = stream.listen(
      (event) {
        final heading = event.heading;
        if (heading == null) return;
        setState(() {
          _heading = heading;
        });
        _updateNeedleTurns();
      },
      onError: (_) {
        if (!mounted) return;
        setState(() {
          _isCompassAvailable = false;
          _errorText = 'ناتوانرێت زانیاری کۆمپا بخوێندرێتەوە.';
        });
      },
    );
  }

  void _updateNeedleTurns() {
    final relative = _relativeQiblaDirection();
    if (relative == null) return;
    if (!_needleInitialized) {
      setState(() {
        _needleTurns = relative / 360.0;
        _needleInitialized = true;
      });
      return;
    }

    final current = _normalize360(_needleTurns * 360.0);
    final delta = _normalize180(relative - current);
    setState(() {
      _needleTurns += delta / 360.0;
    });
  }

  double? _distanceToKaabaKm() {
    final p = _position;
    if (p == null) return null;
    return Geolocator.distanceBetween(
          p.latitude,
          p.longitude,
          _kaabaLat,
          _kaabaLon,
        ) /
        1000.0;
  }

  double? _relativeQiblaDirection() {
    if (_heading == null || _qiblaBearing == null) return null;
    return _normalize360(_qiblaBearing! - _heading!);
  }

  double _calculateQiblaBearing(double latitude, double longitude) {
    final latRad = _toRad(latitude);
    final kaabaLatRad = _toRad(_kaabaLat);
    final deltaLon = _toRad(_kaabaLon - longitude);

    final y = math.sin(deltaLon);
    final x =
        math.cos(latRad) * math.tan(kaabaLatRad) -
        math.sin(latRad) * math.cos(deltaLon);
    final bearing = _toDeg(math.atan2(y, x));
    return _normalize360(bearing);
  }

  double _normalize360(double degree) {
    var value = degree % 360.0;
    if (value < 0) value += 360.0;
    return value;
  }

  double _normalize180(double degree) {
    var value = degree % 360.0;
    if (value > 180.0) value -= 360.0;
    if (value < -180.0) value += 360.0;
    return value;
  }

  double _toRad(double degree) => degree * (math.pi / 180.0);
  double _toDeg(double radian) => radian * (180.0 / math.pi);

  String _format(double value) {
    final rounded = value.abs() >= 100
        ? value.toStringAsFixed(1)
        : value.toStringAsFixed(4);
    return rounded;
  }
}

class _CompassTicksPainter extends CustomPainter {
  const _CompassTicksPainter(this.scheme);

  final ColorScheme scheme;

  @override
  void paint(Canvas canvas, Size size) {
    final center = Offset(size.width / 2, size.height / 2);
    final radius = math.min(size.width, size.height) / 2 - 14;
    final tickPaint = Paint()
      ..strokeWidth = 1.4
      ..color = scheme.onSurface.withValues(alpha: 0.25)
      ..style = PaintingStyle.stroke
      ..strokeCap = StrokeCap.round;
    final majorPaint = Paint()
      ..strokeWidth = 2.2
      ..color = const Color(0xFF1D6C55).withValues(alpha: 0.55)
      ..style = PaintingStyle.stroke
      ..strokeCap = StrokeCap.round;

    for (int i = 0; i < 60; i++) {
      final isMajor = i % 5 == 0;
      final angle = _toRad((i * 6.0) - 90.0);
      final innerRadius = radius - (isMajor ? 14.0 : 7.0);
      final p1 = Offset(
        center.dx + innerRadius * math.cos(angle),
        center.dy + innerRadius * math.sin(angle),
      );
      final p2 = Offset(
        center.dx + radius * math.cos(angle),
        center.dy + radius * math.sin(angle),
      );
      canvas.drawLine(p1, p2, isMajor ? majorPaint : tickPaint);
    }
  }

  double _toRad(double degree) => degree * (math.pi / 180.0);

  @override
  bool shouldRepaint(covariant _CompassTicksPainter oldDelegate) {
    return oldDelegate.scheme != scheme;
  }
}

class _CompassMark {
  const _CompassMark(this.label, this.alignment);

  final String label;
  final Alignment alignment;
}
