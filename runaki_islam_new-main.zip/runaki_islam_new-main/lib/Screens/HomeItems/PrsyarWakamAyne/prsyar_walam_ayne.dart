import 'dart:convert';
import 'dart:math' as math;
import 'dart:ui';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import 'package:runaki_islam/Screens/HomeItems/Pexambarman/page_view.dart';
import 'package:runaki_islam/database/database_helper.dart';
import 'package:runaki_islam/models/prsyarakan_model.dart';
import 'package:runaki_islam/providers/sections_provider.dart';
import 'package:runaki_islam/providers/settings_provider.dart';
import 'package:runaki_islam/util/animation_helper.dart';
import 'package:runaki_islam/util/background.dart';
import 'package:runaki_islam/util/constans.dart';

class PrsyarWalamAyne extends StatefulWidget {
  const PrsyarWalamAyne({super.key});

  @override
  State<PrsyarWalamAyne> createState() => _PrsyarWalamAyneState();
}

class _PrsyarWalamAyneState extends State<PrsyarWalamAyne> {
  final List<PrsyarData> _items = <PrsyarData>[];
  final ScrollController _scrollController = ScrollController();
  final TextEditingController _searchController = TextEditingController();
  final FocusNode _searchFocusNode = FocusNode();
  final Set<String> _favoriteKeys = <String>{};
  final DatabaseHelper _databaseHelper = DatabaseHelper();
  final String _pageTitle = 'پرسیار و وەڵامی ئاینی';

  bool _loading = false;
  bool _showScrollToTop = false;
  bool _showFavoritesOnly = false;
  String _query = '';
  String? _errorMessage;
  String? _lastOpenedKey;
  int _featuredIndex = 0;
  int? fontType;

  List<PrsyarData> get _visibleItems {
    final normalizedQuery = _query.trim().toLowerCase();
    Iterable<PrsyarData> source = _showFavoritesOnly
        ? _items.where(_isFavorite)
        : _items;

    if (normalizedQuery.isNotEmpty) {
      source = source.where((item) {
        final text =
            '${item.babat ?? ''} ${item.prsyar ?? ''} ${item.walam ?? ''}'
                .toLowerCase();
        return text.contains(normalizedQuery);
      });
    }

    return source.toList(growable: false);
  }

  PrsyarData? get _featuredItem {
    final visible = _visibleItems;
    if (visible.isEmpty) return null;
    if (_query.isNotEmpty || _showFavoritesOnly) {
      return visible.first;
    }
    return _items[_featuredIndex % _items.length];
  }

  bool get _isSearching => _query.trim().isNotEmpty;

  int get _favoriteCount => _items.where(_isFavorite).length;

  @override
  void initState() {
    super.initState();
    fontType = Provider.of<SettingsProvider>(
      context,
      listen: false,
    ).getsettingField('font_family');
    _scrollController.addListener(_handleScroll);
    _loadFavoriteKeys();
    _loadLastOpenedKey();
    _loadPrsyarData();
  }

  @override
  void dispose() {
    _scrollController.removeListener(_handleScroll);
    _scrollController.dispose();
    _searchController.dispose();
    _searchFocusNode.dispose();
    super.dispose();
  }

  Future<String> _loadPrsyarAsset() {
    return Provider.of<SectionsProvider>(
      context,
      listen: false,
    ).loadLegacyJsonAsset('assets/data/content/prsyar_ayne.json');
  }

  Future<void> _loadPrsyarData() async {
    setState(() {
      _loading = true;
      _errorMessage = null;
    });

    try {
      final response = await _loadPrsyarAsset();
      final rawData = jsonDecode(response) as List<dynamic>;
      final loadedItems = rawData
          .whereType<Map>()
          .map((entry) => PrsyarData.formJson(Map<String, dynamic>.from(entry)))
          .where((item) {
            final title = (item.babat ?? item.prsyar ?? '').trim();
            final question = (item.prsyar ?? '').trim();
            final answer = (item.walam ?? '').trim();
            return title.isNotEmpty || question.isNotEmpty || answer.isNotEmpty;
          })
          .toList(growable: false);

      final now = DateTime.now();
      final featuredIndex = loadedItems.isEmpty
          ? 0
          : (now.day + (now.month * 31) + now.year) % loadedItems.length;

      if (!mounted) return;
      setState(() {
        _items
          ..clear()
          ..addAll(loadedItems);
        _featuredIndex = featuredIndex;
      });
    } catch (_) {
      if (!mounted) return;
      setState(() {
        _errorMessage = 'Unable to load topics.';
      });
    } finally {
      if (mounted) {
        setState(() {
          _loading = false;
        });
      }
    }
  }

  void _handleScroll() {
    final shouldShow =
        _scrollController.hasClients && _scrollController.offset > 260;
    if (shouldShow == _showScrollToTop) return;
    setState(() {
      _showScrollToTop = shouldShow;
    });
  }

  void _onSearchChanged(String value) {
    setState(() {
      _query = value.trim();
    });
  }

  Future<void> _clearSearch() async {
    _searchController.clear();
    _searchFocusNode.unfocus();
    setState(() {
      _query = '';
    });
  }

  String _itemKey(PrsyarData item) {
    return '${item.babat ?? ''}::${item.prsyar ?? ''}::${item.walam ?? ''}';
  }

  bool _isFavorite(PrsyarData item) {
    return _favoriteKeys.contains(_itemKey(item));
  }

  Future<void> _loadFavoriteKeys() async {
    try {
      final favoriteKeys = await _databaseHelper.getPrsyarFavoriteKeys();
      if (!mounted) return;
      setState(() {
        _favoriteKeys
          ..clear()
          ..addAll(favoriteKeys);
      });
    } catch (_) {
      // Keep UI usable even if local storage fails temporarily.
    }
  }

  Future<void> _loadLastOpenedKey() async {
    try {
      final key = await _databaseHelper.getPrsyarLastOpenedKey();
      if (!mounted) return;
      setState(() {
        _lastOpenedKey = key;
      });
    } catch (_) {
      // Keep UI usable even if local storage fails temporarily.
    }
  }

  Future<void> _toggleFavorite(PrsyarData item) async {
    final key = _itemKey(item);
    final wasFavorite = _favoriteKeys.contains(key);
    final isNowFavorite = !wasFavorite;

    setState(() {
      if (isNowFavorite) {
        _favoriteKeys.add(key);
      } else {
        _favoriteKeys.remove(key);
      }
    });

    HapticFeedback.lightImpact();
    try {
      await _databaseHelper.setPrsyarFavorite(key, isNowFavorite);
      _showSnackBar(
        isNowFavorite ? 'خرایە دڵخوازەکان.' : 'لە دڵخوازەکان لابرا.',
      );
    } catch (_) {
      if (!mounted) return;
      setState(() {
        if (wasFavorite) {
          _favoriteKeys.add(key);
        } else {
          _favoriteKeys.remove(key);
        }
      });
      _showSnackBar('هەڵە ڕوویدا لە پاشەکەوتکردنی دڵخواز.');
    }
  }

  void _toggleFavoritesView() {
    HapticFeedback.selectionClick();
    setState(() {
      _showFavoritesOnly = !_showFavoritesOnly;
    });
  }

  Future<void> _openPrsyar(PrsyarData item) async {
    HapticFeedback.selectionClick();
    final itemKey = _itemKey(item);
    setState(() {
      _lastOpenedKey = itemKey;
    });

    try {
      await _databaseHelper.setPrsyarLastOpenedKey(itemKey);
    } catch (_) {
      // Ignore storage failures and still allow navigation.
    }
    if (!mounted) return;

    await Navigator.of(context).push(
      AppMotion.fadeSlidePage<void>(
        begin: const Offset(0.06, 0.02),
        page: TextPageView(
          title: item.prsyar ?? item.babat,
          desc: item.walam,
          sarder: _pageTitle,
        ),
      ),
    );
  }

  Future<void> _showPreviewSheet(PrsyarData item) async {
    final scheme = Theme.of(context).colorScheme;
    final preview = _previewText(item.walam, 420);

    await showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) {
        return Directionality(
          textDirection: TextDirection.rtl,
          child: SafeArea(
            top: false,
            child: Container(
              margin: const EdgeInsets.fromLTRB(12, 0, 12, 12),
              padding: const EdgeInsets.fromLTRB(16, 12, 16, 18),
              decoration: BoxDecoration(
                color: scheme.surface.withValues(alpha: 0.98),
                borderRadius: BorderRadius.circular(24),
                border: Border.all(
                  color: scheme.outline.withValues(alpha: 0.16),
                ),
              ),
              child: SingleChildScrollView(
                physics: const BouncingScrollPhysics(),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    Align(
                      alignment: Alignment.center,
                      child: Container(
                        width: 54,
                        height: 4,
                        margin: const EdgeInsets.only(bottom: 14),
                        decoration: BoxDecoration(
                          color: scheme.outline.withValues(alpha: 0.34),
                          borderRadius: BorderRadius.circular(99),
                        ),
                      ),
                    ),
                    Text(
                      item.babat ?? item.prsyar ?? '',
                      textAlign: TextAlign.start,
                      style: TextStyle(
                        fontFamily: fontType?.toString(),
                        fontSize: 18,
                        fontWeight: FontWeight.w800,
                        color: scheme.onSurface,
                      ),
                    ),
                    const SizedBox(height: 10),
                    Container(
                      padding: const EdgeInsets.all(14),
                      decoration: BoxDecoration(
                        color: scheme.surfaceContainerHighest.withValues(
                          alpha: 0.25,
                        ),
                        borderRadius: BorderRadius.circular(18),
                      ),
                      child: Text(
                        preview.isEmpty
                            ? 'Preview is not available. Open the topic to read the full text.'
                            : preview,
                        textAlign: TextAlign.start,
                        style: TextStyle(
                          fontFamily: fontType?.toString(),
                          fontSize: 14.4,
                          height: 1.8,
                          color: scheme.onSurfaceVariant,
                        ),
                      ),
                    ),
                    const SizedBox(height: 14),
                    Row(
                      children: [
                        Expanded(
                          child: OutlinedButton.icon(
                            onPressed: () {
                              Navigator.of(context).pop();
                              Clipboard.setData(
                                ClipboardData(
                                  text: item.babat ?? item.prsyar ?? '',
                                ),
                              );
                              _showSnackBar('ناونیشان کۆپی کرا.');
                            },
                            icon: const Icon(Icons.copy_all_rounded),
                            label: const Text('کۆپی ناونیشان'),
                          ),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: FilledButton(
                            onPressed: () {
                              Navigator.of(context).pop();
                              _openPrsyar(item);
                            },
                            child: const Text('کردنەوە'),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
          ),
        );
      },
    );
  }

  void _showSnackBar(String text) {
    final scheme = Theme.of(context).colorScheme;
    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(
        SnackBar(
          behavior: SnackBarBehavior.floating,
          backgroundColor: scheme.primary,
          content: Text(
            text,
            textDirection: TextDirection.rtl,
            textAlign: TextAlign.start,
            style: TextStyle(
              fontFamily: fontType?.toString(),
              color: scheme.onPrimary,
            ),
          ),
        ),
      );
  }

  Future<void> _scrollToTop() {
    return _scrollController.animateTo(
      0,
      duration: const Duration(milliseconds: 420),
      curve: Curves.easeOutCubic,
    );
  }

  String _previewText(String? rawText, [int limit = 140]) {
    final cleaned = (rawText ?? '').replaceAll(RegExp(r'\s+'), ' ').trim();
    if (cleaned.isEmpty) return '';
    if (cleaned.length <= limit) return cleaned;
    return '${cleaned.substring(0, limit).trim()}...';
  }

  @override
  Widget build(BuildContext context) {
    final visibleItems = _visibleItems;
    final featuredItem = _featuredItem;
    final scheme = Theme.of(context).colorScheme;
    final hasActiveTools = _isSearching || _showFavoritesOnly;

    final String sectionTitle;
    if (_showFavoritesOnly && _isSearching) {
      sectionTitle = 'Search results in favorites';
    } else if (_showFavoritesOnly) {
      sectionTitle = 'Favorite topics';
    } else if (_isSearching) {
      sectionTitle = 'Search results';
    } else {
      sectionTitle = 'All topics';
    }

    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        backgroundColor: bgColor,
        body: Stack(
          children: [
            ClipRect(
              child: ImageFiltered(
                imageFilter: ImageFilter.blur(sigmaX: 3, sigmaY: 3),
                child: CustomBackground(
                  color: bgColor,
                  imageColor: bgImageColor.withValues(alpha: 0.22),
                ),
              ),
            ),
            RefreshIndicator(
              color: kActiveIconColor,
              backgroundColor: bgColor,
              onRefresh: () async {
                await _loadFavoriteKeys();
                await _loadLastOpenedKey();
                await _loadPrsyarData();
              },
              child: CustomScrollView(
                controller: _scrollController,
                physics: const BouncingScrollPhysics(
                  parent: AlwaysScrollableScrollPhysics(),
                ),
                slivers: [
                  SliverAppBar(
                    pinned: true,
                    stretch: true,
                    elevation: 0,
                    expandedHeight: 150,
                    backgroundColor: scheme.surface.withValues(alpha: 0.94),
                    surfaceTintColor: Colors.transparent,
                    titleSpacing: 0,
                    leadingWidth: 64,
                    leading: Padding(
                      padding: const EdgeInsetsDirectional.only(start: 16),
                      child: _TopCircleButton(
                        icon: Icons.arrow_back_ios_new_rounded,
                        tooltip: 'گەڕانەوە',
                        onTap: () => Navigator.of(context).pop(),
                      ),
                    ),
                    actions: [
                      Padding(
                        padding: const EdgeInsetsDirectional.only(end: 16),
                        child: _TopCircleButton(
                          icon: _showFavoritesOnly
                              ? Icons.bookmark_rounded
                              : Icons.bookmark_border_rounded,
                          tooltip: _showFavoritesOnly
                              ? 'Show all topics'
                              : 'پیشاندانی دڵخوازەکان ($_favoriteCount)',
                          onTap: _toggleFavoritesView,
                        ),
                      ),
                    ],
                    title: Text(
                      _pageTitle,
                      style: TextStyle(
                        fontFamily: fontType?.toString(),
                        fontSize: 16,
                        fontWeight: FontWeight.w700,
                        color: kTextColor,
                      ),
                    ),
                    flexibleSpace: FlexibleSpaceBar(
                      stretchModes: const [StretchMode.zoomBackground],
                      background: SafeArea(
                        bottom: false,
                        child: Padding(
                          padding: const EdgeInsets.fromLTRB(16, 74, 16, 18),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.stretch,
                            mainAxisAlignment: MainAxisAlignment.start,
                            children: [
                              _SearchField(
                                controller: _searchController,
                                focusNode: _searchFocusNode,
                                hintStyle: TextStyle(
                                  fontFamily: fontType?.toString(),
                                  fontSize: 14,
                                  color: descriptionTectColor,
                                ),
                                onChanged: _onSearchChanged,
                                onClear: _query.isEmpty ? null : _clearSearch,
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ),
                  SliverToBoxAdapter(
                    child: Padding(
                      padding: const EdgeInsets.fromLTRB(16, 12, 16, 16),
                      child: AnimatedSwitcher(
                        duration: const Duration(milliseconds: 320),
                        switchInCurve: AppMotion.curve,
                        switchOutCurve: AppMotion.curve,
                        transitionBuilder: (child, animation) {
                          return FadeTransition(
                            opacity: animation,
                            child: SizeTransition(
                              sizeFactor: animation,
                              axisAlignment: -1,
                              child: child,
                            ),
                          );
                        },
                        child: featuredItem == null
                            ? const SizedBox.shrink()
                            : FadeSlideIn(
                                key: ValueKey<String>(
                                  '${_itemKey(featuredItem)}-${_query.trim()}',
                                ),
                                duration: const Duration(milliseconds: 320),
                                child: _FeaturedPrsyarCard(
                                  title: _isSearching
                                      ? 'یەکەم ئەنجام'
                                      : 'هەڵبژێردراوی ئەمڕۆ',
                                  itemTitle:
                                      featuredItem.babat ??
                                      featuredItem.prsyar ??
                                      '',
                                  subtitle: _previewText(
                                    featuredItem.prsyar ?? featuredItem.walam,
                                    180,
                                  ),
                                  fontFamily: fontType?.toString(),
                                  isFavorite: _isFavorite(featuredItem),
                                  onFavorite: () =>
                                      _toggleFavorite(featuredItem),
                                  onOpen: () => _openPrsyar(featuredItem),
                                  onPreview: () =>
                                      _showPreviewSheet(featuredItem),
                                ),
                              ),
                      ),
                    ),
                  ),
                  if (_loading)
                    SliverPadding(
                      padding: const EdgeInsets.fromLTRB(16, 0, 16, 24),
                      sliver: SliverList(
                        delegate: SliverChildBuilderDelegate(
                          (context, index) => const _LoadingCard(),
                          childCount: 5,
                        ),
                      ),
                    )
                  else if (_errorMessage != null)
                    SliverFillRemaining(
                      hasScrollBody: false,
                      child: _StatePane(
                        icon: Icons.error_outline_rounded,
                        title: 'Unable to load topics',
                        message: _errorMessage!,
                        actionLabel: 'دووبارە هەوڵ بدە',
                        onAction: _loadPrsyarData,
                        fontFamily: fontType?.toString(),
                      ),
                    )
                  else if (visibleItems.isEmpty)
                    SliverFillRemaining(
                      hasScrollBody: false,
                      child: _StatePane(
                        icon: Icons.search_off_rounded,
                        title: hasActiveTools
                            ? 'No topics found'
                            : 'No topics available',
                        message: hasActiveTools
                            ? 'Try a different search keyword.'
                            : 'بکێشە خوارەوە بۆ نوێکردنەوە.',
                        actionLabel: hasActiveTools ? 'پاککردنەوە' : null,
                        onAction: hasActiveTools
                            ? () {
                                _clearSearch();
                                setState(() {
                                  _showFavoritesOnly = false;
                                });
                              }
                            : null,
                        fontFamily: fontType?.toString(),
                      ),
                    )
                  else ...[
                    SliverToBoxAdapter(
                      child: Padding(
                        padding: const EdgeInsets.fromLTRB(16, 0, 16, 12),
                        child: Row(
                          children: [
                            Text(
                              sectionTitle,
                              textAlign: TextAlign.start,
                              style: TextStyle(
                                fontFamily: fontType?.toString(),
                                fontSize: 17,
                                fontWeight: FontWeight.w800,
                                color: kTextColor,
                              ),
                            ),
                            const Spacer(),
                            Text(
                              '${visibleItems.length} بابەت',
                              style: TextStyle(
                                fontFamily: fontType?.toString(),
                                fontSize: 13.4,
                                fontWeight: FontWeight.w700,
                                color: kActiveIconColor,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                    SliverPadding(
                      padding: const EdgeInsets.fromLTRB(16, 0, 16, 26),
                      sliver: SliverList(
                        delegate: SliverChildBuilderDelegate((context, index) {
                          final item = visibleItems[index];
                          return FadeSlideIn(
                            delay: Duration(
                              milliseconds: math.min(index * 45, 260),
                            ),
                            duration: const Duration(milliseconds: 320),
                            offsetY: 18,
                            child: _PrsyarEntryCard(
                              index: index + 1,
                              title: item.babat ?? item.prsyar ?? '',
                              preview: _previewText(
                                item.prsyar ?? item.walam,
                                120,
                              ),
                              fontFamily: fontType?.toString(),
                              isFavorite: _isFavorite(item),
                              isLastOpened: _lastOpenedKey == _itemKey(item),
                              onTap: () => _openPrsyar(item),
                              onPreview: () => _showPreviewSheet(item),
                              onFavorite: () => _toggleFavorite(item),
                            ),
                          );
                        }, childCount: visibleItems.length),
                      ),
                    ),
                  ],
                ],
              ),
            ),
            PositionedDirectional(
              start: 16,
              bottom: 20,
              child: IgnorePointer(
                ignoring: !_showScrollToTop,
                child: AnimatedSlide(
                  duration: AppMotion.fast,
                  curve: AppMotion.curve,
                  offset: _showScrollToTop ? Offset.zero : const Offset(0, 1.2),
                  child: AnimatedOpacity(
                    duration: AppMotion.fast,
                    curve: AppMotion.curve,
                    opacity: _showScrollToTop ? 1 : 0,
                    child: FloatingActionButton.small(
                      heroTag: 'prsyar_scroll_top',
                      backgroundColor: scheme.primary,
                      foregroundColor: scheme.onPrimary,
                      onPressed: _scrollToTop,
                      child: const Icon(Icons.keyboard_arrow_up_rounded),
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _TopCircleButton extends StatelessWidget {
  const _TopCircleButton({
    required this.icon,
    required this.tooltip,
    required this.onTap,
  });

  final IconData icon;
  final String tooltip;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return Tooltip(
      message: tooltip,
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: onTap,
          borderRadius: BorderRadius.circular(18),
          child: Ink(
            width: 46,
            height: 46,
            decoration: BoxDecoration(
              color: scheme.surface.withValues(alpha: 0.78),
              borderRadius: BorderRadius.circular(18),
              border: Border.all(color: scheme.outline.withValues(alpha: 0.14)),
            ),
            child: Icon(
              icon,
              size: 20,
              color: onTap == null ? scheme.outline : scheme.primary,
            ),
          ),
        ),
      ),
    );
  }
}

class _SearchField extends StatelessWidget {
  const _SearchField({
    required this.controller,
    required this.focusNode,
    required this.hintStyle,
    required this.onChanged,
    required this.onClear,
  });

  final TextEditingController controller;
  final FocusNode focusNode;
  final TextStyle hintStyle;
  final ValueChanged<String> onChanged;
  final Future<void> Function()? onClear;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return _BlurSurface(
      borderRadius: BorderRadius.circular(22),
      color: scheme.surface.withValues(alpha: 0.56),
      border: Border.all(color: scheme.outline.withValues(alpha: 0.14)),
      boxShadow: <BoxShadow>[
        BoxShadow(
          color: scheme.shadow.withValues(alpha: 0.08),
          blurRadius: 18,
          offset: const Offset(0, 10),
        ),
      ],
      child: TextField(
        controller: controller,
        focusNode: focusNode,
        onChanged: onChanged,
        maxLines: 1,
        textAlign: TextAlign.start,
        textDirection: TextDirection.rtl,
        cursorColor: kActiveIconColor,
        decoration: InputDecoration(
          border: InputBorder.none,
          hintText: 'گەڕان بە ناونیشان یان ناوەڕۆک',
          hintStyle: hintStyle,
          prefixIcon: Icon(Icons.search_rounded, color: scheme.primary),
          suffixIcon: onClear == null
              ? null
              : IconButton(
                  onPressed: () => onClear!(),
                  icon: Icon(
                    Icons.close_rounded,
                    color: scheme.onSurfaceVariant,
                  ),
                ),
          contentPadding: const EdgeInsets.symmetric(
            horizontal: 18,
            vertical: 15,
          ),
        ),
      ),
    );
  }
}

class _BlurSurface extends StatelessWidget {
  const _BlurSurface({
    required this.child,
    required this.borderRadius,
    required this.color,
    this.border,
    this.padding,
    this.boxShadow = const <BoxShadow>[],
  });

  final Widget child;
  final BorderRadius borderRadius;
  final Color color;
  final BoxBorder? border;
  final EdgeInsetsGeometry? padding;
  final List<BoxShadow> boxShadow;

  @override
  Widget build(BuildContext context) {
    return ClipRRect(
      borderRadius: borderRadius,
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 14, sigmaY: 14),
        child: Container(
          padding: padding,
          decoration: BoxDecoration(
            color: color,
            borderRadius: borderRadius,
            border: border,
            boxShadow: boxShadow,
          ),
          child: child,
        ),
      ),
    );
  }
}

class _FeaturedPrsyarCard extends StatelessWidget {
  const _FeaturedPrsyarCard({
    required this.title,
    required this.itemTitle,
    required this.subtitle,
    required this.fontFamily,
    required this.isFavorite,
    required this.onFavorite,
    required this.onOpen,
    required this.onPreview,
  });

  final String title;
  final String itemTitle;
  final String subtitle;
  final String? fontFamily;
  final bool isFavorite;
  final VoidCallback onFavorite;
  final VoidCallback onOpen;
  final VoidCallback onPreview;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;

    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: onOpen,
        borderRadius: BorderRadius.circular(30),
        child: _BlurSurface(
          borderRadius: BorderRadius.circular(30),
          color: scheme.surface.withValues(alpha: 0.5),
          border: Border.all(
            color: scheme.primary.withValues(alpha: 0.22),
            width: 1.1,
          ),
          boxShadow: <BoxShadow>[
            BoxShadow(
              color: scheme.shadow.withValues(alpha: 0.08),
              blurRadius: 20,
              offset: const Offset(0, 12),
            ),
          ],
          padding: const EdgeInsets.all(18),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Row(
                children: [
                  Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 12,
                      vertical: 8,
                    ),
                    decoration: BoxDecoration(
                      color: scheme.primaryContainer.withValues(alpha: 0.58),
                      borderRadius: BorderRadius.circular(16),
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(
                          Icons.auto_awesome_rounded,
                          size: 16,
                          color: scheme.primary,
                        ),
                        const SizedBox(width: 8),
                        Text(
                          'هەڵبژێردراو',
                          style: TextStyle(
                            fontFamily: fontFamily,
                            color: scheme.primary,
                            fontSize: 12,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 12),
              Text(
                title,
                textAlign: TextAlign.start,
                style: TextStyle(
                  fontFamily: fontFamily,
                  fontSize: 13.2,
                  fontWeight: FontWeight.w700,
                  color: scheme.onSurfaceVariant,
                ),
              ),
              const SizedBox(height: 8),
              Text(
                itemTitle,
                textAlign: TextAlign.start,
                style: TextStyle(
                  fontFamily: fontFamily,
                  fontSize: 22,
                  fontWeight: FontWeight.w800,
                  color: scheme.onSurface,
                ),
              ),
              if (subtitle.isNotEmpty) ...[
                const SizedBox(height: 10),
                Text(
                  subtitle,
                  maxLines: 3,
                  overflow: TextOverflow.ellipsis,
                  textAlign: TextAlign.start,
                  style: TextStyle(
                    fontFamily: fontFamily,
                    fontSize: 13.6,
                    height: 1.7,
                    color: scheme.onSurfaceVariant,
                  ),
                ),
              ],
              const SizedBox(height: 18),
              Wrap(
                spacing: 10,
                runSpacing: 8,
                children: [
                  _InlineAction(
                    icon: Icons.visibility_outlined,
                    label: 'پێشبینین',
                    onTap: onPreview,
                  ),
                  _InlineAction(
                    icon: isFavorite
                        ? Icons.bookmark_remove_outlined
                        : Icons.bookmark_add_outlined,
                    label: isFavorite ? 'لابردن' : 'پاشەکەوتکردن',
                    selected: isFavorite,
                    onTap: onFavorite,
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _PrsyarEntryCard extends StatelessWidget {
  const _PrsyarEntryCard({
    required this.index,
    required this.title,
    required this.preview,
    required this.fontFamily,
    required this.isFavorite,
    required this.isLastOpened,
    required this.onTap,
    required this.onPreview,
    required this.onFavorite,
  });

  final int index;
  final String title;
  final String preview;
  final String? fontFamily;
  final bool isFavorite;
  final bool isLastOpened;
  final VoidCallback onTap;
  final VoidCallback onPreview;
  final VoidCallback onFavorite;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final cardColor = scheme.surface.withValues(alpha: 0.92);

    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: onTap,
          onLongPress: onPreview,
          borderRadius: BorderRadius.circular(24),
          child: ClipRRect(
            borderRadius: BorderRadius.circular(24),
            child: BackdropFilter(
              filter: ImageFilter.blur(sigmaX: 14, sigmaY: 14),
              child: AnimatedContainer(
                duration: AppMotion.fast,
                curve: AppMotion.curve,
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(
                  color: cardColor,
                  borderRadius: BorderRadius.circular(24),
                  border: Border.all(
                    color: isFavorite
                        ? scheme.primary.withValues(alpha: 0.35)
                        : scheme.outline.withValues(alpha: 0.12),
                  ),
                  boxShadow: [
                    BoxShadow(
                      color: scheme.shadow.withValues(alpha: 0.06),
                      blurRadius: 16,
                      offset: const Offset(0, 10),
                    ),
                  ],
                ),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                      width: 52,
                      height: 52,
                      decoration: BoxDecoration(
                        color: scheme.primary.withValues(alpha: 0.9),
                        borderRadius: BorderRadius.circular(18),
                      ),
                      child: Center(
                        child: Text(
                          '$index',
                          style: TextStyle(
                            fontFamily: fontFamily,
                            fontSize: 15,
                            fontWeight: FontWeight.w800,
                            color: scheme.onPrimary,
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(width: 14),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          if (isLastOpened)
                            Container(
                              padding: const EdgeInsets.symmetric(
                                horizontal: 8,
                                vertical: 4,
                              ),
                              decoration: BoxDecoration(
                                color: Colors.orange.withValues(alpha: 0.18),
                                border: Border.all(
                                  color: Colors.orange.withValues(alpha: 0.4),
                                ),
                                borderRadius: BorderRadius.circular(10),
                              ),
                              child: Text(
                                'دوایین خوێندراو',
                                style: TextStyle(
                                  fontFamily: fontFamily,
                                  fontSize: 10.4,
                                  fontWeight: FontWeight.w700,
                                  color: const Color(0xFF8A4B00),
                                ),
                              ),
                            ),
                          const SizedBox(height: 8),
                          Text(
                            title,
                            textAlign: TextAlign.start,
                            maxLines: 2,
                            overflow: TextOverflow.ellipsis,
                            style: TextStyle(
                              fontFamily: fontFamily,
                              fontSize: 16.6,
                              fontWeight: FontWeight.w800,
                              color: scheme.onSurface,
                            ),
                          ),
                          if (preview.isNotEmpty) ...[
                            const SizedBox(height: 8),
                            Text(
                              preview,
                              maxLines: 2,
                              overflow: TextOverflow.ellipsis,
                              textAlign: TextAlign.start,
                              style: TextStyle(
                                fontFamily: fontFamily,
                                fontSize: 13.4,
                                height: 1.7,
                                color: scheme.onSurfaceVariant,
                              ),
                            ),
                          ],
                          const SizedBox(height: 14),
                          Wrap(
                            spacing: 10,
                            runSpacing: 8,
                            children: [
                              _InlineAction(
                                icon: Icons.visibility_outlined,
                                label: 'پێشبینین',
                                onTap: onPreview,
                              ),
                              _InlineAction(
                                icon: isFavorite
                                    ? Icons.bookmark_remove_outlined
                                    : Icons.bookmark_add_outlined,
                                label: isFavorite ? 'لابردن' : 'پاشەکەوتکردن',
                                selected: isFavorite,
                                onTap: onFavorite,
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class _InlineAction extends StatelessWidget {
  const _InlineAction({
    required this.icon,
    required this.label,
    required this.onTap,
    this.selected = false,
  });

  final IconData icon;
  final String label;
  final VoidCallback onTap;
  final bool selected;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return Tooltip(
      message: label,
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: onTap,
          borderRadius: BorderRadius.circular(14),
          child: Ink(
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              color: selected
                  ? scheme.primaryContainer.withValues(alpha: 0.45)
                  : scheme.surfaceContainerHighest.withValues(alpha: 0.28),
              borderRadius: BorderRadius.circular(14),
            ),
            child: Icon(
              icon,
              size: 18,
              color: selected ? scheme.primary : scheme.onSurfaceVariant,
            ),
          ),
        ),
      ),
    );
  }
}

class _StatePane extends StatelessWidget {
  const _StatePane({
    required this.icon,
    required this.title,
    required this.message,
    required this.fontFamily,
    this.actionLabel,
    this.onAction,
  });

  final IconData icon;
  final String title;
  final String message;
  final String? actionLabel;
  final VoidCallback? onAction;
  final String? fontFamily;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return Center(
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 78,
              height: 78,
              decoration: BoxDecoration(
                color: scheme.primaryContainer.withValues(alpha: 0.56),
                shape: BoxShape.circle,
              ),
              child: Icon(icon, size: 34, color: scheme.primary),
            ),
            const SizedBox(height: 18),
            Text(
              title,
              textAlign: TextAlign.center,
              style: TextStyle(
                fontFamily: fontFamily,
                fontSize: 20,
                fontWeight: FontWeight.w800,
                color: scheme.onSurface,
              ),
            ),
            const SizedBox(height: 8),
            Text(
              message,
              textAlign: TextAlign.center,
              style: TextStyle(
                fontFamily: fontFamily,
                fontSize: 14.4,
                height: 1.7,
                color: scheme.onSurfaceVariant,
              ),
            ),
            if (actionLabel != null && onAction != null) ...[
              const SizedBox(height: 18),
              FilledButton.icon(
                onPressed: onAction,
                icon: const Icon(Icons.refresh_rounded),
                label: Text(actionLabel!),
              ),
            ],
          ],
        ),
      ),
    );
  }
}

class _LoadingCard extends StatelessWidget {
  const _LoadingCard();

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: _BlurSurface(
        borderRadius: BorderRadius.circular(24),
        color: scheme.surface.withValues(alpha: 0.52),
        border: Border.all(color: scheme.outline.withValues(alpha: 0.12)),
        padding: const EdgeInsets.all(14),
        child: Row(
          children: [
            Container(
              width: 52,
              height: 52,
              decoration: BoxDecoration(
                color: scheme.surfaceContainerHighest.withValues(alpha: 0.34),
                borderRadius: BorderRadius.circular(18),
              ),
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    height: 16,
                    width: double.infinity,
                    decoration: BoxDecoration(
                      color: scheme.surfaceContainerHighest.withValues(
                        alpha: 0.34,
                      ),
                      borderRadius: BorderRadius.circular(8),
                    ),
                  ),
                  const SizedBox(height: 12),
                  Container(
                    height: 14,
                    width: double.infinity,
                    decoration: BoxDecoration(
                      color: scheme.surfaceContainerHighest.withValues(
                        alpha: 0.26,
                      ),
                      borderRadius: BorderRadius.circular(8),
                    ),
                  ),
                  const SizedBox(height: 8),
                  Container(
                    height: 14,
                    width: 180,
                    decoration: BoxDecoration(
                      color: scheme.surfaceContainerHighest.withValues(
                        alpha: 0.22,
                      ),
                      borderRadius: BorderRadius.circular(8),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
