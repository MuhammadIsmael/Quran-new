import 'package:bouncing_widget/bouncing_widget.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:runaki_islam/providers/settings_provider.dart';
import 'package:runaki_islam/services/app_review_service.dart';
import 'package:runaki_islam/util/animation_helper.dart';
import 'package:runaki_islam/util/constans.dart';

class FeedBack extends StatefulWidget {
  const FeedBack({super.key, required this.sarder});

  final String sarder;

  @override
  State<FeedBack> createState() => _FeedBackState();
}

class _FeedBackState extends State<FeedBack>
    with SingleTickerProviderStateMixin {
  static const List<String> _topics = <String>[
    'پێشنیار',
    'ڕەخنە',
    'کێشەی تەکنیکی',
    'باشترکردنی ناوەڕۆک',
  ];

  final TextEditingController _subjectController = TextEditingController();
  final TextEditingController _messageController = TextEditingController();
  late final AnimationController _heroController;

  int _rating = 4;
  bool _sending = false;
  String _selectedTopic = _topics.first;
  int? _fontType;

  @override
  void initState() {
    super.initState();
    _fontType = Provider.of<SettingsProvider>(
      context,
      listen: false,
    ).getsettingField('font_family');
    _heroController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 2400),
    );
    if (!AppMotion.reduceMotion) {
      _heroController.repeat(reverse: true);
    }
  }

  @override
  void dispose() {
    _heroController.dispose();
    _subjectController.dispose();
    _messageController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final TextStyle bodyStyle = TextStyle(
      fontFamily: _fontType.toString(),
      color: kTextColor,
      fontSize: 15,
      height: 1.7,
    );

    return Scaffold(
      backgroundColor: bgColor,
      body: Stack(
        children: [
          const _FeedbackBackdrop(),
          SafeArea(
            child: SingleChildScrollView(
              padding: const EdgeInsets.fromLTRB(16, 10, 16, 24),
              physics: const BouncingScrollPhysics(),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  _buildTopBar(),
                  const SizedBox(height: 14),
                  FadeSlideIn(child: _buildHeroCard(bodyStyle)),
                  const SizedBox(height: 16),
                  FadeSlideIn(
                    delay: const Duration(milliseconds: 50),
                    child: _buildTopicSelector(),
                  ),
                  const SizedBox(height: 16),
                  FadeSlideIn(
                    delay: const Duration(milliseconds: 90),
                    child: _buildRatingCard(),
                  ),
                  const SizedBox(height: 16),
                  FadeSlideIn(
                    delay: const Duration(milliseconds: 130),
                    child: _buildInputCard(
                      title: 'سەردێڕ',
                      icon: Icons.edit_note_rounded,
                      child: TextField(
                        controller: _subjectController,
                        textDirection: TextDirection.rtl,
                        textAlign: TextAlign.right,
                        style: _fieldStyle(),
                        decoration: _inputDecoration(
                          hint: 'کورتە سەردێڕێک بنووسە',
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(height: 16),
                  FadeSlideIn(
                    delay: const Duration(milliseconds: 170),
                    child: _buildInputCard(
                      title: 'پەیام',
                      icon: Icons.mail_outline_rounded,
                      child: TextField(
                        controller: _messageController,
                        minLines: 7,
                        maxLines: 11,
                        textDirection: TextDirection.rtl,
                        textAlign: TextAlign.right,
                        style: _fieldStyle(height: 1.8),
                        decoration: _inputDecoration(
                          hint:
                              'تکایە بە ڕوونی بنووسە کێشەکە چییە یان چۆن دەتەوێت باشتر بکرێت...',
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(height: 16),
                  FadeSlideIn(
                    delay: const Duration(milliseconds: 210),
                    child: _buildInfoStrip(),
                  ),
                  const SizedBox(height: 20),
                  FadeSlideIn(
                    delay: const Duration(milliseconds: 250),
                    child: BouncingWidget(
                      onPressed: () {
                        if (_sending) {
                          return;
                        }
                        _sendFeedback();
                      },
                      child: DecoratedBox(
                        decoration: BoxDecoration(
                          gradient: const LinearGradient(
                            colors: [Color(0xFF0E7C5A), Color(0xFFCFB176)],
                          ),
                          borderRadius: BorderRadius.circular(22),
                          boxShadow: const [
                            BoxShadow(
                              color: Color(0x2A0E7C5A),
                              blurRadius: 22,
                              offset: Offset(0, 12),
                            ),
                          ],
                        ),
                        child: Padding(
                          padding: const EdgeInsets.symmetric(
                            horizontal: 18,
                            vertical: 16,
                          ),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              if (_sending) ...[
                                const SizedBox(
                                  width: 18,
                                  height: 18,
                                  child: CircularProgressIndicator(
                                    strokeWidth: 2.2,
                                    color: Colors.white,
                                  ),
                                ),
                                const SizedBox(width: 12),
                              ] else ...[
                                const Icon(
                                  Icons.send_rounded,
                                  color: Colors.white,
                                  size: 20,
                                ),
                                const SizedBox(width: 10),
                              ],
                              Text(
                                _sending
                                    ? 'ئامادەکردنی ئیمەیڵ...'
                                    : 'ناردنی ڕەخنە بە ئیمەیڵ',
                                style: TextStyle(
                                  fontFamily: _fontType.toString(),
                                  color: Colors.white,
                                  fontSize: 16,
                                  fontWeight: FontWeight.w800,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildTopBar() {
    return Row(
      children: [
        _roundIconButton(
          icon: Icons.arrow_back_ios_new_rounded,
          onTap: () => Navigator.of(context).pop(),
        ),
        const Spacer(),
        Text(
          widget.sarder,
          textDirection: TextDirection.rtl,
          style: TextStyle(
            fontFamily: _fontType.toString(),
            fontSize: 20,
            color: kTextColor,
            fontWeight: FontWeight.w800,
          ),
        ),
      ],
    );
  }

  Widget _buildHeroCard(TextStyle bodyStyle) {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [
            backgroundColor.withValues(alpha: 0.96),
            thirdColor.withValues(alpha: 0.92),
          ],
          begin: Alignment.topRight,
          end: Alignment.bottomLeft,
        ),
        borderRadius: BorderRadius.circular(28),
        border: Border.all(color: strokeColor),
        boxShadow: [
          BoxShadow(
            color: kShadowColor.withValues(alpha: 0.12),
            blurRadius: 24,
            offset: const Offset(0, 14),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.end,
        children: [
          Row(
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    Text(
                      'دەنگت بۆمان گرنگە',
                      textDirection: TextDirection.rtl,
                      style: TextStyle(
                        fontFamily: _fontType.toString(),
                        fontSize: 23,
                        fontWeight: FontWeight.w900,
                        color: kTextColor,
                      ),
                    ),
                    const SizedBox(height: 8),
                    Text(
                      'هەر ڕەخنە، پێشنیار یان بیرۆکەیەکت هەبێت لێرەدا بنووسە. هەر پەیامێک یارمەتیدەرات دەبێت بۆ ئەوەی ڕووناکی ئیسلام باشتر، خێراتر و سوودبەخشتر بکرێت.',
                      textAlign: TextAlign.right,
                      textDirection: TextDirection.rtl,
                      style: bodyStyle.copyWith(
                        color: titleTextColor,
                        fontSize: 14.6,
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 14),
              AnimatedBuilder(
                animation: _heroController,
                builder: (context, child) {
                  if (AppMotion.reduceMotion) {
                    return child!;
                  }
                  final double t = _heroController.value;
                  return Transform.translate(
                    offset: Offset(0, -6 + (t * 12)),
                    child: Transform.scale(
                      scale: 0.96 + (t * 0.08),
                      child: child,
                    ),
                  );
                },
                child: Container(
                  width: 88,
                  height: 88,
                  padding: const EdgeInsets.all(6),
                  decoration: BoxDecoration(
                    gradient: const LinearGradient(
                      colors: [Color(0xFF0E7C5A), Color(0xFFE1C88F)],
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    ),
                    borderRadius: BorderRadius.circular(26),
                    boxShadow: const [
                      BoxShadow(
                        color: Color(0x220E7C5A),
                        blurRadius: 20,
                        offset: Offset(0, 10),
                      ),
                    ],
                  ),
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(20),
                    child: Image.asset(
                      'assets/icons/icon-main.png',
                      fit: BoxFit.cover,
                    ),
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 18),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
            decoration: BoxDecoration(
              color: Colors.white.withValues(alpha: 0.54),
              borderRadius: BorderRadius.circular(18),
            ),
            child: Row(
              children: [
                Icon(
                  Icons.mark_email_read_outlined,
                  color: kActiveIconColor,
                  size: 18,
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: Text(
                    'پەیامەکەت وەک ئیمەیڵ دەنێردرێت و بە ڕاستەوخۆ دەگاتە تیمی بەرنامە.',
                    textDirection: TextDirection.rtl,
                    textAlign: TextAlign.right,
                    style: TextStyle(
                      fontFamily: _fontType.toString(),
                      color: kTextColor,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildTopicSelector() {
    return _buildInputCard(
      title: 'جۆری پەیام',
      icon: Icons.category_outlined,
      child: Wrap(
        alignment: WrapAlignment.end,
        spacing: 10,
        runSpacing: 10,
        children: _topics.map((topic) {
          final bool selected = topic == _selectedTopic;
          return GestureDetector(
            onTap: () {
              setState(() {
                _selectedTopic = topic;
                if (_subjectController.text.trim().isEmpty) {
                  _subjectController.text = topic;
                }
              });
            },
            child: AnimatedContainer(
              duration: AppMotion.fast,
              curve: AppMotion.curve,
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
              decoration: BoxDecoration(
                gradient: selected
                    ? const LinearGradient(
                        colors: [Color(0xFF0E7C5A), Color(0xFF2FA177)],
                      )
                    : null,
                color: selected ? null : backgroundColor,
                borderRadius: BorderRadius.circular(14),
                border: Border.all(
                  color: selected ? Colors.transparent : strokeColor,
                ),
              ),
              child: Text(
                topic,
                textDirection: TextDirection.rtl,
                style: TextStyle(
                  fontFamily: _fontType.toString(),
                  color: selected ? Colors.white : kTextColor,
                  fontWeight: FontWeight.w700,
                ),
              ),
            ),
          );
        }).toList(),
      ),
    );
  }

  Widget _buildRatingCard() {
    final List<Color> accent = _ratingGradient(_rating);
    return _buildInputCard(
      title: 'هەڵسەنگاندن',
      icon: Icons.auto_awesome_rounded,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.end,
        children: [
          Text(
            'ئەم بەشە تەنها بۆ زانیاریی ناو ئیمەیڵە و یارمەتیمان دەدات هەستت بە وردی تێبگەین.',
            textDirection: TextDirection.rtl,
            textAlign: TextAlign.right,
            style: TextStyle(
              fontFamily: _fontType.toString(),
              color: titleTextColor,
              height: 1.6,
            ),
          ),
          const SizedBox(height: 14),
          AnimatedContainer(
            duration: AppMotion.fast,
            curve: AppMotion.curve,
            padding: const EdgeInsets.fromLTRB(18, 18, 18, 16),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: accent,
                begin: Alignment.topRight,
                end: Alignment.bottomLeft,
              ),
              borderRadius: BorderRadius.circular(24),
              boxShadow: [
                BoxShadow(
                  color: accent.first.withValues(alpha: 0.24),
                  blurRadius: 22,
                  offset: const Offset(0, 10),
                ),
              ],
            ),
            child: Stack(
              children: [
                Positioned(
                  top: -28,
                  left: -18,
                  child: Container(
                    width: 88,
                    height: 88,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: Colors.white.withValues(alpha: 0.10),
                    ),
                  ),
                ),
                Positioned(
                  bottom: -26,
                  right: -10,
                  child: Container(
                    width: 92,
                    height: 92,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: Colors.white.withValues(alpha: 0.08),
                    ),
                  ),
                ),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    Row(
                      children: [
                        Container(
                          width: 66,
                          height: 66,
                          decoration: BoxDecoration(
                            color: Colors.white.withValues(alpha: 0.16),
                            borderRadius: BorderRadius.circular(22),
                            border: Border.all(
                              color: Colors.white.withValues(alpha: 0.22),
                            ),
                          ),
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              const Icon(
                                Icons.star_rounded,
                                color: Colors.white,
                                size: 26,
                              ),
                              Text(
                                '$_rating/5',
                                style: const TextStyle(
                                  fontFamily: 'english',
                                  color: Colors.white,
                                  fontWeight: FontWeight.w800,
                                ),
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.end,
                            children: [
                              Text(
                                _ratingTitle(_rating),
                                textDirection: TextDirection.rtl,
                                style: TextStyle(
                                  fontFamily: _fontType.toString(),
                                  color: Colors.white,
                                  fontSize: 18,
                                  fontWeight: FontWeight.w900,
                                ),
                              ),
                              const SizedBox(height: 4),
                              Text(
                                _ratingCaption(_rating),
                                textDirection: TextDirection.rtl,
                                textAlign: TextAlign.right,
                                style: TextStyle(
                                  fontFamily: _fontType.toString(),
                                  color: Colors.white.withValues(alpha: 0.90),
                                  fontSize: 13.4,
                                  height: 1.5,
                                  fontWeight: FontWeight.w600,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 14),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.end,
                      children: List<Widget>.generate(5, (index) {
                        final bool active = index < _rating;
                        return Padding(
                          padding: EdgeInsets.only(left: index == 4 ? 0 : 4),
                          child: AnimatedScale(
                            duration: AppMotion.fast,
                            curve: AppMotion.curve,
                            scale: active ? 1.0 : 0.88,
                            child: Icon(
                              active
                                  ? Icons.star_rounded
                                  : Icons.star_outline_rounded,
                              color: Colors.white,
                              size: active ? 24 : 21,
                            ),
                          ),
                        );
                      }),
                    ),
                  ],
                ),
              ],
            ),
          ),
          const SizedBox(height: 14),
          SizedBox(
            height: 104,
            child: Stack(
              alignment: Alignment.topCenter,
              children: [
                Positioned(
                  top: 24,
                  left: 12,
                  right: 12,
                  child: Container(
                    height: 6,
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        colors: [
                          accent.first.withValues(alpha: 0.18),
                          accent.last.withValues(alpha: 0.45),
                          accent.first.withValues(alpha: 0.18),
                        ],
                      ),
                      borderRadius: BorderRadius.circular(99),
                    ),
                  ),
                ),
                Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: List<Widget>.generate(5, (index) {
                    final int value = index + 1;
                    return Expanded(child: _buildRatingNode(value));
                  }),
                ),
              ],
            ),
          ),
          const SizedBox(height: 10),
          AnimatedContainer(
            duration: AppMotion.fast,
            curve: AppMotion.curve,
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [
                  accent.first.withValues(alpha: 0.10),
                  accent.last.withValues(alpha: 0.18),
                ],
              ),
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: accent.first.withValues(alpha: 0.14)),
            ),
            child: Row(
              children: [
                Icon(Icons.favorite_rounded, color: accent.first, size: 18),
                const SizedBox(width: 10),
                Expanded(
                  child: Text(
                    _ratingLabel(_rating),
                    textDirection: TextDirection.rtl,
                    textAlign: TextAlign.right,
                    style: TextStyle(
                      fontFamily: _fontType.toString(),
                      color: kTextColor,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildRatingNode(int value) {
    final bool selected = value <= _rating;
    final bool current = value == _rating;
    final List<Color> accent = _ratingGradient(value);

    return GestureDetector(
      onTap: () => setState(() => _rating = value),
      child: Column(
        children: [
          AnimatedContainer(
            duration: AppMotion.fast,
            curve: AppMotion.curve,
            width: current ? 58 : 50,
            height: current ? 58 : 50,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: selected
                  ? LinearGradient(
                      colors: accent,
                      begin: Alignment.topCenter,
                      end: Alignment.bottomCenter,
                    )
                  : null,
              color: selected ? null : backgroundColor,
              border: Border.all(
                color: selected
                    ? Colors.white.withValues(alpha: 0.75)
                    : strokeColor,
                width: current ? 2 : 1,
              ),
              boxShadow: selected
                  ? [
                      BoxShadow(
                        color: accent.first.withValues(alpha: 0.22),
                        blurRadius: current ? 18 : 12,
                        offset: const Offset(0, 8),
                      ),
                    ]
                  : const [],
            ),
            child: Icon(
              selected ? Icons.star_rounded : Icons.star_outline_rounded,
              color: selected ? Colors.white : secondColor,
              size: current ? 28 : 24,
            ),
          ),
          const SizedBox(height: 8),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 2),
            child: Text(
              _ratingNodeLabel(value),
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
              textAlign: TextAlign.center,
              textDirection: TextDirection.rtl,
              style: TextStyle(
                fontFamily: _fontType.toString(),
                fontSize: 11.4,
                height: 1.35,
                fontWeight: current ? FontWeight.w800 : FontWeight.w700,
                color: current ? kTextColor : titleTextColor,
              ),
            ),
          ),
        ],
      ),
    );
  }

  List<Color> _ratingGradient(int rating) {
    switch (rating) {
      case 1:
        return const [Color(0xFF8D5A47), Color(0xFFD49A74)];
      case 2:
        return const [Color(0xFF9B6A2E), Color(0xFFE0B35C)];
      case 3:
        return const [Color(0xFF0F6B53), Color(0xFF57A98A)];
      case 4:
        return const [Color(0xFF0C7C68), Color(0xFF4EC29D)];
      case 5:
        return const [Color(0xFF0C6B78), Color(0xFFE1C88F)];
      default:
        return const [Color(0xFF0E7C5A), Color(0xFFE1C88F)];
    }
  }

  String _ratingTitle(int rating) {
    switch (rating) {
      case 1:
        return 'پێویستی بە چاکسازیی خێرا هەیە';
      case 2:
        return 'ئەزموونەکە هێشتا تەواو نییە';
      case 3:
        return 'باشە، بەڵام شوێنی گەشە هەیە';
      case 4:
        return 'ئەزموونێکی زۆر باش';
      case 5:
        return 'زۆر ناوازە و دلخۆشکەر';
      default:
        return '';
    }
  }

  String _ratingCaption(int rating) {
    switch (rating) {
      case 1:
        return 'ئەگەر کێشەکەمان بۆ ڕوون بکەیتەوە، دەتوانین بە خێرایی چاکی بکەین.';
      case 2:
        return 'هەر وردەکارییەکت هەبێت یارمەتیدەر دەبێت بۆ باشترکردنەوە.';
      case 3:
        return 'پێشنیارەکانت دەتوانن ئەم بەشە لە ئاستی باشەوە بەرزتر بکەن.';
      case 4:
        return 'سوپاس، ئەوە نیشانەیەکی باشە. تکایە ئەو شتانەش بنووسە کە دەتەوێت زیاتر ببینیت.';
      case 5:
        return 'زۆر سوپاس بۆ هەڵسەنگاندنی بەرزەکەت. ئەم پشتگیرییە بەهای زۆری هەیە بۆمان.';
      default:
        return '';
    }
  }

  String _ratingNodeLabel(int rating) {
    switch (rating) {
      case 1:
        return 'زۆر لاواز';
      case 2:
        return 'لاواز';
      case 3:
        return 'باش';
      case 4:
        return 'زۆر باش';
      case 5:
        return 'ناوازە';
      default:
        return '';
    }
  }

  Widget _buildInputCard({
    required String title,
    required IconData icon,
    required Widget child,
  }) {
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: backgroundColor.withValues(alpha: 0.95),
        borderRadius: BorderRadius.circular(24),
        border: Border.all(color: strokeColor),
        boxShadow: [
          BoxShadow(
            color: kShadowColor.withValues(alpha: 0.10),
            blurRadius: 18,
            offset: const Offset(0, 10),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.end,
        children: [
          Row(
            children: [
              Icon(icon, color: kActiveIconColor, size: 18),
              const Spacer(),
              Text(
                title,
                textDirection: TextDirection.rtl,
                style: TextStyle(
                  fontFamily: _fontType.toString(),
                  color: kTextColor,
                  fontWeight: FontWeight.w800,
                  fontSize: 15.5,
                ),
              ),
            ],
          ),
          const SizedBox(height: 14),
          child,
        ],
      ),
    );
  }

  Widget _buildInfoStrip() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
      decoration: BoxDecoration(
        color: thirdColor.withValues(alpha: 0.88),
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: strokeColor),
      ),
      child: Row(
        children: [
          Icon(Icons.info_outline_rounded, color: titleTextColor, size: 18),
          const SizedBox(width: 10),
          Expanded(
            child: Text(
              'تکایە کێشەکە یان پێشنیارەکەت بە نموونە و زانیاریی ورد بنووسە تا بتوانین خێراتر سەیری بکەین.',
              textDirection: TextDirection.rtl,
              textAlign: TextAlign.right,
              style: TextStyle(
                fontFamily: _fontType.toString(),
                color: titleTextColor,
                fontWeight: FontWeight.w700,
                height: 1.55,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _roundIconButton({
    required IconData icon,
    required VoidCallback onTap,
  }) {
    return Material(
      color: backgroundColor.withValues(alpha: 0.92),
      borderRadius: BorderRadius.circular(16),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(16),
        child: SizedBox(
          width: 48,
          height: 48,
          child: Icon(icon, color: iconColor, size: 20),
        ),
      ),
    );
  }

  InputDecoration _inputDecoration({required String hint}) {
    return InputDecoration(
      hintText: hint,
      hintTextDirection: TextDirection.rtl,
      hintStyle: TextStyle(
        fontFamily: _fontType.toString(),
        color: descriptionTectColor,
      ),
      filled: true,
      fillColor: Colors.white.withValues(alpha: 0.66),
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(18),
        borderSide: BorderSide(color: strokeColor),
      ),
      enabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(18),
        borderSide: BorderSide(color: strokeColor),
      ),
      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(18),
        borderSide: BorderSide(color: kActiveIconColor, width: 1.4),
      ),
      contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
    );
  }

  TextStyle _fieldStyle({double? height}) {
    return TextStyle(
      fontFamily: _fontType.toString(),
      color: kTextColor,
      fontSize: 15.4,
      height: height,
      fontWeight: FontWeight.w600,
    );
  }

  String _ratingLabel(int rating) {
    switch (rating) {
      case 1:
        return 'پێویستی بە چاکسازیی زۆر هەیە و باشە لە وردەکارییەکان بۆمان بنووسیت.';
      case 2:
        return 'باشە ئەگەر هەندێک کێشە یان تێبینیی گرنگت هەیە بۆمان ڕوون بکەیتەوە.';
      case 3:
        return 'ئەزموونەکە باش بووە، بەڵام هێشتا شوێنی باشترکردن هەیە.';
      case 4:
        return 'زۆر باشە. پێشنیارەکانت دەتوانن یارمەتیمان بدەن باشترتری بکەین.';
      case 5:
        return 'سوپاس، ئەمە پشتگیرییەکی زۆر جوانە. ئەگەر بیرۆکەیەکی نوێت هەیە بنووسە.';
      default:
        return '';
    }
  }

  Future<void> _sendFeedback() async {
    final String subject = _subjectController.text.trim();
    final String message = _messageController.text.trim();
    if (subject.isEmpty || message.isEmpty) {
      _showSnack('تکایە سەردێڕ و پەیامەکە پڕ بکەرەوە.');
      return;
    }

    FocusScope.of(context).unfocus();
    setState(() => _sending = true);

    final bool sent = await AppReviewService.composeFeedbackEmail(
      context: context,
      subject: 'Runaki Islam | $_selectedTopic | $subject',
      body:
          '''
سڵاو و ڕێز،

ئەم پەیامە لە ناو بەرنامەی ڕووناکی ئیسلام نێردراوە.

جۆری پەیام: $_selectedTopic
ئاستی هەڵسەنگاندن: $_rating / 5

سەردێڕ:
$subject

پەیام:
$message

سوپاس بۆ کات و تێبینییەکانت.
''',
    );

    if (!mounted) {
      return;
    }

    setState(() => _sending = false);

    if (!sent) {
      return;
    }

    _subjectController.clear();
    _messageController.clear();
    setState(() {
      _rating = 4;
      _selectedTopic = _topics.first;
    });
    _showSnack('ئیمەیڵەکەت ئامادەکرا. تکایە لە ناو بەرنامەی ئیمەیڵ بنێرە.');
  }

  void _showSnack(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          message,
          textAlign: TextAlign.right,
          textDirection: TextDirection.rtl,
          style: TextStyle(fontFamily: _fontType.toString()),
        ),
      ),
    );
  }
}

class _FeedbackBackdrop extends StatelessWidget {
  const _FeedbackBackdrop();

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        Container(
          decoration: const BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: [Color(0xFFF7F1E6), Color(0xFFF1F7F3)],
            ),
          ),
        ),
        Positioned(
          top: -70,
          right: -30,
          child: Container(
            width: 180,
            height: 180,
            decoration: const BoxDecoration(
              shape: BoxShape.circle,
              gradient: RadialGradient(
                colors: [Color(0x33E1C88F), Color(0x00E1C88F)],
              ),
            ),
          ),
        ),
        Positioned(
          left: -50,
          top: 220,
          child: Container(
            width: 160,
            height: 160,
            decoration: const BoxDecoration(
              shape: BoxShape.circle,
              gradient: RadialGradient(
                colors: [Color(0x330E7C5A), Color(0x000E7C5A)],
              ),
            ),
          ),
        ),
        Positioned(
          right: 40,
          bottom: -40,
          child: Container(
            width: 150,
            height: 150,
            decoration: const BoxDecoration(
              shape: BoxShape.circle,
              gradient: RadialGradient(
                colors: [Color(0x22CDB177), Color(0x00CDB177)],
              ),
            ),
          ),
        ),
      ],
    );
  }
}
