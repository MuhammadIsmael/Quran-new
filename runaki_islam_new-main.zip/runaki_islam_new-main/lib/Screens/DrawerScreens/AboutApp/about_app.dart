import 'package:background_app_bar/background_app_bar.dart';
import 'package:flutter/material.dart';
import 'package:flutter_staggered_animations/flutter_staggered_animations.dart';
import 'package:runaki_islam/util/background.dart';
import 'package:runaki_islam/util/constans.dart';
import 'package:runaki_islam/providers/settings_provider.dart';
import 'package:provider/provider.dart';

class AboutApp extends StatefulWidget {
  final String? sarder;
  final int? appBarSize = 600;

  const AboutApp({super.key, this.sarder});
  @override
  State<StatefulWidget> createState() => _AboutAppState();
}

class _AboutAppState extends State<AboutApp> {
  int? fontType;
  final List<Items> _list = [];
  @override
  void initState() {
    super.initState();

    fontType = Provider.of<SettingsProvider>(context, listen: false)
        .getsettingField('font_family');

    _list.add(Items(
      title: "قورئانی پیرۆز",
      desc: "تەواوی قورئانی بە نوسین",
    ));
    _list.add(Items(
      title: "زیکرەکان ",
      desc: "کۆمەڵە زیکرێکی ڕۆژانەیی بەسوود ",
    ));
    _list.add(Items(
      title: "تەسبیحی ئەلیکتڕۆنی",
      desc:
          "کۆمەڵە تەسبیحاتێکی ڕۆژانە و هەر زیکرێک بتەوێ زیادی بکەی ڕۆژانە بە تەسبیحی ئەلیکتڕۆنی تەسبیحات بکەیت",
    ));
    _list.add(Items(
      title: "فەرموودە",
      desc: "زیاتر لە 200 فەرموودە",
    ));
    _list.add(Items(
      title: "چیرۆک",
      desc: "1000 چیرۆکی ئاینی بەسوود و کورت",
    ));
    _list.add(Items(
      title: "کتێب ",
      desc:
          "زیاتر لە 170 کتێبی pdf دوای دابەزاندنی هەر کتێبێک دەتوانی بەشێوەی ئۆفلاین کاری پێ بکەیت",
    ));
    _list.add(Items(
      title: "نوێژکردن",
      desc: "20بابەتی تایبەت بە نوێژ کردن بە بەڵگەو ماناکانیەوە ",
    ));
    _list.add(Items(
      title: "ناوەکانی خودای گەورە",
      desc: "هەر 99 ناوەکانی خودای گەورە بە مانای کوردیەوە",
    ));
    _list.add(Items(
      title: " پرسیار و وەڵامی ئاینی",
      desc: "زیاتر لە 600 پرسیار و وەڵامی ئاینی",
    ));
    _list.add(Items(
      title: "ئایەتی کورسی",
      desc: "ئایەتی کورسی بە ئایەت و مانا و سودەکانیەوە",
    ));
    _list.add(Items(
      title: "دوعایەکان",
      desc: "زیاتر لە 120 دوعای بەسوود",
    ));
    _list.add(Items(
      title: "تاقیکردنەوە",
      desc: "کۆمەڵێک پرسیاری ئاینی بە هەڵبژاردن",
    ));
    _list.add(Items(
      title: " ژیاننامەی پێغەمبەر ﷺ",
      desc: "ژیاننامەی پێغەمبەر و موعجیزەکانی ",
    ));
    _list.add(Items(
      title: "خەونامە",
      desc: "زیاد لە 2000 وشە",
    ));
    _list.add(Items(
      title: "ژیاننامەی پێغەمبەران",
      desc: "ژیاننامەی کۆمەڵێک لە پێغەمبەران",
    ));
    _list.add(Items(
      title: "تاوانە گەورەکان",
      desc: "تاوانە گەورەکان",
    ));
    _list.add(Items(
      title: "هاوەڵانی پێغەمبەر ﷺ",
      desc: "کۆمەڵێک لە هاوەڵانی پێغەمبەر ﷺ",
    ));
    _list.add(Items(
      title: "بەهەشت و دۆزەخ",
      desc: "کۆمەڵێک زانیاری لەسەر بەهەشت و دۆزەخ",
    ));
    _list.add(Items(
      title: "مانگی ڕەمەزان",
      desc: "تەواوی زانیاریەکانی مانگی ڕەمەزان",
    ));
    _list.add(Items(
      title: "زانیاری قورئان",
      desc: "هەندێک زانیاری لەسەر قورئان",
    ));
    _list.add(Items(title: "ڕۆژژمێری هیجری", desc: "دیاری کردنی ڕۆژی هیجری"));
    _list.add(
        Items(title: "نیشانەکانی ڕۆژی دوایی", desc: "نیشانە بچوک و گەورەکان"));
    _list.add(Items(
        title: "وتە و ئامۆژگاری", desc: "کۆمەڵێک و وتە و ئامۆژگاری بەسوود"));
    _list.add(Items(title: "سوونەتەکان", desc: "زیاتر لە 1000 سوونەت"));
    _list.add(Items(title: "کەفارەتەکان", desc: "کەفارەتەکان"));
    _list.add(Items(title: "حەڕامکراوەکان", desc: "حەڕامکراوەکان"));
    _list.add(Items(
        title: "پایەکانی ئیمان و ئیسلام", desc: "ئەرکەکانی ئیسلام و ئیمان"));
    _list.add(Items(
        title: "پوختە سەحیحی موسلیم", desc: "زیاتر لە 1500 فەرموودەی سەحیح"));
    _list.add(Items(
      title: "پرسیار و وەڵامەکانی دواڕۆژ",
      desc: "پرسیار و وەڵامەکانی دواڕۆژ",
    ));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: backgroundColor,
      appBar: AppBar(
        backgroundColor: bgColor,
        elevation: 1,
        shadowColor: splashColor,
        shape: const RoundedRectangleBorder(
            borderRadius: BorderRadius.vertical(bottom: Radius.circular(20))),
        title: Text(
          "${widget.sarder}",
          style: TextStyle(fontFamily: fontType.toString(), color: kTextColor),
          textAlign: TextAlign.right,
          textDirection: TextDirection.rtl,
        ),
        leading: IconButton(
            icon: Icon(Icons.arrow_back_ios_new_rounded, color: iconColor),
            onPressed: () => Navigator.pop(context)),
      ),
      body: NestedScrollView(
        physics: const BouncingScrollPhysics(),
        headerSliverBuilder: (_, _) => <Widget>[
          SliverAppBar(
            automaticallyImplyLeading: false,
            expandedHeight: 380.0,
            elevation: 0.0,
            backgroundColor: Colors.transparent,
            flexibleSpace: BackgroundFlexibleSpaceBar(
                collapseMode: CollapseMode.parallax,
                centerTitle: true,
                background: Column(children: [
                  Container(
                      height: 200,
                      width: double.infinity,
                      margin: const EdgeInsets.symmetric(
                          vertical: 15, horizontal: 5),
                      decoration: BoxDecoration(
                          color: splashColor.withValues(alpha: 0.6),
                          borderRadius: BorderRadius.circular(10)),
                      child: Stack(alignment: Alignment.center, children: [
                        ClipRRect(
                            borderRadius: BorderRadius.circular(10),
                            child: const Background()),
                        Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              ClipRRect(
                                  borderRadius: BorderRadius.circular(15),
                                  child: Image.asset(
                                      "assets/icons/icon-app.jpg",
                                      height: 100,
                                      width: 100)),
                              const SizedBox(height: 10),
                              Text("ڕوناکی ئیسلام",
                                  style: TextStyle(
                                      fontFamily: fontType.toString(),
                                      color: kActiveIconColor,
                                      fontSize: 26.0))
                            ])
                      ])),
                  Text(
                      " بەناوی بەخشندە و میهرەبان سوپاس بۆ خوا  لە دەرفەتێکی ترم توانیم ئەپلیکەیشنێکی ئاینی دروست بکەم  ئەپلیکەیشنی ڕوناکی ئیسلام ئەم بەشانەی لەخۆ گرتووە",
                      style: TextStyle(
                        fontFamily: fontType.toString(),
                        color: titleTextColor,
                        fontSize: 16,
                      ),
                      textAlign: TextAlign.center),
                  const SizedBox(height: 30),
                  // Container(
                  //   width: double.infinity,
                  //   padding:const EdgeInsets.all(8),
                  //   decoration: BoxDecoration(
                  //       borderRadius: BorderRadius.circular(10),
                  //       color: bgColor.withValues(alpha: 0.4)),
                  //   child: Text(
                  //     "Powered By Bircode for\nsoftware solutions",
                  //     textAlign: TextAlign.center,
                  //     style: TextStyle(
                  //       color: kActiveIconColor,
                  //       fontFamily: "english",
                  //     ),
                  //   ),
                  // ),
                ])),
          ),
        ],
        body: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 10),
          child: Stack(
            children: [
              CustomBackground(
                color: Colors.transparent,
                imageColor: bgColor.withValues(alpha: 0.2),
              ),
              AnimationLimiter(
                  child: AnimationConfiguration.synchronized(
                      child: SlideAnimation(
                duration: const Duration(milliseconds: 2500),
                curve: Curves.fastLinearToSlowEaseIn,
                horizontalOffset: 30,
                verticalOffset: 300.0,
                child: FlipAnimation(
                  duration: const Duration(milliseconds: 3000),
                  curve: Curves.fastLinearToSlowEaseIn,
                  flipAxis: FlipAxis.y,
                  child: Column(
                    children: [
                      const SizedBox(height: 15),
                      Expanded(
                        child: ListView.builder(
                            physics: const BouncingScrollPhysics(),
                            padding: const EdgeInsets.only(bottom: 60.0),
                            itemCount: _list.length,
                            itemBuilder: (context, i) {
                              final a = _list[i];
                              return ListTile(
                                leading: Container(
                                  padding: const EdgeInsets.all(8),
                                  decoration: BoxDecoration(
                                    shape: BoxShape.circle,
                                    color: bgColor.withValues(alpha: 0.7),
                                  ),
                                  child: Text("${i + 1}",
                                      style: TextStyle(
                                          fontFamily: fontType.toString(),
                                          color:
                                              kActiveIconColor.withValues(alpha: 0.7),
                                          fontSize: 12)),
                                ),
                                title: Text(
                                  a.title!,
                                  style: TextStyle(
                                      fontFamily: fontType.toString(),
                                      color: kActiveIconColor),
                                  textDirection: TextDirection.rtl,
                                ),
                                subtitle: Text(
                                  a.desc!,
                                  textDirection: TextDirection.rtl,
                                  style: TextStyle(
                                      fontFamily: fontType.toString(),
                                      color: descriptionTectColor),
                                ),
                              );
                            }),
                      )
                    ],
                  ),
                ),
              ))),
            ],
          ),
        ),
      ),
    );
  }
}

class Items {
  final String? title;
  final String? desc;

  Items({this.title, this.desc});
}
