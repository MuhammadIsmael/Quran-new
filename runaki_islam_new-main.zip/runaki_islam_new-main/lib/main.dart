import 'dart:async';

import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_kurdish_localization/kurdish_material_localization_delegate.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:get/get_navigation/src/root/get_material_app.dart';
import 'package:provider/provider.dart';
import 'package:runaki_islam/Screens/mainScreens/home_page.dart';
import 'package:runaki_islam/providers/quran_state_provider.dart';
import 'package:runaki_islam/providers/sebha_provider.dart';
import 'package:runaki_islam/providers/sections_provider.dart';
import 'package:runaki_islam/providers/settings_provider.dart';
import 'package:runaki_islam/providers/theme_provider.dart';
import 'package:runaki_islam/services/push_notification_service.dart';
import 'package:runaki_islam/services/zikr_notification_service.dart';
import 'package:runaki_islam/services/zikr_reminder_open_service.dart';
import 'package:runaki_islam/util/animation_helper.dart';
import 'package:runaki_islam/util/constans.dart';
import 'package:runaki_islam/util/kurdish_fallback_cupertino_delegate.dart';
import 'package:runaki_islam/util/kurdish_fallback_widgets_delegate.dart';

import 'firebase_options.dart';
import 'theme/theme.dart';
import 'Screens/mainScreens/loading_page.dart';

int? initScreen;

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await _initializeFirebaseIfConfigured();
  PushNotificationService.registerBackgroundHandler();

  SystemChrome.setSystemUIOverlayStyle(_overlayStyleForTheme(AppTheme.light));
  runApp(const MyApp());
}

SystemUiOverlayStyle _overlayStyleForTheme(ThemeData theme) {
  final isDark = theme.brightness == Brightness.dark;
  final background = theme.scaffoldBackgroundColor;

  return (isDark ? SystemUiOverlayStyle.light : SystemUiOverlayStyle.dark)
      .copyWith(
        systemNavigationBarColor: background,
        statusBarColor: Colors.transparent,
        systemNavigationBarIconBrightness: isDark
            ? Brightness.light
            : Brightness.dark,
        statusBarIconBrightness: isDark ? Brightness.light : Brightness.dark,
        statusBarBrightness: isDark ? Brightness.dark : Brightness.light,
      );
}

Future<void> _initializeFirebaseIfConfigured() async {
  try {
    await Firebase.initializeApp(
      options: DefaultFirebaseOptions.currentPlatform,
    );
    debugPrint('Firebase initialized successfully.');
  } on UnsupportedError catch (error) {
    debugPrint('Firebase is not configured for this platform: $error');
  } catch (error, stackTrace) {
    debugPrint('Firebase initialization failed: $error');
    debugPrintStack(stackTrace: stackTrace);
  }
}

class MyApp extends StatefulWidget {
  const MyApp({super.key});

  @override
  State<MyApp> createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  late final SectionsProvider _sectionsProvider;
  late final SettingsProvider _settingsProvider;
  late final QuranStateProvider _quranStateProvider;
  late final SebhaProvider _sebhaProvider;
  late final ThemeNotifier _themeNotifier;
  late final Future<bool> _appBootstrapFuture;

  @override
  void initState() {
    super.initState();
    _sectionsProvider = SectionsProvider();
    _settingsProvider = SettingsProvider();
    _quranStateProvider = QuranStateProvider();
    _sebhaProvider = SebhaProvider();
    _themeNotifier = ThemeNotifier();
    _appBootstrapFuture = _sectionsProvider.ensureInitialized(
      settingsProvider: _settingsProvider,
      sebhaProvider: _sebhaProvider,
    );

    WidgetsBinding.instance.addPostFrameCallback((_) {
      Future<void>.delayed(const Duration(milliseconds: 700), () {
        if (!mounted) return;
        unawaited(_initializeAppServices());
      });
    });
  }

  @override
  void dispose() {
    _themeNotifier.dispose();
    _sebhaProvider.dispose();
    _quranStateProvider.dispose();
    _settingsProvider.dispose();
    _sectionsProvider.dispose();
    super.dispose();
  }

  Future<void> _initializeAppServices() async {
    await _runAppService(
      'Zikr reminder open handling',
      ZikrReminderOpenService.initialize,
    );
    await _runAppService(
      'Push notifications',
      PushNotificationService.initialize,
    );
    await _runAppService(
      'Background zikr reminders',
      ZikrNotificationService.startBackgroundZikrNotifications,
    );
  }

  Future<void> _runAppService(
    String name,
    Future<void> Function() initialize,
  ) async {
    try {
      await initialize();
    } on MissingPluginException catch (error) {
      debugPrint('$name plugin missing: $error');
    } on PlatformException catch (error) {
      debugPrint('$name platform error: ${error.code} ${error.message}');
    } catch (error, stackTrace) {
      debugPrint('$name initialization failed: $error');
      debugPrintStack(stackTrace: stackTrace);
    }
  }

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider<SectionsProvider>.value(
          value: _sectionsProvider,
        ),
        ChangeNotifierProvider<SettingsProvider>.value(
          value: _settingsProvider,
        ),
        ChangeNotifierProvider<QuranStateProvider>.value(
          value: _quranStateProvider,
        ),
        ChangeNotifierProvider<SebhaProvider>.value(value: _sebhaProvider),
        ChangeNotifierProvider<ThemeNotifier>.value(value: _themeNotifier),
      ],
      child: Consumer<ThemeNotifier>(
        builder: (context, notifier, child) {
          final selectedTheme = notifier.currentTheme;
          applyLegacyPaletteFromTheme(selectedTheme);
          SystemChrome.setSystemUIOverlayStyle(
            _overlayStyleForTheme(selectedTheme),
          );

          return GetMaterialApp(
            navigatorKey: ZikrReminderOpenService.navigatorKey,
            debugShowCheckedModeBanner: false,
            localizationsDelegates: const [
              KurdishMaterialLocalizations.delegate,
              KurdishFallbackWidgetsLocalizationsDelegate(),
              KurdishFallbackCupertinoLocalizationsDelegate(),
              GlobalMaterialLocalizations.delegate,
              GlobalWidgetsLocalizations.delegate,
              GlobalCupertinoLocalizations.delegate,
            ],
            supportedLocales: const [Locale('ku')],
            locale: const Locale('ku'),
            theme: lightMode,
            darkTheme: darkMode,
            themeMode: notifier.themeMode,
            title: "ڕوناکی ئیسلام",
            builder: (context, child) {
              final mediaQuery = MediaQuery.of(context);
              return AnnotatedRegion<SystemUiOverlayStyle>(
                value: _overlayStyleForTheme(Theme.of(context)),
                child: MediaQuery(
                  data: mediaQuery.copyWith(
                    disableAnimations: AppMotion.reduceMotion,
                  ),
                  child: child ?? const SizedBox.shrink(),
                ),
              );
            },
            home: FutureBuilder<bool>(
              future: _appBootstrapFuture,
              builder: (context, result) {
                if (result.connectionState == ConnectionState.waiting) {
                  debugPrint(' The page is  Loading !!');
                  return const LoadingPage();
                }
                debugPrint(' username is Amin ');
                return const Homepage();
              },
            ),
          );
        },
      ),
    );
  }
}
