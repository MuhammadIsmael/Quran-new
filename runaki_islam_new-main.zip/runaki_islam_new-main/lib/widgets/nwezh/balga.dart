import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:runaki_islam/providers/settings_provider.dart';
import 'package:runaki_islam/util/constans.dart';

class BalgaWidget extends StatefulWidget {
  final String? description;

  const BalgaWidget({super.key, this.description});

  @override
  State<BalgaWidget> createState() => _BalgaWidgetState();
}

class _BalgaWidgetState extends State<BalgaWidget> {
  int? fontType;
  int? quranFontType;
  double? quranFontSize;
  double? fontSize;
  @override
  void initState() {
    super.initState();

    fontType = Provider.of<SettingsProvider>(context, listen: false)
        .getsettingField('font_family');
    quranFontType = Provider.of<SettingsProvider>(context, listen: false)
        .getsettingField('quran_font_family');
    quranFontSize = Provider.of<SettingsProvider>(context, listen: false)
        .getsettingField('quran_font_size');
    fontSize = Provider.of<SettingsProvider>(context, listen: false)
        .getsettingField('font_size');
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: <Widget>[
        Align(
          alignment: Alignment.centerRight,
          child: Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: thirdColor.withValues(alpha: 0.5),
              borderRadius: const BorderRadius.only(
                topLeft: Radius.circular(10),
                topRight: Radius.circular(10),
              ),
            ),
            child: Text(
              "بەڵگە",
              textAlign: TextAlign.center,
              style: simpleTextStyle.copyWith(
                  fontFamily: fontType.toString(),
                  fontSize: fontSize,
                  color: kActiveIconColor),
            ),
          ),
        ),
        Container(
          width: double.infinity,
          padding: const EdgeInsets.all(8),
          decoration: BoxDecoration(
              color: thirdColor.withValues(alpha: 0.5),
              borderRadius: const BorderRadius.only(
                topLeft: Radius.circular(10),
                bottomLeft: Radius.circular(10),
                bottomRight: Radius.circular(10),
              )),
          child: Text(
            widget.description!,
            textAlign: TextAlign.center,
            style: simpleTextStyle.copyWith(
                fontFamily: fontType.toString(), fontSize: fontSize),
          ),
        )
      ],
    );
  }
}

class BalgaWidget2 extends StatefulWidget {
  final String? text;
  final String? quran;

  const BalgaWidget2({super.key, this.text, this.quran});

  @override
  State<BalgaWidget2> createState() => _BalgaWidget2State();
}

class _BalgaWidget2State extends State<BalgaWidget2> {
  int? fontType;
  int? quranFontType;
  double? quranFontSize;
  double? fontSize;

  @override
  void initState() {
    super.initState();

    fontType = Provider.of<SettingsProvider>(context, listen: false)
        .getsettingField('font_family');
    quranFontType = Provider.of<SettingsProvider>(context, listen: false)
        .getsettingField('quran_font_family');
    quranFontSize = Provider.of<SettingsProvider>(context, listen: false)
        .getsettingField('quran_font_size');
    fontSize = Provider.of<SettingsProvider>(context, listen: false)
        .getsettingField('font_size');
  }

  @override
  Widget build(BuildContext context) {
    return Center(
        child: Column(
      children: <Widget>[
        Align(
          alignment: Alignment.centerRight,
          child: Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: thirdColor.withValues(alpha: 0.5),
              borderRadius: const BorderRadius.only(
                topLeft: Radius.circular(10),
                topRight: Radius.circular(10),
              ),
            ),
            child: Text(
              "بەڵگە",
              textAlign: TextAlign.center,
              style: simpleTextStyle.copyWith(
                  fontFamily: fontType.toString(),
                  fontSize: fontSize,
                  color: kActiveIconColor),
            ),
          ),
        ),
        Container(
            width: double.infinity,
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
                color: thirdColor.withValues(alpha: 0.5),
                borderRadius: const BorderRadius.only(
                  topLeft: Radius.circular(10),
                  bottomLeft: Radius.circular(10),
                  bottomRight: Radius.circular(10),
                )),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(
                  widget.quran!,
                  style: quranStyle.copyWith(
                      fontFamily: quranFontType.toString(),
                      fontSize: quranFontSize),
                  textAlign: TextAlign.center,
                ),
                Text(
                  widget.text!,
                  style: simpleTextStyle.copyWith(
                      fontFamily: fontType.toString(), fontSize: fontSize),
                  textAlign: TextAlign.center,
                ),
              ],
            )),
      ],
    ));
  }
}

class BalgaWidget3 extends StatefulWidget {
  final String? text1;
  final String? quran;
  final String? text2;

  const BalgaWidget3({super.key, this.text1, this.text2, this.quran});

  @override
  State<BalgaWidget3> createState() => _BalgaWidget3State();
}

class _BalgaWidget3State extends State<BalgaWidget3> {
  int? fontType;
  int? quranFontType;
  double? quranFontSize;
  double? fontSize;
  @override
  void initState() {
    super.initState();

    fontType = Provider.of<SettingsProvider>(context, listen: false)
        .getsettingField('font_family');
    quranFontType = Provider.of<SettingsProvider>(context, listen: false)
        .getsettingField('quran_font_family');
    quranFontSize = Provider.of<SettingsProvider>(context, listen: false)
        .getsettingField('quran_font_size');
    fontSize = Provider.of<SettingsProvider>(context, listen: false)
        .getsettingField('font_size');
  }

  @override
  Widget build(BuildContext context) {
    return Center(
        child: Column(
      children: <Widget>[
        Align(
          alignment: Alignment.centerRight,
          child: Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: thirdColor.withValues(alpha: 0.5),
              borderRadius: const BorderRadius.only(
                topLeft: Radius.circular(10),
                topRight: Radius.circular(10),
              ),
            ),
            child: Text(
              "بەڵگە",
              textAlign: TextAlign.center,
              style: simpleTextStyle.copyWith(
                  fontSize: fontSize,
                  fontFamily: fontType.toString(),
                  color: kActiveIconColor),
            ),
          ),
        ),
        Container(
            width: double.infinity,
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
                color: thirdColor.withValues(alpha: 0.5),
                borderRadius: const BorderRadius.only(
                  topLeft: Radius.circular(10),
                  bottomLeft: Radius.circular(10),
                  bottomRight: Radius.circular(10),
                )),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(
                  widget.text1!,
                  style: simpleTextStyle.copyWith(
                    fontSize: fontSize,
                    fontFamily: fontType.toString(),
                  ),
                  textAlign: TextAlign.center,
                ),
                Padding(
                  padding: const EdgeInsets.symmetric(vertical: 10),
                  child: Text(
                    widget.quran!,
                    style: quranStyle.copyWith(
                        fontFamily: quranFontType.toString(),
                        fontSize: quranFontSize),
                    textAlign: TextAlign.center,
                  ),
                ),
                Text(
                  widget.text2!,
                  style: simpleTextStyle.copyWith(
                      fontFamily: fontType.toString(), fontSize: fontSize),
                  textAlign: TextAlign.center,
                ),
              ],
            )),
      ],
    ));
  }
}
