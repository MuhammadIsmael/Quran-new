import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:runaki_islam/providers/settings_provider.dart';
import 'package:runaki_islam/util/constans.dart';

class HeaderNwezhItem extends StatefulWidget {
  final String? text;

  const HeaderNwezhItem({super.key, this.text});

  @override
  State<HeaderNwezhItem> createState() => _HeaderNwezhItemState();
}

class _HeaderNwezhItemState extends State<HeaderNwezhItem> {
  int? fontType;
  double? fontSize;
  @override
  void initState() {
    super.initState();

    fontType = Provider.of<SettingsProvider>(context, listen: false)
        .getsettingField('font_family');

    fontSize = Provider.of<SettingsProvider>(context, listen: false)
        .getsettingField('font_size');
  }

  @override
  Widget build(BuildContext context) {
    return Align(
      alignment: Alignment.center,
      child: Container(
        padding: const EdgeInsets.all(8),
        decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(10),
            gradient: LinearGradient(
                colors: [secondColor.withValues(alpha: 0.6), secondColor]),
            boxShadow: [
              BoxShadow(
                blurRadius: 30,
                color: thirdColor,
              )
            ]),
        child: Text(
          widget.text!,
          textAlign: TextAlign.center,
          style: TextStyle(fontFamily: fontType.toString(), fontSize: fontSize),
        ),
      ),
    );
  }
}
