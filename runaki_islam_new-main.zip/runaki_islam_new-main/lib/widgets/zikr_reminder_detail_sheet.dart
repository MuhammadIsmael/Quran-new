import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:runaki_islam/models/zikr_reminder_entry.dart';
import 'package:runaki_islam/providers/settings_provider.dart';

Future<void> showZikrReminderDetailSheet(
  BuildContext context,
  ZikrReminderEntry entry,
) {
  return showModalBottomSheet<void>(
    context: context,
    useRootNavigator: true,
    isScrollControlled: true,
    backgroundColor: Colors.transparent,
    barrierColor: Colors.black.withValues(alpha: 0.46),
    builder: (context) => DraggableScrollableSheet(
      expand: false,
      initialChildSize: 0.88,
      minChildSize: 0.62,
      maxChildSize: 0.97,
      builder: (context, scrollController) {
        return _ZikrReminderDetailSheet(
          entry: entry,
          scrollController: scrollController,
        );
      },
    ),
  );
}

class _ZikrReminderDetailSheet extends StatelessWidget {
  const _ZikrReminderDetailSheet({
    required this.entry,
    required this.scrollController,
  });

  final ZikrReminderEntry entry;
  final ScrollController scrollController;

  @override
  Widget build(BuildContext context) {
    final fontFamily = Provider.of<SettingsProvider>(
      context,
      listen: false,
    ).getsettingField('font_family')?.toString();
    const accent = Color(0xFF0D6A57);
    const accentSoft = Color(0xFFB88B3D);
    const paper = Color(0xFFF8F3E7);
    const paperDeep = Color(0xFFE7E1CF);
    const ink = Color(0xFF17322C);

    return Directionality(
      textDirection: TextDirection.rtl,
      child: SafeArea(
        top: false,
        child: _buildScrollableSheet(
          context: context,
          fontFamily: fontFamily,
          accent: accent,
          accentSoft: accentSoft,
          paper: paper,
          paperDeep: paperDeep,
          ink: ink,
        ),
      ),
    );
  }

  Widget _buildScrollableSheet({
    required BuildContext context,
    required String? fontFamily,
    required Color accent,
    required Color accentSoft,
    required Color paper,
    required Color paperDeep,
    required Color ink,
  }) {
    return Container(
      decoration: const BoxDecoration(
        borderRadius: BorderRadius.vertical(top: Radius.circular(34)),
        boxShadow: [
          BoxShadow(
            color: Color(0x33000000),
            blurRadius: 28,
            offset: Offset(0, -8),
          ),
        ],
      ),
      child: ClipRRect(
        borderRadius: const BorderRadius.vertical(top: Radius.circular(34)),
        child: Stack(
          children: [
            Container(
              decoration: const BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [
                    Color(0xFFF8F5EA),
                    Color(0xFFF0E8D5),
                    Color(0xFFE6F1EB),
                  ],
                ),
              ),
            ),
            Positioned.fill(
              child: CustomPaint(
                painter: _IslamicPatternPainter(
                  accent: accent,
                  accentSoft: accentSoft,
                ),
              ),
            ),
            Positioned.fill(
              child: LayoutBuilder(
                builder: (context, constraints) {
                  return Scrollbar(
                    controller: scrollController,
                    thumbVisibility: true,
                    interactive: true,
                    radius: const Radius.circular(999),
                    child: SingleChildScrollView(
                      controller: scrollController,
                      physics: const BouncingScrollPhysics(
                        parent: AlwaysScrollableScrollPhysics(),
                      ),
                      padding: const EdgeInsets.fromLTRB(18, 18, 18, 22),
                      child: ConstrainedBox(
                        constraints: BoxConstraints(
                          minHeight: constraints.maxHeight - 40,
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.stretch,
                          children: [
                            Center(
                              child: Container(
                                width: 58,
                                height: 6,
                                decoration: BoxDecoration(
                                  color: accent.withValues(alpha: 0.18),
                                  borderRadius: BorderRadius.circular(999),
                                ),
                              ),
                            ),
                            const SizedBox(height: 8),
                            Align(
                              alignment: Alignment.centerLeft,
                              child: IconButton(
                                onPressed: () => Navigator.of(context).pop(),
                                icon: const Icon(Icons.close_rounded),
                                color: accent,
                              ),
                            ),
                            _buildHeaderCard(
                              fontFamily: fontFamily,
                              accent: accent,
                              accentSoft: accentSoft,
                              ink: ink,
                            ),
                            const SizedBox(height: 14),
                            _buildReadingHint(
                              fontFamily: fontFamily,
                              accent: accent,
                              ink: ink,
                            ),
                            const SizedBox(height: 16),
                            _buildReadingPanel(
                              fontFamily: fontFamily,
                              accent: accent,
                              accentSoft: accentSoft,
                              paper: paper,
                              ink: ink,
                            ),
                            const SizedBox(height: 20),
                            SizedBox(
                              width: double.infinity,
                              child: FilledButton(
                                style: FilledButton.styleFrom(
                                  backgroundColor: accent,
                                  foregroundColor: Colors.white,
                                  padding: const EdgeInsets.symmetric(
                                    vertical: 16,
                                  ),
                                  shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(18),
                                  ),
                                ),
                                onPressed: () => Navigator.of(context).pop(),
                                child: Text(
                                  'داخستن',
                                  style: TextStyle(
                                    fontFamily: fontFamily,
                                    fontSize: 16,
                                    fontWeight: FontWeight.w700,
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  );
                },
              ),
            ),
            IgnorePointer(
              child: Align(
                alignment: Alignment.topCenter,
                child: Container(
                  height: 10,
                  margin: const EdgeInsets.only(top: 138),
                  width: 210,
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: [
                        accentSoft.withValues(alpha: 0),
                        accentSoft.withValues(alpha: 0.22),
                        accentSoft.withValues(alpha: 0),
                      ],
                    ),
                    borderRadius: BorderRadius.circular(999),
                  ),
                ),
              ),
            ),
            IgnorePointer(
              child: Align(
                alignment: Alignment.bottomCenter,
                child: Container(
                  height: 90,
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      begin: Alignment.bottomCenter,
                      end: Alignment.topCenter,
                      colors: [paperDeep, paperDeep.withValues(alpha: 0)],
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildHeaderCard({
    required String? fontFamily,
    required Color accent,
    required Color accentSoft,
    required Color ink,
  }) {
    return Column(
      children: [
        Container(
          width: 92,
          height: 92,
          margin: const EdgeInsets.only(bottom: 18),
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            gradient: const RadialGradient(
              colors: [Color(0xFFFDF5DF), Color(0xFFE2D2AA)],
            ),
            border: Border.all(
              color: accentSoft.withValues(alpha: 0.55),
              width: 1.5,
            ),
            boxShadow: [
              BoxShadow(
                color: accentSoft.withValues(alpha: 0.16),
                blurRadius: 22,
                offset: const Offset(0, 8),
              ),
            ],
          ),
          child: Icon(Icons.auto_stories_rounded, size: 42, color: accent),
        ),
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
          decoration: BoxDecoration(
            color: accent.withValues(alpha: 0.10),
            borderRadius: BorderRadius.circular(999),
            border: Border.all(color: accent.withValues(alpha: 0.18)),
          ),
          child: Text(
            entry.categoryLabel,
            style: TextStyle(
              fontFamily: fontFamily,
              fontSize: 13,
              color: accent,
              fontWeight: FontWeight.w700,
            ),
          ),
        ),
        const SizedBox(height: 14),
        Container(
          width: double.infinity,
          padding: const EdgeInsets.fromLTRB(20, 20, 20, 18),
          decoration: BoxDecoration(
            color: Colors.white.withValues(alpha: 0.72),
            borderRadius: BorderRadius.circular(28),
            border: Border.all(color: accentSoft.withValues(alpha: 0.28)),
          ),
          child: Column(
            children: [
              Text(
                entry.title,
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontFamily: fontFamily,
                  fontSize: 24,
                  height: 1.45,
                  color: ink,
                  fontWeight: FontWeight.w700,
                ),
              ),
              if (entry.body.trim().isNotEmpty &&
                  entry.body.trim() != entry.resolvedDetail)
                Padding(
                  padding: const EdgeInsets.only(top: 12),
                  child: Text(
                    entry.body,
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      fontFamily: fontFamily,
                      fontSize: 14,
                      height: 1.8,
                      color: ink.withValues(alpha: 0.74),
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildReadingHint({
    required String? fontFamily,
    required Color accent,
    required Color ink,
  }) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      decoration: BoxDecoration(
        color: Colors.white.withValues(alpha: 0.58),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: accent.withValues(alpha: 0.10)),
      ),
      child: Row(
        children: [
          Icon(Icons.swipe_up_alt_rounded, color: accent, size: 22),
          const SizedBox(width: 10),
          Expanded(
            child: Text(
              'بۆ خوێندنەوەی ئاسان، شیتەکە ڕاکێشە یان سکرۆڵ بکە.',
              style: TextStyle(
                fontFamily: fontFamily,
                fontSize: 13.5,
                height: 1.6,
                color: ink.withValues(alpha: 0.78),
                fontWeight: FontWeight.w600,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildReadingPanel({
    required String? fontFamily,
    required Color accent,
    required Color accentSoft,
    required Color paper,
    required Color ink,
  }) {
    return Container(
      width: double.infinity,
      decoration: BoxDecoration(
        color: paper.withValues(alpha: 0.95),
        borderRadius: BorderRadius.circular(30),
        border: Border.all(color: accentSoft.withValues(alpha: 0.24)),
        boxShadow: [
          BoxShadow(
            color: accent.withValues(alpha: 0.06),
            blurRadius: 20,
            offset: const Offset(0, 8),
          ),
        ],
      ),
      child: Stack(
        children: [
          Positioned(
            top: -24,
            right: -12,
            child: _DecorativeBloom(color: accentSoft.withValues(alpha: 0.14)),
          ),
          Positioned(
            bottom: -30,
            left: -6,
            child: _DecorativeBloom(color: accent.withValues(alpha: 0.10)),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(22, 22, 22, 24),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Row(
                  children: [
                    Icon(Icons.menu_book_rounded, color: accent, size: 22),
                    const SizedBox(width: 8),
                    Expanded(
                      child: Text(
                        'دەقی تەواوی زیکر',
                        style: TextStyle(
                          fontFamily: fontFamily,
                          fontSize: 16,
                          color: accent,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                    ),
                  ],
                ),
                Padding(
                  padding: const EdgeInsets.symmetric(vertical: 14),
                  child: Divider(
                    color: accentSoft.withValues(alpha: 0.28),
                    height: 1,
                  ),
                ),
                SelectableText(
                  entry.resolvedDetail,
                  textAlign: TextAlign.right,
                  style: TextStyle(
                    fontFamily: fontFamily,
                    fontSize: 19,
                    height: 2.0,
                    color: ink,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _DecorativeBloom extends StatelessWidget {
  const _DecorativeBloom({required this.color});

  final Color color;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: 128,
      height: 128,
      child: CustomPaint(painter: _BloomPainter(color: color)),
    );
  }
}

class _IslamicPatternPainter extends CustomPainter {
  const _IslamicPatternPainter({
    required this.accent,
    required this.accentSoft,
  });

  final Color accent;
  final Color accentSoft;

  @override
  void paint(Canvas canvas, Size size) {
    final starPaint = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.1
      ..color = accent.withValues(alpha: 0.10);
    final fillPaint = Paint()
      ..style = PaintingStyle.fill
      ..color = accentSoft.withValues(alpha: 0.05);
    final dotPaint = Paint()
      ..style = PaintingStyle.fill
      ..color = accent.withValues(alpha: 0.12);
    const spacing = 92.0;

    for (double y = -spacing; y < size.height + spacing; y += spacing) {
      final offsetX = (((y / spacing).round()) % 2 == 0) ? 0.0 : spacing / 2;
      for (double x = -spacing; x < size.width + spacing; x += spacing) {
        final center = Offset(x + offsetX, y);
        canvas.drawPath(_buildStar(center, 22, 10), fillPaint);
        canvas.drawPath(_buildStar(center, 30, 16), starPaint);
        canvas.drawCircle(center, 2.2, dotPaint);
      }
    }
  }

  Path _buildStar(Offset center, double outerRadius, double innerRadius) {
    final path = Path();
    for (int i = 0; i < 16; i++) {
      final angle = (-math.pi / 2) + (i * math.pi / 8);
      final radius = i.isEven ? outerRadius : innerRadius;
      final point = Offset(
        center.dx + math.cos(angle) * radius,
        center.dy + math.sin(angle) * radius,
      );
      if (i == 0) {
        path.moveTo(point.dx, point.dy);
      } else {
        path.lineTo(point.dx, point.dy);
      }
    }
    path.close();
    return path;
  }

  @override
  bool shouldRepaint(covariant _IslamicPatternPainter oldDelegate) {
    return oldDelegate.accent != accent || oldDelegate.accentSoft != accentSoft;
  }
}

class _BloomPainter extends CustomPainter {
  const _BloomPainter({required this.color});

  final Color color;

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 2
      ..color = color;
    final center = Offset(size.width / 2, size.height / 2);
    for (int i = 0; i < 8; i++) {
      final angle = i * math.pi / 4;
      final start = Offset(
        center.dx + math.cos(angle) * 14,
        center.dy + math.sin(angle) * 14,
      );
      final end = Offset(
        center.dx + math.cos(angle) * 46,
        center.dy + math.sin(angle) * 46,
      );
      canvas.drawLine(start, end, paint);
      canvas.drawCircle(end, 8, paint);
    }
    canvas.drawCircle(center, 18, paint);
  }

  @override
  bool shouldRepaint(covariant _BloomPainter oldDelegate) {
    return oldDelegate.color != color;
  }
}
