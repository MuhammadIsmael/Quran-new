import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:runaki_islam/providers/settings_provider.dart';

class MyImageView extends StatelessWidget {
  const MyImageView(this.imgPath, {super.key});

  final String? imgPath;

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 5),
      child: FittedBox(fit: BoxFit.fill, child: Image.asset(imgPath ?? '')),
    );
  }
}

class MyContainer extends StatefulWidget {
  const MyContainer({super.key, this.title, this.desc, this.img});

  final String? title;
  final String? desc;
  final Widget? img;

  @override
  State<MyContainer> createState() => _MyContainerState();
}

class _MyContainerState extends State<MyContainer> {
  int? fontType;

  @override
  void initState() {
    super.initState();
    fontType = Provider.of<SettingsProvider>(
      context,
      listen: false,
    ).getsettingField('font_family');
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 14),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(22),
        boxShadow: const [
          BoxShadow(
            color: Color(0x18000000),
            blurRadius: 20,
            offset: Offset(0, 10),
          ),
        ],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(22),
        child: Stack(
          children: [
            Container(
              width: double.infinity,
              decoration: const BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [
                    Color(0xFFFCCF75),
                    Color(0xFFF5BA4C),
                    Color(0xFFECA73E),
                  ],
                ),
              ),
            ),
            Positioned(
              left: -30,
              top: -30,
              child: Container(
                width: 120,
                height: 120,
                decoration: const BoxDecoration(
                  shape: BoxShape.circle,
                  color: Color(0x22FFFFFF),
                ),
              ),
            ),
            Positioned(
              right: -40,
              bottom: -36,
              child: Container(
                width: 130,
                height: 130,
                decoration: const BoxDecoration(
                  shape: BoxShape.circle,
                  color: Color(0x1FFFFFFF),
                ),
              ),
            ),
            Positioned(
              left: 0,
              right: 0,
              bottom: -4,
              child: Opacity(
                opacity: 0.28,
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: const [
                    Icon(Icons.mosque_rounded, color: Colors.white, size: 46),
                    Icon(Icons.mosque_rounded, color: Colors.white, size: 54),
                    Icon(Icons.mosque_rounded, color: Colors.white, size: 46),
                  ],
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(14, 12, 14, 12),
              child: Row(
                children: [
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.end,
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        const Align(
                          alignment: Alignment.centerLeft,
                          child: Icon(
                            Icons.nightlight_round,
                            size: 17,
                            color: Color(0xE1FFFFFF),
                          ),
                        ),
                        Text(
                          widget.title ?? '',
                          textAlign: TextAlign.right,
                          maxLines: 2,
                          overflow: TextOverflow.ellipsis,
                          style: TextStyle(
                            fontFamily: fontType.toString(),
                            color: Colors.white,
                            fontSize: 18,
                            fontWeight: FontWeight.w800,
                            shadows: const [
                              Shadow(
                                color: Color(0x26000000),
                                offset: Offset(0, 2),
                                blurRadius: 6,
                              ),
                            ],
                          ),
                        ),
                        Text(
                          widget.desc ?? '',
                          textAlign: TextAlign.right,
                          style: TextStyle(
                            fontFamily: fontType.toString(),
                            color: const Color(0xEDFFF8EE),
                            fontSize: 13.5,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(width: 12),
                  SizedBox(
                    width: 88,
                    height: 88,
                    child: widget.img ?? const SizedBox(),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
