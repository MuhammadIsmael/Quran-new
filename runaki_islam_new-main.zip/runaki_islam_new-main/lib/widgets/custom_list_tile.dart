import 'package:flutter/material.dart';
import 'package:flutter_switch/flutter_switch.dart';
import 'package:runaki_islam/util/constans.dart';

class CustomListTile extends StatefulWidget {
  const CustomListTile(
      {super.key,
      this.title,
      this.description,
      this.leading,
      this.value,
      this.onToggle,
      this.haveDesc = true,
      required this.fontFamily});
  final String? title;
  final String? description;
  final IconData? leading;
  final bool? value;
  final void Function(bool)? onToggle;
  final bool haveDesc;
  final int? fontFamily;

  @override
  State<CustomListTile> createState() => _CustomListTileState();
}

class _CustomListTileState extends State<CustomListTile> {
  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return ListTile(
      contentPadding: const EdgeInsets.only(left: 0),
      trailing: Text(
        widget.title!,
        textAlign: TextAlign.center,
        textDirection: TextDirection.ltr,
        style: TextStyle(
          fontSize: 14,
          fontFamily: widget.fontFamily.toString(),
        ),
      ),
      subtitle: widget.haveDesc
          ? Text(
              widget.description!,
              style: TextStyle(
                fontSize: 12,
                fontFamily: widget.fontFamily.toString(),
              ),
              textAlign: TextAlign.center,
            )
          : null,
      leading: RotatedBox(
        quarterTurns: 2,
        child: Container(
            width: 70.0,
            height: 30.0,
            padding: const EdgeInsets.only(left: 12),
            child: FlutterSwitch(
              toggleSize: 25.0,
              value: widget.value!,
              borderRadius: 30.0,
              padding: 2.0,
              activeToggleColor: secondColor,
              inactiveToggleColor: scheme.onSurfaceVariant,
              activeSwitchBorder: Border.all(
                color: secondColor,
                width: 1.5,
              ),
              inactiveSwitchBorder: Border.all(
                color: scheme.outline.withValues(alpha: 0.42),
                width: 1.5,
              ),
              activeColor: primaryColor,
              inactiveColor: isDark ? scheme.surfaceContainerHighest : Colors.white,
              activeIcon: const Icon(
                Icons.light_mode_rounded,
                color: Color(0xFFF8E3A1),
              ),
              inactiveIcon: const Icon(
                Icons.dark_mode_rounded,
                color: Color(0xFFF8E3A1),
              ),
              onToggle: widget.onToggle!,
            )),
      ),
    );
  }
}
