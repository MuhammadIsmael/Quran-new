import 'package:runaki_islam/providers/settings_provider.dart';
import 'package:runaki_islam/util/constans.dart';
import 'package:top_snackbar_flutter/custom_snack_bar.dart';
import 'package:top_snackbar_flutter/top_snack_bar.dart';

import 'tasbih_fields/tasbih_form.dart';
import '../../models/sebha_model.dart';
import '../../providers/sebha_provider.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

class AddTasbih extends StatefulWidget {
  final String? title;

  const AddTasbih({
    super.key,
    this.title,
  });

  @override
  State<StatefulWidget> createState() => _AddTasbihState();
}

class _AddTasbihState extends State<AddTasbih> {
  SebhaModel? _tasbih;
  int? fontType;
  @override
  void initState() {
    _tasbih = SebhaModel(-1, '', 0, 0);
    fontType = Provider.of<SettingsProvider>(context, listen: false)
        .getsettingField('font_family');
    super.initState();
  }

  Future<void> _addTasbih() async {
    _tasbih!.setFavorite(0);
    _tasbih!.setId(Provider.of<SebhaProvider>(context, listen: false).newId);
    await Provider.of<SebhaProvider>(context, listen: false)
        .addItemToSebha(_tasbih!);
  }

  @override
  Widget build(BuildContext context) {
    return Dialog(
      backgroundColor: bgColor,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(10),
      ),
      elevation: 0.0,
      child: TasbihForm(
        title: 'زیادکردنی زیکرەکان',
        tasbih: _tasbih,
        onChangedName: (value) => setState(() {
          _tasbih!.setName = value;
        }),
        onChangedCounter: (value) => setState(() {
          _tasbih!.setCounter = int.parse(value);
        }),
        onTapCancle: () => Navigator.of(context).pop(false),
        onTapDone: () async {
          final navigator = Navigator.of(context);
          final overlay = Overlay.of(context);
          await _addTasbih();
          if (!context.mounted) return;
          navigator.pop(true);
          showTopSnackBar(
            overlay,
              CustomSnackBar.success(
                  message: "زیادکرا",
                  backgroundColor: const Color(0xff7BCBC4),
                  iconRotationAngle: 10,
                  textStyle: TextStyle(
                    fontFamily: fontType.toString(),
                  ),
                  icon: Icon(
                    Icons.done,
                    size: 80,
                    color: Colors.black.withValues(alpha: 0.1),
                  )));
        },
      ),
    );
  }
}
