import 'package:clipboard/clipboard.dart';
import 'package:provider/provider.dart';
import 'package:runaki_islam/providers/settings_provider.dart';
import 'package:runaki_islam/util/constans.dart';
import 'package:flutter/material.dart';
import 'package:top_snackbar_flutter/top_snack_bar.dart';
import 'package:top_snackbar_flutter/custom_snack_bar.dart';
import '../../widgets/sebha_widget/edit_tasbih_dialog.dart';
import '../../models/sebha_model.dart';
import 'delete_dialog.dart';

class PopUpMenuSebha extends StatefulWidget {
  final SebhaModel? tasbih;
  final BuildContext? buildContext;

  const PopUpMenuSebha({
    super.key,
    this.tasbih,
    this.buildContext,
  });

  @override
  State<PopUpMenuSebha> createState() => _PopUpMenuSebhaState();
}

class _PopUpMenuSebhaState extends State<PopUpMenuSebha> {
  int? fontType;

  @override
  void initState() {
    fontType = Provider.of<SettingsProvider>(context, listen: false)
        .getsettingField('font_family');
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Material(
      color: bgColor,
      borderRadius: const BorderRadius.only(
        topLeft: Radius.circular(10),
        topRight: Radius.circular(10),
      ),
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 5.0, vertical: 5.0),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: <Widget>[
            _buildButton(
              title: 'کۆپیکردن',
              icon: Icons.content_copy,
              onTap: () async {
                FlutterClipboard.copy(widget.tasbih!.name);
                showTopSnackBar(
                  Overlay.of(context),
                  CustomSnackBar.success(
                      textStyle: TextStyle(
                        fontFamily: fontType.toString(),
                      ),
                      backgroundColor: const Color(0xff7BCBC4),
                      message: "کۆپیبوو !",
                      icon: Icon(
                        Icons.copy,
                        size: 80,
                        color: Colors.black.withValues(alpha: 0.1),
                      )),
                );

                Navigator.pop(context);
              },
            ),
            const SizedBox(
              height: 15,
            ),
            _buildButton(
              title: 'دەستکاریکرن',
              icon: Icons.edit,
              onTap: () async {
                Navigator.pop(context);
                await showDialog<bool>(
                  context: context,
                  builder: (BuildContext context) => EditTasbih(
                    title: 'دەستکاریکرن',
                    tasbih: widget.tasbih,
                  ),
                );
              },
            ),
            const SizedBox(
              height: 15,
            ),
            _buildButton(
              title: 'سڕینەوە',
              icon: Icons.delete_outline,
              onTap: () async {
                Navigator.pop(context);
                await showDialog<bool>(
                  context: context,
                  builder: (BuildContext context) => DeleteDialog(
                    tasbihFavorite: widget.tasbih!.favorite,
                    tasbihId: widget.tasbih!.id,
                  ),
                );
              },
            ),
            const SizedBox(
              height: 50,
            )
          ],
        ),
      ),
    );
  }

  Widget _buildButton({String? title, VoidCallback? onTap, IconData? icon}) {
    return Material(
      color: Colors.transparent,
      borderRadius: BorderRadius.circular(10),
      child: InkWell(
        highlightColor: splashColor.withAlpha(300),
        splashColor: splashColor,
        borderRadius: BorderRadius.circular(10),
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 10.0, vertical: 10.0),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              Icon(
                icon,
                size: 21,
                color: kActiveIconColor,
              ),
              const Spacer(),
              Text(
                title!,
                style: TextStyle(
                  fontFamily: fontType.toString(),
                  color: kActiveIconColor,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
