import 'package:runaki_islam/providers/settings_provider.dart';
import 'package:runaki_islam/util/constans.dart';
import 'package:top_snackbar_flutter/custom_snack_bar.dart';
import 'package:top_snackbar_flutter/top_snack_bar.dart';

import 'tasbih_fields/tasbih_form.dart';
import '../../models/sebha_model.dart';
import '../../providers/sebha_provider.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

class EditTasbih extends StatefulWidget {
  final String? title;
  final SebhaModel? tasbih;

  const EditTasbih({
    super.key,
    this.title,
    this.tasbih,
  });

  @override
  State<StatefulWidget> createState() => _EditTasbihState();
}

class _EditTasbihState extends State<EditTasbih> {
  SebhaModel? _tasbih;
  int? fontType;

  @override
  void initState() {
    _tasbih = widget.tasbih;
        fontType = Provider.of<SettingsProvider>(context, listen: false)
        .getsettingField('font_family');
    super.initState();
  }

  Future<void> _editTasbih() async {
    await Provider.of<SebhaProvider>(context, listen: false)
        .updateItemFromSebha(_tasbih!);
  }

  @override
  Widget build(BuildContext context) {
    return Dialog(
      backgroundColor: bgColor,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(10),
      ),
      elevation: 0.0,
      child: TasbihForm(
        title: 'دەستکاریکرن',
        tasbih: _tasbih,
        onChangedName: (value) => setState(() {
          _tasbih!.setName = value;
        }),
        onChangedCounter: (value) => setState(() {
          _tasbih!.setCounter = int.parse(value);
        }),
        onTapCancle: () => Navigator.of(context).pop(false),
        onTapDone: () async {
          final navigator = Navigator.of(context);
          final overlay = Overlay.of(context);
          await _editTasbih();
          if (!context.mounted) return;
          navigator.pop(true);
          showTopSnackBar(
            overlay,
              CustomSnackBar.info(
                textStyle: TextStyle(fontFamily: fontType.toString() ,),
                  message: "سەرکەوتوو بوو !",
                  iconRotationAngle: 10,
                  icon: Icon(
                    Icons.done,
                    size: 70,
                    color: Colors.black.withValues(alpha: 0.1),
                  )));
        },
      ),
    );
  }
}
