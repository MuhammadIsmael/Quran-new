import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:runaki_islam/providers/settings_provider.dart';
import 'package:runaki_islam/util/constans.dart';

class TasbihTextField extends StatefulWidget {
  final String? text, hintText, errorText;
  final int? maxLines, maxlength;
  final ValueChanged<String>? onSubmitted, onChanged;
  final bool? isNumber, autoFocus, isFinalField;

  const TasbihTextField({
    super.key,
    this.text,
    required this.hintText,
    this.errorText,
    this.maxLines,
    this.maxlength,
    this.onSubmitted,
    this.onChanged,
    this.isNumber = false,
    this.isFinalField = false,
    this.autoFocus = false,
  });

  @override
  State<StatefulWidget> createState() => _TasbihTextFieldState();
}

class _TasbihTextFieldState extends State<TasbihTextField> {
  TextEditingController? _controller;
  int? fontType;

  @override
  void initState() {
    super.initState();
    fontType = Provider.of<SettingsProvider>(context, listen: false)
        .getsettingField('font_family');
    _controller = TextEditingController(text: widget.text);

    _controller!.selection = TextSelection.fromPosition(
        TextPosition(offset: _controller!.text.length));
  }

  @override
  void dispose() {
    _controller?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(5.0),
      margin: const EdgeInsets.all(10.0),
      decoration: BoxDecoration(
          color: backgroundColor.withValues(alpha: 0.7),
          borderRadius: BorderRadius.circular(10)),
      child: TextField(
        autofocus: widget.autoFocus!,
        controller: _controller,
        maxLines: widget.maxLines,
        maxLength: widget.maxlength,
        textDirection: TextDirection.rtl,
        style: TextStyle(
          fontFamily: fontType.toString(),
          color: kActiveIconColor,
        ),
        onSubmitted: widget.onSubmitted,
        onChanged: widget.onChanged,
        textInputAction:
            widget.isFinalField! ? TextInputAction.done : TextInputAction.next,
        keyboardType:
            widget.isNumber! ? TextInputType.number : TextInputType.text,
        decoration: InputDecoration(
          hintTextDirection: TextDirection.rtl,
          errorText: widget.errorText,
          focusedErrorBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(8),
            borderSide: BorderSide(color: kActiveIconColor, width: 1.0),
          ),
          hintText: widget.hintText,
          hintStyle: TextStyle(
            color: secondColor,
            fontFamily: fontType.toString(),
          ),
          contentPadding: const EdgeInsets.all(15.0),
          border: InputBorder.none,
          counterStyle: TextStyle(
            fontFamily: fontType.toString(),
            color: kActiveIconColor.withAlpha(175),
          ),
        ),
      ),
    );
  }
}
