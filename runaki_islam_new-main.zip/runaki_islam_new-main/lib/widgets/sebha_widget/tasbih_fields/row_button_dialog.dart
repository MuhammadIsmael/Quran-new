import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:runaki_islam/providers/settings_provider.dart';
import 'package:runaki_islam/util/constans.dart';

class RowButtons extends StatefulWidget {
  final String? titleFirst, titleSecond;
  final VoidCallback? onTapFirst, onTapSecond;

  const RowButtons(
      {super.key,
      this.titleFirst,
      this.titleSecond,
      this.onTapFirst,
      this.onTapSecond});

  @override
  State<RowButtons> createState() => _RowButtonsState();
}

class _RowButtonsState extends State<RowButtons> {
  int? fontType;
  @override
  void initState() {
    fontType = Provider.of<SettingsProvider>(context, listen: false)
        .getsettingField('font_family');
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Row(
      children: <Widget>[
        Expanded(
          child: Padding(
            padding: const EdgeInsets.all(8.0),
            child: _buildButton(
              text: widget.titleFirst!,
              isClose: false,
              onTap: widget.onTapFirst!,
            ),
          ),
        ),
        Padding(
          padding: const EdgeInsets.all(8.0),
          child: _buildButton(
            text: widget.titleSecond!,
            isClose: true,
            onTap: widget.onTapSecond!,
          ),
        )
      ],
    );
  }

  Widget _buildButton({String? text, VoidCallback? onTap, bool? isClose}) {
    return Material(
      color: isClose! ? thirdColor : kActiveIconColor,
      borderRadius: BorderRadius.circular(10),
      child: InkWell(
        highlightColor: secondColor.withAlpha(400),
        splashColor:
            isClose ? thirdColor.withAlpha(400) : thirdColor.withAlpha(400),
        borderRadius: BorderRadius.circular(10),
        onTap: onTap!,
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 25.0, vertical: 10.0),
          child: Text(
            text!,
            textAlign: TextAlign.center,
            style: TextStyle(
              fontFamily: fontType.toString(),
              color: isClose ? kActiveIconColor : Colors.white,
            ),
          ),
        ),
      ),
    );
  }
}
