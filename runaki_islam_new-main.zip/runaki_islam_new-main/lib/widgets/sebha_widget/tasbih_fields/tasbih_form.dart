import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:runaki_islam/providers/settings_provider.dart';
import 'package:runaki_islam/util/constans.dart';
import 'package:runaki_islam/widgets/sebha_widget/tasbih_fields/row_button_dialog.dart';
import 'tasbih_text_field.dart';
import '../../../models/sebha_model.dart';

class TasbihForm extends StatefulWidget {
  final String? title;
  final SebhaModel? tasbih;
  final VoidCallback? onTapCancle, onTapDone;
  final ValueChanged<String>? onChangedName, onChangedCounter;

  const TasbihForm({
    super.key,
    required this.title,
    this.tasbih,
    required this.onChangedName,
    required this.onChangedCounter,
    required this.onTapCancle,
    required this.onTapDone,
  });

  @override
  State<TasbihForm> createState() => _TasbihFormState();
}

class _TasbihFormState extends State<TasbihForm> {
  bool get _isAdd => widget.tasbih!.id == -1;

  
int? fontType;
  @override
  void initState() {
    fontType = Provider.of<SettingsProvider>(context, listen: false)
        .getsettingField('font_family');
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Stack(
      clipBehavior: Clip.none,
      children: <Widget>[
        _buildForm(context),
        _buildCloseButton(context),
      ],
    );
  }

  Widget _buildCloseButton(BuildContext context) {
    return Positioned(
      right: -16.0,
      top: -16.0,
      child: InkResponse(
        onTap: () {
          Navigator.of(context).pop(false);
        },
        child: CircleAvatar(
          radius: 18,
          backgroundColor: secondColor,
          child: const Icon(
            Icons.close,
            color: Colors.white,
          ),
        ),
      ),
    );
  }

  Widget _buildForm(BuildContext context) {
    return PopScope<void>(
      canPop: false,
      child: SingleChildScrollView(
        physics: const BouncingScrollPhysics(),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: <Widget>[
            _buildTitle(),
            TasbihTextField(
              text: widget.tasbih!.name,
              hintText: 'زیکرەکە بنوسە',
              maxlength: 250,
              
              maxLines: 2,
              autoFocus: true,
              onChanged: widget.onChangedName!,
              onSubmitted: (text) => FocusScope.of(context).nextFocus(),
            ),
            TasbihTextField(
              text: widget.tasbih!.counter.toString(),
              hintText: 'جار',
              maxLines: 1,
              maxlength: 4,
              isNumber: true,
              isFinalField: true,
              onChanged: widget.onChangedCounter!,
              onSubmitted: (text) {
                FocusScope.of(context).unfocus();
              },
            ),
            RowButtons(
              titleFirst: _isAdd ? 'زیادکردن' : 'دەستکاریکرن',
              titleSecond: 'داخستن',
              onTapFirst: widget.onTapDone!,
              onTapSecond: widget.onTapCancle!,
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildTitle() {
    return Container(
      alignment: Alignment.center,
      padding: const EdgeInsets.symmetric(vertical: 15.0),
      child: Text(
        widget.title!,
        style: TextStyle(fontFamily: fontType.toString() ,
          color: kActiveIconColor,
          fontSize: 16,
        ),
      ),
    );
  }
}
