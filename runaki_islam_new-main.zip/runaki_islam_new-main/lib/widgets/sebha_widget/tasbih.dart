import 'package:provider/provider.dart';
import 'package:runaki_islam/Screens/HomeItems/Tasbeeh/pages/sebha/tasbih_page.dart';
import 'package:runaki_islam/providers/settings_provider.dart';
import 'package:runaki_islam/util/constans.dart';

import '../../models/sebha_model.dart';
import 'package:flutter/material.dart';
import 'pop_up_menu.dart';

class Tasbih extends StatefulWidget {
  final SebhaModel? tasbih;
  final int? number;

  const Tasbih({
    super.key,
    this.tasbih,
    this.number,
  });

  @override
  State<StatefulWidget> createState() => _TasbihState();
}

class _TasbihState extends State<Tasbih> {
  int? fontType;
  @override
  void initState() {
    fontType = Provider.of<SettingsProvider>(context, listen: false)
        .getsettingField('font_family');
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size;

    return Card(
      color: backgroundColor,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      child: InkWell(
        highlightColor: bgColor,
        splashColor: bgColor,
        borderRadius: BorderRadius.circular(10),
        onTap: () => Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => SebhaPage(widget.tasbih!),
            )),
        onLongPress: _showModalBottomSheet,
        onDoubleTap: () {/**copyText(context,widget.tasbih.name)*/},
        child: Column(
          children: <Widget>[
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              crossAxisAlignment: CrossAxisAlignment.start,
              textDirection: TextDirection.rtl,
              children: <Widget>[
                _buildNumberField(),
                Row(
                  children: <Widget>[
                    _buildMenuButton(),
                  ],
                ),
              ],
            ),
            _buildNameField(),
            _buildBottomWidget(size),
          ],
        ),
      ),
    );
  }

  void _showModalBottomSheet() {
    showModalBottomSheet<void>(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (BuildContext buildContext) {
        return PopUpMenuSebha(
          tasbih: widget.tasbih,
          buildContext: context,
        );
      },
    );
  }

  Widget _buildMenuButton() {
    return Material(
      color: Colors.transparent,
      borderRadius: BorderRadius.circular(10),
      child: InkWell(
        highlightColor: kTextColor.withAlpha(300),
        splashColor: kTextColor.withAlpha(100),
        borderRadius: BorderRadius.circular(10),
        onTap: _showModalBottomSheet,
        child: Padding(
          padding: const EdgeInsets.all(8.0),
          child: Icon(
            Icons.more_vert,
            size: 22,
            color: kTextColor,
          ),
        ),
      ),
    );
  }

  Widget _buildNumberField() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10.0, vertical: 5.0),
      decoration: BoxDecoration(
          color: thirdColor,
          borderRadius: const BorderRadius.only(
              topRight: Radius.circular(10), bottomLeft: Radius.circular(10))),
      child: Text(
        '${widget.number}',
        textAlign: TextAlign.center,
        style: TextStyle(
          color: kTextColor.withValues(alpha: 0.6),
          fontWeight: FontWeight.w700,
          fontSize: 12,
        ),
      ),
    );
  }

  Widget _buildNameField() {
    return Padding(
      padding: const EdgeInsets.only(left: 12, right: 12, top: 10, bottom: 10),
      child: Text(
        widget.tasbih!.name,
        textAlign: TextAlign.center,
        style: TextStyle(
          fontFamily: fontType.toString(),
          color: kTextColor.withValues(alpha: 0.8),
        ),
      ),
    );
  }

  Widget _buildBottomWidget(Size size) {
    return Container(
      width: size.width,
      padding: const EdgeInsets.symmetric(horizontal: 12.0, vertical: 5.0),
      decoration: BoxDecoration(
          color: thirdColor,
          borderRadius: const BorderRadius.only(
            bottomLeft: Radius.circular(10),
            bottomRight: Radius.circular(10),
          )),
      child: widget.tasbih!.counter == 0
          ? Text(
              ' جار :  +',
              textDirection: TextDirection.rtl,
              style: TextStyle(
                fontFamily: fontType.toString(),
                color: kActiveIconColor,
                fontWeight: FontWeight.w500,
              ),
            )
          : Text(
              ' جار : ${widget.tasbih!.counter}',
              textDirection: TextDirection.rtl,
              style: TextStyle(
                  fontFamily: fontType.toString(), color: kActiveIconColor),
            ),
    );
  }
}
