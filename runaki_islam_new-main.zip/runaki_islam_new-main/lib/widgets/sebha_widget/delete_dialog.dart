import 'package:runaki_islam/providers/settings_provider.dart';
import 'package:runaki_islam/util/constans.dart';
import 'package:top_snackbar_flutter/custom_snack_bar.dart';
import 'package:top_snackbar_flutter/top_snack_bar.dart';

import '../../providers/sebha_provider.dart';
import '../../widgets/sebha_widget/tasbih_fields/row_button_dialog.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

class DeleteDialog extends StatefulWidget {
  final int? tasbihId, tasbihFavorite;

  const DeleteDialog({
    super.key,
    this.tasbihId,
    this.tasbihFavorite,
  });

  @override
  State<DeleteDialog> createState() => _DeleteDialogState();
}

class _DeleteDialogState extends State<DeleteDialog> {
  int? fontType;
  @override
  void initState() {
    fontType = Provider.of<SettingsProvider>(context, listen: false)
        .getsettingField('font_family');
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Dialog(
      backgroundColor: bgColor,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(10),
      ),
      elevation: 0.0,
      child: Stack(
        clipBehavior: Clip.none,
        children: <Widget>[
          Column(
            mainAxisSize: MainAxisSize.min,
            children: <Widget>[
              const SizedBox(height: 20),
              _buildTitle(context),
              const SizedBox(height: 20),
              RowButtons(
                titleFirst: 'بەڵێ',
                titleSecond: 'نەخێر',
                onTapFirst: () async {
                  final navigator = Navigator.of(context);
                  final overlay = Overlay.of(context);
                  await Provider.of<SebhaProvider>(context, listen: false)
                      .deleteItemFromSebha(widget.tasbihId!);
                  if (!context.mounted) return;
                  navigator.pop(true);

                  showTopSnackBar(
                    overlay,
                    CustomSnackBar.error(
                        textStyle: TextStyle(
                          fontFamily: fontType.toString(),
                        ),
                        message: "سڕایەوە",
                        icon: Icon(
                          Icons.delete_rounded,
                          size: 80,
                          color: Colors.black.withValues(alpha: 0.1),
                        )),
                  );
                },
                onTapSecond: () => Navigator.of(context).pop(false),
              ),
            ],
          ),
          _buildCloseButton(context),
        ],
      ),
    );
  }

  Widget _buildCloseButton(BuildContext context) {
    return Positioned(
      right: -16.0,
      top: -16.0,
      child: InkResponse(
        onTap: () {
          Navigator.of(context).pop(false);
        },
        child: CircleAvatar(
          radius: 18,
          backgroundColor: secondColor,
          child: const Icon(
            Icons.close,
            color: Colors.white,
          ),
        ),
      ),
    );
  }

  Widget _buildTitle(BuildContext context) {
    return Container(
      alignment: Alignment.center,
      padding: const EdgeInsets.symmetric(vertical: 15.0, horizontal: 10),
      child: Text(
        'دڵنیای دەتەوێت ئەم زیکرە لەم لیستە بسڕیتەوە ؟',
        textAlign: TextAlign.center,
        style: TextStyle(
          fontFamily: fontType.toString(),
          color: kTextColor,
          fontSize: 18,
        ),
      ),
    );
  }
}
