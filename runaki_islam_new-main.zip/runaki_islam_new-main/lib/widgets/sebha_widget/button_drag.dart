import 'package:runaki_islam/providers/settings_provider.dart';

import '../../providers/sebha_provider.dart';
import '../../widgets/sebha_widget/tasbih_fields/row_button_dialog.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

class DeleteDialog extends StatefulWidget {
  final int? tasbihId, tasbihFavorite;

  const DeleteDialog({
    super.key,
    this.tasbihId,
    this.tasbihFavorite,
  });

  @override
  State<DeleteDialog> createState() => _DeleteDialogState();
}

class _DeleteDialogState extends State<DeleteDialog> {
  int? fontType;
  @override
  void initState() {
    fontType = Provider.of<SettingsProvider>(context, listen: false)
        .getsettingField('font_family');
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Dialog(
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(10),
      ),
      elevation: 0.0,
      child: Stack(
        children: <Widget>[
          Column(
            mainAxisSize: MainAxisSize.min,
            children: <Widget>[
              _buildTitle(context),
              _buildSubTitle(context),
              RowButtons(
                titleFirst: 'delete',
                titleSecond: 'cancle',
                onTapFirst: () async {
                  if (widget.tasbihFavorite == 1) {
                    await Provider.of<SebhaProvider>(context, listen: false)
                        .deleteItemFromSebha(widget.tasbihId!);
                  }
                  if (!context.mounted) return;
                  Navigator.of(context).pop(true);
                },
                onTapSecond: () => Navigator.of(context).pop(false),
              ),
            ],
          ),
          _buildCloseButton(context),
        ],
      ),
    );
  }

  Widget _buildCloseButton(BuildContext context) {
    return Positioned(
      right: -16.0,
      top: -16.0,
      child: InkResponse(
        onTap: () => Navigator.of(context).pop(false),
        child: CircleAvatar(
          radius: 18,
          backgroundColor: Colors.red[600],
          child: const Icon(
            Icons.close,
          ),
        ),
      ),
    );
  }

  Widget _buildTitle(BuildContext context) {
    return Container(
      alignment: Alignment.center,
      padding: const EdgeInsets.symmetric(vertical: 15.0),
      child: Text(
        'sebha_delete_dialog_title',
        style: TextStyle(
          fontFamily: fontType.toString(),
          color: Colors.red[700],
          fontSize: 18,
        ),
      ),
    );
  }

  Widget _buildSubTitle(BuildContext context) {
    return Container(
      alignment: Alignment.center,
      padding: const EdgeInsets.symmetric(vertical: 15.0, horizontal: 10.0),
      child: Text(
        'sebha_delete_dialog_subtitle',
        style: TextStyle(
          fontFamily: fontType.toString(),
          color: Colors.red[500],
          fontSize: 16,
        ),
      ),
    );
  }
}
