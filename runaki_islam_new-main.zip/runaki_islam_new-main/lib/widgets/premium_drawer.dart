import 'dart:ui';

import 'package:flutter/material.dart';
import 'package:runaki_islam/util/animation_helper.dart';
import 'package:runaki_islam/util/constans.dart';

class DrawerActionItem {
  const DrawerActionItem({
    required this.title,
    required this.icon,
    required this.onTap,
  });

  final String title;
  final IconData icon;
  final VoidCallback onTap;
}

class PremiumIslamicDrawer extends StatelessWidget {
  const PremiumIslamicDrawer({
    super.key,
    required this.name,
    required this.subtitle,
    required this.avatar,
    required this.items,
    this.footer,
  });

  final String name;
  final String subtitle;
  final ImageProvider avatar;
  final List<DrawerActionItem> items;
  final Widget? footer;

  @override
  Widget build(BuildContext context) {
    final ThemeData theme = Theme.of(context);
    final ColorScheme scheme = theme.colorScheme;
    final bool isDark = theme.brightness == Brightness.dark;
    final double drawerWidth = MediaQuery.sizeOf(context).width.clamp(
      290.0,
      360.0,
    );

    return Directionality(
      textDirection: TextDirection.rtl,
      child: Drawer(
        width: drawerWidth,
        backgroundColor: Colors.transparent,
        surfaceTintColor: Colors.transparent,
        elevation: 0,
        child: TweenAnimationBuilder<double>(
          duration: AppMotion.page,
          curve: AppMotion.curve,
          tween: Tween<double>(begin: 0, end: 1),
          builder: (context, value, child) {
            return Opacity(
              opacity: value,
              child: Transform.translate(
                offset: Offset((1 - value) * 16, 0),
                child: child,
              ),
            );
          },
          child: SafeArea(
            child: Padding(
              padding: const EdgeInsets.fromLTRB(8, 10, 10, 10),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(30),
                child: BackdropFilter(
                  filter: ImageFilter.blur(sigmaX: 24, sigmaY: 24),
                  child: Container(
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        begin: Alignment.topCenter,
                        end: Alignment.bottomCenter,
                        colors: <Color>[
                          theme.colorScheme.surface.withValues(
                            alpha: isDark ? 0.97 : 0.985,
                          ),
                          thirdColor.withValues(alpha: isDark ? 0.92 : 0.96),
                          backgroundColor.withValues(alpha: 0.98),
                        ],
                      ),
                      borderRadius: BorderRadius.circular(30),
                      border: Border.all(
                        color: scheme.outline.withValues(
                          alpha: isDark ? 0.22 : 0.12,
                        ),
                      ),
                      boxShadow: <BoxShadow>[
                        BoxShadow(
                          color: kShadowColor.withValues(alpha: 0.18),
                          blurRadius: 28,
                          offset: const Offset(0, 14),
                        ),
                      ],
                    ),
                    child: Stack(
                      children: <Widget>[
                        Positioned(
                          top: -34,
                          right: -16,
                          child: _glowCircle(
                            size: 132,
                            color: kActiveIconColor.withValues(alpha: 0.18),
                          ),
                        ),
                        Positioned(
                          bottom: 88,
                          left: -34,
                          child: _glowCircle(
                            size: 148,
                            color: secondColor.withValues(alpha: 0.16),
                          ),
                        ),
                        Column(
                          children: <Widget>[
                            const SizedBox(height: 12),
                            Container(
                              width: 42,
                              height: 4,
                              decoration: BoxDecoration(
                                color: scheme.outline.withValues(
                                  alpha: isDark ? 0.34 : 0.18,
                                ),
                                borderRadius: BorderRadius.circular(99),
                              ),
                            ),
                            _DrawerHeader(
                              name: name,
                              subtitle: subtitle,
                              avatar: avatar,
                              itemCount: items.length,
                            ),
                            Expanded(
                              child: Container(
                                margin: const EdgeInsets.fromLTRB(12, 0, 12, 12),
                                padding: const EdgeInsets.all(8),
                                decoration: BoxDecoration(
                                  color: theme.colorScheme.surface.withValues(
                                    alpha: isDark ? 0.34 : 0.52,
                                  ),
                                  borderRadius: BorderRadius.circular(24),
                                  border: Border.all(
                                    color: scheme.outline.withValues(
                                      alpha: isDark ? 0.18 : 0.10,
                                    ),
                                  ),
                                ),
                                child: ListView.separated(
                                  padding: EdgeInsets.zero,
                                  physics: const BouncingScrollPhysics(),
                                  itemCount: items.length,
                                  separatorBuilder: (context, index) =>
                                      const SizedBox(height: 8),
                                  itemBuilder: (context, index) {
                                    final DrawerActionItem item = items[index];
                                    return FadeSlideIn(
                                      delay: Duration(
                                        milliseconds: 40 + (index * 35),
                                      ),
                                      offsetY: 10,
                                      child: _DrawerTile(item: item),
                                    );
                                  },
                                ),
                              ),
                            ),
                            if (footer != null)
                              Container(
                                margin: const EdgeInsets.fromLTRB(
                                  12,
                                  0,
                                  12,
                                  12,
                                ),
                                padding: const EdgeInsets.all(8),
                                decoration: BoxDecoration(
                                  color: theme.colorScheme.surface.withValues(
                                    alpha: isDark ? 0.42 : 0.64,
                                  ),
                                  borderRadius: BorderRadius.circular(22),
                                  border: Border.all(
                                    color: scheme.outline.withValues(
                                      alpha: isDark ? 0.18 : 0.10,
                                    ),
                                  ),
                                ),
                                child: footer!,
                              ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _glowCircle({required double size, required Color color}) {
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        gradient: RadialGradient(
          colors: <Color>[color, color.withValues(alpha: 0)],
        ),
      ),
    );
  }
}

class _DrawerHeader extends StatelessWidget {
  const _DrawerHeader({
    required this.name,
    required this.subtitle,
    required this.avatar,
    required this.itemCount,
  });

  final String name;
  final String subtitle;
  final ImageProvider avatar;
  final int itemCount;

  @override
  Widget build(BuildContext context) {
    final ThemeData theme = Theme.of(context);
    final bool isDark = theme.brightness == Brightness.dark;
    final Color headerStart =
        Color.lerp(kActiveIconColor, secondColor, isDark ? 0.24 : 0.34) ??
            kActiveIconColor;
    final Color headerEnd =
        Color.lerp(kActiveIconColor, const Color(0xFF0B3D32), 0.28) ??
            kActiveIconColor;

    return Container(
      margin: const EdgeInsets.fromLTRB(14, 10, 14, 12),
      padding: const EdgeInsets.fromLTRB(18, 18, 18, 18),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(28),
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: <Color>[headerStart, headerEnd],
        ),
        border: Border.all(color: Colors.white.withValues(alpha: 0.10)),
        boxShadow: <BoxShadow>[
          BoxShadow(
            color: kActiveIconColor.withValues(alpha: 0.22),
            blurRadius: 24,
            offset: const Offset(0, 12),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.end,
        children: <Widget>[
       
          Row(
            children: <Widget>[
              Container(
                width: 72,
                height: 72,
                padding: const EdgeInsets.all(4),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(24),
                  color: Colors.white.withValues(alpha: 0.14),
                  border: Border.all(
                    color: Colors.white.withValues(alpha: 0.24),
                  ),
                ),
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(20),
                  child: Image(image: avatar, fit: BoxFit.cover),
                ),
              ),
              const SizedBox(width: 14),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  Text(
                    name,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: theme.textTheme.titleLarge?.copyWith(
                      fontWeight: FontWeight.w800,
                      color: Colors.white,
                      letterSpacing: 0.1,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    subtitle,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: theme.textTheme.bodyMedium?.copyWith(
                      color: Colors.white.withValues(alpha: 0.84),
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ],
              ),
            ],
          ),
        SizedBox(height: 18),
          Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 12,
                        vertical: 8,
                      ),
                      decoration: BoxDecoration(
                        color: Colors.white.withValues(alpha: 0.10),
                        borderRadius: BorderRadius.circular(16),
                        border: Border.all(
                          color: Colors.white.withValues(alpha: 0.14),
                        ),
                      ),
                      child: Row(
                        children: <Widget>[
                          Icon(
                            Icons.circle,
                            size: 8,
                            color: secondColor.withValues(alpha: 0.95),
                          ),
                          const SizedBox(width: 8),
                          Expanded(
                            child: Text(
                              'باشترین بەرنامە، زیاتر له‌ ده‌یان به‌شی جیاواز ',
                              textAlign: TextAlign.right,
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: theme.textTheme.bodySmall?.copyWith(
                                color: Colors.white.withValues(alpha: 0.82),
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
     
        ],
      ),
    );
  }




}


class _DrawerTile extends StatefulWidget {
  const _DrawerTile({required this.item});

  final DrawerActionItem item;

  @override
  State<_DrawerTile> createState() => _DrawerTileState();
}

class _DrawerTileState extends State<_DrawerTile> {
  bool _pressed = false;

  @override
  Widget build(BuildContext context) {
    final ThemeData theme = Theme.of(context);
    final ColorScheme scheme = theme.colorScheme;
    final bool isDark = theme.brightness == Brightness.dark;

    return AnimatedScale(
      duration: AppMotion.fast,
      curve: AppMotion.curve,
      scale: _pressed ? 0.982 : 1.0,
      child: AnimatedContainer(
        duration: AppMotion.fast,
        curve: AppMotion.curve,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(20),
          gradient: _pressed
              ? LinearGradient(
                  begin: Alignment.topRight,
                  end: Alignment.bottomLeft,
                  colors: <Color>[
                    kActiveIconColor.withValues(alpha: isDark ? 0.28 : 0.16),
                    secondColor.withValues(alpha: isDark ? 0.20 : 0.12),
                  ],
                )
              : null,
          color: _pressed
              ? null
              : scheme.surface.withValues(alpha: isDark ? 0.38 : 0.76),
          border: Border.all(
            color: _pressed
                ? kActiveIconColor.withValues(alpha: 0.28)
                : scheme.outline.withValues(alpha: isDark ? 0.16 : 0.10),
          ),
          boxShadow: _pressed
              ? <BoxShadow>[
                  BoxShadow(
                    color: kActiveIconColor.withValues(alpha: 0.12),
                    blurRadius: 18,
                    offset: const Offset(0, 8),
                  ),
                ]
              : const <BoxShadow>[],
        ),
        child: Material(
          color: Colors.transparent,
          child: InkWell(
            borderRadius: BorderRadius.circular(20),
            onTapDown: (_) => setState(() => _pressed = true),
            onTapCancel: () => setState(() => _pressed = false),
            onTap: () {
              setState(() => _pressed = false);
              widget.item.onTap();
            },
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 10),
              child: Row(
                children: <Widget>[
                  Container(
                    width: 40,
                    height: 40,
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        begin: Alignment.topCenter,
                        end: Alignment.bottomCenter,
                        colors: <Color>[
                          kActiveIconColor.withValues(alpha: 0.96),
                          (Color.lerp(kActiveIconColor, secondColor, 0.34) ??
                                  kActiveIconColor)
                              .withValues(alpha: 0.96),
                        ],
                      ),
                      borderRadius: BorderRadius.circular(16),
                      boxShadow: <BoxShadow>[
                        BoxShadow(
                          color: kActiveIconColor.withValues(alpha: 0.18),
                          blurRadius: 12,
                          offset: const Offset(0, 6),
                        ),
                      ],
                    ),
                    child: Icon(widget.item.icon, size: 20, color: Colors.white),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Text(
                      widget.item.title,
                      textAlign: TextAlign.right,
                      style: theme.textTheme.titleSmall?.copyWith(
                        color: kTextColor,
                        fontWeight: FontWeight.w700,
                        height: 1.2,
                      ),
                    ),
                  ),
                  const SizedBox(width: 10),
                  AnimatedContainer(
                    duration: AppMotion.fast,
                    curve: AppMotion.curve,
                    width: 32,
                    height: 32,
                    decoration: BoxDecoration(
                      color: _pressed
                          ? Colors.white.withValues(alpha: 0.28)
                          : scheme.surfaceContainerHighest.withValues(
                              alpha: isDark ? 0.22 : 0.48,
                            ),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Icon(
                      Icons.chevron_right_rounded,
                      size: 18,
                      color: _pressed ? kActiveIconColor : iconColor,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
