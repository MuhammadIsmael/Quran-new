import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter_staggered_animations/flutter_staggered_animations.dart';

import 'package:runaki_islam/models/global_search_item.dart';
import 'package:runaki_islam/services/global_search_service.dart';
import 'package:runaki_islam/util/animation_helper.dart';
import 'package:runaki_islam/util/constans.dart';

Future<void> showGeneralSearchPage({
  required BuildContext context,
  required int? fontFamily,
}) {
  return Navigator.of(context).push<void>(
    AppMotion.fadeSlidePage(
      page: GeneralSearchPage(rootContext: context, fontFamily: fontFamily),
    ),
  );
}

class GeneralSearchPage extends StatefulWidget {
  const GeneralSearchPage({
    super.key,
    required this.rootContext,
    required this.fontFamily,
  });

  final BuildContext rootContext;
  final int? fontFamily;

  @override
  State<GeneralSearchPage> createState() => _GeneralSearchPageState();
}

class _GeneralSearchPageState extends State<GeneralSearchPage> {
  final GlobalSearchService _service = GlobalSearchService.instance;
  late final TextEditingController _controller;
  late final FocusNode _focusNode;

  bool _loading = true;
  String? _errorText;
  List<GlobalSearchItem> _items = const <GlobalSearchItem>[];
  List<String> _recentSearches = const <String>[];

  String get _fontFamily => widget.fontFamily?.toString() ?? '0';
  String get _query => _controller.text.trim();

  @override
  void initState() {
    super.initState();
    _controller = TextEditingController()..addListener(_refresh);
    _focusNode = FocusNode();
    _bootstrap();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted) {
        _focusNode.requestFocus();
      }
    });
  }

  @override
  void dispose() {
    _controller
      ..removeListener(_refresh)
      ..dispose();
    _focusNode.dispose();
    super.dispose();
  }

  Future<void> _bootstrap() async {
    setState(() {
      _loading = true;
      _errorText = null;
    });

    try {
      final results = await Future.wait<dynamic>(<Future<dynamic>>[
        _service.ensureIndex(),
        _service.loadRecentSearches(),
      ]);

      if (!mounted) {
        return;
      }

      setState(() {
        _items = List<GlobalSearchItem>.from(
          results[0] as List<GlobalSearchItem>,
        );
        _recentSearches = List<String>.from(results[1] as List<String>);
        _loading = false;
      });
    } catch (error) {
      if (!mounted) {
        return;
      }

      setState(() {
        _errorText = '$error';
        _loading = false;
      });
    }
  }

  void _refresh() {
    if (mounted) {
      setState(() {});
    }
  }

  void _openItem(GlobalSearchItem item) {
    final savedQuery = _query.isEmpty ? item.title : _query;
    final navigator = Navigator.of(context);
    navigator.pop();
    unawaited(_service.saveRecentSearch(savedQuery));
    WidgetsBinding.instance.addPostFrameCallback((_) {
      item.onOpen(widget.rootContext);
    });
  }

  Future<void> _clearRecentSearches() async {
    await _service.clearRecentSearches();
    if (mounted) {
      setState(() {
        _recentSearches = const <String>[];
      });
    }
  }

  void _reuseSearch(String query) {
    _controller.value = TextEditingValue(
      text: query,
      selection: TextSelection.collapsed(offset: query.length),
    );
    _focusNode.requestFocus();
  }

  @override
  Widget build(BuildContext context) {
    final results = _service.search(_query, _items);
    final sectionResults = results
        .where((item) => item.kind == GlobalSearchKind.section)
        .take(8)
        .toList(growable: false);
    final contentResults = results
        .where((item) => item.kind == GlobalSearchKind.content)
        .take(28)
        .toList(growable: false);

    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        backgroundColor: bgColor,
        body: Stack(
          children: [
            const _Backdrop(),
            SafeArea(
              child: Column(
                children: [
                  Padding(
                    padding: const EdgeInsets.fromLTRB(16, 12, 16, 0),
                    child: Row(
                      textDirection: TextDirection.rtl,
                      children: [
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                'گەڕانی گشتی',
                                textAlign: TextAlign.right,
                                style: TextStyle(
                                  fontFamily: _fontFamily,
                                  color: kTextColor,
                                  fontSize: 24,
                                  fontWeight: FontWeight.w900,
                                ),
                              ),
                              const SizedBox(height: 4),
                              Text(
                                'ناوی بەشەکان، ناونیشان، مانا و ناوەڕۆک بگەڕێ.',
                                textAlign: TextAlign.right,
                                style: TextStyle(
                                  fontFamily: _fontFamily,
                                  color: titleTextColor,
                                  fontSize: 13,
                                  fontWeight: FontWeight.w600,
                                ),
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(width: 10),
                        _CircleButton(
                          icon: Icons.close_rounded,
                          onTap: () => Navigator.of(context).pop(),
                        ),
                      ],
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.fromLTRB(16, 16, 16, 0),
                    child: _SearchField(
                      controller: _controller,
                      focusNode: _focusNode,
                      fontFamily: _fontFamily,
                      onSubmitted: (_) {
                        if (results.isNotEmpty) {
                          _openItem(results.first);
                        }
                      },
                    ),
                  ),
                  const SizedBox(height: 14),
                  Expanded(
                    child: AnimatedSwitcher(
                      duration: const Duration(milliseconds: 220),
                      child: _buildBody(
                        sectionResults: sectionResults,
                        contentResults: contentResults,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildBody({
    required List<GlobalSearchItem> sectionResults,
    required List<GlobalSearchItem> contentResults,
  }) {
    if (_loading) {
      return _StateCard(
        key: const ValueKey<String>('loading'),
        title: 'ئامادەکردنی گەڕان...',
        subtitle: 'هەموو بەش و ناوەڕۆکەکان کۆدەکرێنەوە.',
        fontFamily: _fontFamily,
        loading: true,
      );
    }

    if (_errorText != null) {
      return _StateCard(
        key: const ValueKey<String>('error'),
        title: 'هەڵەیەک ڕوویدا',
        subtitle: _errorText!,
        fontFamily: _fontFamily,
        actionLabel: 'دووبارە هەوڵبدە',
        onAction: _bootstrap,
      );
    }

    if (_query.isEmpty) {
      return _buildDiscoverView();
    }

    if (sectionResults.isEmpty && contentResults.isEmpty) {
      return _StateCard(
        key: const ValueKey<String>('empty'),
        title: 'هیچ ئەنجامێک نەدۆزرایەوە',
        subtitle: 'هەوڵبدە بە وشەیەکی تر بگەڕێیت یان ناوی بەشەکە بنووسیت.',
        fontFamily: _fontFamily,
        actionLabel: 'پاککردنەوە',
        onAction: _controller.clear,
      );
    }

    return ListView(
      key: ValueKey<String>('results:${_query.toLowerCase()}'),
      padding: const EdgeInsets.fromLTRB(16, 0, 16, 20),
      physics: const BouncingScrollPhysics(),
      children: [
        Row(
          textDirection: TextDirection.rtl,
          children: [
            _TinyPill(
              label: 'بەشەکان ${sectionResults.length}',
              fontFamily: _fontFamily,
            ),
            const SizedBox(width: 8),
            _TinyPill(
              label: 'ناوەڕۆک ${contentResults.length}',
              fontFamily: _fontFamily,
            ),
          ],
        ),
        if (sectionResults.isNotEmpty) ...[
          const SizedBox(height: 16),
          _HeaderText(
            title: 'بەشەکان',
            subtitle: 'بەشە نزیکەکان بۆ ئەم گەڕانە',
            fontFamily: _fontFamily,
          ),
          const SizedBox(height: 10),
          SizedBox(
            height: 158,
            child: ListView.separated(
              scrollDirection: Axis.horizontal,
              reverse: true,
              physics: const BouncingScrollPhysics(),
              itemCount: sectionResults.length,
              separatorBuilder: (_, index) => const SizedBox(width: 10),
              itemBuilder: (context, index) => _SectionCard(
                item: sectionResults[index],
                fontFamily: _fontFamily,
                onTap: () => _openItem(sectionResults[index]),
              ),
            ),
          ),
        ],
        if (contentResults.isNotEmpty) ...[
          const SizedBox(height: 18),
          _HeaderText(
            title: 'ناوەڕۆک',
            subtitle: 'ئەنجامەکانی ناونیشان و ناوەڕۆک',
            fontFamily: _fontFamily,
          ),
          const SizedBox(height: 10),
          AnimationLimiter(
            child: ListView.builder(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              itemCount: contentResults.length,
              itemBuilder: (context, index) =>
                  AnimationConfiguration.staggeredList(
                    position: index,
                    duration: const Duration(milliseconds: 320),
                    child: SlideAnimation(
                      verticalOffset: 16,
                      child: FadeInAnimation(
                        child: _ContentTile(
                          item: contentResults[index],
                          fontFamily: _fontFamily,
                          onTap: () => _openItem(contentResults[index]),
                        ),
                      ),
                    ),
                  ),
            ),
          ),
        ],
      ],
    );
  }

  Widget _buildDiscoverView() {
    final featured = _service.featuredSections(_items);
    return ListView(
      key: const ValueKey<String>('discover'),
      padding: const EdgeInsets.fromLTRB(16, 0, 16, 20),
      physics: const BouncingScrollPhysics(),
      children: [
        if (_recentSearches.isNotEmpty) ...[
          Row(
            textDirection: TextDirection.rtl,
            children: [
              Text(
                'دوایین گەڕانەکان',
                textAlign: TextAlign.right,
                style: TextStyle(
                  fontFamily: _fontFamily,
                  color: kTextColor,
                  fontSize: 18,
                  fontWeight: FontWeight.w800,
                ),
              ),
              const Spacer(),
              TextButton(
                onPressed: _clearRecentSearches,
                child: Text(
                  'پاککردنەوە',
                  style: TextStyle(
                    fontFamily: _fontFamily,
                    color: kActiveIconColor,
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),
          Wrap(
            alignment: WrapAlignment.start,
            spacing: 8,
            runSpacing: 8,
            textDirection: TextDirection.rtl,
            children: _recentSearches
                .map(
                  (query) => _RecentChip(
                    label: query,
                    fontFamily: _fontFamily,
                    onTap: () => _reuseSearch(query),
                  ),
                )
                .toList(growable: false),
          ),
          const SizedBox(height: 20),
        ],
        _HeaderText(
          title: 'بەشە پێشنیارکراوەکان',
          subtitle: 'خێراتر بگەیە بەشە پرکاربردەکان',
          fontFamily: _fontFamily,
        ),
        const SizedBox(height: 10),
        GridView.builder(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          itemCount: featured.length,
          gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 2,
            crossAxisSpacing: 10,
            mainAxisSpacing: 10,
            childAspectRatio: 1.05,
          ),
          itemBuilder: (context, index) => _FeatureCard(
            item: featured[index],
            fontFamily: _fontFamily,
            onTap: () => _openItem(featured[index]),
          ),
        ),
      ],
    );
  }
}

class _Backdrop extends StatelessWidget {
  const _Backdrop();

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [Color(0xFFF6F4EC), Color(0xFFF8F1E3), Color(0xFFF4F8F3)],
        ),
      ),
      child: Stack(
        children: [
          Positioned(
            top: -80,
            right: -30,
            child: _Glow(size: 220, color: const Color(0x4014A06F)),
          ),
          Positioned(
            top: 180,
            left: -50,
            child: _Glow(size: 180, color: const Color(0x33D3B56C)),
          ),
          Positioned(
            bottom: -30,
            right: 40,
            child: _Glow(size: 160, color: const Color(0x262F8FCC)),
          ),
        ],
      ),
    );
  }
}

class _Glow extends StatelessWidget {
  const _Glow({required this.size, required this.color});

  final double size;
  final Color color;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(shape: BoxShape.circle, color: color),
    );
  }
}

class _CircleButton extends StatelessWidget {
  const _CircleButton({required this.icon, required this.onTap});

  final IconData icon;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(18),
        child: Ink(
          width: 46,
          height: 46,
          decoration: BoxDecoration(
            color: Colors.white.withValues(alpha: 0.88),
            borderRadius: BorderRadius.circular(18),
            border: Border.all(color: const Color(0x1A000000)),
          ),
          child: Icon(icon, color: kActiveIconColor),
        ),
      ),
    );
  }
}

class _SearchField extends StatelessWidget {
  const _SearchField({
    required this.controller,
    required this.focusNode,
    required this.fontFamily,
    required this.onSubmitted,
  });

  final TextEditingController controller;
  final FocusNode focusNode;
  final String fontFamily;
  final ValueChanged<String> onSubmitted;

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white.withValues(alpha: 0.92),
        borderRadius: BorderRadius.circular(24),
        border: Border.all(color: const Color(0x190E7A5B)),
        boxShadow: const [
          BoxShadow(
            color: Color(0x14000000),
            blurRadius: 20,
            offset: Offset(0, 10),
          ),
        ],
      ),
      child: TextField(
        controller: controller,
        focusNode: focusNode,
        textAlign: TextAlign.right,
        textDirection: TextDirection.rtl,
        textInputAction: TextInputAction.search,
        onSubmitted: onSubmitted,
        style: TextStyle(
          fontFamily: fontFamily,
          color: kTextColor,
          fontSize: 15.6,
          fontWeight: FontWeight.w700,
        ),
        decoration: InputDecoration(
          border: InputBorder.none,
          contentPadding: const EdgeInsets.symmetric(
            horizontal: 16,
            vertical: 16,
          ),
          hintText: 'گەڕان لە ناوی بەش و ناوەڕۆک...',
          hintStyle: TextStyle(
            fontFamily: fontFamily,
            color: titleTextColor,
            fontSize: 14.5,
          ),
          prefixIcon: Icon(Icons.search_rounded, color: kActiveIconColor),
          suffixIcon: controller.text.isEmpty
              ? null
              : IconButton(
                  onPressed: controller.clear,
                  icon: Icon(Icons.close_rounded, color: iconColor),
                ),
        ),
      ),
    );
  }
}

class _HeaderText extends StatelessWidget {
  const _HeaderText({
    required this.title,
    required this.subtitle,
    required this.fontFamily,
  });

  final String title;
  final String subtitle;
  final String fontFamily;

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          title,
          textAlign: TextAlign.right,
          style: TextStyle(
            fontFamily: fontFamily,
            color: kTextColor,
            fontSize: 18,
            fontWeight: FontWeight.w800,
          ),
        ),
        const SizedBox(height: 4),
        Text(
          subtitle,
          textAlign: TextAlign.right,
          style: TextStyle(
            fontFamily: fontFamily,
            color: titleTextColor,
            fontSize: 12.8,
            fontWeight: FontWeight.w600,
          ),
        ),
      ],
    );
  }
}

class _TinyPill extends StatelessWidget {
  const _TinyPill({required this.label, required this.fontFamily});

  final String label;
  final String fontFamily;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
      decoration: BoxDecoration(
        color: const Color(0x140E7A5B),
        borderRadius: BorderRadius.circular(99),
      ),
      child: Text(
        label,
        textAlign: TextAlign.right,
        style: TextStyle(
          fontFamily: fontFamily,
          color: kActiveIconColor,
          fontWeight: FontWeight.w800,
          fontSize: 12.2,
        ),
      ),
    );
  }
}

class _RecentChip extends StatelessWidget {
  const _RecentChip({
    required this.label,
    required this.fontFamily,
    required this.onTap,
  });

  final String label;
  final String fontFamily;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(99),
        child: Ink(
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
          decoration: BoxDecoration(
            color: Colors.white.withValues(alpha: 0.9),
            borderRadius: BorderRadius.circular(99),
            border: Border.all(color: const Color(0x1A0E7A5B)),
          ),
          child: Row(
            textDirection: TextDirection.rtl,
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                label,
                textAlign: TextAlign.right,
                style: TextStyle(
                  fontFamily: fontFamily,
                  color: kTextColor,
                  fontWeight: FontWeight.w700,
                ),
              ),
              const SizedBox(width: 8),
              const Icon(
                Icons.history_rounded,
                size: 18,
                color: Color(0xFF0F6B53),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _FeatureCard extends StatelessWidget {
  const _FeatureCard({
    required this.item,
    required this.fontFamily,
    required this.onTap,
  });

  final GlobalSearchItem item;
  final String fontFamily;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(22),
        child: Ink(
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            gradient: const LinearGradient(
              begin: Alignment.topRight,
              end: Alignment.bottomLeft,
              colors: [Color(0xFFFDFBF6), Color(0xFFF0F7F3)],
            ),
            borderRadius: BorderRadius.circular(22),
            border: Border.all(color: const Color(0x180E7A5B)),
            boxShadow: const [
              BoxShadow(
                color: Color(0x12000000),
                blurRadius: 18,
                offset: Offset(0, 10),
              ),
            ],
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                width: 48,
                height: 48,
                decoration: BoxDecoration(
                  color: kActiveIconColor.withValues(alpha: 0.12),
                  borderRadius: BorderRadius.circular(16),
                ),
                child: Icon(item.icon, color: kActiveIconColor),
              ),
              const Spacer(),
              Text(
                item.title,
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
                textAlign: TextAlign.right,
                style: TextStyle(
                  fontFamily: fontFamily,
                  color: kTextColor,
                  fontSize: 15.6,
                  fontWeight: FontWeight.w800,
                ),
              ),
              const SizedBox(height: 6),
              Text(
                item.subtitle,
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
                textAlign: TextAlign.right,
                style: TextStyle(
                  fontFamily: fontFamily,
                  color: titleTextColor,
                  fontSize: 12.6,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _SectionCard extends StatelessWidget {
  const _SectionCard({
    required this.item,
    required this.fontFamily,
    required this.onTap,
  });

  final GlobalSearchItem item;
  final String fontFamily;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(22),
        child: Ink(
          width: 220,
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            gradient: const LinearGradient(
              begin: Alignment.topRight,
              end: Alignment.bottomLeft,
              colors: [Color(0xFF0E7A5B), Color(0xFF1B9E74), Color(0xFFDFC37D)],
            ),
            borderRadius: BorderRadius.circular(22),
            boxShadow: const [
              BoxShadow(
                color: Color(0x220E7A5B),
                blurRadius: 22,
                offset: Offset(0, 14),
              ),
            ],
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                width: 44,
                height: 44,
                decoration: BoxDecoration(
                  color: Colors.white.withValues(alpha: 0.16),
                  borderRadius: BorderRadius.circular(14),
                ),
                child: Icon(item.icon, color: Colors.white),
              ),
              const Spacer(),
              Text(
                item.title,
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
                textAlign: TextAlign.right,
                style: TextStyle(
                  fontFamily: fontFamily,
                  color: Colors.white,
                  fontSize: 16.4,
                  fontWeight: FontWeight.w900,
                ),
              ),
              const SizedBox(height: 6),
              Text(
                item.subtitle,
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
                textAlign: TextAlign.right,
                style: TextStyle(
                  fontFamily: fontFamily,
                  color: Colors.white.withValues(alpha: 0.88),
                  fontSize: 12.8,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _ContentTile extends StatelessWidget {
  const _ContentTile({
    required this.item,
    required this.fontFamily,
    required this.onTap,
  });

  final GlobalSearchItem item;
  final String fontFamily;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: onTap,
          borderRadius: BorderRadius.circular(20),
          child: Ink(
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              color: Colors.white.withValues(alpha: 0.92),
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: const Color(0x160E7A5B)),
              boxShadow: const [
                BoxShadow(
                  color: Color(0x11000000),
                  blurRadius: 16,
                  offset: Offset(0, 8),
                ),
              ],
            ),
            child: Row(
              textDirection: TextDirection.rtl,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Container(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 10,
                          vertical: 5,
                        ),
                        decoration: BoxDecoration(
                          color: const Color(0x140E7A5B),
                          borderRadius: BorderRadius.circular(99),
                        ),
                        child: Text(
                          item.sectionTitle,
                          textAlign: TextAlign.right,
                          style: TextStyle(
                            fontFamily: fontFamily,
                            color: kActiveIconColor,
                            fontSize: 11.8,
                            fontWeight: FontWeight.w800,
                          ),
                        ),
                      ),
                      const SizedBox(height: 10),
                      Text(
                        item.title,
                        textAlign: TextAlign.right,
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(
                          fontFamily: fontFamily,
                          color: kTextColor,
                          fontSize: 15.6,
                          fontWeight: FontWeight.w800,
                        ),
                      ),
                      if (item.subtitle.trim().isNotEmpty) ...[
                        const SizedBox(height: 4),
                        Text(
                          item.subtitle,
                          textAlign: TextAlign.right,
                          maxLines: 2,
                          overflow: TextOverflow.ellipsis,
                          style: TextStyle(
                            fontFamily: fontFamily,
                            color: titleTextColor,
                            fontSize: 12.8,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ],
                      if (item.preview.trim().isNotEmpty) ...[
                        const SizedBox(height: 6),
                        Text(
                          item.preview.replaceAll(RegExp(r'\s+'), ' '),
                          textAlign: TextAlign.right,
                          maxLines: 3,
                          overflow: TextOverflow.ellipsis,
                          style: TextStyle(
                            fontFamily: fontFamily,
                            color: titleTextColor.withValues(alpha: 0.9),
                            fontSize: 12.6,
                            height: 1.45,
                          ),
                        ),
                      ],
                    ],
                  ),
                ),
                const SizedBox(width: 12),
                Container(
                  width: 46,
                  height: 46,
                  decoration: BoxDecoration(
                    color: kActiveIconColor.withValues(alpha: 0.10),
                    borderRadius: BorderRadius.circular(14),
                  ),
                  child: Icon(item.icon, color: kActiveIconColor, size: 22),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _StateCard extends StatelessWidget {
  const _StateCard({
    super.key,
    required this.title,
    required this.subtitle,
    required this.fontFamily,
    this.actionLabel,
    this.onAction,
    this.loading = false,
  });

  final String title;
  final String subtitle;
  final String fontFamily;
  final String? actionLabel;
  final VoidCallback? onAction;
  final bool loading;

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 28),
        child: Container(
          padding: const EdgeInsets.all(24),
          decoration: BoxDecoration(
            color: Colors.white.withValues(alpha: 0.9),
            borderRadius: BorderRadius.circular(24),
            border: Border.all(color: const Color(0x160E7A5B)),
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              if (loading)
                const SizedBox(
                  width: 26,
                  height: 26,
                  child: CircularProgressIndicator(strokeWidth: 2.6),
                )
              else
                Icon(
                  Icons.search_off_rounded,
                  color: kActiveIconColor,
                  size: 34,
                ),
              const SizedBox(height: 14),
              Text(
                title,
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontFamily: fontFamily,
                  color: kTextColor,
                  fontSize: 17.2,
                  fontWeight: FontWeight.w900,
                ),
              ),
              const SizedBox(height: 8),
              Text(
                subtitle,
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontFamily: fontFamily,
                  color: titleTextColor,
                  fontSize: 13,
                  height: 1.5,
                  fontWeight: FontWeight.w600,
                ),
              ),
              if (actionLabel != null && onAction != null) ...[
                const SizedBox(height: 16),
                ElevatedButton(
                  onPressed: onAction,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: kActiveIconColor,
                    foregroundColor: Colors.white,
                    padding: const EdgeInsets.symmetric(
                      horizontal: 18,
                      vertical: 12,
                    ),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(14),
                    ),
                  ),
                  child: Text(
                    actionLabel!,
                    style: TextStyle(
                      fontFamily: fontFamily,
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }
}
