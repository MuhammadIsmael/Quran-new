import 'package:flutter/material.dart';
import 'package:flutter_staggered_animations/flutter_staggered_animations.dart';
import 'package:provider/provider.dart';
import 'package:runaki_islam/providers/settings_provider.dart';
import 'package:runaki_islam/util/constans.dart';

class CardList extends StatefulWidget {
  final String? arabic;
  final int? ayahCount;
  final int? count;
  final VoidCallback? onTap;

  const CardList(
      {super.key, this.arabic, this.ayahCount, this.count, this.onTap});

  @override
  State<CardList> createState() => _CardListState();
}

class _CardListState extends State<CardList> {
  int? fontType;
  @override
  void initState() {
    fontType = Provider.of<SettingsProvider>(context, listen: false)
        .getsettingField('font_family');
    super.initState();
  }

  Color myColor = const Color(0xffeffcf5);

  Color iColor = const Color(0xff6a7885);

  Color tColor = const Color(0xff4d5351);

  @override
  Widget build(BuildContext context) {
    return AnimationConfiguration.synchronized(
        duration: const Duration(milliseconds: 2000),
        child: SlideAnimation(
            duration: const Duration(milliseconds: 2500),
            curve: Curves.fastLinearToSlowEaseIn,
            horizontalOffset: 30,
            verticalOffset: 300.0,
            child: FlipAnimation(
              duration: const Duration(milliseconds: 3000),
              curve: Curves.fastLinearToSlowEaseIn,
              flipAxis: FlipAxis.y,
              child: Column(
                children: [
                  ListTile(
                    tileColor: backgroundColor,
                    leading: Container(
                        alignment: Alignment.center,
                        padding: const EdgeInsets.all(8),
                        height: 40,
                        width: 40,
                        decoration: BoxDecoration(
                            color: bgColor,
                            borderRadius: BorderRadius.circular(10)),
                        child: Text(widget.count.toString(),
                            style: TextStyle(
                                fontFamily: "english",
                                color: kActiveIconColor))),
                    title: Text(
                      widget.arabic!,
                      style: TextStyle(
                        color: kTextColor,
                        fontSize: 18,
                        fontFamily: fontType.toString(),
                      ),
                      textDirection: TextDirection.rtl,
                    ),
                    subtitle: Text(
                      "ژمارەی ئایەت : ${widget.ayahCount.toString()}",
                      textDirection: TextDirection.rtl,
                      style: TextStyle(
                          fontFamily: fontType.toString(),
                          color: const Color(0xff9e9e9e)),
                    ),
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(8)),
                    onTap: widget.onTap,
                  ),
                  const Divider(
                    color: Colors.transparent,
                  )
                ],
              ),
            )));
  }
}
