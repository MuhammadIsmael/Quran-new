# Google Play release

The app version is `1.0.4+7`, targets Android API 36, and produces an Android
App Bundle at `build/app/outputs/bundle/release/app-release.aab`.

## 1. Configure the existing Play upload key

Use the same upload key that is already registered for this app in Google Play
Console. Do not create a replacement key unless you are deliberately following
Google Play's upload-key reset process.

Copy `android/key.properties.example` to `android/key.properties`, fill in the
four values, and keep both the properties file and keystore private. They are
ignored by Git.

## 2. Build and verify

```sh
flutter clean
flutter pub get
flutter analyze
flutter test
flutter build appbundle --release
```

Confirm that the bundle is signed:

```sh
"$JAVA_HOME/bin/jarsigner" -verify \
  build/app/outputs/bundle/release/app-release.aab
```

The result must not say `jar is unsigned`.

## 3. Upload

Upload `build/app/outputs/bundle/release/app-release.aab` to the intended Play
Console track. Review the generated App Bundle details before promoting it.

Suggested release notes are in `CHANGELOG.md`.
