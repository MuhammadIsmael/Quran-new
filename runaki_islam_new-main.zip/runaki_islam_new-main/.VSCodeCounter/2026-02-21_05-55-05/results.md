# Summary

Date : 2026-02-21 05:55:05

Directory c:\\Users\\Amin's PC\\StudioProjects\\runaki_islam

Total : 352 files,  51150 codes, 499 comments, 1887 blanks, all 53536 lines

Summary / [Details](details.md) / [Diff Summary](diff.md) / [Diff Details](diff-details.md)

## Languages
| language | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| Dart | 148 | 25,065 | 231 | 1,487 | 26,783 |
| JSON | 123 | 24,116 | 0 | 9 | 24,125 |
| XML | 44 | 688 | 53 | 33 | 774 |
| C++ | 16 | 570 | 136 | 191 | 897 |
| CMake | 8 | 466 | 0 | 92 | 558 |
| YAML | 2 | 141 | 57 | 38 | 236 |
| Swift | 6 | 65 | 7 | 21 | 93 |
| HTML | 1 | 19 | 15 | 5 | 39 |
| Markdown | 2 | 13 | 0 | 9 | 22 |
| Properties | 2 | 7 | 0 | 2 | 9 |

## Directories
| path | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| . | 352 | 51,150 | 499 | 1,887 | 53,536 |
| . (Files) | 3 | 151 | 57 | 45 | 253 |
| android | 9 | 73 | 51 | 11 | 135 |
| android (Files) | 1 | 2 | 0 | 1 | 3 |
| android\\app | 7 | 66 | 51 | 9 | 126 |
| android\\app\\src | 7 | 66 | 51 | 9 | 126 |
| android\\app\\src\\debug | 1 | 3 | 4 | 1 | 8 |
| android\\app\\src\\main | 5 | 60 | 43 | 7 | 110 |
| android\\app\\src\\main (Files) | 1 | 34 | 11 | 1 | 46 |
| android\\app\\src\\main\\res | 4 | 26 | 32 | 6 | 64 |
| android\\app\\src\\main\\res\\drawable | 1 | 4 | 7 | 2 | 13 |
| android\\app\\src\\main\\res\\drawable-v21 | 1 | 4 | 7 | 2 | 13 |
| android\\app\\src\\main\\res\\values | 1 | 9 | 9 | 1 | 19 |
| android\\app\\src\\main\\res\\values-night | 1 | 9 | 9 | 1 | 19 |
| android\\app\\src\\profile | 1 | 3 | 4 | 1 | 8 |
| android\\gradle | 1 | 5 | 0 | 1 | 6 |
| android\\gradle\\wrapper | 1 | 5 | 0 | 1 | 6 |
| assets | 153 | 24,086 | 0 | 26 | 24,112 |
| assets\\icons | 34 | 218 | 0 | 21 | 239 |
| assets\\surah | 119 | 23,868 | 0 | 5 | 23,873 |
| ios | 8 | 229 | 4 | 13 | 246 |
| ios\\Runner | 7 | 222 | 2 | 9 | 233 |
| ios\\Runner (Files) | 2 | 13 | 0 | 3 | 16 |
| ios\\RunnerTests | 1 | 7 | 2 | 4 | 13 |
| ios\\Runner\\Assets.xcassets | 3 | 148 | 0 | 4 | 152 |
| ios\\Runner\\Assets.xcassets\\AppIcon.appiconset | 1 | 122 | 0 | 1 | 123 |
| ios\\Runner\\Assets.xcassets\\LaunchImage.imageset | 2 | 26 | 0 | 3 | 29 |
| ios\\Runner\\Base.lproj | 2 | 61 | 2 | 2 | 65 |
| lib | 147 | 25,051 | 221 | 1,480 | 26,752 |
| lib (Files) | 1 | 83 | 53 | 15 | 151 |
| lib\\Screens | 94 | 21,213 | 124 | 981 | 22,318 |
| lib\\Screens\\DrawerScreens | 2 | 507 | 15 | 18 | 540 |
| lib\\Screens\\DrawerScreens\\AboutApp | 1 | 270 | 15 | 9 | 294 |
| lib\\Screens\\DrawerScreens\\FeedBack | 1 | 237 | 0 | 9 | 246 |
| lib\\Screens\\HomeItems | 85 | 18,823 | 74 | 873 | 19,770 |
| lib\\Screens\\HomeItems\\AyatKursi | 1 | 189 | 0 | 15 | 204 |
| lib\\Screens\\HomeItems\\Bahasht_Dozax | 1 | 528 | 3 | 18 | 549 |
| lib\\Screens\\HomeItems\\Books | 2 | 1,561 | 7 | 43 | 1,611 |
| lib\\Screens\\HomeItems\\Cherok | 1 | 197 | 0 | 9 | 206 |
| lib\\Screens\\HomeItems\\Dua | 1 | 223 | 2 | 19 | 244 |
| lib\\Screens\\HomeItems\\Farmuda | 1 | 200 | 0 | 10 | 210 |
| lib\\Screens\\HomeItems\\Haramkrawakan | 1 | 223 | 2 | 18 | 243 |
| lib\\Screens\\HomeItems\\HawalanePexambar | 1 | 318 | 0 | 17 | 335 |
| lib\\Screens\\HomeItems\\HijriCalendar | 1 | 261 | 0 | 9 | 270 |
| lib\\Screens\\HomeItems\\Kafaratakan | 1 | 292 | 5 | 16 | 313 |
| lib\\Screens\\HomeItems\\MangeRamazan | 2 | 388 | 0 | 19 | 407 |
| lib\\Screens\\HomeItems\\NeshanakaneRozheDway | 11 | 3,137 | 0 | 97 | 3,234 |
| lib\\Screens\\HomeItems\\Nwezhkrdn | 13 | 3,608 | 8 | 114 | 3,730 |
| lib\\Screens\\HomeItems\\PayakaneEmanIslam | 15 | 2,325 | 0 | 134 | 2,459 |
| lib\\Screens\\HomeItems\\PayakaneEmanIslam (Files) | 1 | 205 | 0 | 7 | 212 |
| lib\\Screens\\HomeItems\\PayakaneEmanIslam\\ArkakaneEman | 8 | 1,173 | 0 | 74 | 1,247 |
| lib\\Screens\\HomeItems\\PayakaneEmanIslam\\ArkakaneEman (Files) | 1 | 272 | 0 | 9 | 281 |
| lib\\Screens\\HomeItems\\PayakaneEmanIslam\\ArkakaneEman\\pages | 7 | 901 | 0 | 65 | 966 |
| lib\\Screens\\HomeItems\\PayakaneEmanIslam\\ArkakaneIslam | 6 | 947 | 0 | 53 | 1,000 |
| lib\\Screens\\HomeItems\\PayakaneEmanIslam\\ArkakaneIslam (Files) | 1 | 252 | 0 | 8 | 260 |
| lib\\Screens\\HomeItems\\PayakaneEmanIslam\\ArkakaneIslam\\pages | 5 | 695 | 0 | 45 | 740 |
| lib\\Screens\\HomeItems\\Pexambarman | 4 | 711 | 1 | 35 | 747 |
| lib\\Screens\\HomeItems\\PrsyarWakamAyne | 1 | 235 | 2 | 18 | 255 |
| lib\\Screens\\HomeItems\\PrsyarWalamRozheDway | 2 | 380 | 0 | 21 | 401 |
| lib\\Screens\\HomeItems\\PuxtaySaheheMuslim | 2 | 442 | 9 | 26 | 477 |
| lib\\Screens\\HomeItems\\Qurani Piroz | 5 | 631 | 17 | 56 | 704 |
| lib\\Screens\\HomeItems\\Qurani Piroz (Files) | 1 | 142 | 7 | 16 | 165 |
| lib\\Screens\\HomeItems\\Qurani Piroz\\data | 3 | 92 | 0 | 17 | 109 |
| lib\\Screens\\HomeItems\\Qurani Piroz\\data (Files) | 1 | 18 | 0 | 4 | 22 |
| lib\\Screens\\HomeItems\\Qurani Piroz\\data\\models | 2 | 74 | 0 | 13 | 87 |
| lib\\Screens\\HomeItems\\Qurani Piroz\\ui | 1 | 397 | 10 | 23 | 430 |
| lib\\Screens\\HomeItems\\Sunatakan | 1 | 143 | 0 | 11 | 154 |
| lib\\Screens\\HomeItems\\Taqekrdnawa | 8 | 916 | 13 | 47 | 976 |
| lib\\Screens\\HomeItems\\Taqekrdnawa\\Walamakan | 1 | 335 | 7 | 8 | 350 |
| lib\\Screens\\HomeItems\\Taqekrdnawa\\quiz | 5 | 330 | 6 | 26 | 362 |
| lib\\Screens\\HomeItems\\Taqekrdnawa\\quiz (Files) | 1 | 26 | 0 | 3 | 29 |
| lib\\Screens\\HomeItems\\Taqekrdnawa\\quiz\\components | 4 | 304 | 6 | 23 | 333 |
| lib\\Screens\\HomeItems\\Taqekrdnawa\\score | 1 | 107 | 0 | 5 | 112 |
| lib\\Screens\\HomeItems\\Taqekrdnawa\\welcome | 1 | 144 | 0 | 8 | 152 |
| lib\\Screens\\HomeItems\\Tasbeeh | 4 | 447 | 0 | 32 | 479 |
| lib\\Screens\\HomeItems\\Tasbeeh (Files) | 2 | 47 | 0 | 6 | 53 |
| lib\\Screens\\HomeItems\\Tasbeeh\\pages | 2 | 400 | 0 | 26 | 426 |
| lib\\Screens\\HomeItems\\Tasbeeh\\pages\\sebha | 2 | 400 | 0 | 26 | 426 |
| lib\\Screens\\HomeItems\\TawanaGawrakan | 1 | 140 | 0 | 10 | 150 |
| lib\\Screens\\HomeItems\\WtawAmozhgary | 1 | 261 | 0 | 12 | 273 |
| lib\\Screens\\HomeItems\\ZanyareQuran | 1 | 321 | 0 | 17 | 338 |
| lib\\Screens\\HomeItems\\Zekrakan | 1 | 228 | 2 | 19 | 249 |
| lib\\Screens\\HomeItems\\ZhyanNamayPexambaran | 1 | 232 | 1 | 18 | 251 |
| lib\\Screens\\HomeItems\\nawakany_xuday_gawra | 1 | 286 | 2 | 13 | 301 |
| lib\\Screens\\mainScreens | 7 | 1,883 | 35 | 90 | 2,008 |
| lib\\Screens\\mainScreens (Files) | 3 | 748 | 19 | 38 | 805 |
| lib\\Screens\\mainScreens\\widget | 4 | 1,135 | 16 | 52 | 1,203 |
| lib\\bottom_navigation_view | 2 | 389 | 2 | 29 | 420 |
| lib\\controller | 1 | 75 | 18 | 22 | 115 |
| lib\\database | 1 | 183 | 9 | 57 | 249 |
| lib\\models | 19 | 505 | 11 | 79 | 595 |
| lib\\providers | 4 | 300 | 2 | 66 | 368 |
| lib\\util | 9 | 592 | 1 | 59 | 652 |
| lib\\util (Files) | 5 | 412 | 1 | 48 | 461 |
| lib\\util\\navigate_between_pages | 4 | 180 | 0 | 11 | 191 |
| lib\\widgets | 16 | 1,711 | 1 | 172 | 1,884 |
| lib\\widgets (Files) | 3 | 279 | 0 | 23 | 302 |
| lib\\widgets\\Profile | 1 | 93 | 0 | 17 | 110 |
| lib\\widgets\\nwezh | 2 | 296 | 0 | 28 | 324 |
| lib\\widgets\\sebha_widget | 10 | 1,043 | 1 | 104 | 1,148 |
| lib\\widgets\\sebha_widget (Files) | 7 | 760 | 1 | 76 | 837 |
| lib\\widgets\\sebha_widget\\tasbih_fields | 3 | 283 | 0 | 28 | 311 |
| linux | 9 | 344 | 42 | 94 | 480 |
| linux (Files) | 1 | 104 | 0 | 25 | 129 |
| linux\\flutter | 4 | 110 | 9 | 27 | 146 |
| linux\\runner | 4 | 130 | 33 | 42 | 205 |
| macos | 6 | 457 | 5 | 17 | 479 |
| macos\\Flutter | 1 | 16 | 3 | 4 | 23 |
| macos\\Runner | 4 | 434 | 0 | 9 | 443 |
| macos\\Runner (Files) | 2 | 23 | 0 | 7 | 30 |
| macos\\RunnerTests | 1 | 7 | 2 | 4 | 13 |
| macos\\Runner\\Assets.xcassets | 1 | 68 | 0 | 1 | 69 |
| macos\\Runner\\Assets.xcassets\\AppIcon.appiconset | 1 | 68 | 0 | 1 | 69 |
| macos\\Runner\\Base.lproj | 1 | 343 | 0 | 1 | 344 |
| test | 1 | 14 | 10 | 7 | 31 |
| web | 2 | 54 | 15 | 6 | 75 |
| windows | 14 | 691 | 94 | 188 | 973 |
| windows (Files) | 1 | 89 | 0 | 20 | 109 |
| windows\\flutter | 4 | 140 | 9 | 29 | 178 |
| windows\\runner | 9 | 462 | 85 | 139 | 686 |

Summary / [Details](details.md) / [Diff Summary](diff.md) / [Diff Details](diff-details.md)