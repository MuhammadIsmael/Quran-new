# Summary

Date : 2026-02-23 06:03:22

Directory c:\\Users\\Amin's PC\\StudioProjects\\runaki_islam - Copy

Total : 387 files,  67006 codes, 468 comments, 2911 blanks, all 70385 lines

Summary / [Details](details.md) / [Diff Summary](diff.md) / [Diff Details](diff-details.md)

## Languages
| language | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| Dart | 173 | 39,794 | 194 | 2,334 | 42,322 |
| JSON | 123 | 24,116 | 0 | 9 | 24,125 |
| XML | 52 | 1,239 | 57 | 94 | 1,390 |
| C++ | 16 | 576 | 136 | 191 | 903 |
| HTML | 2 | 567 | 17 | 119 | 703 |
| CMake | 8 | 468 | 0 | 92 | 560 |
| YAML | 3 | 153 | 57 | 40 | 250 |
| Swift | 6 | 73 | 7 | 21 | 101 |
| Markdown | 2 | 13 | 0 | 9 | 22 |
| Properties | 2 | 7 | 0 | 2 | 9 |

## Directories
| path | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| . | 387 | 67,006 | 468 | 2,911 | 70,385 |
| . (Files) | 4 | 163 | 57 | 47 | 267 |
| android | 18 | 1,172 | 57 | 186 | 1,415 |
| android (Files) | 1 | 2 | 0 | 1 | 3 |
| android\\app | 15 | 617 | 55 | 70 | 742 |
| android\\app\\src | 15 | 617 | 55 | 70 | 742 |
| android\\app\\src\\debug | 1 | 3 | 4 | 1 | 8 |
| android\\app\\src\\main | 13 | 611 | 47 | 68 | 726 |
| android\\app\\src\\main (Files) | 1 | 115 | 15 | 10 | 140 |
| android\\app\\src\\main\\res | 12 | 496 | 32 | 58 | 586 |
| android\\app\\src\\main\\res\\drawable | 3 | 22 | 7 | 4 | 33 |
| android\\app\\src\\main\\res\\drawable-v21 | 1 | 4 | 7 | 2 | 13 |
| android\\app\\src\\main\\res\\layout | 3 | 428 | 0 | 47 | 475 |
| android\\app\\src\\main\\res\\values | 1 | 9 | 9 | 1 | 19 |
| android\\app\\src\\main\\res\\values-night | 1 | 9 | 9 | 1 | 19 |
| android\\app\\src\\main\\res\\xml | 3 | 24 | 0 | 3 | 27 |
| android\\app\\src\\profile | 1 | 3 | 4 | 1 | 8 |
| android\\build | 1 | 548 | 2 | 114 | 664 |
| android\\build\\reports | 1 | 548 | 2 | 114 | 664 |
| android\\build\\reports\\problems | 1 | 548 | 2 | 114 | 664 |
| android\\gradle | 1 | 5 | 0 | 1 | 6 |
| android\\gradle\\wrapper | 1 | 5 | 0 | 1 | 6 |
| assets | 153 | 24,086 | 0 | 26 | 24,112 |
| assets\\icons | 34 | 218 | 0 | 21 | 239 |
| assets\\surah | 119 | 23,868 | 0 | 5 | 23,873 |
| ios | 8 | 229 | 4 | 13 | 246 |
| ios\\Runner | 7 | 222 | 2 | 9 | 233 |
| ios\\Runner (Files) | 2 | 13 | 0 | 3 | 16 |
| ios\\RunnerTests | 1 | 7 | 2 | 4 | 13 |
| ios\\Runner\\Assets.xcassets | 3 | 148 | 0 | 4 | 152 |
| ios\\Runner\\Assets.xcassets\\AppIcon.appiconset | 1 | 122 | 0 | 1 | 123 |
| ios\\Runner\\Assets.xcassets\\LaunchImage.imageset | 2 | 26 | 0 | 3 | 29 |
| ios\\Runner\\Base.lproj | 2 | 61 | 2 | 2 | 65 |
| lib | 172 | 39,782 | 194 | 2,330 | 42,306 |
| lib (Files) | 1 | 111 | 58 | 12 | 181 |
| lib\\Screens | 109 | 33,998 | 91 | 1,636 | 35,725 |
| lib\\Screens\\DrawerScreens | 2 | 507 | 15 | 18 | 540 |
| lib\\Screens\\DrawerScreens\\AboutApp | 1 | 270 | 15 | 9 | 294 |
| lib\\Screens\\DrawerScreens\\FeedBack | 1 | 237 | 0 | 9 | 246 |
| lib\\Screens\\HomeItems | 98 | 28,248 | 56 | 1,367 | 29,671 |
| lib\\Screens\\HomeItems\\AyatKursi | 1 | 189 | 0 | 15 | 204 |
| lib\\Screens\\HomeItems\\Bahasht_Dozax | 1 | 528 | 3 | 18 | 549 |
| lib\\Screens\\HomeItems\\Books | 2 | 1,571 | 7 | 43 | 1,621 |
| lib\\Screens\\HomeItems\\Cherok | 1 | 197 | 0 | 9 | 206 |
| lib\\Screens\\HomeItems\\Dua | 1 | 223 | 2 | 19 | 244 |
| lib\\Screens\\HomeItems\\Farmuda | 1 | 200 | 0 | 10 | 210 |
| lib\\Screens\\HomeItems\\Haramkrawakan | 1 | 223 | 2 | 18 | 243 |
| lib\\Screens\\HomeItems\\HawalanePexambar | 1 | 318 | 0 | 17 | 335 |
| lib\\Screens\\HomeItems\\HijriCalendar | 1 | 261 | 0 | 9 | 270 |
| lib\\Screens\\HomeItems\\IslamicAI | 2 | 841 | 0 | 56 | 897 |
| lib\\Screens\\HomeItems\\Kafaratakan | 1 | 292 | 5 | 16 | 313 |
| lib\\Screens\\HomeItems\\MangeRamazan | 3 | 1,852 | 0 | 107 | 1,959 |
| lib\\Screens\\HomeItems\\NeshanakaneRozheDway | 11 | 3,137 | 0 | 97 | 3,234 |
| lib\\Screens\\HomeItems\\Nwezhkrdn | 13 | 3,608 | 8 | 114 | 3,730 |
| lib\\Screens\\HomeItems\\PayakaneEmanIslam | 15 | 2,325 | 0 | 134 | 2,459 |
| lib\\Screens\\HomeItems\\PayakaneEmanIslam (Files) | 1 | 205 | 0 | 7 | 212 |
| lib\\Screens\\HomeItems\\PayakaneEmanIslam\\ArkakaneEman | 8 | 1,173 | 0 | 74 | 1,247 |
| lib\\Screens\\HomeItems\\PayakaneEmanIslam\\ArkakaneEman (Files) | 1 | 272 | 0 | 9 | 281 |
| lib\\Screens\\HomeItems\\PayakaneEmanIslam\\ArkakaneEman\\pages | 7 | 901 | 0 | 65 | 966 |
| lib\\Screens\\HomeItems\\PayakaneEmanIslam\\ArkakaneIslam | 6 | 947 | 0 | 53 | 1,000 |
| lib\\Screens\\HomeItems\\PayakaneEmanIslam\\ArkakaneIslam (Files) | 1 | 252 | 0 | 8 | 260 |
| lib\\Screens\\HomeItems\\PayakaneEmanIslam\\ArkakaneIslam\\pages | 5 | 695 | 0 | 45 | 740 |
| lib\\Screens\\HomeItems\\Pexambarman | 4 | 792 | 1 | 39 | 832 |
| lib\\Screens\\HomeItems\\PrsyarWakamAyne | 1 | 235 | 2 | 18 | 255 |
| lib\\Screens\\HomeItems\\PrsyarWalamRozheDway | 2 | 380 | 0 | 21 | 401 |
| lib\\Screens\\HomeItems\\PuxtaySaheheMuslim | 2 | 442 | 9 | 26 | 477 |
| lib\\Screens\\HomeItems\\QiblaFinder | 1 | 726 | 0 | 44 | 770 |
| lib\\Screens\\HomeItems\\Qurani Piroz | 13 | 5,844 | 1 | 307 | 6,152 |
| lib\\Screens\\HomeItems\\Qurani Piroz (Files) | 1 | 1,388 | 0 | 88 | 1,476 |
| lib\\Screens\\HomeItems\\Qurani Piroz\\data | 5 | 695 | 1 | 75 | 771 |
| lib\\Screens\\HomeItems\\Qurani Piroz\\data (Files) | 1 | 485 | 1 | 46 | 532 |
| lib\\Screens\\HomeItems\\Qurani Piroz\\data\\models | 4 | 210 | 0 | 29 | 239 |
| lib\\Screens\\HomeItems\\Qurani Piroz\\ui | 1 | 2,561 | 0 | 93 | 2,654 |
| lib\\Screens\\HomeItems\\Qurani Piroz\\widgets | 6 | 1,200 | 0 | 51 | 1,251 |
| lib\\Screens\\HomeItems\\Sunatakan | 1 | 143 | 0 | 11 | 154 |
| lib\\Screens\\HomeItems\\Taqekrdnawa | 8 | 916 | 13 | 47 | 976 |
| lib\\Screens\\HomeItems\\Taqekrdnawa\\Walamakan | 1 | 335 | 7 | 8 | 350 |
| lib\\Screens\\HomeItems\\Taqekrdnawa\\quiz | 5 | 330 | 6 | 26 | 362 |
| lib\\Screens\\HomeItems\\Taqekrdnawa\\quiz (Files) | 1 | 26 | 0 | 3 | 29 |
| lib\\Screens\\HomeItems\\Taqekrdnawa\\quiz\\components | 4 | 304 | 6 | 23 | 333 |
| lib\\Screens\\HomeItems\\Taqekrdnawa\\score | 1 | 107 | 0 | 5 | 112 |
| lib\\Screens\\HomeItems\\Taqekrdnawa\\welcome | 1 | 144 | 0 | 8 | 152 |
| lib\\Screens\\HomeItems\\Tasbeeh | 4 | 514 | 0 | 30 | 544 |
| lib\\Screens\\HomeItems\\Tasbeeh (Files) | 2 | 45 | 0 | 6 | 51 |
| lib\\Screens\\HomeItems\\Tasbeeh\\pages | 2 | 469 | 0 | 24 | 493 |
| lib\\Screens\\HomeItems\\Tasbeeh\\pages\\sebha | 2 | 469 | 0 | 24 | 493 |
| lib\\Screens\\HomeItems\\TawanaGawrakan | 1 | 140 | 0 | 10 | 150 |
| lib\\Screens\\HomeItems\\WtawAmozhgary | 1 | 261 | 0 | 12 | 273 |
| lib\\Screens\\HomeItems\\ZakatCalculator | 1 | 715 | 0 | 36 | 751 |
| lib\\Screens\\HomeItems\\ZanyareQuran | 1 | 321 | 0 | 17 | 338 |
| lib\\Screens\\HomeItems\\Zekrakan | 1 | 228 | 2 | 19 | 249 |
| lib\\Screens\\HomeItems\\ZhyanNamayPexambaran | 1 | 232 | 1 | 18 | 251 |
| lib\\Screens\\HomeItems\\nawakany_xuday_gawra | 1 | 594 | 0 | 30 | 624 |
| lib\\Screens\\mainScreens | 9 | 5,243 | 20 | 251 | 5,514 |
| lib\\Screens\\mainScreens (Files) | 3 | 882 | 19 | 34 | 935 |
| lib\\Screens\\mainScreens\\widget | 6 | 4,361 | 1 | 217 | 4,579 |
| lib\\bottom_navigation_view | 2 | 250 | 0 | 20 | 270 |
| lib\\controller | 1 | 75 | 18 | 22 | 115 |
| lib\\database | 1 | 203 | 9 | 53 | 265 |
| lib\\models | 19 | 523 | 11 | 82 | 616 |
| lib\\providers | 5 | 851 | 0 | 135 | 986 |
| lib\\services | 4 | 494 | 1 | 80 | 575 |
| lib\\theme | 1 | 139 | 0 | 6 | 145 |
| lib\\util | 11 | 876 | 5 | 81 | 962 |
| lib\\util (Files) | 7 | 654 | 5 | 70 | 729 |
| lib\\util\\navigate_between_pages | 4 | 222 | 0 | 11 | 233 |
| lib\\widgets | 18 | 2,262 | 1 | 203 | 2,466 |
| lib\\widgets (Files) | 5 | 830 | 0 | 54 | 884 |
| lib\\widgets\\Profile | 1 | 93 | 0 | 17 | 110 |
| lib\\widgets\\nwezh | 2 | 296 | 0 | 28 | 324 |
| lib\\widgets\\sebha_widget | 10 | 1,043 | 1 | 104 | 1,148 |
| lib\\widgets\\sebha_widget (Files) | 7 | 760 | 1 | 76 | 837 |
| lib\\widgets\\sebha_widget\\tasbih_fields | 3 | 283 | 0 | 28 | 311 |
| linux | 9 | 344 | 42 | 94 | 480 |
| linux (Files) | 1 | 104 | 0 | 25 | 129 |
| linux\\flutter | 4 | 110 | 9 | 27 | 146 |
| linux\\runner | 4 | 130 | 33 | 42 | 205 |
| macos | 6 | 465 | 5 | 17 | 487 |
| macos\\Flutter | 1 | 24 | 3 | 4 | 31 |
| macos\\Runner | 4 | 434 | 0 | 9 | 443 |
| macos\\Runner (Files) | 2 | 23 | 0 | 7 | 30 |
| macos\\RunnerTests | 1 | 7 | 2 | 4 | 13 |
| macos\\Runner\\Assets.xcassets | 1 | 68 | 0 | 1 | 69 |
| macos\\Runner\\Assets.xcassets\\AppIcon.appiconset | 1 | 68 | 0 | 1 | 69 |
| macos\\Runner\\Base.lproj | 1 | 343 | 0 | 1 | 344 |
| test | 1 | 12 | 0 | 4 | 16 |
| web | 2 | 54 | 15 | 6 | 75 |
| windows | 14 | 699 | 94 | 188 | 981 |
| windows (Files) | 1 | 89 | 0 | 20 | 109 |
| windows\\flutter | 4 | 148 | 9 | 29 | 186 |
| windows\\runner | 9 | 462 | 85 | 139 | 686 |

Summary / [Details](details.md) / [Diff Summary](diff.md) / [Diff Details](diff-details.md)