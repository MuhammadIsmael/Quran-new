# Diff Details

Date : 2026-02-23 06:03:22

Directory c:\\Users\\Amin's PC\\StudioProjects\\runaki_islam - Copy

Total : 739 files,  15856 codes, -31 comments, 1024 blanks, all 16849 lines

[Summary](results.md) / [Details](details.md) / [Diff Summary](diff.md) / Diff Details

## Files
| filename | language | code | comment | blank | total |
| :--- | :--- | ---: | ---: | ---: | ---: |
| [README.md](/README.md) | Markdown | 10 | 0 | 7 | 17 |
| [analysis\_options.yaml](/analysis_options.yaml) | YAML | 3 | 22 | 4 | 29 |
| [android/app/src/debug/AndroidManifest.xml](/android/app/src/debug/AndroidManifest.xml) | XML | 3 | 4 | 1 | 8 |
| [android/app/src/main/AndroidManifest.xml](/android/app/src/main/AndroidManifest.xml) | XML | 115 | 15 | 10 | 140 |
| [android/app/src/main/res/drawable-v21/launch\_background.xml](/android/app/src/main/res/drawable-v21/launch_background.xml) | XML | 4 | 7 | 2 | 13 |
| [android/app/src/main/res/drawable/launch\_background.xml](/android/app/src/main/res/drawable/launch_background.xml) | XML | 4 | 7 | 2 | 13 |
| [android/app/src/main/res/drawable/prayer\_widget\_bg.xml](/android/app/src/main/res/drawable/prayer_widget_bg.xml) | XML | 9 | 0 | 1 | 10 |
| [android/app/src/main/res/drawable/prayer\_widget\_bg\_light.xml](/android/app/src/main/res/drawable/prayer_widget_bg_light.xml) | XML | 9 | 0 | 1 | 10 |
| [android/app/src/main/res/layout/prayer\_times\_home\_widget.xml](/android/app/src/main/res/layout/prayer_times_home_widget.xml) | XML | 208 | 0 | 23 | 231 |
| [android/app/src/main/res/layout/prayer\_times\_home\_widget\_compact.xml](/android/app/src/main/res/layout/prayer_times_home_widget_compact.xml) | XML | 154 | 0 | 17 | 171 |
| [android/app/src/main/res/layout/prayer\_times\_home\_widget\_mini.xml](/android/app/src/main/res/layout/prayer_times_home_widget_mini.xml) | XML | 66 | 0 | 7 | 73 |
| [android/app/src/main/res/values-night/styles.xml](/android/app/src/main/res/values-night/styles.xml) | XML | 9 | 9 | 1 | 19 |
| [android/app/src/main/res/values/styles.xml](/android/app/src/main/res/values/styles.xml) | XML | 9 | 9 | 1 | 19 |
| [android/app/src/main/res/xml/prayer\_times\_home\_widget\_compact\_info.xml](/android/app/src/main/res/xml/prayer_times_home_widget_compact_info.xml) | XML | 8 | 0 | 1 | 9 |
| [android/app/src/main/res/xml/prayer\_times\_home\_widget\_info.xml](/android/app/src/main/res/xml/prayer_times_home_widget_info.xml) | XML | 8 | 0 | 1 | 9 |
| [android/app/src/main/res/xml/prayer\_times\_home\_widget\_mini\_info.xml](/android/app/src/main/res/xml/prayer_times_home_widget_mini_info.xml) | XML | 8 | 0 | 1 | 9 |
| [android/app/src/profile/AndroidManifest.xml](/android/app/src/profile/AndroidManifest.xml) | XML | 3 | 4 | 1 | 8 |
| [android/build/reports/problems/problems-report.html](/android/build/reports/problems/problems-report.html) | HTML | 548 | 2 | 114 | 664 |
| [android/gradle.properties](/android/gradle.properties) | Properties | 2 | 0 | 1 | 3 |
| [android/gradle/wrapper/gradle-wrapper.properties](/android/gradle/wrapper/gradle-wrapper.properties) | Properties | 5 | 0 | 1 | 6 |
| [assets/icons/allah-word.svg](/assets/icons/allah-word.svg) | XML | 1 | 0 | 0 | 1 |
| [assets/icons/books.svg](/assets/icons/books.svg) | XML | 1 | 0 | 0 | 1 |
| [assets/icons/calendar.svg](/assets/icons/calendar.svg) | XML | 1 | 0 | 0 | 1 |
| [assets/icons/cherok.svg](/assets/icons/cherok.svg) | XML | 67 | 0 | 0 | 67 |
| [assets/icons/contact.svg](/assets/icons/contact.svg) | XML | 2 | 0 | 1 | 3 |
| [assets/icons/dream.svg](/assets/icons/dream.svg) | XML | 1 | 0 | 0 | 1 |
| [assets/icons/dua.svg](/assets/icons/dua.svg) | XML | 1 | 0 | 0 | 1 |
| [assets/icons/exit.svg](/assets/icons/exit.svg) | XML | 2 | 0 | 1 | 3 |
| [assets/icons/facebook.svg](/assets/icons/facebook.svg) | XML | 1 | 0 | 0 | 1 |
| [assets/icons/haram.svg](/assets/icons/haram.svg) | XML | 1 | 0 | 0 | 1 |
| [assets/icons/hawal.svg](/assets/icons/hawal.svg) | XML | 1 | 0 | 0 | 1 |
| [assets/icons/hijri-calendar.svg](/assets/icons/hijri-calendar.svg) | XML | 1 | 0 | 0 | 1 |
| [assets/icons/home.svg](/assets/icons/home.svg) | XML | 2 | 0 | 1 | 3 |
| [assets/icons/info.svg](/assets/icons/info.svg) | XML | 2 | 0 | 1 | 3 |
| [assets/icons/instagran.svg](/assets/icons/instagran.svg) | XML | 1 | 0 | 0 | 1 |
| [assets/icons/islam.svg](/assets/icons/islam.svg) | XML | 1 | 0 | 0 | 1 |
| [assets/icons/middle-tab.svg](/assets/icons/middle-tab.svg) | XML | 55 | 0 | 0 | 55 |
| [assets/icons/more.svg](/assets/icons/more.svg) | XML | 2 | 0 | 1 | 3 |
| [assets/icons/prayer-time.svg](/assets/icons/prayer-time.svg) | XML | 1 | 0 | 0 | 1 |
| [assets/icons/praying.svg](/assets/icons/praying.svg) | XML | 1 | 0 | 0 | 1 |
| [assets/icons/prsyar.svg](/assets/icons/prsyar.svg) | XML | 1 | 0 | 0 | 1 |
| [assets/icons/qoute.svg](/assets/icons/qoute.svg) | XML | 1 | 0 | 0 | 1 |
| [assets/icons/quran-icon.svg](/assets/icons/quran-icon.svg) | XML | 1 | 0 | 0 | 1 |
| [assets/icons/ramazan.svg](/assets/icons/ramazan.svg) | XML | 1 | 0 | 0 | 1 |
| [assets/icons/snapchat.svg](/assets/icons/snapchat.svg) | XML | 1 | 0 | 0 | 1 |
| [assets/icons/sunnah.svg](/assets/icons/sunnah.svg) | XML | 1 | 0 | 0 | 1 |
| [assets/icons/support.svg](/assets/icons/support.svg) | XML | 1 | 0 | 0 | 1 |
| [assets/icons/tajwed.svg](/assets/icons/tajwed.svg) | XML | 49 | 0 | 0 | 49 |
| [assets/icons/tasbih.svg](/assets/icons/tasbih.svg) | XML | 1 | 0 | 0 | 1 |
| [assets/icons/tawanakan.svg](/assets/icons/tawanakan.svg) | XML | 1 | 0 | 0 | 1 |
| [assets/icons/user.svg](/assets/icons/user.svg) | XML | 2 | 0 | 1 | 3 |
| [assets/icons/zanste-quran.svg](/assets/icons/zanste-quran.svg) | XML | 1 | 0 | 0 | 1 |
| [assets/icons/zanyare-quran.svg](/assets/icons/zanyare-quran.svg) | XML | 11 | 0 | 15 | 26 |
| [assets/icons/zikr.svg](/assets/icons/zikr.svg) | XML | 1 | 0 | 0 | 1 |
| [assets/surah/1.json](/assets/surah/1.json) | JSON | 48 | 0 | 0 | 48 |
| [assets/surah/10.json](/assets/surah/10.json) | JSON | 354 | 0 | 0 | 354 |
| [assets/surah/100.json](/assets/surah/100.json) | JSON | 60 | 0 | 0 | 60 |
| [assets/surah/101.json](/assets/surah/101.json) | JSON | 60 | 0 | 0 | 60 |
| [assets/surah/102.json](/assets/surah/102.json) | JSON | 51 | 0 | 0 | 51 |
| [assets/surah/103.json](/assets/surah/103.json) | JSON | 36 | 0 | 0 | 36 |
| [assets/surah/104.json](/assets/surah/104.json) | JSON | 54 | 0 | 0 | 54 |
| [assets/surah/105.json](/assets/surah/105.json) | JSON | 42 | 0 | 0 | 42 |
| [assets/surah/106.json](/assets/surah/106.json) | JSON | 39 | 0 | 0 | 39 |
| [assets/surah/107.json](/assets/surah/107.json) | JSON | 48 | 0 | 0 | 48 |
| [assets/surah/108.json](/assets/surah/108.json) | JSON | 36 | 0 | 0 | 36 |
| [assets/surah/109.json](/assets/surah/109.json) | JSON | 45 | 0 | 0 | 45 |
| [assets/surah/11.json](/assets/surah/11.json) | JSON | 396 | 0 | 0 | 396 |
| [assets/surah/110.json](/assets/surah/110.json) | JSON | 36 | 0 | 0 | 36 |
| [assets/surah/111.json](/assets/surah/111.json) | JSON | 42 | 0 | 0 | 42 |
| [assets/surah/112.json](/assets/surah/112.json) | JSON | 39 | 0 | 0 | 39 |
| [assets/surah/113.json](/assets/surah/113.json) | JSON | 42 | 0 | 0 | 42 |
| [assets/surah/114.json](/assets/surah/114.json) | JSON | 45 | 0 | 0 | 45 |
| [assets/surah/12.json](/assets/surah/12.json) | JSON | 360 | 0 | 0 | 360 |
| [assets/surah/13.json](/assets/surah/13.json) | JSON | 156 | 0 | 0 | 156 |
| [assets/surah/14.json](/assets/surah/14.json) | JSON | 183 | 0 | 0 | 183 |
| [assets/surah/15.json](/assets/surah/15.json) | JSON | 324 | 0 | 0 | 324 |
| [assets/surah/16.json](/assets/surah/16.json) | JSON | 411 | 0 | 0 | 411 |
| [assets/surah/17.json](/assets/surah/17.json) | JSON | 360 | 0 | 0 | 360 |
| [assets/surah/18.json](/assets/surah/18.json) | JSON | 357 | 0 | 0 | 357 |
| [assets/surah/19.json](/assets/surah/19.json) | JSON | 321 | 0 | 0 | 321 |
| [assets/surah/2.json](/assets/surah/2.json) | JSON | 885 | 0 | 0 | 885 |
| [assets/surah/20.json](/assets/surah/20.json) | JSON | 432 | 0 | 0 | 432 |
| [assets/surah/21.json](/assets/surah/21.json) | JSON | 363 | 0 | 0 | 363 |
| [assets/surah/22.json](/assets/surah/22.json) | JSON | 261 | 0 | 0 | 261 |
| [assets/surah/23.json](/assets/surah/23.json) | JSON | 381 | 0 | 0 | 381 |
| [assets/surah/24.json](/assets/surah/24.json) | JSON | 219 | 0 | 0 | 219 |
| [assets/surah/25.json](/assets/surah/25.json) | JSON | 258 | 0 | 0 | 258 |
| [assets/surah/26.json](/assets/surah/26.json) | JSON | 708 | 0 | 0 | 708 |
| [assets/surah/27.json](/assets/surah/27.json) | JSON | 306 | 0 | 0 | 306 |
| [assets/surah/28.json](/assets/surah/28.json) | JSON | 291 | 0 | 0 | 291 |
| [assets/surah/29.json](/assets/surah/29.json) | JSON | 234 | 0 | 0 | 234 |
| [assets/surah/3.json](/assets/surah/3.json) | JSON | 627 | 0 | 0 | 627 |
| [assets/surah/30.json](/assets/surah/30.json) | JSON | 207 | 0 | 0 | 207 |
| [assets/surah/31.json](/assets/surah/31.json) | JSON | 129 | 0 | 0 | 129 |
| [assets/surah/32.json](/assets/surah/32.json) | JSON | 117 | 0 | 0 | 117 |
| [assets/surah/33.json](/assets/surah/33.json) | JSON | 246 | 0 | 0 | 246 |
| [assets/surah/34.json](/assets/surah/34.json) | JSON | 189 | 0 | 0 | 189 |
| [assets/surah/35.json](/assets/surah/35.json) | JSON | 162 | 0 | 0 | 162 |
| [assets/surah/36.json](/assets/surah/36.json) | JSON | 276 | 0 | 0 | 276 |
| [assets/surah/37.json](/assets/surah/37.json) | JSON | 573 | 0 | 0 | 573 |
| [assets/surah/38.json](/assets/surah/38.json) | JSON | 291 | 0 | 0 | 291 |
| [assets/surah/39.json](/assets/surah/39.json) | JSON | 252 | 0 | 0 | 252 |
| [assets/surah/4.json](/assets/surah/4.json) | JSON | 555 | 0 | 0 | 555 |
| [assets/surah/40.json](/assets/surah/40.json) | JSON | 282 | 0 | 0 | 282 |
| [assets/surah/41.json](/assets/surah/41.json) | JSON | 189 | 0 | 0 | 189 |
| [assets/surah/42.json](/assets/surah/42.json) | JSON | 186 | 0 | 0 | 186 |
| [assets/surah/43.json](/assets/surah/43.json) | JSON | 294 | 0 | 0 | 294 |
| [assets/surah/44.json](/assets/surah/44.json) | JSON | 204 | 0 | 0 | 204 |
| [assets/surah/45.json](/assets/surah/45.json) | JSON | 138 | 0 | 0 | 138 |
| [assets/surah/46.json](/assets/surah/46.json) | JSON | 132 | 0 | 0 | 132 |
| [assets/surah/47.json](/assets/surah/47.json) | JSON | 141 | 0 | 0 | 141 |
| [assets/surah/48.json](/assets/surah/48.json) | JSON | 114 | 0 | 0 | 114 |
| [assets/surah/49.json](/assets/surah/49.json) | JSON | 81 | 0 | 0 | 81 |
| [assets/surah/5.json](/assets/surah/5.json) | JSON | 387 | 0 | 0 | 387 |
| [assets/surah/50.json](/assets/surah/50.json) | JSON | 162 | 0 | 0 | 162 |
| [assets/surah/51.json](/assets/surah/51.json) | JSON | 207 | 0 | 0 | 207 |
| [assets/surah/52.json](/assets/surah/52.json) | JSON | 174 | 0 | 0 | 174 |
| [assets/surah/53.json](/assets/surah/53.json) | JSON | 213 | 0 | 0 | 213 |
| [assets/surah/54.json](/assets/surah/54.json) | JSON | 192 | 0 | 0 | 192 |
| [assets/surah/55.json](/assets/surah/55.json) | JSON | 261 | 0 | 0 | 261 |
| [assets/surah/56.json](/assets/surah/56.json) | JSON | 315 | 0 | 0 | 315 |
| [assets/surah/57.json](/assets/surah/57.json) | JSON | 114 | 0 | 0 | 114 |
| [assets/surah/58.json](/assets/surah/58.json) | JSON | 93 | 0 | 0 | 93 |
| [assets/surah/59.json](/assets/surah/59.json) | JSON | 99 | 0 | 0 | 99 |
| [assets/surah/6.json](/assets/surah/6.json) | JSON | 522 | 0 | 0 | 522 |
| [assets/surah/60.json](/assets/surah/60.json) | JSON | 66 | 0 | 0 | 66 |
| [assets/surah/61.json](/assets/surah/61.json) | JSON | 69 | 0 | 0 | 69 |
| [assets/surah/62.json](/assets/surah/62.json) | JSON | 60 | 0 | 0 | 60 |
| [assets/surah/63.json](/assets/surah/63.json) | JSON | 60 | 0 | 0 | 60 |
| [assets/surah/64.json](/assets/surah/64.json) | JSON | 81 | 0 | 0 | 81 |
| [assets/surah/65.json](/assets/surah/65.json) | JSON | 63 | 0 | 0 | 63 |
| [assets/surah/66.json](/assets/surah/66.json) | JSON | 63 | 0 | 0 | 63 |
| [assets/surah/67.json](/assets/surah/67.json) | JSON | 117 | 0 | 0 | 117 |
| [assets/surah/68.json](/assets/surah/68.json) | JSON | 183 | 0 | 0 | 183 |
| [assets/surah/69.json](/assets/surah/69.json) | JSON | 183 | 0 | 0 | 183 |
| [assets/surah/7.json](/assets/surah/7.json) | JSON | 645 | 0 | 0 | 645 |
| [assets/surah/70.json](/assets/surah/70.json) | JSON | 159 | 0 | 0 | 159 |
| [assets/surah/71.json](/assets/surah/71.json) | JSON | 111 | 0 | 0 | 111 |
| [assets/surah/72.json](/assets/surah/72.json) | JSON | 111 | 0 | 0 | 111 |
| [assets/surah/73.json](/assets/surah/73.json) | JSON | 87 | 0 | 0 | 87 |
| [assets/surah/74.json](/assets/surah/74.json) | JSON | 195 | 0 | 0 | 195 |
| [assets/surah/75.json](/assets/surah/75.json) | JSON | 147 | 0 | 0 | 147 |
| [assets/surah/76.json](/assets/surah/76.json) | JSON | 120 | 0 | 0 | 120 |
| [assets/surah/77.json](/assets/surah/77.json) | JSON | 177 | 0 | 0 | 177 |
| [assets/surah/78.json](/assets/surah/78.json) | JSON | 147 | 0 | 0 | 147 |
| [assets/surah/79.json](/assets/surah/79.json) | JSON | 165 | 0 | 0 | 165 |
| [assets/surah/8.json](/assets/surah/8.json) | JSON | 252 | 0 | 0 | 252 |
| [assets/surah/80.json](/assets/surah/80.json) | JSON | 153 | 0 | 0 | 153 |
| [assets/surah/81.json](/assets/surah/81.json) | JSON | 114 | 0 | 0 | 114 |
| [assets/surah/82.json](/assets/surah/82.json) | JSON | 84 | 0 | 0 | 84 |
| [assets/surah/83.json](/assets/surah/83.json) | JSON | 135 | 0 | 0 | 135 |
| [assets/surah/84.json](/assets/surah/84.json) | JSON | 102 | 0 | 0 | 102 |
| [assets/surah/85.json](/assets/surah/85.json) | JSON | 93 | 0 | 0 | 93 |
| [assets/surah/86.json](/assets/surah/86.json) | JSON | 78 | 0 | 0 | 78 |
| [assets/surah/87.json](/assets/surah/87.json) | JSON | 84 | 0 | 0 | 84 |
| [assets/surah/88.json](/assets/surah/88.json) | JSON | 105 | 0 | 0 | 105 |
| [assets/surah/89.json](/assets/surah/89.json) | JSON | 117 | 0 | 0 | 117 |
| [assets/surah/9.json](/assets/surah/9.json) | JSON | 414 | 0 | 0 | 414 |
| [assets/surah/90.json](/assets/surah/90.json) | JSON | 87 | 0 | 0 | 87 |
| [assets/surah/91.json](/assets/surah/91.json) | JSON | 72 | 0 | 0 | 72 |
| [assets/surah/92.json](/assets/surah/92.json) | JSON | 90 | 0 | 0 | 90 |
| [assets/surah/93.json](/assets/surah/93.json) | JSON | 60 | 0 | 0 | 60 |
| [assets/surah/94.json](/assets/surah/94.json) | JSON | 51 | 0 | 0 | 51 |
| [assets/surah/95.json](/assets/surah/95.json) | JSON | 51 | 0 | 0 | 51 |
| [assets/surah/96.json](/assets/surah/96.json) | JSON | 84 | 0 | 0 | 84 |
| [assets/surah/97.json](/assets/surah/97.json) | JSON | 42 | 0 | 0 | 42 |
| [assets/surah/98.json](/assets/surah/98.json) | JSON | 51 | 0 | 0 | 51 |
| [assets/surah/99.json](/assets/surah/99.json) | JSON | 51 | 0 | 0 | 51 |
| [assets/surah/asmaul-husna.json](/assets/surah/asmaul-husna.json) | JSON | 697 | 0 | 1 | 698 |
| [assets/surah/ayat-kursi.json](/assets/surah/ayat-kursi.json) | JSON | 8 | 0 | 1 | 9 |
| [assets/surah/doa-harian.json](/assets/surah/doa-harian.json) | JSON | 214 | 0 | 1 | 215 |
| [assets/surah/pola-kerja.json](/assets/surah/pola-kerja.json) | JSON | 135 | 0 | 1 | 136 |
| [assets/surah/surah-info.json](/assets/surah/surah-info.json) | JSON | 1,028 | 0 | 1 | 1,029 |
| [devtools\_options.yaml](/devtools_options.yaml) | YAML | 3 | 0 | 1 | 4 |
| [ios/RunnerTests/RunnerTests.swift](/ios/RunnerTests/RunnerTests.swift) | Swift | 7 | 2 | 4 | 13 |
| [ios/Runner/AppDelegate.swift](/ios/Runner/AppDelegate.swift) | Swift | 12 | 0 | 2 | 14 |
| [ios/Runner/Assets.xcassets/AppIcon.appiconset/Contents.json](/ios/Runner/Assets.xcassets/AppIcon.appiconset/Contents.json) | JSON | 122 | 0 | 1 | 123 |
| [ios/Runner/Assets.xcassets/LaunchImage.imageset/Contents.json](/ios/Runner/Assets.xcassets/LaunchImage.imageset/Contents.json) | JSON | 23 | 0 | 1 | 24 |
| [ios/Runner/Assets.xcassets/LaunchImage.imageset/README.md](/ios/Runner/Assets.xcassets/LaunchImage.imageset/README.md) | Markdown | 3 | 0 | 2 | 5 |
| [ios/Runner/Base.lproj/LaunchScreen.storyboard](/ios/Runner/Base.lproj/LaunchScreen.storyboard) | XML | 36 | 1 | 1 | 38 |
| [ios/Runner/Base.lproj/Main.storyboard](/ios/Runner/Base.lproj/Main.storyboard) | XML | 25 | 1 | 1 | 27 |
| [ios/Runner/Runner-Bridging-Header.h](/ios/Runner/Runner-Bridging-Header.h) | C++ | 1 | 0 | 1 | 2 |
| [lib/Screens/DrawerScreens/AboutApp/about\_app.dart](/lib/Screens/DrawerScreens/AboutApp/about_app.dart) | Dart | 270 | 15 | 9 | 294 |
| [lib/Screens/DrawerScreens/FeedBack/feed\_back\_page.dart](/lib/Screens/DrawerScreens/FeedBack/feed_back_page.dart) | Dart | 237 | 0 | 9 | 246 |
| [lib/Screens/HomeItems/AyatKursi/ayat\_kursi.dart](/lib/Screens/HomeItems/AyatKursi/ayat_kursi.dart) | Dart | 189 | 0 | 15 | 204 |
| [lib/Screens/HomeItems/Bahasht\_Dozax/bahasht\_u\_dozax\_page.dart](/lib/Screens/HomeItems/Bahasht_Dozax/bahasht_u_dozax_page.dart) | Dart | 528 | 3 | 18 | 549 |
| [lib/Screens/HomeItems/Books/book\_page.dart](/lib/Screens/HomeItems/Books/book_page.dart) | Dart | 1,292 | 7 | 32 | 1,331 |
| [lib/Screens/HomeItems/Books/book\_view.dart](/lib/Screens/HomeItems/Books/book_view.dart) | Dart | 279 | 0 | 11 | 290 |
| [lib/Screens/HomeItems/Cherok/cherok\_page.dart](/lib/Screens/HomeItems/Cherok/cherok_page.dart) | Dart | 197 | 0 | 9 | 206 |
| [lib/Screens/HomeItems/Dua/dua\_list.dart](/lib/Screens/HomeItems/Dua/dua_list.dart) | Dart | 223 | 2 | 19 | 244 |
| [lib/Screens/HomeItems/Farmuda/farmuda\_page.dart](/lib/Screens/HomeItems/Farmuda/farmuda_page.dart) | Dart | 200 | 0 | 10 | 210 |
| [lib/Screens/HomeItems/Haramkrawakan/haramkrawan.dart](/lib/Screens/HomeItems/Haramkrawakan/haramkrawan.dart) | Dart | 223 | 2 | 18 | 243 |
| [lib/Screens/HomeItems/HawalanePexambar/hawalane\_pexambar\_page.dart](/lib/Screens/HomeItems/HawalanePexambar/hawalane_pexambar_page.dart) | Dart | 318 | 0 | 17 | 335 |
| [lib/Screens/HomeItems/HijriCalendar/hijri\_calendar\_page.dart](/lib/Screens/HomeItems/HijriCalendar/hijri_calendar_page.dart) | Dart | 261 | 0 | 9 | 270 |
| [lib/Screens/HomeItems/IslamicAI/islamic\_ai\_assistant\_page.dart](/lib/Screens/HomeItems/IslamicAI/islamic_ai_assistant_page.dart) | Dart | 222 | 0 | 4 | 226 |
| [lib/Screens/HomeItems/IslamicAI/islamic\_ai\_chat\_page.dart](/lib/Screens/HomeItems/IslamicAI/islamic_ai_chat_page.dart) | Dart | 619 | 0 | 52 | 671 |
| [lib/Screens/HomeItems/Kafaratakan/kafaratakan.dart](/lib/Screens/HomeItems/Kafaratakan/kafaratakan.dart) | Dart | 292 | 5 | 16 | 313 |
| [lib/Screens/HomeItems/MangeRamazan/mange\_ramazan\_page.dart](/lib/Screens/HomeItems/MangeRamazan/mange_ramazan_page.dart) | Dart | 244 | 0 | 8 | 252 |
| [lib/Screens/HomeItems/MangeRamazan/page\_1.dart](/lib/Screens/HomeItems/MangeRamazan/page_1.dart) | Dart | 144 | 0 | 11 | 155 |
| [lib/Screens/HomeItems/MangeRamazan/ramadan\_tools\_pages.dart](/lib/Screens/HomeItems/MangeRamazan/ramadan_tools_pages.dart) | Dart | 1,464 | 0 | 88 | 1,552 |
| [lib/Screens/HomeItems/NeshanakaneRozheDway/list\_a.dart](/lib/Screens/HomeItems/NeshanakaneRozheDway/list_a.dart) | Dart | 545 | 0 | 10 | 555 |
| [lib/Screens/HomeItems/NeshanakaneRozheDway/list\_b.dart](/lib/Screens/HomeItems/NeshanakaneRozheDway/list_b.dart) | Dart | 256 | 0 | 9 | 265 |
| [lib/Screens/HomeItems/NeshanakaneRozheDway/list\_c.dart](/lib/Screens/HomeItems/NeshanakaneRozheDway/list_c.dart) | Dart | 275 | 0 | 9 | 284 |
| [lib/Screens/HomeItems/NeshanakaneRozheDway/list\_d.dart](/lib/Screens/HomeItems/NeshanakaneRozheDway/list_d.dart) | Dart | 443 | 0 | 8 | 451 |
| [lib/Screens/HomeItems/NeshanakaneRozheDway/list\_e.dart](/lib/Screens/HomeItems/NeshanakaneRozheDway/list_e.dart) | Dart | 263 | 0 | 8 | 271 |
| [lib/Screens/HomeItems/NeshanakaneRozheDway/list\_f.dart](/lib/Screens/HomeItems/NeshanakaneRozheDway/list_f.dart) | Dart | 212 | 0 | 8 | 220 |
| [lib/Screens/HomeItems/NeshanakaneRozheDway/list\_g.dart](/lib/Screens/HomeItems/NeshanakaneRozheDway/list_g.dart) | Dart | 208 | 0 | 8 | 216 |
| [lib/Screens/HomeItems/NeshanakaneRozheDway/list\_h.dart](/lib/Screens/HomeItems/NeshanakaneRozheDway/list_h.dart) | Dart | 218 | 0 | 10 | 228 |
| [lib/Screens/HomeItems/NeshanakaneRozheDway/list\_i.dart](/lib/Screens/HomeItems/NeshanakaneRozheDway/list_i.dart) | Dart | 212 | 0 | 10 | 222 |
| [lib/Screens/HomeItems/NeshanakaneRozheDway/list\_j.dart](/lib/Screens/HomeItems/NeshanakaneRozheDway/list_j.dart) | Dart | 202 | 0 | 8 | 210 |
| [lib/Screens/HomeItems/NeshanakaneRozheDway/neshanakane\_rozhe\_dway.dart](/lib/Screens/HomeItems/NeshanakaneRozheDway/neshanakane_rozhe_dway.dart) | Dart | 303 | 0 | 9 | 312 |
| [lib/Screens/HomeItems/Nwezhkrdn/bangdan.dart](/lib/Screens/HomeItems/Nwezhkrdn/bangdan.dart) | Dart | 102 | 0 | 9 | 111 |
| [lib/Screens/HomeItems/Nwezhkrdn/batalkary\_nwezh.dart](/lib/Screens/HomeItems/Nwezhkrdn/batalkary_nwezh.dart) | Dart | 120 | 0 | 11 | 131 |
| [lib/Screens/HomeItems/Nwezhkrdn/chunasar\_aw.dart](/lib/Screens/HomeItems/Nwezhkrdn/chunasar_aw.dart) | Dart | 138 | 0 | 6 | 144 |
| [lib/Screens/HomeItems/Nwezhkrdn/dastnwezh.dart](/lib/Screens/HomeItems/Nwezhkrdn/dastnwezh.dart) | Dart | 904 | 1 | 11 | 916 |
| [lib/Screens/HomeItems/Nwezhkrdn/hala\_bawakan.dart](/lib/Screens/HomeItems/Nwezhkrdn/hala_bawakan.dart) | Dart | 144 | 0 | 5 | 149 |
| [lib/Screens/HomeItems/Nwezhkrdn/j\_nwezhakan.dart](/lib/Screens/HomeItems/Nwezhkrdn/j_nwezhakan.dart) | Dart | 71 | 0 | 5 | 76 |
| [lib/Screens/HomeItems/Nwezhkrdn/manay\_nwezh.dart](/lib/Screens/HomeItems/Nwezhkrdn/manay_nwezh.dart) | Dart | 218 | 0 | 10 | 228 |
| [lib/Screens/HomeItems/Nwezhkrdn/manay\_tahyat.dart](/lib/Screens/HomeItems/Nwezhkrdn/manay_tahyat.dart) | Dart | 122 | 0 | 7 | 129 |
| [lib/Screens/HomeItems/Nwezhkrdn/nwezh.dart](/lib/Screens/HomeItems/Nwezhkrdn/nwezh.dart) | Dart | 538 | 0 | 7 | 545 |
| [lib/Screens/HomeItems/Nwezhkrdn/nwezh\_page.dart](/lib/Screens/HomeItems/Nwezhkrdn/nwezh_page.dart) | Dart | 438 | 3 | 11 | 452 |
| [lib/Screens/HomeItems/Nwezhkrdn/q\_nwezh.dart](/lib/Screens/HomeItems/Nwezhkrdn/q_nwezh.dart) | Dart | 213 | 0 | 11 | 224 |
| [lib/Screens/HomeItems/Nwezhkrdn/qdast\_nwezh.dart](/lib/Screens/HomeItems/Nwezhkrdn/qdast_nwezh.dart) | Dart | 157 | 0 | 13 | 170 |
| [lib/Screens/HomeItems/Nwezhkrdn/tayamum.dart](/lib/Screens/HomeItems/Nwezhkrdn/tayamum.dart) | Dart | 443 | 4 | 8 | 455 |
| [lib/Screens/HomeItems/PayakaneEmanIslam/ArkakaneEman/arkakane\_eman.dart](/lib/Screens/HomeItems/PayakaneEmanIslam/ArkakaneEman/arkakane_eman.dart) | Dart | 272 | 0 | 9 | 281 |
| [lib/Screens/HomeItems/PayakaneEmanIslam/ArkakaneEman/pages/bawarbun\_bafreshta.dart](/lib/Screens/HomeItems/PayakaneEmanIslam/ArkakaneEman/pages/bawarbun_bafreshta.dart) | Dart | 146 | 0 | 9 | 155 |
| [lib/Screens/HomeItems/PayakaneEmanIslam/ArkakaneEman/pages/bawarbun\_baktebe\_asmane.dart](/lib/Screens/HomeItems/PayakaneEmanIslam/ArkakaneEman/pages/bawarbun_baktebe_asmane.dart) | Dart | 139 | 0 | 9 | 148 |
| [lib/Screens/HomeItems/PayakaneEmanIslam/ArkakaneEman/pages/bawarbun\_bapexambaran.dart](/lib/Screens/HomeItems/PayakaneEmanIslam/ArkakaneEman/pages/bawarbun_bapexambaran.dart) | Dart | 125 | 0 | 10 | 135 |
| [lib/Screens/HomeItems/PayakaneEmanIslam/ArkakaneEman/pages/bawarbun\_baqadar.dart](/lib/Screens/HomeItems/PayakaneEmanIslam/ArkakaneEman/pages/bawarbun_baqadar.dart) | Dart | 121 | 0 | 9 | 130 |
| [lib/Screens/HomeItems/PayakaneEmanIslam/ArkakaneEman/pages/bawarbun\_barozhedway.dart](/lib/Screens/HomeItems/PayakaneEmanIslam/ArkakaneEman/pages/bawarbun_barozhedway.dart) | Dart | 133 | 0 | 9 | 142 |
| [lib/Screens/HomeItems/PayakaneEmanIslam/ArkakaneEman/pages/bawarnun\_baxwda.dart](/lib/Screens/HomeItems/PayakaneEmanIslam/ArkakaneEman/pages/bawarnun_baxwda.dart) | Dart | 122 | 0 | 9 | 131 |
| [lib/Screens/HomeItems/PayakaneEmanIslam/ArkakaneEman/pages/payakane\_bawar.dart](/lib/Screens/HomeItems/PayakaneEmanIslam/ArkakaneEman/pages/payakane_bawar.dart) | Dart | 115 | 0 | 10 | 125 |
| [lib/Screens/HomeItems/PayakaneEmanIslam/ArkakaneIslam/arkakane\_islam.dart](/lib/Screens/HomeItems/PayakaneEmanIslam/ArkakaneIslam/arkakane_islam.dart) | Dart | 252 | 0 | 8 | 260 |
| [lib/Screens/HomeItems/PayakaneEmanIslam/ArkakaneIslam/pages/haj.dart](/lib/Screens/HomeItems/PayakaneEmanIslam/ArkakaneIslam/pages/haj.dart) | Dart | 139 | 0 | 9 | 148 |
| [lib/Screens/HomeItems/PayakaneEmanIslam/ArkakaneIslam/pages/nwezh.dart](/lib/Screens/HomeItems/PayakaneEmanIslam/ArkakaneIslam/pages/nwezh.dart) | Dart | 126 | 0 | 9 | 135 |
| [lib/Screens/HomeItems/PayakaneEmanIslam/ArkakaneIslam/pages/rozhugrtn.dart](/lib/Screens/HomeItems/PayakaneEmanIslam/ArkakaneIslam/pages/rozhugrtn.dart) | Dart | 147 | 0 | 9 | 156 |
| [lib/Screens/HomeItems/PayakaneEmanIslam/ArkakaneIslam/pages/shayatman.dart](/lib/Screens/HomeItems/PayakaneEmanIslam/ArkakaneIslam/pages/shayatman.dart) | Dart | 128 | 0 | 9 | 137 |
| [lib/Screens/HomeItems/PayakaneEmanIslam/ArkakaneIslam/pages/zakat.dart](/lib/Screens/HomeItems/PayakaneEmanIslam/ArkakaneIslam/pages/zakat.dart) | Dart | 155 | 0 | 9 | 164 |
| [lib/Screens/HomeItems/PayakaneEmanIslam/payakane\_eman\_islam.dart](/lib/Screens/HomeItems/PayakaneEmanIslam/payakane_eman_islam.dart) | Dart | 205 | 0 | 7 | 212 |
| [lib/Screens/HomeItems/Pexambarman/page1.dart](/lib/Screens/HomeItems/Pexambarman/page1.dart) | Dart | 133 | 0 | 10 | 143 |
| [lib/Screens/HomeItems/Pexambarman/page2.dart](/lib/Screens/HomeItems/Pexambarman/page2.dart) | Dart | 133 | 0 | 10 | 143 |
| [lib/Screens/HomeItems/Pexambarman/page\_view.dart](/lib/Screens/HomeItems/Pexambarman/page_view.dart) | Dart | 338 | 1 | 12 | 351 |
| [lib/Screens/HomeItems/Pexambarman/zhyan\_namay\_pexambarman.dart](/lib/Screens/HomeItems/Pexambarman/zhyan_namay_pexambarman.dart) | Dart | 188 | 0 | 7 | 195 |
| [lib/Screens/HomeItems/PrsyarWakamAyne/prsyar\_walam\_ayne.dart](/lib/Screens/HomeItems/PrsyarWakamAyne/prsyar_walam_ayne.dart) | Dart | 235 | 2 | 18 | 255 |
| [lib/Screens/HomeItems/PrsyarWalamRozheDway/prsyar\_list.dart](/lib/Screens/HomeItems/PrsyarWalamRozheDway/prsyar_list.dart) | Dart | 129 | 0 | 12 | 141 |
| [lib/Screens/HomeItems/PrsyarWalamRozheDway/prsyar\_walam\_rozhe\_dway.dart](/lib/Screens/HomeItems/PrsyarWalamRozheDway/prsyar_walam_rozhe_dway.dart) | Dart | 251 | 0 | 9 | 260 |
| [lib/Screens/HomeItems/PuxtaySaheheMuslim/p\_s\_m\_lists.dart](/lib/Screens/HomeItems/PuxtaySaheheMuslim/p_s_m_lists.dart) | Dart | 247 | 2 | 18 | 267 |
| [lib/Screens/HomeItems/PuxtaySaheheMuslim/puxtay\_sahehe\_muslim.dart](/lib/Screens/HomeItems/PuxtaySaheheMuslim/puxtay_sahehe_muslim.dart) | Dart | 195 | 7 | 8 | 210 |
| [lib/Screens/HomeItems/QiblaFinder/qibla\_finder\_page.dart](/lib/Screens/HomeItems/QiblaFinder/qibla_finder_page.dart) | Dart | 726 | 0 | 44 | 770 |
| [lib/Screens/HomeItems/Qurani Piroz/data/models/allsurah.dart](/lib/Screens/HomeItems/Qurani%20Piroz/data/models/allsurah.dart) | Dart | 41 | 0 | 6 | 47 |
| [lib/Screens/HomeItems/Qurani Piroz/data/models/quran\_meta.dart](/lib/Screens/HomeItems/Qurani%20Piroz/data/models/quran_meta.dart) | Dart | 58 | 0 | 9 | 67 |
| [lib/Screens/HomeItems/Qurani Piroz/data/models/quran\_rich\_surah.dart](/lib/Screens/HomeItems/Qurani%20Piroz/data/models/quran_rich_surah.dart) | Dart | 70 | 0 | 7 | 77 |
| [lib/Screens/HomeItems/Qurani Piroz/data/models/surahinfo.dart](/lib/Screens/HomeItems/Qurani%20Piroz/data/models/surahinfo.dart) | Dart | 41 | 0 | 7 | 48 |
| [lib/Screens/HomeItems/Qurani Piroz/data/services.dart](/lib/Screens/HomeItems/Qurani%20Piroz/data/services.dart) | Dart | 485 | 1 | 46 | 532 |
| [lib/Screens/HomeItems/Qurani Piroz/quran\_page.dart](/lib/Screens/HomeItems/Qurani%20Piroz/quran_page.dart) | Dart | 1,388 | 0 | 88 | 1,476 |
| [lib/Screens/HomeItems/Qurani Piroz/ui/detail\_surah.dart](/lib/Screens/HomeItems/Qurani%20Piroz/ui/detail_surah.dart) | Dart | 2,561 | 0 | 93 | 2,654 |
| [lib/Screens/HomeItems/Qurani Piroz/widgets/ayah\_action\_sheet.dart](/lib/Screens/HomeItems/Qurani%20Piroz/widgets/ayah_action_sheet.dart) | Dart | 184 | 0 | 7 | 191 |
| [lib/Screens/HomeItems/Qurani Piroz/widgets/ayah\_card.dart](/lib/Screens/HomeItems/Qurani%20Piroz/widgets/ayah_card.dart) | Dart | 278 | 0 | 19 | 297 |
| [lib/Screens/HomeItems/Qurani Piroz/widgets/quran\_player\_full\_sheet.dart](/lib/Screens/HomeItems/Qurani%20Piroz/widgets/quran_player_full_sheet.dart) | Dart | 329 | 0 | 9 | 338 |
| [lib/Screens/HomeItems/Qurani Piroz/widgets/quran\_player\_mini\_bar.dart](/lib/Screens/HomeItems/Qurani%20Piroz/widgets/quran_player_mini_bar.dart) | Dart | 119 | 0 | 4 | 123 |
| [lib/Screens/HomeItems/Qurani Piroz/widgets/reciter\_picker\_sheet.dart](/lib/Screens/HomeItems/Qurani%20Piroz/widgets/reciter_picker_sheet.dart) | Dart | 127 | 0 | 5 | 132 |
| [lib/Screens/HomeItems/Qurani Piroz/widgets/surah\_header.dart](/lib/Screens/HomeItems/Qurani%20Piroz/widgets/surah_header.dart) | Dart | 163 | 0 | 7 | 170 |
| [lib/Screens/HomeItems/Sunatakan/sunatakan.dart](/lib/Screens/HomeItems/Sunatakan/sunatakan.dart) | Dart | 143 | 0 | 11 | 154 |
| [lib/Screens/HomeItems/Taqekrdnawa/Walamakan/walamakan.dart](/lib/Screens/HomeItems/Taqekrdnawa/Walamakan/walamakan.dart) | Dart | 335 | 7 | 8 | 350 |
| [lib/Screens/HomeItems/Taqekrdnawa/quiz/components/body.dart](/lib/Screens/HomeItems/Taqekrdnawa/quiz/components/body.dart) | Dart | 81 | 2 | 5 | 88 |
| [lib/Screens/HomeItems/Taqekrdnawa/quiz/components/option.dart](/lib/Screens/HomeItems/Taqekrdnawa/quiz/components/option.dart) | Dart | 93 | 0 | 7 | 100 |
| [lib/Screens/HomeItems/Taqekrdnawa/quiz/components/progress\_bar.dart](/lib/Screens/HomeItems/Taqekrdnawa/quiz/components/progress_bar.dart) | Dart | 71 | 3 | 5 | 79 |
| [lib/Screens/HomeItems/Taqekrdnawa/quiz/components/question\_card.dart](/lib/Screens/HomeItems/Taqekrdnawa/quiz/components/question_card.dart) | Dart | 59 | 1 | 6 | 66 |
| [lib/Screens/HomeItems/Taqekrdnawa/quiz/quiz\_screen.dart](/lib/Screens/HomeItems/Taqekrdnawa/quiz/quiz_screen.dart) | Dart | 26 | 0 | 3 | 29 |
| [lib/Screens/HomeItems/Taqekrdnawa/score/score\_screen.dart](/lib/Screens/HomeItems/Taqekrdnawa/score/score_screen.dart) | Dart | 107 | 0 | 5 | 112 |
| [lib/Screens/HomeItems/Taqekrdnawa/welcome/welcome\_screen.dart](/lib/Screens/HomeItems/Taqekrdnawa/welcome/welcome_screen.dart) | Dart | 144 | 0 | 8 | 152 |
| [lib/Screens/HomeItems/Tasbeeh/check\_database.dart](/lib/Screens/HomeItems/Tasbeeh/check_database.dart) | Dart | 24 | 0 | 3 | 27 |
| [lib/Screens/HomeItems/Tasbeeh/loading.dart](/lib/Screens/HomeItems/Tasbeeh/loading.dart) | Dart | 21 | 0 | 3 | 24 |
| [lib/Screens/HomeItems/Tasbeeh/pages/sebha/items\_sebha.dart](/lib/Screens/HomeItems/Tasbeeh/pages/sebha/items_sebha.dart) | Dart | 149 | 0 | 8 | 157 |
| [lib/Screens/HomeItems/Tasbeeh/pages/sebha/tasbih\_page.dart](/lib/Screens/HomeItems/Tasbeeh/pages/sebha/tasbih_page.dart) | Dart | 320 | 0 | 16 | 336 |
| [lib/Screens/HomeItems/TawanaGawrakan/tawana\_gawrakan\_page.dart](/lib/Screens/HomeItems/TawanaGawrakan/tawana_gawrakan_page.dart) | Dart | 140 | 0 | 10 | 150 |
| [lib/Screens/HomeItems/WtawAmozhgary/wtaw\_amozhgare.dart](/lib/Screens/HomeItems/WtawAmozhgary/wtaw_amozhgare.dart) | Dart | 261 | 0 | 12 | 273 |
| [lib/Screens/HomeItems/ZakatCalculator/zakat\_calculator\_page.dart](/lib/Screens/HomeItems/ZakatCalculator/zakat_calculator_page.dart) | Dart | 715 | 0 | 36 | 751 |
| [lib/Screens/HomeItems/ZanyareQuran/zanyare\_quran\_page.dart](/lib/Screens/HomeItems/ZanyareQuran/zanyare_quran_page.dart) | Dart | 321 | 0 | 17 | 338 |
| [lib/Screens/HomeItems/Zekrakan/zekrakan.dart](/lib/Screens/HomeItems/Zekrakan/zekrakan.dart) | Dart | 228 | 2 | 19 | 249 |
| [lib/Screens/HomeItems/ZhyanNamayPexambaran/zh\_pexambaran.dart](/lib/Screens/HomeItems/ZhyanNamayPexambaran/zh_pexambaran.dart) | Dart | 232 | 1 | 18 | 251 |
| [lib/Screens/HomeItems/nawakany\_xuday\_gawra/allah\_names.dart](/lib/Screens/HomeItems/nawakany_xuday_gawra/allah_names.dart) | Dart | 594 | 0 | 30 | 624 |
| [lib/Screens/mainScreens/all\_items.dart](/lib/Screens/mainScreens/all_items.dart) | Dart | 693 | 19 | 18 | 730 |
| [lib/Screens/mainScreens/home\_page.dart](/lib/Screens/mainScreens/home_page.dart) | Dart | 169 | 0 | 12 | 181 |
| [lib/Screens/mainScreens/loading\_page.dart](/lib/Screens/mainScreens/loading_page.dart) | Dart | 20 | 0 | 4 | 24 |
| [lib/Screens/mainScreens/widget/about\_me\_widget.dart](/lib/Screens/mainScreens/widget/about_me_widget.dart) | Dart | 258 | 0 | 10 | 268 |
| [lib/Screens/mainScreens/widget/home\_widget.dart](/lib/Screens/mainScreens/widget/home_widget.dart) | Dart | 1,013 | 0 | 35 | 1,048 |
| [lib/Screens/mainScreens/widget/notifications\_screen.dart](/lib/Screens/mainScreens/widget/notifications_screen.dart) | Dart | 0 | 0 | 1 | 1 |
| [lib/Screens/mainScreens/widget/prayer\_times\_screen.dart](/lib/Screens/mainScreens/widget/prayer_times_screen.dart) | Dart | 1,760 | 1 | 125 | 1,886 |
| [lib/Screens/mainScreens/widget/profile\_screen.dart](/lib/Screens/mainScreens/widget/profile_screen.dart) | Dart | 124 | 0 | 10 | 134 |
| [lib/Screens/mainScreens/widget/settings\_widget.dart](/lib/Screens/mainScreens/widget/settings_widget.dart) | Dart | 1,206 | 0 | 36 | 1,242 |
| [lib/bottom\_navigation\_view/bottom\_bar\_view.dart](/lib/bottom_navigation_view/bottom_bar_view.dart) | Dart | 216 | 0 | 17 | 233 |
| [lib/bottom\_navigation\_view/tab\_icon\_data.dart](/lib/bottom_navigation_view/tab_icon_data.dart) | Dart | 34 | 0 | 3 | 37 |
| [lib/controller/question\_controller.dart](/lib/controller/question_controller.dart) | Dart | 75 | 18 | 22 | 115 |
| [lib/database/database\_helper.dart](/lib/database/database_helper.dart) | Dart | 203 | 9 | 53 | 265 |
| [lib/main.dart](/lib/main.dart) | Dart | 111 | 58 | 12 | 181 |
| [lib/models/allah\_names\_model.dart](/lib/models/allah_names_model.dart) | Dart | 21 | 0 | 5 | 26 |
| [lib/models/book\_model.dart](/lib/models/book_model.dart) | Dart | 5 | 0 | 2 | 7 |
| [lib/models/cherok\_model.dart](/lib/models/cherok_model.dart) | Dart | 18 | 0 | 3 | 21 |
| [lib/models/dua\_model.dart](/lib/models/dua_model.dart) | Dart | 8 | 0 | 3 | 11 |
| [lib/models/farmuda\_model.dart](/lib/models/farmuda_model.dart) | Dart | 24 | 0 | 3 | 27 |
| [lib/models/muhjizakan.dart](/lib/models/muhjizakan.dart) | Dart | 8 | 0 | 3 | 11 |
| [lib/models/prsyarakan\_model.dart](/lib/models/prsyarakan_model.dart) | Dart | 17 | 0 | 3 | 20 |
| [lib/models/puxtay\_sahehe\_muslim\_model.dart](/lib/models/puxtay_sahehe_muslim_model.dart) | Dart | 13 | 0 | 3 | 16 |
| [lib/models/questions.dart](/lib/models/questions.dart) | Dart | 229 | 11 | 3 | 243 |
| [lib/models/qyamat\_model.dart](/lib/models/qyamat_model.dart) | Dart | 13 | 0 | 3 | 16 |
| [lib/models/ramazan\_model.dart](/lib/models/ramazan_model.dart) | Dart | 5 | 0 | 2 | 7 |
| [lib/models/sebha\_model.dart](/lib/models/sebha_model.dart) | Dart | 40 | 0 | 12 | 52 |
| [lib/models/section\_model.dart](/lib/models/section_model.dart) | Dart | 19 | 0 | 6 | 25 |
| [lib/models/settings\_model.dart](/lib/models/settings_model.dart) | Dart | 59 | 0 | 16 | 75 |
| [lib/models/tawanakan\_model.dart](/lib/models/tawanakan_model.dart) | Dart | 8 | 0 | 3 | 11 |
| [lib/models/wtaw\_amozhgare.dart](/lib/models/wtaw_amozhgare.dart) | Dart | 7 | 0 | 3 | 10 |
| [lib/models/xawnama\_model.dart](/lib/models/xawnama_model.dart) | Dart | 13 | 0 | 3 | 16 |
| [lib/models/zekr\_model.dart](/lib/models/zekr_model.dart) | Dart | 8 | 0 | 3 | 11 |
| [lib/models/zhayanama\_model.dart](/lib/models/zhayanama_model.dart) | Dart | 8 | 0 | 3 | 11 |
| [lib/providers/quran\_state\_provider.dart](/lib/providers/quran_state_provider.dart) | Dart | 563 | 0 | 69 | 632 |
| [lib/providers/sebha\_provider.dart](/lib/providers/sebha_provider.dart) | Dart | 93 | 0 | 17 | 110 |
| [lib/providers/sections\_provider.dart](/lib/providers/sections_provider.dart) | Dart | 66 | 0 | 20 | 86 |
| [lib/providers/settings\_provider.dart](/lib/providers/settings_provider.dart) | Dart | 93 | 0 | 20 | 113 |
| [lib/providers/theme\_provider.dart](/lib/providers/theme_provider.dart) | Dart | 36 | 0 | 9 | 45 |
| [lib/services/adhan\_alarm\_service.dart](/lib/services/adhan_alarm_service.dart) | Dart | 178 | 0 | 25 | 203 |
| [lib/services/gemini\_ai\_service.dart](/lib/services/gemini_ai_service.dart) | Dart | 225 | 1 | 43 | 269 |
| [lib/services/prayer\_home\_widget\_service.dart](/lib/services/prayer_home_widget_service.dart) | Dart | 39 | 0 | 3 | 42 |
| [lib/services/zikr\_notification\_service.dart](/lib/services/zikr_notification_service.dart) | Dart | 52 | 0 | 9 | 61 |
| [lib/theme/theme.dart](/lib/theme/theme.dart) | Dart | 139 | 0 | 6 | 145 |
| [lib/util/animation\_helper.dart](/lib/util/animation_helper.dart) | Dart | 119 | 0 | 14 | 133 |
| [lib/util/background.dart](/lib/util/background.dart) | Dart | 101 | 0 | 15 | 116 |
| [lib/util/constans.dart](/lib/util/constans.dart) | Dart | 75 | 0 | 13 | 88 |
| [lib/util/grid\_card.dart](/lib/util/grid_card.dart) | Dart | 95 | 0 | 7 | 102 |
| [lib/util/item\_list.dart](/lib/util/item_list.dart) | Dart | 223 | 0 | 14 | 237 |
| [lib/util/kurdish\_fallback\_cupertino\_delegate.dart](/lib/util/kurdish_fallback_cupertino_delegate.dart) | Dart | 18 | 5 | 5 | 28 |
| [lib/util/navigate\_between\_pages/fade\_route.dart](/lib/util/navigate_between_pages/fade_route.dart) | Dart | 41 | 0 | 2 | 43 |
| [lib/util/navigate\_between\_pages/scale\_route.dart](/lib/util/navigate_between_pages/scale_route.dart) | Dart | 28 | 0 | 2 | 30 |
| [lib/util/navigate\_between\_pages/size\_route.dart](/lib/util/navigate_between_pages/size_route.dart) | Dart | 31 | 0 | 2 | 33 |
| [lib/util/navigate\_between\_pages/slide\_route.dart](/lib/util/navigate_between_pages/slide_route.dart) | Dart | 122 | 0 | 5 | 127 |
| [lib/util/scale\_in.dart](/lib/util/scale_in.dart) | Dart | 23 | 0 | 2 | 25 |
| [lib/widgets/Profile/radial\_progress.dart](/lib/widgets/Profile/radial_progress.dart) | Dart | 93 | 0 | 17 | 110 |
| [lib/widgets/carousel\_slider\_widget.dart](/lib/widgets/carousel_slider_widget.dart) | Dart | 168 | 0 | 10 | 178 |
| [lib/widgets/custom\_list\_tile.dart](/lib/widgets/custom_list_tile.dart) | Dart | 85 | 0 | 4 | 89 |
| [lib/widgets/general\_search\_delegate.dart](/lib/widgets/general_search_delegate.dart) | Dart | 266 | 0 | 16 | 282 |
| [lib/widgets/nwezh/balga.dart](/lib/widgets/nwezh/balga.dart) | Dart | 250 | 0 | 20 | 270 |
| [lib/widgets/nwezh/header\_nwezh.dart](/lib/widgets/nwezh/header_nwezh.dart) | Dart | 46 | 0 | 8 | 54 |
| [lib/widgets/premium\_drawer.dart](/lib/widgets/premium_drawer.dart) | Dart | 227 | 0 | 15 | 242 |
| [lib/widgets/quran\_list\_widget.dart](/lib/widgets/quran_list_widget.dart) | Dart | 84 | 0 | 9 | 93 |
| [lib/widgets/sebha\_widget/add\_tasbih\_dialog.dart](/lib/widgets/sebha_widget/add_tasbih_dialog.dart) | Dart | 74 | 0 | 8 | 82 |
| [lib/widgets/sebha\_widget/button\_drag.dart](/lib/widgets/sebha_widget/button_drag.dart) | Dart | 101 | 0 | 10 | 111 |
| [lib/widgets/sebha\_widget/delete\_dialog.dart](/lib/widgets/sebha_widget/delete_dialog.dart) | Dart | 108 | 0 | 11 | 119 |
| [lib/widgets/sebha\_widget/edit\_tasbih\_dialog.dart](/lib/widgets/sebha_widget/edit_tasbih_dialog.dart) | Dart | 71 | 0 | 9 | 80 |
| [lib/widgets/sebha\_widget/expansion\_tile\_sebha.dart](/lib/widgets/sebha_widget/expansion_tile_sebha.dart) | Dart | 109 | 1 | 16 | 126 |
| [lib/widgets/sebha\_widget/pop\_up\_menu.dart](/lib/widgets/sebha_widget/pop_up_menu.dart) | Dart | 140 | 0 | 9 | 149 |
| [lib/widgets/sebha\_widget/tasbih.dart](/lib/widgets/sebha_widget/tasbih.dart) | Dart | 157 | 0 | 13 | 170 |
| [lib/widgets/sebha\_widget/tasbih\_fields/row\_button\_dialog.dart](/lib/widgets/sebha_widget/tasbih_fields/row_button_dialog.dart) | Dart | 75 | 0 | 7 | 82 |
| [lib/widgets/sebha\_widget/tasbih\_fields/tasbih\_form.dart](/lib/widgets/sebha_widget/tasbih_fields/tasbih_form.dart) | Dart | 119 | 0 | 12 | 131 |
| [lib/widgets/sebha\_widget/tasbih\_fields/tasbih\_text\_field.dart](/lib/widgets/sebha_widget/tasbih_fields/tasbih_text_field.dart) | Dart | 89 | 0 | 9 | 98 |
| [linux/CMakeLists.txt](/linux/CMakeLists.txt) | CMake | 104 | 0 | 25 | 129 |
| [linux/flutter/CMakeLists.txt](/linux/flutter/CMakeLists.txt) | CMake | 79 | 0 | 10 | 89 |
| [linux/flutter/generated\_plugin\_registrant.cc](/linux/flutter/generated_plugin_registrant.cc) | C++ | 7 | 4 | 5 | 16 |
| [linux/flutter/generated\_plugin\_registrant.h](/linux/flutter/generated_plugin_registrant.h) | C++ | 5 | 5 | 6 | 16 |
| [linux/flutter/generated\_plugins.cmake](/linux/flutter/generated_plugins.cmake) | CMake | 19 | 0 | 6 | 25 |
| [linux/runner/CMakeLists.txt](/linux/runner/CMakeLists.txt) | CMake | 21 | 0 | 6 | 27 |
| [linux/runner/main.cc](/linux/runner/main.cc) | C++ | 5 | 0 | 2 | 7 |
| [linux/runner/my\_application.cc](/linux/runner/my_application.cc) | C++ | 94 | 26 | 29 | 149 |
| [linux/runner/my\_application.h](/linux/runner/my_application.h) | C++ | 10 | 7 | 5 | 22 |
| [macos/Flutter/GeneratedPluginRegistrant.swift](/macos/Flutter/GeneratedPluginRegistrant.swift) | Swift | 24 | 3 | 4 | 31 |
| [macos/RunnerTests/RunnerTests.swift](/macos/RunnerTests/RunnerTests.swift) | Swift | 7 | 2 | 4 | 13 |
| [macos/Runner/AppDelegate.swift](/macos/Runner/AppDelegate.swift) | Swift | 11 | 0 | 3 | 14 |
| [macos/Runner/Assets.xcassets/AppIcon.appiconset/Contents.json](/macos/Runner/Assets.xcassets/AppIcon.appiconset/Contents.json) | JSON | 68 | 0 | 1 | 69 |
| [macos/Runner/Base.lproj/MainMenu.xib](/macos/Runner/Base.lproj/MainMenu.xib) | XML | 343 | 0 | 1 | 344 |
| [macos/Runner/MainFlutterWindow.swift](/macos/Runner/MainFlutterWindow.swift) | Swift | 12 | 0 | 4 | 16 |
| [pubspec.yaml](/pubspec.yaml) | YAML | 147 | 35 | 35 | 217 |
| [test/widget\_test.dart](/test/widget_test.dart) | Dart | 12 | 0 | 4 | 16 |
| [web/index.html](/web/index.html) | HTML | 19 | 15 | 5 | 39 |
| [web/manifest.json](/web/manifest.json) | JSON | 35 | 0 | 1 | 36 |
| [windows/CMakeLists.txt](/windows/CMakeLists.txt) | CMake | 89 | 0 | 20 | 109 |
| [windows/flutter/CMakeLists.txt](/windows/flutter/CMakeLists.txt) | CMake | 98 | 0 | 12 | 110 |
| [windows/flutter/generated\_plugin\_registrant.cc](/windows/flutter/generated_plugin_registrant.cc) | C++ | 21 | 4 | 5 | 30 |
| [windows/flutter/generated\_plugin\_registrant.h](/windows/flutter/generated_plugin_registrant.h) | C++ | 5 | 5 | 6 | 16 |
| [windows/flutter/generated\_plugins.cmake](/windows/flutter/generated_plugins.cmake) | CMake | 24 | 0 | 6 | 30 |
| [windows/runner/CMakeLists.txt](/windows/runner/CMakeLists.txt) | CMake | 34 | 0 | 7 | 41 |
| [windows/runner/flutter\_window.cpp](/windows/runner/flutter_window.cpp) | C++ | 49 | 7 | 16 | 72 |
| [windows/runner/flutter\_window.h](/windows/runner/flutter_window.h) | C++ | 20 | 5 | 9 | 34 |
| [windows/runner/main.cpp](/windows/runner/main.cpp) | C++ | 30 | 4 | 10 | 44 |
| [windows/runner/resource.h](/windows/runner/resource.h) | C++ | 9 | 6 | 2 | 17 |
| [windows/runner/utils.cpp](/windows/runner/utils.cpp) | C++ | 54 | 2 | 10 | 66 |
| [windows/runner/utils.h](/windows/runner/utils.h) | C++ | 8 | 6 | 6 | 20 |
| [windows/runner/win32\_window.cpp](/windows/runner/win32_window.cpp) | C++ | 210 | 24 | 55 | 289 |
| [windows/runner/win32\_window.h](/windows/runner/win32_window.h) | C++ | 48 | 31 | 24 | 103 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\README.md](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5CREADME.md) | Markdown | -10 | 0 | -7 | -17 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\analysis\_options.yaml](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Canalysis_options.yaml) | YAML | -3 | -22 | -4 | -29 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\android\\app\\src\\debug\\AndroidManifest.xml](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Candroid%5Capp%5Csrc%5Cdebug%5CAndroidManifest.xml) | XML | -3 | -4 | -1 | -8 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\android\\app\\src\\main\\AndroidManifest.xml](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Candroid%5Capp%5Csrc%5Cmain%5CAndroidManifest.xml) | XML | -34 | -11 | -1 | -46 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\android\\app\\src\\main\\res\\drawable-v21\\launch\_background.xml](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Candroid%5Capp%5Csrc%5Cmain%5Cres%5Cdrawable-v21%5Claunch_background.xml) | XML | -4 | -7 | -2 | -13 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\android\\app\\src\\main\\res\\drawable\\launch\_background.xml](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Candroid%5Capp%5Csrc%5Cmain%5Cres%5Cdrawable%5Claunch_background.xml) | XML | -4 | -7 | -2 | -13 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\android\\app\\src\\main\\res\\values-night\\styles.xml](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Candroid%5Capp%5Csrc%5Cmain%5Cres%5Cvalues-night%5Cstyles.xml) | XML | -9 | -9 | -1 | -19 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\android\\app\\src\\main\\res\\values\\styles.xml](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Candroid%5Capp%5Csrc%5Cmain%5Cres%5Cvalues%5Cstyles.xml) | XML | -9 | -9 | -1 | -19 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\android\\app\\src\\profile\\AndroidManifest.xml](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Candroid%5Capp%5Csrc%5Cprofile%5CAndroidManifest.xml) | XML | -3 | -4 | -1 | -8 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\android\\gradle.properties](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Candroid%5Cgradle.properties) | Properties | -2 | 0 | -1 | -3 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\android\\gradle\\wrapper\\gradle-wrapper.properties](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Candroid%5Cgradle%5Cwrapper%5Cgradle-wrapper.properties) | Properties | -5 | 0 | -1 | -6 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\assets\\icons\\allah-word.svg](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Cassets%5Cicons%5Callah-word.svg) | XML | -1 | 0 | 0 | -1 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\assets\\icons\\books.svg](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Cassets%5Cicons%5Cbooks.svg) | XML | -1 | 0 | 0 | -1 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\assets\\icons\\calendar.svg](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Cassets%5Cicons%5Ccalendar.svg) | XML | -1 | 0 | 0 | -1 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\assets\\icons\\cherok.svg](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Cassets%5Cicons%5Ccherok.svg) | XML | -67 | 0 | 0 | -67 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\assets\\icons\\contact.svg](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Cassets%5Cicons%5Ccontact.svg) | XML | -2 | 0 | -1 | -3 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\assets\\icons\\dream.svg](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Cassets%5Cicons%5Cdream.svg) | XML | -1 | 0 | 0 | -1 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\assets\\icons\\dua.svg](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Cassets%5Cicons%5Cdua.svg) | XML | -1 | 0 | 0 | -1 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\assets\\icons\\exit.svg](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Cassets%5Cicons%5Cexit.svg) | XML | -2 | 0 | -1 | -3 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\assets\\icons\\facebook.svg](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Cassets%5Cicons%5Cfacebook.svg) | XML | -1 | 0 | 0 | -1 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\assets\\icons\\haram.svg](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Cassets%5Cicons%5Charam.svg) | XML | -1 | 0 | 0 | -1 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\assets\\icons\\hawal.svg](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Cassets%5Cicons%5Chawal.svg) | XML | -1 | 0 | 0 | -1 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\assets\\icons\\hijri-calendar.svg](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Cassets%5Cicons%5Chijri-calendar.svg) | XML | -1 | 0 | 0 | -1 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\assets\\icons\\home.svg](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Cassets%5Cicons%5Chome.svg) | XML | -2 | 0 | -1 | -3 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\assets\\icons\\info.svg](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Cassets%5Cicons%5Cinfo.svg) | XML | -2 | 0 | -1 | -3 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\assets\\icons\\instagran.svg](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Cassets%5Cicons%5Cinstagran.svg) | XML | -1 | 0 | 0 | -1 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\assets\\icons\\islam.svg](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Cassets%5Cicons%5Cislam.svg) | XML | -1 | 0 | 0 | -1 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\assets\\icons\\middle-tab.svg](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Cassets%5Cicons%5Cmiddle-tab.svg) | XML | -55 | 0 | 0 | -55 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\assets\\icons\\more.svg](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Cassets%5Cicons%5Cmore.svg) | XML | -2 | 0 | -1 | -3 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\assets\\icons\\prayer-time.svg](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Cassets%5Cicons%5Cprayer-time.svg) | XML | -1 | 0 | 0 | -1 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\assets\\icons\\praying.svg](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Cassets%5Cicons%5Cpraying.svg) | XML | -1 | 0 | 0 | -1 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\assets\\icons\\prsyar.svg](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Cassets%5Cicons%5Cprsyar.svg) | XML | -1 | 0 | 0 | -1 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\assets\\icons\\qoute.svg](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Cassets%5Cicons%5Cqoute.svg) | XML | -1 | 0 | 0 | -1 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\assets\\icons\\quran-icon.svg](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Cassets%5Cicons%5Cquran-icon.svg) | XML | -1 | 0 | 0 | -1 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\assets\\icons\\ramazan.svg](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Cassets%5Cicons%5Cramazan.svg) | XML | -1 | 0 | 0 | -1 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\assets\\icons\\snapchat.svg](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Cassets%5Cicons%5Csnapchat.svg) | XML | -1 | 0 | 0 | -1 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\assets\\icons\\sunnah.svg](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Cassets%5Cicons%5Csunnah.svg) | XML | -1 | 0 | 0 | -1 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\assets\\icons\\support.svg](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Cassets%5Cicons%5Csupport.svg) | XML | -1 | 0 | 0 | -1 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\assets\\icons\\tajwed.svg](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Cassets%5Cicons%5Ctajwed.svg) | XML | -49 | 0 | 0 | -49 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\assets\\icons\\tasbih.svg](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Cassets%5Cicons%5Ctasbih.svg) | XML | -1 | 0 | 0 | -1 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\assets\\icons\\tawanakan.svg](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Cassets%5Cicons%5Ctawanakan.svg) | XML | -1 | 0 | 0 | -1 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\assets\\icons\\user.svg](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Cassets%5Cicons%5Cuser.svg) | XML | -2 | 0 | -1 | -3 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\assets\\icons\\zanste-quran.svg](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Cassets%5Cicons%5Czanste-quran.svg) | XML | -1 | 0 | 0 | -1 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\assets\\icons\\zanyare-quran.svg](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Cassets%5Cicons%5Czanyare-quran.svg) | XML | -11 | 0 | -15 | -26 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\assets\\icons\\zikr.svg](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Cassets%5Cicons%5Czikr.svg) | XML | -1 | 0 | 0 | -1 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\assets\\surah\\1.json](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Cassets%5Csurah%5C1.json) | JSON | -48 | 0 | 0 | -48 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\assets\\surah\\10.json](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Cassets%5Csurah%5C10.json) | JSON | -354 | 0 | 0 | -354 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\assets\\surah\\100.json](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Cassets%5Csurah%5C100.json) | JSON | -60 | 0 | 0 | -60 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\assets\\surah\\101.json](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Cassets%5Csurah%5C101.json) | JSON | -60 | 0 | 0 | -60 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\assets\\surah\\102.json](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Cassets%5Csurah%5C102.json) | JSON | -51 | 0 | 0 | -51 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\assets\\surah\\103.json](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Cassets%5Csurah%5C103.json) | JSON | -36 | 0 | 0 | -36 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\assets\\surah\\104.json](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Cassets%5Csurah%5C104.json) | JSON | -54 | 0 | 0 | -54 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\assets\\surah\\105.json](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Cassets%5Csurah%5C105.json) | JSON | -42 | 0 | 0 | -42 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\assets\\surah\\106.json](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Cassets%5Csurah%5C106.json) | JSON | -39 | 0 | 0 | -39 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\assets\\surah\\107.json](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Cassets%5Csurah%5C107.json) | JSON | -48 | 0 | 0 | -48 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\assets\\surah\\108.json](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Cassets%5Csurah%5C108.json) | JSON | -36 | 0 | 0 | -36 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\assets\\surah\\109.json](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Cassets%5Csurah%5C109.json) | JSON | -45 | 0 | 0 | -45 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\assets\\surah\\11.json](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Cassets%5Csurah%5C11.json) | JSON | -396 | 0 | 0 | -396 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\assets\\surah\\110.json](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Cassets%5Csurah%5C110.json) | JSON | -36 | 0 | 0 | -36 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\assets\\surah\\111.json](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Cassets%5Csurah%5C111.json) | JSON | -42 | 0 | 0 | -42 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\assets\\surah\\112.json](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Cassets%5Csurah%5C112.json) | JSON | -39 | 0 | 0 | -39 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\assets\\surah\\113.json](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Cassets%5Csurah%5C113.json) | JSON | -42 | 0 | 0 | -42 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\assets\\surah\\114.json](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Cassets%5Csurah%5C114.json) | JSON | -45 | 0 | 0 | -45 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\assets\\surah\\12.json](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Cassets%5Csurah%5C12.json) | JSON | -360 | 0 | 0 | -360 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\assets\\surah\\13.json](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Cassets%5Csurah%5C13.json) | JSON | -156 | 0 | 0 | -156 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\assets\\surah\\14.json](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Cassets%5Csurah%5C14.json) | JSON | -183 | 0 | 0 | -183 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\assets\\surah\\15.json](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Cassets%5Csurah%5C15.json) | JSON | -324 | 0 | 0 | -324 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\assets\\surah\\16.json](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Cassets%5Csurah%5C16.json) | JSON | -411 | 0 | 0 | -411 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\assets\\surah\\17.json](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Cassets%5Csurah%5C17.json) | JSON | -360 | 0 | 0 | -360 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\assets\\surah\\18.json](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Cassets%5Csurah%5C18.json) | JSON | -357 | 0 | 0 | -357 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\assets\\surah\\19.json](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Cassets%5Csurah%5C19.json) | JSON | -321 | 0 | 0 | -321 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\assets\\surah\\2.json](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Cassets%5Csurah%5C2.json) | JSON | -885 | 0 | 0 | -885 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\assets\\surah\\20.json](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Cassets%5Csurah%5C20.json) | JSON | -432 | 0 | 0 | -432 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\assets\\surah\\21.json](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Cassets%5Csurah%5C21.json) | JSON | -363 | 0 | 0 | -363 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\assets\\surah\\22.json](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Cassets%5Csurah%5C22.json) | JSON | -261 | 0 | 0 | -261 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\assets\\surah\\23.json](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Cassets%5Csurah%5C23.json) | JSON | -381 | 0 | 0 | -381 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\assets\\surah\\24.json](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Cassets%5Csurah%5C24.json) | JSON | -219 | 0 | 0 | -219 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\assets\\surah\\25.json](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Cassets%5Csurah%5C25.json) | JSON | -258 | 0 | 0 | -258 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\assets\\surah\\26.json](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Cassets%5Csurah%5C26.json) | JSON | -708 | 0 | 0 | -708 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\assets\\surah\\27.json](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Cassets%5Csurah%5C27.json) | JSON | -306 | 0 | 0 | -306 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\assets\\surah\\28.json](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Cassets%5Csurah%5C28.json) | JSON | -291 | 0 | 0 | -291 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\assets\\surah\\29.json](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Cassets%5Csurah%5C29.json) | JSON | -234 | 0 | 0 | -234 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\assets\\surah\\3.json](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Cassets%5Csurah%5C3.json) | JSON | -627 | 0 | 0 | -627 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\assets\\surah\\30.json](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Cassets%5Csurah%5C30.json) | JSON | -207 | 0 | 0 | -207 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\assets\\surah\\31.json](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Cassets%5Csurah%5C31.json) | JSON | -129 | 0 | 0 | -129 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\assets\\surah\\32.json](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Cassets%5Csurah%5C32.json) | JSON | -117 | 0 | 0 | -117 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\assets\\surah\\33.json](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Cassets%5Csurah%5C33.json) | JSON | -246 | 0 | 0 | -246 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\assets\\surah\\34.json](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Cassets%5Csurah%5C34.json) | JSON | -189 | 0 | 0 | -189 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\assets\\surah\\35.json](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Cassets%5Csurah%5C35.json) | JSON | -162 | 0 | 0 | -162 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\assets\\surah\\36.json](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Cassets%5Csurah%5C36.json) | JSON | -276 | 0 | 0 | -276 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\assets\\surah\\37.json](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Cassets%5Csurah%5C37.json) | JSON | -573 | 0 | 0 | -573 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\assets\\surah\\38.json](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Cassets%5Csurah%5C38.json) | JSON | -291 | 0 | 0 | -291 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\assets\\surah\\39.json](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Cassets%5Csurah%5C39.json) | JSON | -252 | 0 | 0 | -252 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\assets\\surah\\4.json](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Cassets%5Csurah%5C4.json) | JSON | -555 | 0 | 0 | -555 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\assets\\surah\\40.json](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Cassets%5Csurah%5C40.json) | JSON | -282 | 0 | 0 | -282 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\assets\\surah\\41.json](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Cassets%5Csurah%5C41.json) | JSON | -189 | 0 | 0 | -189 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\assets\\surah\\42.json](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Cassets%5Csurah%5C42.json) | JSON | -186 | 0 | 0 | -186 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\assets\\surah\\43.json](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Cassets%5Csurah%5C43.json) | JSON | -294 | 0 | 0 | -294 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\assets\\surah\\44.json](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Cassets%5Csurah%5C44.json) | JSON | -204 | 0 | 0 | -204 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\assets\\surah\\45.json](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Cassets%5Csurah%5C45.json) | JSON | -138 | 0 | 0 | -138 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\assets\\surah\\46.json](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Cassets%5Csurah%5C46.json) | JSON | -132 | 0 | 0 | -132 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\assets\\surah\\47.json](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Cassets%5Csurah%5C47.json) | JSON | -141 | 0 | 0 | -141 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\assets\\surah\\48.json](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Cassets%5Csurah%5C48.json) | JSON | -114 | 0 | 0 | -114 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\assets\\surah\\49.json](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Cassets%5Csurah%5C49.json) | JSON | -81 | 0 | 0 | -81 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\assets\\surah\\5.json](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Cassets%5Csurah%5C5.json) | JSON | -387 | 0 | 0 | -387 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\assets\\surah\\50.json](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Cassets%5Csurah%5C50.json) | JSON | -162 | 0 | 0 | -162 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\assets\\surah\\51.json](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Cassets%5Csurah%5C51.json) | JSON | -207 | 0 | 0 | -207 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\assets\\surah\\52.json](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Cassets%5Csurah%5C52.json) | JSON | -174 | 0 | 0 | -174 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\assets\\surah\\53.json](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Cassets%5Csurah%5C53.json) | JSON | -213 | 0 | 0 | -213 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\assets\\surah\\54.json](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Cassets%5Csurah%5C54.json) | JSON | -192 | 0 | 0 | -192 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\assets\\surah\\55.json](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Cassets%5Csurah%5C55.json) | JSON | -261 | 0 | 0 | -261 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\assets\\surah\\56.json](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Cassets%5Csurah%5C56.json) | JSON | -315 | 0 | 0 | -315 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\assets\\surah\\57.json](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Cassets%5Csurah%5C57.json) | JSON | -114 | 0 | 0 | -114 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\assets\\surah\\58.json](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Cassets%5Csurah%5C58.json) | JSON | -93 | 0 | 0 | -93 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\assets\\surah\\59.json](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Cassets%5Csurah%5C59.json) | JSON | -99 | 0 | 0 | -99 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\assets\\surah\\6.json](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Cassets%5Csurah%5C6.json) | JSON | -522 | 0 | 0 | -522 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\assets\\surah\\60.json](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Cassets%5Csurah%5C60.json) | JSON | -66 | 0 | 0 | -66 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\assets\\surah\\61.json](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Cassets%5Csurah%5C61.json) | JSON | -69 | 0 | 0 | -69 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\assets\\surah\\62.json](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Cassets%5Csurah%5C62.json) | JSON | -60 | 0 | 0 | -60 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\assets\\surah\\63.json](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Cassets%5Csurah%5C63.json) | JSON | -60 | 0 | 0 | -60 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\assets\\surah\\64.json](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Cassets%5Csurah%5C64.json) | JSON | -81 | 0 | 0 | -81 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\assets\\surah\\65.json](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Cassets%5Csurah%5C65.json) | JSON | -63 | 0 | 0 | -63 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\assets\\surah\\66.json](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Cassets%5Csurah%5C66.json) | JSON | -63 | 0 | 0 | -63 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\assets\\surah\\67.json](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Cassets%5Csurah%5C67.json) | JSON | -117 | 0 | 0 | -117 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\assets\\surah\\68.json](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Cassets%5Csurah%5C68.json) | JSON | -183 | 0 | 0 | -183 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\assets\\surah\\69.json](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Cassets%5Csurah%5C69.json) | JSON | -183 | 0 | 0 | -183 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\assets\\surah\\7.json](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Cassets%5Csurah%5C7.json) | JSON | -645 | 0 | 0 | -645 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\assets\\surah\\70.json](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Cassets%5Csurah%5C70.json) | JSON | -159 | 0 | 0 | -159 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\assets\\surah\\71.json](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Cassets%5Csurah%5C71.json) | JSON | -111 | 0 | 0 | -111 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\assets\\surah\\72.json](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Cassets%5Csurah%5C72.json) | JSON | -111 | 0 | 0 | -111 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\assets\\surah\\73.json](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Cassets%5Csurah%5C73.json) | JSON | -87 | 0 | 0 | -87 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\assets\\surah\\74.json](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Cassets%5Csurah%5C74.json) | JSON | -195 | 0 | 0 | -195 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\assets\\surah\\75.json](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Cassets%5Csurah%5C75.json) | JSON | -147 | 0 | 0 | -147 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\assets\\surah\\76.json](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Cassets%5Csurah%5C76.json) | JSON | -120 | 0 | 0 | -120 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\assets\\surah\\77.json](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Cassets%5Csurah%5C77.json) | JSON | -177 | 0 | 0 | -177 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\assets\\surah\\78.json](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Cassets%5Csurah%5C78.json) | JSON | -147 | 0 | 0 | -147 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\assets\\surah\\79.json](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Cassets%5Csurah%5C79.json) | JSON | -165 | 0 | 0 | -165 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\assets\\surah\\8.json](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Cassets%5Csurah%5C8.json) | JSON | -252 | 0 | 0 | -252 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\assets\\surah\\80.json](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Cassets%5Csurah%5C80.json) | JSON | -153 | 0 | 0 | -153 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\assets\\surah\\81.json](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Cassets%5Csurah%5C81.json) | JSON | -114 | 0 | 0 | -114 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\assets\\surah\\82.json](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Cassets%5Csurah%5C82.json) | JSON | -84 | 0 | 0 | -84 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\assets\\surah\\83.json](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Cassets%5Csurah%5C83.json) | JSON | -135 | 0 | 0 | -135 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\assets\\surah\\84.json](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Cassets%5Csurah%5C84.json) | JSON | -102 | 0 | 0 | -102 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\assets\\surah\\85.json](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Cassets%5Csurah%5C85.json) | JSON | -93 | 0 | 0 | -93 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\assets\\surah\\86.json](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Cassets%5Csurah%5C86.json) | JSON | -78 | 0 | 0 | -78 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\assets\\surah\\87.json](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Cassets%5Csurah%5C87.json) | JSON | -84 | 0 | 0 | -84 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\assets\\surah\\88.json](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Cassets%5Csurah%5C88.json) | JSON | -105 | 0 | 0 | -105 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\assets\\surah\\89.json](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Cassets%5Csurah%5C89.json) | JSON | -117 | 0 | 0 | -117 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\assets\\surah\\9.json](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Cassets%5Csurah%5C9.json) | JSON | -414 | 0 | 0 | -414 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\assets\\surah\\90.json](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Cassets%5Csurah%5C90.json) | JSON | -87 | 0 | 0 | -87 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\assets\\surah\\91.json](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Cassets%5Csurah%5C91.json) | JSON | -72 | 0 | 0 | -72 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\assets\\surah\\92.json](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Cassets%5Csurah%5C92.json) | JSON | -90 | 0 | 0 | -90 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\assets\\surah\\93.json](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Cassets%5Csurah%5C93.json) | JSON | -60 | 0 | 0 | -60 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\assets\\surah\\94.json](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Cassets%5Csurah%5C94.json) | JSON | -51 | 0 | 0 | -51 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\assets\\surah\\95.json](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Cassets%5Csurah%5C95.json) | JSON | -51 | 0 | 0 | -51 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\assets\\surah\\96.json](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Cassets%5Csurah%5C96.json) | JSON | -84 | 0 | 0 | -84 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\assets\\surah\\97.json](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Cassets%5Csurah%5C97.json) | JSON | -42 | 0 | 0 | -42 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\assets\\surah\\98.json](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Cassets%5Csurah%5C98.json) | JSON | -51 | 0 | 0 | -51 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\assets\\surah\\99.json](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Cassets%5Csurah%5C99.json) | JSON | -51 | 0 | 0 | -51 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\assets\\surah\\asmaul-husna.json](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Cassets%5Csurah%5Casmaul-husna.json) | JSON | -697 | 0 | -1 | -698 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\assets\\surah\\ayat-kursi.json](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Cassets%5Csurah%5Cayat-kursi.json) | JSON | -8 | 0 | -1 | -9 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\assets\\surah\\doa-harian.json](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Cassets%5Csurah%5Cdoa-harian.json) | JSON | -214 | 0 | -1 | -215 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\assets\\surah\\pola-kerja.json](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Cassets%5Csurah%5Cpola-kerja.json) | JSON | -135 | 0 | -1 | -136 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\assets\\surah\\surah-info.json](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Cassets%5Csurah%5Csurah-info.json) | JSON | -1,028 | 0 | -1 | -1,029 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\ios\\RunnerTests\\RunnerTests.swift](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Cios%5CRunnerTests%5CRunnerTests.swift) | Swift | -7 | -2 | -4 | -13 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\ios\\Runner\\AppDelegate.swift](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Cios%5CRunner%5CAppDelegate.swift) | Swift | -12 | 0 | -2 | -14 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\ios\\Runner\\Assets.xcassets\\AppIcon.appiconset\\Contents.json](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Cios%5CRunner%5CAssets.xcassets%5CAppIcon.appiconset%5CContents.json) | JSON | -122 | 0 | -1 | -123 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\ios\\Runner\\Assets.xcassets\\LaunchImage.imageset\\Contents.json](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Cios%5CRunner%5CAssets.xcassets%5CLaunchImage.imageset%5CContents.json) | JSON | -23 | 0 | -1 | -24 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\ios\\Runner\\Assets.xcassets\\LaunchImage.imageset\\README.md](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Cios%5CRunner%5CAssets.xcassets%5CLaunchImage.imageset%5CREADME.md) | Markdown | -3 | 0 | -2 | -5 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\ios\\Runner\\Base.lproj\\LaunchScreen.storyboard](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Cios%5CRunner%5CBase.lproj%5CLaunchScreen.storyboard) | XML | -36 | -1 | -1 | -38 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\ios\\Runner\\Base.lproj\\Main.storyboard](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Cios%5CRunner%5CBase.lproj%5CMain.storyboard) | XML | -25 | -1 | -1 | -27 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\ios\\Runner\\Runner-Bridging-Header.h](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Cios%5CRunner%5CRunner-Bridging-Header.h) | C++ | -1 | 0 | -1 | -2 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\lib\\Screens\\DrawerScreens\\AboutApp\\about\_app.dart](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Clib%5CScreens%5CDrawerScreens%5CAboutApp%5Cabout_app.dart) | Dart | -270 | -15 | -9 | -294 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\lib\\Screens\\DrawerScreens\\FeedBack\\feed\_back\_page.dart](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Clib%5CScreens%5CDrawerScreens%5CFeedBack%5Cfeed_back_page.dart) | Dart | -237 | 0 | -9 | -246 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\lib\\Screens\\HomeItems\\AyatKursi\\ayat\_kursi.dart](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Clib%5CScreens%5CHomeItems%5CAyatKursi%5Cayat_kursi.dart) | Dart | -189 | 0 | -15 | -204 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\lib\\Screens\\HomeItems\\Bahasht\_Dozax\\bahasht\_u\_dozax\_page.dart](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Clib%5CScreens%5CHomeItems%5CBahasht_Dozax%5Cbahasht_u_dozax_page.dart) | Dart | -528 | -3 | -18 | -549 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\lib\\Screens\\HomeItems\\Books\\book\_page.dart](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Clib%5CScreens%5CHomeItems%5CBooks%5Cbook_page.dart) | Dart | -1,292 | -7 | -32 | -1,331 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\lib\\Screens\\HomeItems\\Books\\book\_view.dart](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Clib%5CScreens%5CHomeItems%5CBooks%5Cbook_view.dart) | Dart | -269 | 0 | -11 | -280 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\lib\\Screens\\HomeItems\\Cherok\\cherok\_page.dart](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Clib%5CScreens%5CHomeItems%5CCherok%5Ccherok_page.dart) | Dart | -197 | 0 | -9 | -206 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\lib\\Screens\\HomeItems\\Dua\\dua\_list.dart](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Clib%5CScreens%5CHomeItems%5CDua%5Cdua_list.dart) | Dart | -223 | -2 | -19 | -244 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\lib\\Screens\\HomeItems\\Farmuda\\farmuda\_page.dart](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Clib%5CScreens%5CHomeItems%5CFarmuda%5Cfarmuda_page.dart) | Dart | -200 | 0 | -10 | -210 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\lib\\Screens\\HomeItems\\Haramkrawakan\\haramkrawan.dart](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Clib%5CScreens%5CHomeItems%5CHaramkrawakan%5Charamkrawan.dart) | Dart | -223 | -2 | -18 | -243 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\lib\\Screens\\HomeItems\\HawalanePexambar\\hawalane\_pexambar\_page.dart](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Clib%5CScreens%5CHomeItems%5CHawalanePexambar%5Chawalane_pexambar_page.dart) | Dart | -318 | 0 | -17 | -335 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\lib\\Screens\\HomeItems\\HijriCalendar\\hijri\_calendar\_page.dart](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Clib%5CScreens%5CHomeItems%5CHijriCalendar%5Chijri_calendar_page.dart) | Dart | -261 | 0 | -9 | -270 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\lib\\Screens\\HomeItems\\Kafaratakan\\kafaratakan.dart](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Clib%5CScreens%5CHomeItems%5CKafaratakan%5Ckafaratakan.dart) | Dart | -292 | -5 | -16 | -313 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\lib\\Screens\\HomeItems\\MangeRamazan\\mange\_ramazan\_page.dart](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Clib%5CScreens%5CHomeItems%5CMangeRamazan%5Cmange_ramazan_page.dart) | Dart | -244 | 0 | -8 | -252 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\lib\\Screens\\HomeItems\\MangeRamazan\\page\_1.dart](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Clib%5CScreens%5CHomeItems%5CMangeRamazan%5Cpage_1.dart) | Dart | -144 | 0 | -11 | -155 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\lib\\Screens\\HomeItems\\NeshanakaneRozheDway\\list\_a.dart](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Clib%5CScreens%5CHomeItems%5CNeshanakaneRozheDway%5Clist_a.dart) | Dart | -545 | 0 | -10 | -555 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\lib\\Screens\\HomeItems\\NeshanakaneRozheDway\\list\_b.dart](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Clib%5CScreens%5CHomeItems%5CNeshanakaneRozheDway%5Clist_b.dart) | Dart | -256 | 0 | -9 | -265 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\lib\\Screens\\HomeItems\\NeshanakaneRozheDway\\list\_c.dart](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Clib%5CScreens%5CHomeItems%5CNeshanakaneRozheDway%5Clist_c.dart) | Dart | -275 | 0 | -9 | -284 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\lib\\Screens\\HomeItems\\NeshanakaneRozheDway\\list\_d.dart](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Clib%5CScreens%5CHomeItems%5CNeshanakaneRozheDway%5Clist_d.dart) | Dart | -443 | 0 | -8 | -451 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\lib\\Screens\\HomeItems\\NeshanakaneRozheDway\\list\_e.dart](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Clib%5CScreens%5CHomeItems%5CNeshanakaneRozheDway%5Clist_e.dart) | Dart | -263 | 0 | -8 | -271 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\lib\\Screens\\HomeItems\\NeshanakaneRozheDway\\list\_f.dart](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Clib%5CScreens%5CHomeItems%5CNeshanakaneRozheDway%5Clist_f.dart) | Dart | -212 | 0 | -8 | -220 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\lib\\Screens\\HomeItems\\NeshanakaneRozheDway\\list\_g.dart](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Clib%5CScreens%5CHomeItems%5CNeshanakaneRozheDway%5Clist_g.dart) | Dart | -208 | 0 | -8 | -216 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\lib\\Screens\\HomeItems\\NeshanakaneRozheDway\\list\_h.dart](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Clib%5CScreens%5CHomeItems%5CNeshanakaneRozheDway%5Clist_h.dart) | Dart | -218 | 0 | -10 | -228 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\lib\\Screens\\HomeItems\\NeshanakaneRozheDway\\list\_i.dart](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Clib%5CScreens%5CHomeItems%5CNeshanakaneRozheDway%5Clist_i.dart) | Dart | -212 | 0 | -10 | -222 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\lib\\Screens\\HomeItems\\NeshanakaneRozheDway\\list\_j.dart](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Clib%5CScreens%5CHomeItems%5CNeshanakaneRozheDway%5Clist_j.dart) | Dart | -202 | 0 | -8 | -210 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\lib\\Screens\\HomeItems\\NeshanakaneRozheDway\\neshanakane\_rozhe\_dway.dart](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Clib%5CScreens%5CHomeItems%5CNeshanakaneRozheDway%5Cneshanakane_rozhe_dway.dart) | Dart | -303 | 0 | -9 | -312 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\lib\\Screens\\HomeItems\\Nwezhkrdn\\bangdan.dart](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Clib%5CScreens%5CHomeItems%5CNwezhkrdn%5Cbangdan.dart) | Dart | -102 | 0 | -9 | -111 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\lib\\Screens\\HomeItems\\Nwezhkrdn\\batalkary\_nwezh.dart](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Clib%5CScreens%5CHomeItems%5CNwezhkrdn%5Cbatalkary_nwezh.dart) | Dart | -120 | 0 | -11 | -131 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\lib\\Screens\\HomeItems\\Nwezhkrdn\\chunasar\_aw.dart](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Clib%5CScreens%5CHomeItems%5CNwezhkrdn%5Cchunasar_aw.dart) | Dart | -138 | 0 | -6 | -144 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\lib\\Screens\\HomeItems\\Nwezhkrdn\\dastnwezh.dart](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Clib%5CScreens%5CHomeItems%5CNwezhkrdn%5Cdastnwezh.dart) | Dart | -904 | -1 | -11 | -916 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\lib\\Screens\\HomeItems\\Nwezhkrdn\\hala\_bawakan.dart](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Clib%5CScreens%5CHomeItems%5CNwezhkrdn%5Chala_bawakan.dart) | Dart | -144 | 0 | -5 | -149 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\lib\\Screens\\HomeItems\\Nwezhkrdn\\j\_nwezhakan.dart](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Clib%5CScreens%5CHomeItems%5CNwezhkrdn%5Cj_nwezhakan.dart) | Dart | -71 | 0 | -5 | -76 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\lib\\Screens\\HomeItems\\Nwezhkrdn\\manay\_nwezh.dart](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Clib%5CScreens%5CHomeItems%5CNwezhkrdn%5Cmanay_nwezh.dart) | Dart | -218 | 0 | -10 | -228 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\lib\\Screens\\HomeItems\\Nwezhkrdn\\manay\_tahyat.dart](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Clib%5CScreens%5CHomeItems%5CNwezhkrdn%5Cmanay_tahyat.dart) | Dart | -122 | 0 | -7 | -129 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\lib\\Screens\\HomeItems\\Nwezhkrdn\\nwezh.dart](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Clib%5CScreens%5CHomeItems%5CNwezhkrdn%5Cnwezh.dart) | Dart | -538 | 0 | -7 | -545 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\lib\\Screens\\HomeItems\\Nwezhkrdn\\nwezh\_page.dart](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Clib%5CScreens%5CHomeItems%5CNwezhkrdn%5Cnwezh_page.dart) | Dart | -438 | -3 | -11 | -452 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\lib\\Screens\\HomeItems\\Nwezhkrdn\\q\_nwezh.dart](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Clib%5CScreens%5CHomeItems%5CNwezhkrdn%5Cq_nwezh.dart) | Dart | -213 | 0 | -11 | -224 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\lib\\Screens\\HomeItems\\Nwezhkrdn\\qdast\_nwezh.dart](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Clib%5CScreens%5CHomeItems%5CNwezhkrdn%5Cqdast_nwezh.dart) | Dart | -157 | 0 | -13 | -170 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\lib\\Screens\\HomeItems\\Nwezhkrdn\\tayamum.dart](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Clib%5CScreens%5CHomeItems%5CNwezhkrdn%5Ctayamum.dart) | Dart | -443 | -4 | -8 | -455 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\lib\\Screens\\HomeItems\\PayakaneEmanIslam\\ArkakaneEman\\arkakane\_eman.dart](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Clib%5CScreens%5CHomeItems%5CPayakaneEmanIslam%5CArkakaneEman%5Carkakane_eman.dart) | Dart | -272 | 0 | -9 | -281 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\lib\\Screens\\HomeItems\\PayakaneEmanIslam\\ArkakaneEman\\pages\\bawarbun\_bafreshta.dart](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Clib%5CScreens%5CHomeItems%5CPayakaneEmanIslam%5CArkakaneEman%5Cpages%5Cbawarbun_bafreshta.dart) | Dart | -146 | 0 | -9 | -155 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\lib\\Screens\\HomeItems\\PayakaneEmanIslam\\ArkakaneEman\\pages\\bawarbun\_baktebe\_asmane.dart](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Clib%5CScreens%5CHomeItems%5CPayakaneEmanIslam%5CArkakaneEman%5Cpages%5Cbawarbun_baktebe_asmane.dart) | Dart | -139 | 0 | -9 | -148 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\lib\\Screens\\HomeItems\\PayakaneEmanIslam\\ArkakaneEman\\pages\\bawarbun\_bapexambaran.dart](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Clib%5CScreens%5CHomeItems%5CPayakaneEmanIslam%5CArkakaneEman%5Cpages%5Cbawarbun_bapexambaran.dart) | Dart | -125 | 0 | -10 | -135 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\lib\\Screens\\HomeItems\\PayakaneEmanIslam\\ArkakaneEman\\pages\\bawarbun\_baqadar.dart](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Clib%5CScreens%5CHomeItems%5CPayakaneEmanIslam%5CArkakaneEman%5Cpages%5Cbawarbun_baqadar.dart) | Dart | -121 | 0 | -9 | -130 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\lib\\Screens\\HomeItems\\PayakaneEmanIslam\\ArkakaneEman\\pages\\bawarbun\_barozhedway.dart](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Clib%5CScreens%5CHomeItems%5CPayakaneEmanIslam%5CArkakaneEman%5Cpages%5Cbawarbun_barozhedway.dart) | Dart | -133 | 0 | -9 | -142 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\lib\\Screens\\HomeItems\\PayakaneEmanIslam\\ArkakaneEman\\pages\\bawarnun\_baxwda.dart](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Clib%5CScreens%5CHomeItems%5CPayakaneEmanIslam%5CArkakaneEman%5Cpages%5Cbawarnun_baxwda.dart) | Dart | -122 | 0 | -9 | -131 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\lib\\Screens\\HomeItems\\PayakaneEmanIslam\\ArkakaneEman\\pages\\payakane\_bawar.dart](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Clib%5CScreens%5CHomeItems%5CPayakaneEmanIslam%5CArkakaneEman%5Cpages%5Cpayakane_bawar.dart) | Dart | -115 | 0 | -10 | -125 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\lib\\Screens\\HomeItems\\PayakaneEmanIslam\\ArkakaneIslam\\arkakane\_islam.dart](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Clib%5CScreens%5CHomeItems%5CPayakaneEmanIslam%5CArkakaneIslam%5Carkakane_islam.dart) | Dart | -252 | 0 | -8 | -260 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\lib\\Screens\\HomeItems\\PayakaneEmanIslam\\ArkakaneIslam\\pages\\haj.dart](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Clib%5CScreens%5CHomeItems%5CPayakaneEmanIslam%5CArkakaneIslam%5Cpages%5Chaj.dart) | Dart | -139 | 0 | -9 | -148 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\lib\\Screens\\HomeItems\\PayakaneEmanIslam\\ArkakaneIslam\\pages\\nwezh.dart](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Clib%5CScreens%5CHomeItems%5CPayakaneEmanIslam%5CArkakaneIslam%5Cpages%5Cnwezh.dart) | Dart | -126 | 0 | -9 | -135 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\lib\\Screens\\HomeItems\\PayakaneEmanIslam\\ArkakaneIslam\\pages\\rozhugrtn.dart](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Clib%5CScreens%5CHomeItems%5CPayakaneEmanIslam%5CArkakaneIslam%5Cpages%5Crozhugrtn.dart) | Dart | -147 | 0 | -9 | -156 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\lib\\Screens\\HomeItems\\PayakaneEmanIslam\\ArkakaneIslam\\pages\\shayatman.dart](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Clib%5CScreens%5CHomeItems%5CPayakaneEmanIslam%5CArkakaneIslam%5Cpages%5Cshayatman.dart) | Dart | -128 | 0 | -9 | -137 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\lib\\Screens\\HomeItems\\PayakaneEmanIslam\\ArkakaneIslam\\pages\\zakat.dart](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Clib%5CScreens%5CHomeItems%5CPayakaneEmanIslam%5CArkakaneIslam%5Cpages%5Czakat.dart) | Dart | -155 | 0 | -9 | -164 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\lib\\Screens\\HomeItems\\PayakaneEmanIslam\\payakane\_eman\_islam.dart](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Clib%5CScreens%5CHomeItems%5CPayakaneEmanIslam%5Cpayakane_eman_islam.dart) | Dart | -205 | 0 | -7 | -212 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\lib\\Screens\\HomeItems\\Pexambarman\\page1.dart](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Clib%5CScreens%5CHomeItems%5CPexambarman%5Cpage1.dart) | Dart | -133 | 0 | -10 | -143 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\lib\\Screens\\HomeItems\\Pexambarman\\page2.dart](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Clib%5CScreens%5CHomeItems%5CPexambarman%5Cpage2.dart) | Dart | -133 | 0 | -10 | -143 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\lib\\Screens\\HomeItems\\Pexambarman\\page\_view.dart](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Clib%5CScreens%5CHomeItems%5CPexambarman%5Cpage_view.dart) | Dart | -257 | -1 | -8 | -266 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\lib\\Screens\\HomeItems\\Pexambarman\\zhyan\_namay\_pexambarman.dart](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Clib%5CScreens%5CHomeItems%5CPexambarman%5Czhyan_namay_pexambarman.dart) | Dart | -188 | 0 | -7 | -195 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\lib\\Screens\\HomeItems\\PrsyarWakamAyne\\prsyar\_walam\_ayne.dart](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Clib%5CScreens%5CHomeItems%5CPrsyarWakamAyne%5Cprsyar_walam_ayne.dart) | Dart | -235 | -2 | -18 | -255 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\lib\\Screens\\HomeItems\\PrsyarWalamRozheDway\\prsyar\_list.dart](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Clib%5CScreens%5CHomeItems%5CPrsyarWalamRozheDway%5Cprsyar_list.dart) | Dart | -129 | 0 | -12 | -141 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\lib\\Screens\\HomeItems\\PrsyarWalamRozheDway\\prsyar\_walam\_rozhe\_dway.dart](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Clib%5CScreens%5CHomeItems%5CPrsyarWalamRozheDway%5Cprsyar_walam_rozhe_dway.dart) | Dart | -251 | 0 | -9 | -260 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\lib\\Screens\\HomeItems\\PuxtaySaheheMuslim\\p\_s\_m\_lists.dart](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Clib%5CScreens%5CHomeItems%5CPuxtaySaheheMuslim%5Cp_s_m_lists.dart) | Dart | -247 | -2 | -18 | -267 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\lib\\Screens\\HomeItems\\PuxtaySaheheMuslim\\puxtay\_sahehe\_muslim.dart](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Clib%5CScreens%5CHomeItems%5CPuxtaySaheheMuslim%5Cpuxtay_sahehe_muslim.dart) | Dart | -195 | -7 | -8 | -210 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\lib\\Screens\\HomeItems\\Qurani Piroz\\data\\models\\allsurah.dart](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Clib%5CScreens%5CHomeItems%5CQurani%20Piroz%5Cdata%5Cmodels%5Callsurah.dart) | Dart | -41 | 0 | -6 | -47 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\lib\\Screens\\HomeItems\\Qurani Piroz\\data\\models\\surahinfo.dart](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Clib%5CScreens%5CHomeItems%5CQurani%20Piroz%5Cdata%5Cmodels%5Csurahinfo.dart) | Dart | -33 | 0 | -7 | -40 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\lib\\Screens\\HomeItems\\Qurani Piroz\\data\\services.dart](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Clib%5CScreens%5CHomeItems%5CQurani%20Piroz%5Cdata%5Cservices.dart) | Dart | -18 | 0 | -4 | -22 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\lib\\Screens\\HomeItems\\Qurani Piroz\\quran\_page.dart](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Clib%5CScreens%5CHomeItems%5CQurani%20Piroz%5Cquran_page.dart) | Dart | -142 | -7 | -16 | -165 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\lib\\Screens\\HomeItems\\Qurani Piroz\\ui\\detail\_surah.dart](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Clib%5CScreens%5CHomeItems%5CQurani%20Piroz%5Cui%5Cdetail_surah.dart) | Dart | -397 | -10 | -23 | -430 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\lib\\Screens\\HomeItems\\Sunatakan\\sunatakan.dart](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Clib%5CScreens%5CHomeItems%5CSunatakan%5Csunatakan.dart) | Dart | -143 | 0 | -11 | -154 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\lib\\Screens\\HomeItems\\Taqekrdnawa\\Walamakan\\walamakan.dart](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Clib%5CScreens%5CHomeItems%5CTaqekrdnawa%5CWalamakan%5Cwalamakan.dart) | Dart | -335 | -7 | -8 | -350 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\lib\\Screens\\HomeItems\\Taqekrdnawa\\quiz\\components\\body.dart](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Clib%5CScreens%5CHomeItems%5CTaqekrdnawa%5Cquiz%5Ccomponents%5Cbody.dart) | Dart | -81 | -2 | -5 | -88 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\lib\\Screens\\HomeItems\\Taqekrdnawa\\quiz\\components\\option.dart](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Clib%5CScreens%5CHomeItems%5CTaqekrdnawa%5Cquiz%5Ccomponents%5Coption.dart) | Dart | -93 | 0 | -7 | -100 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\lib\\Screens\\HomeItems\\Taqekrdnawa\\quiz\\components\\progress\_bar.dart](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Clib%5CScreens%5CHomeItems%5CTaqekrdnawa%5Cquiz%5Ccomponents%5Cprogress_bar.dart) | Dart | -71 | -3 | -5 | -79 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\lib\\Screens\\HomeItems\\Taqekrdnawa\\quiz\\components\\question\_card.dart](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Clib%5CScreens%5CHomeItems%5CTaqekrdnawa%5Cquiz%5Ccomponents%5Cquestion_card.dart) | Dart | -59 | -1 | -6 | -66 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\lib\\Screens\\HomeItems\\Taqekrdnawa\\quiz\\quiz\_screen.dart](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Clib%5CScreens%5CHomeItems%5CTaqekrdnawa%5Cquiz%5Cquiz_screen.dart) | Dart | -26 | 0 | -3 | -29 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\lib\\Screens\\HomeItems\\Taqekrdnawa\\score\\score\_screen.dart](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Clib%5CScreens%5CHomeItems%5CTaqekrdnawa%5Cscore%5Cscore_screen.dart) | Dart | -107 | 0 | -5 | -112 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\lib\\Screens\\HomeItems\\Taqekrdnawa\\welcome\\welcome\_screen.dart](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Clib%5CScreens%5CHomeItems%5CTaqekrdnawa%5Cwelcome%5Cwelcome_screen.dart) | Dart | -144 | 0 | -8 | -152 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\lib\\Screens\\HomeItems\\Tasbeeh\\check\_database.dart](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Clib%5CScreens%5CHomeItems%5CTasbeeh%5Ccheck_database.dart) | Dart | -26 | 0 | -3 | -29 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\lib\\Screens\\HomeItems\\Tasbeeh\\loading.dart](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Clib%5CScreens%5CHomeItems%5CTasbeeh%5Cloading.dart) | Dart | -21 | 0 | -3 | -24 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\lib\\Screens\\HomeItems\\Tasbeeh\\pages\\sebha\\items\_sebha.dart](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Clib%5CScreens%5CHomeItems%5CTasbeeh%5Cpages%5Csebha%5Citems_sebha.dart) | Dart | -149 | 0 | -8 | -157 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\lib\\Screens\\HomeItems\\Tasbeeh\\pages\\sebha\\tasbih\_page.dart](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Clib%5CScreens%5CHomeItems%5CTasbeeh%5Cpages%5Csebha%5Ctasbih_page.dart) | Dart | -251 | 0 | -18 | -269 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\lib\\Screens\\HomeItems\\TawanaGawrakan\\tawana\_gawrakan\_page.dart](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Clib%5CScreens%5CHomeItems%5CTawanaGawrakan%5Ctawana_gawrakan_page.dart) | Dart | -140 | 0 | -10 | -150 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\lib\\Screens\\HomeItems\\WtawAmozhgary\\wtaw\_amozhgare.dart](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Clib%5CScreens%5CHomeItems%5CWtawAmozhgary%5Cwtaw_amozhgare.dart) | Dart | -261 | 0 | -12 | -273 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\lib\\Screens\\HomeItems\\ZanyareQuran\\zanyare\_quran\_page.dart](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Clib%5CScreens%5CHomeItems%5CZanyareQuran%5Czanyare_quran_page.dart) | Dart | -321 | 0 | -17 | -338 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\lib\\Screens\\HomeItems\\Zekrakan\\zekrakan.dart](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Clib%5CScreens%5CHomeItems%5CZekrakan%5Czekrakan.dart) | Dart | -228 | -2 | -19 | -249 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\lib\\Screens\\HomeItems\\ZhyanNamayPexambaran\\zh\_pexambaran.dart](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Clib%5CScreens%5CHomeItems%5CZhyanNamayPexambaran%5Czh_pexambaran.dart) | Dart | -232 | -1 | -18 | -251 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\lib\\Screens\\HomeItems\\nawakany\_xuday\_gawra\\allah\_names.dart](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Clib%5CScreens%5CHomeItems%5Cnawakany_xuday_gawra%5Callah_names.dart) | Dart | -286 | -2 | -13 | -301 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\lib\\Screens\\mainScreens\\all\_items.dart](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Clib%5CScreens%5CmainScreens%5Call_items.dart) | Dart | -623 | -19 | -18 | -660 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\lib\\Screens\\mainScreens\\home\_page.dart](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Clib%5CScreens%5CmainScreens%5Chome_page.dart) | Dart | -105 | 0 | -16 | -121 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\lib\\Screens\\mainScreens\\loading\_page.dart](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Clib%5CScreens%5CmainScreens%5Cloading_page.dart) | Dart | -20 | 0 | -4 | -24 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\lib\\Screens\\mainScreens\\widget\\about\_me\_widget.dart](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Clib%5CScreens%5CmainScreens%5Cwidget%5Cabout_me_widget.dart) | Dart | -253 | -4 | -15 | -272 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\lib\\Screens\\mainScreens\\widget\\home\_widget.dart](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Clib%5CScreens%5CmainScreens%5Cwidget%5Chome_widget.dart) | Dart | -283 | -2 | -12 | -297 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\lib\\Screens\\mainScreens\\widget\\notifications\_screen.dart](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Clib%5CScreens%5CmainScreens%5Cwidget%5Cnotifications_screen.dart) | Dart | 0 | 0 | -1 | -1 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\lib\\Screens\\mainScreens\\widget\\settings\_widget.dart](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Clib%5CScreens%5CmainScreens%5Cwidget%5Csettings_widget.dart) | Dart | -599 | -10 | -24 | -633 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\lib\\bottom\_navigation\_view\\bottom\_bar\_view.dart](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Clib%5Cbottom_navigation_view%5Cbottom_bar_view.dart) | Dart | -355 | -2 | -26 | -383 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\lib\\bottom\_navigation\_view\\tab\_icon\_data.dart](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Clib%5Cbottom_navigation_view%5Ctab_icon_data.dart) | Dart | -34 | 0 | -3 | -37 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\lib\\controller\\question\_controller.dart](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Clib%5Ccontroller%5Cquestion_controller.dart) | Dart | -75 | -18 | -22 | -115 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\lib\\database\\database\_helper.dart](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Clib%5Cdatabase%5Cdatabase_helper.dart) | Dart | -183 | -9 | -57 | -249 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\lib\\main.dart](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Clib%5Cmain.dart) | Dart | -83 | -53 | -15 | -151 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\lib\\models\\allah\_names\_model.dart](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Clib%5Cmodels%5Callah_names_model.dart) | Dart | -21 | 0 | -5 | -26 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\lib\\models\\book\_model.dart](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Clib%5Cmodels%5Cbook_model.dart) | Dart | -5 | 0 | -2 | -7 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\lib\\models\\cherok\_model.dart](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Clib%5Cmodels%5Ccherok_model.dart) | Dart | -18 | 0 | -3 | -21 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\lib\\models\\dua\_model.dart](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Clib%5Cmodels%5Cdua_model.dart) | Dart | -8 | 0 | -3 | -11 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\lib\\models\\farmuda\_model.dart](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Clib%5Cmodels%5Cfarmuda_model.dart) | Dart | -24 | 0 | -3 | -27 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\lib\\models\\muhjizakan.dart](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Clib%5Cmodels%5Cmuhjizakan.dart) | Dart | -8 | 0 | -3 | -11 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\lib\\models\\prsyarakan\_model.dart](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Clib%5Cmodels%5Cprsyarakan_model.dart) | Dart | -17 | 0 | -3 | -20 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\lib\\models\\puxtay\_sahehe\_muslim\_model.dart](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Clib%5Cmodels%5Cpuxtay_sahehe_muslim_model.dart) | Dart | -13 | 0 | -3 | -16 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\lib\\models\\questions.dart](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Clib%5Cmodels%5Cquestions.dart) | Dart | -229 | -11 | -3 | -243 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\lib\\models\\qyamat\_model.dart](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Clib%5Cmodels%5Cqyamat_model.dart) | Dart | -13 | 0 | -3 | -16 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\lib\\models\\ramazan\_model.dart](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Clib%5Cmodels%5Cramazan_model.dart) | Dart | -5 | 0 | -2 | -7 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\lib\\models\\sebha\_model.dart](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Clib%5Cmodels%5Csebha_model.dart) | Dart | -40 | 0 | -12 | -52 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\lib\\models\\section\_model.dart](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Clib%5Cmodels%5Csection_model.dart) | Dart | -19 | 0 | -6 | -25 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\lib\\models\\settings\_model.dart](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Clib%5Cmodels%5Csettings_model.dart) | Dart | -41 | 0 | -13 | -54 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\lib\\models\\tawanakan\_model.dart](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Clib%5Cmodels%5Ctawanakan_model.dart) | Dart | -8 | 0 | -3 | -11 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\lib\\models\\wtaw\_amozhgare.dart](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Clib%5Cmodels%5Cwtaw_amozhgare.dart) | Dart | -7 | 0 | -3 | -10 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\lib\\models\\xawnama\_model.dart](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Clib%5Cmodels%5Cxawnama_model.dart) | Dart | -13 | 0 | -3 | -16 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\lib\\models\\zekr\_model.dart](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Clib%5Cmodels%5Czekr_model.dart) | Dart | -8 | 0 | -3 | -11 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\lib\\models\\zhayanama\_model.dart](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Clib%5Cmodels%5Czhayanama_model.dart) | Dart | -8 | 0 | -3 | -11 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\lib\\providers\\sebha\_provider.dart](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Clib%5Cproviders%5Csebha_provider.dart) | Dart | -88 | 0 | -16 | -104 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\lib\\providers\\sections\_provider.dart](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Clib%5Cproviders%5Csections_provider.dart) | Dart | -61 | 0 | -22 | -83 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\lib\\providers\\settings\_provider.dart](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Clib%5Cproviders%5Csettings_provider.dart) | Dart | -71 | 0 | -18 | -89 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\lib\\providers\\theme\_provider.dart](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Clib%5Cproviders%5Ctheme_provider.dart) | Dart | -80 | -2 | -10 | -92 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\lib\\util\\background.dart](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Clib%5Cutil%5Cbackground.dart) | Dart | -92 | 0 | -15 | -107 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\lib\\util\\constans.dart](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Clib%5Cutil%5Cconstans.dart) | Dart | -31 | 0 | -8 | -39 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\lib\\util\\grid\_card.dart](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Clib%5Cutil%5Cgrid_card.dart) | Dart | -95 | 0 | -7 | -102 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\lib\\util\\item\_list.dart](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Clib%5Cutil%5Citem_list.dart) | Dart | -171 | -1 | -16 | -188 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\lib\\util\\navigate\_between\_pages\\fade\_route.dart](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Clib%5Cutil%5Cnavigate_between_pages%5Cfade_route.dart) | Dart | -23 | 0 | -2 | -25 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\lib\\util\\navigate\_between\_pages\\scale\_route.dart](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Clib%5Cutil%5Cnavigate_between_pages%5Cscale_route.dart) | Dart | -31 | 0 | -2 | -33 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\lib\\util\\navigate\_between\_pages\\size\_route.dart](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Clib%5Cutil%5Cnavigate_between_pages%5Csize_route.dart) | Dart | -25 | 0 | -2 | -27 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\lib\\util\\navigate\_between\_pages\\slide\_route.dart](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Clib%5Cutil%5Cnavigate_between_pages%5Cslide_route.dart) | Dart | -101 | 0 | -5 | -106 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\lib\\util\\scale\_in.dart](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Clib%5Cutil%5Cscale_in.dart) | Dart | -23 | 0 | -2 | -25 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\lib\\widgets\\Profile\\radial\_progress.dart](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Clib%5Cwidgets%5CProfile%5Cradial_progress.dart) | Dart | -93 | 0 | -17 | -110 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\lib\\widgets\\carousel\_slider\_widget.dart](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Clib%5Cwidgets%5Ccarousel_slider_widget.dart) | Dart | -110 | 0 | -10 | -120 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\lib\\widgets\\custom\_list\_tile.dart](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Clib%5Cwidgets%5Ccustom_list_tile.dart) | Dart | -85 | 0 | -4 | -89 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\lib\\widgets\\nwezh\\balga.dart](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Clib%5Cwidgets%5Cnwezh%5Cbalga.dart) | Dart | -250 | 0 | -20 | -270 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\lib\\widgets\\nwezh\\header\_nwezh.dart](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Clib%5Cwidgets%5Cnwezh%5Cheader_nwezh.dart) | Dart | -46 | 0 | -8 | -54 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\lib\\widgets\\quran\_list\_widget.dart](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Clib%5Cwidgets%5Cquran_list_widget.dart) | Dart | -84 | 0 | -9 | -93 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\lib\\widgets\\sebha\_widget\\add\_tasbih\_dialog.dart](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Clib%5Cwidgets%5Csebha_widget%5Cadd_tasbih_dialog.dart) | Dart | -74 | 0 | -8 | -82 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\lib\\widgets\\sebha\_widget\\button\_drag.dart](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Clib%5Cwidgets%5Csebha_widget%5Cbutton_drag.dart) | Dart | -101 | 0 | -10 | -111 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\lib\\widgets\\sebha\_widget\\delete\_dialog.dart](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Clib%5Cwidgets%5Csebha_widget%5Cdelete_dialog.dart) | Dart | -108 | 0 | -11 | -119 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\lib\\widgets\\sebha\_widget\\edit\_tasbih\_dialog.dart](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Clib%5Cwidgets%5Csebha_widget%5Cedit_tasbih_dialog.dart) | Dart | -71 | 0 | -9 | -80 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\lib\\widgets\\sebha\_widget\\expansion\_tile\_sebha.dart](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Clib%5Cwidgets%5Csebha_widget%5Cexpansion_tile_sebha.dart) | Dart | -109 | -1 | -16 | -126 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\lib\\widgets\\sebha\_widget\\pop\_up\_menu.dart](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Clib%5Cwidgets%5Csebha_widget%5Cpop_up_menu.dart) | Dart | -140 | 0 | -9 | -149 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\lib\\widgets\\sebha\_widget\\tasbih.dart](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Clib%5Cwidgets%5Csebha_widget%5Ctasbih.dart) | Dart | -157 | 0 | -13 | -170 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\lib\\widgets\\sebha\_widget\\tasbih\_fields\\row\_button\_dialog.dart](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Clib%5Cwidgets%5Csebha_widget%5Ctasbih_fields%5Crow_button_dialog.dart) | Dart | -75 | 0 | -7 | -82 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\lib\\widgets\\sebha\_widget\\tasbih\_fields\\tasbih\_form.dart](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Clib%5Cwidgets%5Csebha_widget%5Ctasbih_fields%5Ctasbih_form.dart) | Dart | -119 | 0 | -12 | -131 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\lib\\widgets\\sebha\_widget\\tasbih\_fields\\tasbih\_text\_field.dart](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Clib%5Cwidgets%5Csebha_widget%5Ctasbih_fields%5Ctasbih_text_field.dart) | Dart | -89 | 0 | -9 | -98 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\linux\\CMakeLists.txt](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Clinux%5CCMakeLists.txt) | CMake | -104 | 0 | -25 | -129 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\linux\\flutter\\CMakeLists.txt](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Clinux%5Cflutter%5CCMakeLists.txt) | CMake | -79 | 0 | -10 | -89 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\linux\\flutter\\generated\_plugin\_registrant.cc](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Clinux%5Cflutter%5Cgenerated_plugin_registrant.cc) | C++ | -7 | -4 | -5 | -16 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\linux\\flutter\\generated\_plugin\_registrant.h](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Clinux%5Cflutter%5Cgenerated_plugin_registrant.h) | C++ | -5 | -5 | -6 | -16 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\linux\\flutter\\generated\_plugins.cmake](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Clinux%5Cflutter%5Cgenerated_plugins.cmake) | CMake | -19 | 0 | -6 | -25 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\linux\\runner\\CMakeLists.txt](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Clinux%5Crunner%5CCMakeLists.txt) | CMake | -21 | 0 | -6 | -27 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\linux\\runner\\main.cc](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Clinux%5Crunner%5Cmain.cc) | C++ | -5 | 0 | -2 | -7 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\linux\\runner\\my\_application.cc](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Clinux%5Crunner%5Cmy_application.cc) | C++ | -94 | -26 | -29 | -149 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\linux\\runner\\my\_application.h](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Clinux%5Crunner%5Cmy_application.h) | C++ | -10 | -7 | -5 | -22 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\macos\\Flutter\\GeneratedPluginRegistrant.swift](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Cmacos%5CFlutter%5CGeneratedPluginRegistrant.swift) | Swift | -16 | -3 | -4 | -23 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\macos\\RunnerTests\\RunnerTests.swift](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Cmacos%5CRunnerTests%5CRunnerTests.swift) | Swift | -7 | -2 | -4 | -13 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\macos\\Runner\\AppDelegate.swift](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Cmacos%5CRunner%5CAppDelegate.swift) | Swift | -11 | 0 | -3 | -14 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\macos\\Runner\\Assets.xcassets\\AppIcon.appiconset\\Contents.json](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Cmacos%5CRunner%5CAssets.xcassets%5CAppIcon.appiconset%5CContents.json) | JSON | -68 | 0 | -1 | -69 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\macos\\Runner\\Base.lproj\\MainMenu.xib](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Cmacos%5CRunner%5CBase.lproj%5CMainMenu.xib) | XML | -343 | 0 | -1 | -344 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\macos\\Runner\\MainFlutterWindow.swift](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Cmacos%5CRunner%5CMainFlutterWindow.swift) | Swift | -12 | 0 | -4 | -16 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\pubspec.yaml](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Cpubspec.yaml) | YAML | -138 | -35 | -34 | -207 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\test\\widget\_test.dart](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Ctest%5Cwidget_test.dart) | Dart | -14 | -10 | -7 | -31 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\web\\index.html](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Cweb%5Cindex.html) | HTML | -19 | -15 | -5 | -39 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\web\\manifest.json](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Cweb%5Cmanifest.json) | JSON | -35 | 0 | -1 | -36 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\windows\\CMakeLists.txt](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Cwindows%5CCMakeLists.txt) | CMake | -89 | 0 | -20 | -109 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\windows\\flutter\\CMakeLists.txt](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Cwindows%5Cflutter%5CCMakeLists.txt) | CMake | -98 | 0 | -12 | -110 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\windows\\flutter\\generated\_plugin\_registrant.cc](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Cwindows%5Cflutter%5Cgenerated_plugin_registrant.cc) | C++ | -15 | -4 | -5 | -24 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\windows\\flutter\\generated\_plugin\_registrant.h](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Cwindows%5Cflutter%5Cgenerated_plugin_registrant.h) | C++ | -5 | -5 | -6 | -16 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\windows\\flutter\\generated\_plugins.cmake](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Cwindows%5Cflutter%5Cgenerated_plugins.cmake) | CMake | -22 | 0 | -6 | -28 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\windows\\runner\\CMakeLists.txt](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Cwindows%5Crunner%5CCMakeLists.txt) | CMake | -34 | 0 | -7 | -41 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\windows\\runner\\flutter\_window.cpp](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Cwindows%5Crunner%5Cflutter_window.cpp) | C++ | -49 | -7 | -16 | -72 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\windows\\runner\\flutter\_window.h](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Cwindows%5Crunner%5Cflutter_window.h) | C++ | -20 | -5 | -9 | -34 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\windows\\runner\\main.cpp](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Cwindows%5Crunner%5Cmain.cpp) | C++ | -30 | -4 | -10 | -44 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\windows\\runner\\resource.h](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Cwindows%5Crunner%5Cresource.h) | C++ | -9 | -6 | -2 | -17 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\windows\\runner\\utils.cpp](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Cwindows%5Crunner%5Cutils.cpp) | C++ | -54 | -2 | -10 | -66 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\windows\\runner\\utils.h](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Cwindows%5Crunner%5Cutils.h) | C++ | -8 | -6 | -6 | -20 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\windows\\runner\\win32\_window.cpp](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Cwindows%5Crunner%5Cwin32_window.cpp) | C++ | -210 | -24 | -55 | -289 |
| [c:\\Users\\Amin's PC\\StudioProjects\\runaki\_islam\\windows\\runner\\win32\_window.h](/c:%5CUsers%5CAmin's%20PC%5CStudioProjects%5Crunaki_islam%5Cwindows%5Crunner%5Cwin32_window.h) | C++ | -48 | -31 | -24 | -103 |

[Summary](results.md) / [Details](details.md) / [Diff Summary](diff.md) / Diff Details