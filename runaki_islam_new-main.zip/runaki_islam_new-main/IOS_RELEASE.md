# iOS Release Setup

1. Run `flutter pub get`.
2. On macOS, run `cd ios && pod install`.
3. Open `ios/Runner.xcworkspace` in Xcode.
4. If you want the AI screen enabled, pass `--dart-define=GEMINI_API_KEY=your_key` when building, or add the same value to the Xcode run/archive configuration.
5. Set the Apple `Development Team`, final bundle identifier, and signing profile.
6. Archive from Xcode and upload with Organizer.

## Current iOS behavior

- The repo now includes a standard `ios/Podfile` so CocoaPods can resolve Flutter plugins on macOS.
- Prayer times, Quran, Qibla, content screens, and the rest of the main app flow remain available on iPhone.
- Firebase push notifications remain available on signed iOS builds.
- The home-screen prayer widget is wired for iOS 14+ through the `PrayerTimesWidget` extension and the shared app group `group.com.amin.runakeislam.shared`.
- iOS still requires real-device verification for notification delivery, widget refresh timing, signing, and app-group entitlements before release.

## Before App Store upload

- Verify the final display name, screenshots, privacy answers, and bundle id in Xcode.
- Run `pod install` and test on a real iPhone and an iPhone simulator.
- In Xcode, confirm both `Runner` and `PrayerTimesWidget` use the same Apple team and have the shared App Group enabled.
- Verify the build includes `GEMINI_API_KEY` if the AI feature should work in production.
- Confirm location permission text matches the actual app behavior.
- Confirm Firebase push notifications and the prayer widget work on a signed device build.
- Archive with a real Apple signing team on macOS.
