import 'package:flutter_test/flutter_test.dart';

import 'package:runaki_islam/main.dart';

void main() {
  testWidgets('App boots without framework exceptions', (
    WidgetTester tester,
  ) async {
    await tester.pumpWidget(const MyApp());
    await tester.pump(const Duration(milliseconds: 300));
    await tester.pump(const Duration(seconds: 1));

    expect(tester.takeException(), isNull);
  });
}
