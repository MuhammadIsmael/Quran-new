# Changelog

## 1.0.4+7

### Google Play short notes

- Improved push notifications and background zikr reminder reliability.
- Improved Android 16 compatibility and Play Store release readiness.
- Fixed Kurdish localization startup issues on current Flutter versions.
- Improved stability and removed unused code.

### Detailed changes

- Updated the target to Android 16 (API 36).
- Added a proper monochrome notification icon for Firebase and foreground notifications.
- Split zikr reminder delivery from reboot/time-change handling and protected the app-only receiver from external broadcasts.
- Reschedule zikr reminders after reboot, time changes, timezone changes, date changes, and app updates.
- Isolated notification service startup so Firebase failures do not block zikr reminders.
- Removed unused Athan alarm code, exact-alarm permission, and bundled Athan audio.
- Changed zikr reminders to battery-friendly inexact alarms that do not need
  restricted exact-alarm access.
- Added a forward-compatible Kurdish widgets localization delegate.
- Updated compatible dependency versions.
- Updated the Android Gradle wrapper and core Android libraries.
- Updated the iOS Firebase pod lock to SDK 12.15.0.
- Added an Xcode 26-compatible local patch for the iOS compass plugin.
- Fixed the iOS widget extension version and CocoaPods profile configuration.
- Fixed all analyzer warnings, deprecated API usage, and unsafe async context usage.
- Removed committed iOS build-cache artifacts.
- Prevented Android release builds from silently using the debug signing key.

## 1.0.2+5

### Google Play short notes
- Improved Quran reading experience with better fonts and smoother Surah detail scrolling.
- Fixed Ayah repeat and auto-scroll behavior in Surah detail.
- Improved Athan alarm behavior on Android and made dismissing more reliable.
- Added background zikr reminders with morning and evening reminders.
- Fixed prayer-time location detection on real Android devices.

### Detailed changes
- Applied Quran font selection correctly across the Quran list and detail reading flow.
- Fixed Surah detail auto-scroll targeting and repeat stop behavior.
- Kept the Surah banner only in paper mode for a cleaner Quran detail layout.
- Cleaned up duplicate Quran font options and fixed font setting persistence.
- Improved Android Athan playback to use the alarm path with stronger alert behavior.
- Added background zikr notifications that work even when the app is closed.
- Opening a zikr notification now launches the app into a detailed modal sheet with an Islamic reading design.
- Improved the zikr modal to be easier to scroll and read for long content.
- Reworked passed-prayer timing so elapsed time is shown clearly instead of using the remaining countdown widget.
- Improved prayer-time auto-location flow so it does not incorrectly report GPS as disabled on some devices.

### Suggested Google Play "What's New"
- Fixed several Quran reading and Surah playback issues.
- Improved Athan alarm reliability on Android devices.
- Added better background zikr reminders with detailed reading view.
- Improved prayer-time location detection and overall stability.
