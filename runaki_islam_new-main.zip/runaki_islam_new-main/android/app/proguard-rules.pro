# Keep default R8 behavior; add project-specific rules here only if a release
# build proves a library needs extra retention.
