package com.amin.runakeislam

import android.appwidget.AppWidgetManager
import android.content.Context
import android.content.SharedPreferences
import es.antonborri.home_widget.HomeWidgetProvider

class PrayerTimesHomeWidgetProvider : HomeWidgetProvider() {
  override fun onUpdate(
      context: Context,
      appWidgetManager: AppWidgetManager,
      appWidgetIds: IntArray,
      widgetData: SharedPreferences,
  ) {
    appWidgetIds.forEach { widgetId ->
      val views = PrayerWidgetRemoteViewsBuilder.buildLarge(context, widgetData)
      appWidgetManager.updateAppWidget(widgetId, views)
    }
  }
}
