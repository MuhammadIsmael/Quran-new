package com.amin.runakeislam

import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.content.edit
import org.json.JSONArray
import org.json.JSONObject
import java.util.Calendar
import kotlin.random.Random

data class ZikrReminderContent(
    val title: String,
    val body: String,
    val detail: String = body,
    val kind: String = "periodic",
)

object ZikrReminderScheduler {
  const val ACTION_FIRE_ZIKR_REMINDER = "com.amin.runakeislam.runaki_islam.ACTION_FIRE_ZIKR_REMINDER"
  const val ACTION_OPEN_ZIKR_REMINDER = "com.amin.runakeislam.runaki_islam.ACTION_OPEN_ZIKR_REMINDER"
  const val EXTRA_REQUEST_CODE = "extra_zikr_request_code"
  const val EXTRA_ZIKR_TITLE = "extra_zikr_title"
  const val EXTRA_ZIKR_BODY = "extra_zikr_body"
  const val EXTRA_ZIKR_DETAIL = "extra_zikr_detail"
  const val EXTRA_ZIKR_KIND = "extra_zikr_kind"

  private const val PREFS_NAME = "zikr_reminder_scheduler"
  private const val KEY_ENABLED = "enabled"
  private const val KEY_INTERVAL_MS = "interval_ms"
  private const val KEY_NEXT_PERIODIC_TRIGGER_MS = "next_trigger_ms"
  private const val KEY_NEXT_MORNING_TRIGGER_MS = "next_morning_trigger_ms"
  private const val KEY_NEXT_EVENING_TRIGGER_MS = "next_evening_trigger_ms"
  private const val KEY_PERIODIC_REMINDERS_JSON = "messages_json"
  private const val KEY_MORNING_REMINDER_JSON = "morning_reminder_json"
  private const val KEY_EVENING_REMINDER_JSON = "evening_reminder_json"

  private const val REQUEST_CODE_PERIODIC = 991001
  private const val REQUEST_CODE_MORNING = 991002
  private const val REQUEST_CODE_EVENING = 991003

  private const val DEFAULT_INTERVAL_MS = 5L * 60L * 60L * 1000L
  private const val CHANNEL_ID = "zikr_reminder_channel"
  private const val CHANNEL_NAME = "Zikr Reminder"
  private const val CHANNEL_DESC = "Morning, evening, and periodic zikr reminders"

  private const val MORNING_HOUR = 7
  private const val MORNING_MINUTE = 0
  private const val EVENING_HOUR = 17
  private const val EVENING_MINUTE = 0
  private const val KIND_PERIODIC = "periodic"
  private const val KIND_MORNING = "morning"
  private const val KIND_EVENING = "evening"

  private const val FALLBACK_PERIODIC_TITLE = "بیربهێنەوەی زیکر"
  private const val FALLBACK_PERIODIC_BODY = "سبحان الله"
  private const val FALLBACK_MORNING_TITLE = "زیکری بەیانیان"
  private const val FALLBACK_MORNING_BODY =
      "بەیانیە. کاتێکی جوانە بۆ دەستپێکردن بە زیکر و یادی خوا."
  private const val FALLBACK_EVENING_TITLE = "زیکری ئێواران"
  private const val FALLBACK_EVENING_BODY =
      "ئێوارەیە. ڕۆژەکەت بە زیکر و دڵنیایی کۆتایی پێ بهێنە."

  private val allRequestCodes =
      intArrayOf(
          REQUEST_CODE_PERIODIC,
          REQUEST_CODE_MORNING,
          REQUEST_CODE_EVENING,
      )

  fun scheduleReminders(
      context: Context,
      intervalMinutes: Int,
      periodicReminders: List<ZikrReminderContent>,
      morningReminder: ZikrReminderContent?,
      eveningReminder: ZikrReminderContent?,
  ) {
    val intervalMillis = normalizeIntervalMillis(intervalMinutes)
    val sanitizedPeriodic =
        sanitizeReminders(
            reminders = periodicReminders,
            fallbackTitle = FALLBACK_PERIODIC_TITLE,
            fallbackBody = FALLBACK_PERIODIC_BODY,
        )
    val resolvedMorning =
        sanitizeSingleReminder(
            reminder = morningReminder,
            fallbackTitle = FALLBACK_MORNING_TITLE,
            fallbackBody = FALLBACK_MORNING_BODY,
        )
    val resolvedEvening =
        sanitizeSingleReminder(
            reminder = eveningReminder,
            fallbackTitle = FALLBACK_EVENING_TITLE,
            fallbackBody = FALLBACK_EVENING_BODY,
        )

    val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    val now = System.currentTimeMillis()
    val savedEnabled = prefs.getBoolean(KEY_ENABLED, false)
    val savedInterval = prefs.getLong(KEY_INTERVAL_MS, intervalMillis)
    val savedPeriodicNext = prefs.getLong(KEY_NEXT_PERIODIC_TRIGGER_MS, 0L)
    val savedMorningNext = prefs.getLong(KEY_NEXT_MORNING_TRIGGER_MS, 0L)
    val savedEveningNext = prefs.getLong(KEY_NEXT_EVENING_TRIGGER_MS, 0L)

    val nextPeriodicAt =
        if (savedEnabled && savedInterval == intervalMillis && savedPeriodicNext > now + 1000L) {
          savedPeriodicNext
        } else {
          now + intervalMillis
        }
    val nextMorningAt =
        preserveOrComputeFixedTrigger(
            storedNext = savedMorningNext,
            now = now,
            hour = MORNING_HOUR,
            minute = MORNING_MINUTE,
        )
    val nextEveningAt =
        preserveOrComputeFixedTrigger(
            storedNext = savedEveningNext,
            now = now,
            hour = EVENING_HOUR,
            minute = EVENING_MINUTE,
        )

    cancelPendingOnly(context)
    scheduleOne(context, REQUEST_CODE_PERIODIC, nextPeriodicAt)
    scheduleOne(context, REQUEST_CODE_MORNING, nextMorningAt)
    scheduleOne(context, REQUEST_CODE_EVENING, nextEveningAt)

    prefs.edit {
      putBoolean(KEY_ENABLED, true)
      putLong(KEY_INTERVAL_MS, intervalMillis)
      putLong(KEY_NEXT_PERIODIC_TRIGGER_MS, nextPeriodicAt)
      putLong(KEY_NEXT_MORNING_TRIGGER_MS, nextMorningAt)
      putLong(KEY_NEXT_EVENING_TRIGGER_MS, nextEveningAt)
      putString(KEY_PERIODIC_REMINDERS_JSON, toJsonArray(sanitizedPeriodic).toString())
      putString(KEY_MORNING_REMINDER_JSON, toJsonObject(resolvedMorning).toString())
      putString(KEY_EVENING_REMINDER_JSON, toJsonObject(resolvedEvening).toString())
    }
  }

  fun cancelReminders(context: Context) {
    cancelPendingOnly(context)
    context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).edit {
      putBoolean(KEY_ENABLED, false)
      putLong(KEY_NEXT_PERIODIC_TRIGGER_MS, 0L)
      putLong(KEY_NEXT_MORNING_TRIGGER_MS, 0L)
      putLong(KEY_NEXT_EVENING_TRIGGER_MS, 0L)
    }
  }

  fun rescheduleFromStorage(context: Context) {
    val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    val enabled = prefs.getBoolean(KEY_ENABLED, false)
    if (!enabled) return

    val now = System.currentTimeMillis()
    val intervalMillis = prefs.getLong(KEY_INTERVAL_MS, DEFAULT_INTERVAL_MS).coerceAtLeast(60_000L)
    val storedPeriodicNext = prefs.getLong(KEY_NEXT_PERIODIC_TRIGGER_MS, 0L)
    val storedMorningNext = prefs.getLong(KEY_NEXT_MORNING_TRIGGER_MS, 0L)
    val storedEveningNext = prefs.getLong(KEY_NEXT_EVENING_TRIGGER_MS, 0L)

    val periodicReminders =
        loadReminders(
            rawJson = prefs.getString(KEY_PERIODIC_REMINDERS_JSON, null),
            fallbackTitle = FALLBACK_PERIODIC_TITLE,
            fallbackBody = FALLBACK_PERIODIC_BODY,
        )
    val morningReminder =
        loadSingleReminder(
            rawJson = prefs.getString(KEY_MORNING_REMINDER_JSON, null),
            fallbackTitle = FALLBACK_MORNING_TITLE,
            fallbackBody = FALLBACK_MORNING_BODY,
        )
    val eveningReminder =
        loadSingleReminder(
            rawJson = prefs.getString(KEY_EVENING_REMINDER_JSON, null),
            fallbackTitle = FALLBACK_EVENING_TITLE,
            fallbackBody = FALLBACK_EVENING_BODY,
        )

    val nextPeriodicAt = if (storedPeriodicNext > now + 1000L) storedPeriodicNext else now + intervalMillis
    val nextMorningAt =
        preserveOrComputeFixedTrigger(
            storedNext = storedMorningNext,
            now = now,
            hour = MORNING_HOUR,
            minute = MORNING_MINUTE,
        )
    val nextEveningAt =
        preserveOrComputeFixedTrigger(
            storedNext = storedEveningNext,
            now = now,
            hour = EVENING_HOUR,
            minute = EVENING_MINUTE,
        )

    cancelPendingOnly(context)
    if (periodicReminders.isNotEmpty()) {
      scheduleOne(context, REQUEST_CODE_PERIODIC, nextPeriodicAt)
    }
    if (morningReminder != null) {
      scheduleOne(context, REQUEST_CODE_MORNING, nextMorningAt)
    }
    if (eveningReminder != null) {
      scheduleOne(context, REQUEST_CODE_EVENING, nextEveningAt)
    }

    prefs.edit {
      putLong(KEY_NEXT_PERIODIC_TRIGGER_MS, nextPeriodicAt)
      putLong(KEY_NEXT_MORNING_TRIGGER_MS, nextMorningAt)
      putLong(KEY_NEXT_EVENING_TRIGGER_MS, nextEveningAt)
    }
  }

  fun onReminderFired(context: Context, intent: Intent?) {
    val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    val enabled = prefs.getBoolean(KEY_ENABLED, false)
    if (!enabled) return

    val requestCode = intent?.getIntExtra(EXTRA_REQUEST_CODE, REQUEST_CODE_PERIODIC)
        ?: REQUEST_CODE_PERIODIC
    when (requestCode) {
      REQUEST_CODE_MORNING -> handleMorningReminder(context, prefs)
      REQUEST_CODE_EVENING -> handleEveningReminder(context, prefs)
      else -> handlePeriodicReminder(context, prefs)
    }
  }

  private fun handlePeriodicReminder(
      context: Context,
      prefs: android.content.SharedPreferences,
  ) {
    val reminders =
        loadReminders(
            rawJson = prefs.getString(KEY_PERIODIC_REMINDERS_JSON, null),
            fallbackTitle = FALLBACK_PERIODIC_TITLE,
            fallbackBody = FALLBACK_PERIODIC_BODY,
        )
    val reminder = pickRandomReminder(reminders)
    val intervalMillis = prefs.getLong(KEY_INTERVAL_MS, DEFAULT_INTERVAL_MS).coerceAtLeast(60_000L)
    val subText =
        if (intervalMillis <= 60_000L) {
          "تاقیکردنەوەی زیکر"
        } else {
          "بیربهێنەوەی زیکر"
        }
    showNotification(context = context, reminder = reminder, subText = subText)

    val nextTriggerAt = System.currentTimeMillis() + intervalMillis
    scheduleOne(context, REQUEST_CODE_PERIODIC, nextTriggerAt)
    prefs.edit { putLong(KEY_NEXT_PERIODIC_TRIGGER_MS, nextTriggerAt) }
  }

  private fun handleMorningReminder(
      context: Context,
      prefs: android.content.SharedPreferences,
  ) {
    val reminder =
        loadSingleReminder(
            rawJson = prefs.getString(KEY_MORNING_REMINDER_JSON, null),
            fallbackTitle = FALLBACK_MORNING_TITLE,
            fallbackBody = FALLBACK_MORNING_BODY,
        )
            ?: ZikrReminderContent(
                title = FALLBACK_MORNING_TITLE,
                body = FALLBACK_MORNING_BODY,
                detail = FALLBACK_MORNING_BODY,
                kind = KIND_MORNING,
            )

    showNotification(
        context = context,
        reminder = reminder,
        subText = "بیربهێنەوەی بەیانی",
    )

    val nextTriggerAt =
        nextFixedOccurrence(
            now = System.currentTimeMillis(),
            hour = MORNING_HOUR,
            minute = MORNING_MINUTE,
        )
    scheduleOne(context, REQUEST_CODE_MORNING, nextTriggerAt)
    prefs.edit { putLong(KEY_NEXT_MORNING_TRIGGER_MS, nextTriggerAt) }
  }

  private fun handleEveningReminder(
      context: Context,
      prefs: android.content.SharedPreferences,
  ) {
    val reminder =
        loadSingleReminder(
            rawJson = prefs.getString(KEY_EVENING_REMINDER_JSON, null),
            fallbackTitle = FALLBACK_EVENING_TITLE,
            fallbackBody = FALLBACK_EVENING_BODY,
        )
            ?: ZikrReminderContent(
                title = FALLBACK_EVENING_TITLE,
                body = FALLBACK_EVENING_BODY,
                detail = FALLBACK_EVENING_BODY,
                kind = KIND_EVENING,
            )

    showNotification(
        context = context,
        reminder = reminder,
        subText = "بیربهێنەوەی ئێوارە",
    )

    val nextTriggerAt =
        nextFixedOccurrence(
            now = System.currentTimeMillis(),
            hour = EVENING_HOUR,
            minute = EVENING_MINUTE,
        )
    scheduleOne(context, REQUEST_CODE_EVENING, nextTriggerAt)
    prefs.edit { putLong(KEY_NEXT_EVENING_TRIGGER_MS, nextTriggerAt) }
  }

  private fun normalizeIntervalMillis(intervalMinutes: Int): Long {
    val normalizedMinutes = intervalMinutes.coerceIn(1, 72 * 60)
    return normalizedMinutes * 60L * 1000L
  }

  private fun sanitizeReminders(
      reminders: List<ZikrReminderContent>,
      fallbackTitle: String,
      fallbackBody: String,
  ): List<ZikrReminderContent> {
    val unique = LinkedHashMap<String, ZikrReminderContent>()
    for (reminder in reminders) {
      val title = reminder.title.trim()
      val body = reminder.body.trim()
      val detail = reminder.detail.trim().ifEmpty { body }
      val kind = normalizeKind(reminder.kind)
      if (title.isEmpty() || detail.isEmpty()) continue
      unique["$title|$detail"] =
          ZikrReminderContent(
              title = title,
              body = if (body.isNotEmpty()) body else detail,
              detail = detail,
              kind = kind,
          )
      if (unique.size >= 180) break
    }
    if (unique.isEmpty()) {
      return listOf(
          ZikrReminderContent(
              title = fallbackTitle,
              body = fallbackBody,
              detail = fallbackBody,
              kind = KIND_PERIODIC,
          ))
    }
    return unique.values.toList()
  }

  private fun sanitizeSingleReminder(
      reminder: ZikrReminderContent?,
      fallbackTitle: String,
      fallbackBody: String,
  ): ZikrReminderContent {
    val title = reminder?.title?.trim().orEmpty()
    val body = reminder?.body?.trim().orEmpty()
    val detail = reminder?.detail?.trim().orEmpty().ifEmpty { body }
    val kind = normalizeKind(reminder?.kind.orEmpty())
    if (title.isEmpty() || detail.isEmpty()) {
      return ZikrReminderContent(
          title = fallbackTitle,
          body = fallbackBody,
          detail = fallbackBody,
          kind =
              when (fallbackTitle) {
                FALLBACK_MORNING_TITLE -> KIND_MORNING
                FALLBACK_EVENING_TITLE -> KIND_EVENING
                else -> KIND_PERIODIC
              },
      )
    }
    return ZikrReminderContent(
        title = title,
        body = if (body.isNotEmpty()) body else detail,
        detail = detail,
        kind = kind,
    )
  }

  private fun loadReminders(
      rawJson: String?,
      fallbackTitle: String,
      fallbackBody: String,
  ): List<ZikrReminderContent> {
    if (rawJson.isNullOrBlank()) {
      return listOf(
          ZikrReminderContent(
              title = fallbackTitle,
              body = fallbackBody,
              detail = fallbackBody,
              kind = KIND_PERIODIC,
          ))
    }

    return try {
      val json = JSONArray(rawJson)
      val reminders = ArrayList<ZikrReminderContent>(json.length())
      for (index in 0 until json.length()) {
        when (val item = json.opt(index)) {
          is JSONObject -> {
            val title = item.optString("title", "").trim()
            val body = item.optString("body", "").trim()
            val detail = item.optString("detail", "").trim().ifEmpty { body }
            if (title.isNotEmpty() && detail.isNotEmpty()) {
              reminders.add(
                  ZikrReminderContent(
                      title = title,
                      body = if (body.isNotEmpty()) body else detail,
                      detail = detail,
                      kind = normalizeKind(item.optString("kind", "")),
                  ))
            }
          }

          is String -> {
            val body = item.trim()
            if (body.isNotEmpty()) {
              reminders.add(
                  ZikrReminderContent(
                      title = fallbackTitle,
                      body = body,
                      detail = body,
                      kind = KIND_PERIODIC,
                  ))
            }
          }
        }
      }

      if (reminders.isEmpty()) {
        listOf(
            ZikrReminderContent(
                title = fallbackTitle,
                body = fallbackBody,
                detail = fallbackBody,
                kind = KIND_PERIODIC,
            ))
      } else {
        sanitizeReminders(reminders, fallbackTitle, fallbackBody)
      }
    } catch (_: Exception) {
      listOf(
          ZikrReminderContent(
              title = fallbackTitle,
              body = fallbackBody,
              detail = fallbackBody,
              kind = KIND_PERIODIC,
          ))
    }
  }

  private fun loadSingleReminder(
      rawJson: String?,
      fallbackTitle: String,
      fallbackBody: String,
  ): ZikrReminderContent? {
    if (rawJson.isNullOrBlank()) {
      return ZikrReminderContent(
          title = fallbackTitle,
          body = fallbackBody,
          detail = fallbackBody,
      )
    }

    return try {
      val json = JSONObject(rawJson)
      sanitizeSingleReminder(
          reminder =
              ZikrReminderContent(
                  title = json.optString("title", ""),
                  body = json.optString("body", ""),
                  detail = json.optString("detail", ""),
                  kind = json.optString("kind", ""),
              ),
          fallbackTitle = fallbackTitle,
          fallbackBody = fallbackBody,
      )
    } catch (_: Exception) {
      ZikrReminderContent(
          title = fallbackTitle,
          body = fallbackBody,
          detail = fallbackBody,
      )
    }
  }

  private fun toJsonArray(reminders: List<ZikrReminderContent>): JSONArray {
    val json = JSONArray()
    reminders.forEach { reminder -> json.put(toJsonObject(reminder)) }
    return json
  }

  private fun toJsonObject(reminder: ZikrReminderContent): JSONObject {
    return JSONObject()
        .put("title", reminder.title)
        .put("body", reminder.body)
        .put("detail", reminder.detail)
        .put("kind", reminder.kind)
  }

  private fun pickRandomReminder(reminders: List<ZikrReminderContent>): ZikrReminderContent {
    if (reminders.isEmpty()) {
      return ZikrReminderContent(
          title = FALLBACK_PERIODIC_TITLE,
          body = FALLBACK_PERIODIC_BODY,
          detail = FALLBACK_PERIODIC_BODY,
          kind = KIND_PERIODIC,
      )
    }
    return reminders[Random.nextInt(reminders.size)]
  }

  private fun normalizeKind(raw: String): String {
    return when (raw.trim().lowercase()) {
      KIND_MORNING -> KIND_MORNING
      KIND_EVENING -> KIND_EVENING
      else -> KIND_PERIODIC
    }
  }

  private fun preserveOrComputeFixedTrigger(
      storedNext: Long,
      now: Long,
      hour: Int,
      minute: Int,
  ): Long {
    return if (storedNext > now + 1000L) {
      storedNext
    } else {
      nextFixedOccurrence(now, hour, minute)
    }
  }

  private fun nextFixedOccurrence(
      now: Long,
      hour: Int,
      minute: Int,
  ): Long {
    val calendar =
        Calendar.getInstance().apply {
          timeInMillis = now
          set(Calendar.HOUR_OF_DAY, hour)
          set(Calendar.MINUTE, minute)
          set(Calendar.SECOND, 0)
          set(Calendar.MILLISECOND, 0)
          if (timeInMillis <= now + 1000L) {
            add(Calendar.DAY_OF_YEAR, 1)
          }
        }
    return calendar.timeInMillis
  }

  private fun cancelPendingOnly(context: Context) {
    val manager = context.getSystemService(AlarmManager::class.java) ?: return
    for (requestCode in allRequestCodes) {
      val intent =
          Intent(context, ZikrReminderReceiver::class.java).apply {
            action = ACTION_FIRE_ZIKR_REMINDER
          }
      val pendingIntent =
          PendingIntent.getBroadcast(
              context,
              requestCode,
              intent,
              PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE,
          )
      if (pendingIntent != null) {
        manager.cancel(pendingIntent)
        pendingIntent.cancel()
      }
    }
  }

  private fun scheduleOne(
      context: Context,
      requestCode: Int,
      triggerAtMillis: Long,
  ) {
    val manager = context.getSystemService(AlarmManager::class.java) ?: return
    val intent =
        Intent(context, ZikrReminderReceiver::class.java).apply {
          action = ACTION_FIRE_ZIKR_REMINDER
          putExtra(EXTRA_REQUEST_CODE, requestCode)
        }
    val pendingIntent =
        PendingIntent.getBroadcast(
            context,
            requestCode,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )

    // A zikr reminder does not need alarm-clock precision. Inexact idle alarms
    // preserve battery and avoid Play's restricted exact-alarm permission.
    manager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAtMillis, pendingIntent)
  }

  private fun showNotification(
      context: Context,
      reminder: ZikrReminderContent,
      subText: String,
  ) {
    val manager = context.getSystemService(NotificationManager::class.java) ?: return
    ensureChannel(manager)

    val notificationId = ((System.currentTimeMillis() / 1000L) % Int.MAX_VALUE).toInt()
    val launchIntent =
        Intent(context, MainActivity::class.java).apply {
          action = ACTION_OPEN_ZIKR_REMINDER
          putExtra(EXTRA_ZIKR_TITLE, reminder.title)
          putExtra(EXTRA_ZIKR_BODY, reminder.body)
          putExtra(EXTRA_ZIKR_DETAIL, reminder.detail)
          putExtra(EXTRA_ZIKR_KIND, normalizeKind(reminder.kind))
          flags =
              Intent.FLAG_ACTIVITY_NEW_TASK or
                  Intent.FLAG_ACTIVITY_CLEAR_TOP or
                  Intent.FLAG_ACTIVITY_SINGLE_TOP
        }
    val launchPendingIntent =
        PendingIntent.getActivity(
            context,
            notificationId,
            launchIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )

    val notification =
        NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle(reminder.title)
            .setContentText(reminder.body)
            .setSubText(subText)
            .setStyle(
                NotificationCompat.BigTextStyle()
                    .bigText(reminder.body)
                    .setBigContentTitle(reminder.title)
                    .setSummaryText(subText))
            .setAutoCancel(true)
            .setContentIntent(launchPendingIntent)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setCategory(NotificationCompat.CATEGORY_REMINDER)
            .build()

    manager.notify(notificationId, notification)
  }

  private fun ensureChannel(manager: NotificationManager) {
    if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
    val existing = manager.getNotificationChannel(CHANNEL_ID)
    if (existing != null) return

    val channel =
        NotificationChannel(CHANNEL_ID, CHANNEL_NAME, NotificationManager.IMPORTANCE_HIGH).apply {
          description = CHANNEL_DESC
          enableVibration(true)
          lockscreenVisibility = NotificationCompat.VISIBILITY_PUBLIC
        }
    manager.createNotificationChannel(channel)
  }
}
