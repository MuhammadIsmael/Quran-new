package com.amin.runakeislam

import android.content.Context
import android.content.SharedPreferences
import android.widget.RemoteViews
import es.antonborri.home_widget.HomeWidgetLaunchIntent

internal object PrayerWidgetRemoteViewsBuilder {
  private val largeTimeIds =
      intArrayOf(
          R.id.widget_time_1,
          R.id.widget_time_2,
          R.id.widget_time_3,
          R.id.widget_time_4,
          R.id.widget_time_5,
      )
  private val largeNameIds =
      intArrayOf(
          R.id.widget_name_1,
          R.id.widget_name_2,
          R.id.widget_name_3,
          R.id.widget_name_4,
          R.id.widget_name_5,
      )

  private val compactTimeIds =
      intArrayOf(
          R.id.compact_time_1,
          R.id.compact_time_2,
          R.id.compact_time_3,
      )
  private val compactNameIds =
      intArrayOf(
          R.id.compact_name_1,
          R.id.compact_name_2,
          R.id.compact_name_3,
      )

  private val fallbackRowNames = arrayOf("Fajr", "Dhuhr", "Asr", "Maghrib", "Isha")

  fun buildLarge(context: Context, widgetData: SharedPreferences): RemoteViews {
    return RemoteViews(context.packageName, R.layout.prayer_times_home_widget).apply {
      bindHeader(
          widgetData = widgetData,
          cityViewId = R.id.widget_city,
          nextLineViewId = R.id.widget_next_line,
          nextTimeViewId = R.id.widget_next_time,
          remainingViewId = R.id.widget_remaining,
          dateViewId = R.id.widget_date,
      )
      bindRows(widgetData, largeTimeIds, largeNameIds, rowOffset = 0)
      bindRootClick(context, R.id.widget_root)
    }
  }

  fun buildCompact(context: Context, widgetData: SharedPreferences): RemoteViews {
    return RemoteViews(context.packageName, R.layout.prayer_times_home_widget_compact).apply {
      bindHeader(
          widgetData = widgetData,
          cityViewId = R.id.compact_city,
          nextLineViewId = R.id.compact_next_line,
          nextTimeViewId = R.id.compact_next_time,
          remainingViewId = R.id.compact_remaining,
          dateViewId = R.id.compact_date,
      )
      bindRows(widgetData, compactTimeIds, compactNameIds, rowOffset = 0)
      bindRootClick(context, R.id.compact_root)
    }
  }

  fun buildMini(context: Context, widgetData: SharedPreferences): RemoteViews {
    return RemoteViews(context.packageName, R.layout.prayer_times_home_widget_mini).apply {
      setTextViewText(
          R.id.mini_city, getText(widgetData, "prayer_city", defaultValue = "Prayer Times"))
      setTextViewText(
          R.id.mini_next_line,
          getText(widgetData, "prayer_next_line", defaultValue = "Next prayer"),
      )
      setTextViewText(
          R.id.mini_next_time,
          getText(widgetData, "prayer_next_time", defaultValue = "--:--"),
      )
      setTextViewText(
          R.id.mini_remaining,
          getText(widgetData, "prayer_remaining", defaultValue = "-- min"),
      )
      setTextViewText(R.id.mini_date, getText(widgetData, "prayer_date", defaultValue = "--/--"))
      bindRootClick(context, R.id.mini_root)
    }
  }

  private fun RemoteViews.bindHeader(
      widgetData: SharedPreferences,
      cityViewId: Int,
      nextLineViewId: Int,
      nextTimeViewId: Int,
      remainingViewId: Int,
      dateViewId: Int,
  ) {
    setTextViewText(cityViewId, getText(widgetData, "prayer_city", defaultValue = "Prayer Times"))
    setTextViewText(
        nextLineViewId, getText(widgetData, "prayer_next_line", defaultValue = "Next prayer"))
    setTextViewText(
        nextTimeViewId, getText(widgetData, "prayer_next_time", defaultValue = "--:--"))
    setTextViewText(
        remainingViewId, getText(widgetData, "prayer_remaining", defaultValue = "-- min"))
    setTextViewText(dateViewId, getText(widgetData, "prayer_date", defaultValue = "--/--"))
  }

  private fun RemoteViews.bindRows(
      widgetData: SharedPreferences,
      timeIds: IntArray,
      nameIds: IntArray,
      rowOffset: Int,
  ) {
    for (index in timeIds.indices) {
      val rowIndex = index + rowOffset
      setTextViewText(
          timeIds[index],
          getText(widgetData, "prayer_row_time_${rowIndex + 1}", defaultValue = "--:--"),
      )
      val fallback = fallbackRowNames.getOrNull(rowIndex) ?: "Prayer"
      setTextViewText(
          nameIds[index],
          getText(widgetData, "prayer_row_name_${rowIndex + 1}", defaultValue = fallback),
      )
    }
  }

  private fun RemoteViews.bindRootClick(context: Context, rootId: Int) {
    val launchIntent = HomeWidgetLaunchIntent.getActivity(context, MainActivity::class.java)
    setOnClickPendingIntent(rootId, launchIntent)
  }

  private fun getText(widgetData: SharedPreferences, key: String, defaultValue: String): String {
    val value = widgetData.getString(key, null)?.trim()
    return if (value.isNullOrEmpty()) defaultValue else value
  }
}
