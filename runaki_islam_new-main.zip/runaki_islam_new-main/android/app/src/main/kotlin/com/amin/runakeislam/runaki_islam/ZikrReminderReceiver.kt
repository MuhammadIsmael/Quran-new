package com.amin.runakeislam

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class ZikrReminderReceiver : BroadcastReceiver() {
  override fun onReceive(context: Context, intent: Intent?) {
    if (intent?.action == ZikrReminderScheduler.ACTION_FIRE_ZIKR_REMINDER) {
      ZikrReminderScheduler.onReminderFired(context, intent)
    }
  }
}
