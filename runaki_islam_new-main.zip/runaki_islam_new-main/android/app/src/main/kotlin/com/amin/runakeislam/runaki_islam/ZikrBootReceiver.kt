package com.amin.runakeislam

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class ZikrBootReceiver : BroadcastReceiver() {
  override fun onReceive(context: Context, intent: Intent?) {
    when (intent?.action) {
      Intent.ACTION_BOOT_COMPLETED,
      Intent.ACTION_MY_PACKAGE_REPLACED,
      Intent.ACTION_TIME_CHANGED,
      Intent.ACTION_TIMEZONE_CHANGED,
      Intent.ACTION_DATE_CHANGED -> ZikrReminderScheduler.rescheduleFromStorage(context)
    }
  }
}
