package com.amin.runakeislam

import android.content.Intent
import com.ryanheise.audioservice.AudioServiceActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel

class MainActivity : AudioServiceActivity() {
  private var alarmChannel: MethodChannel? = null
  private var pendingZikrReminder: Map<String, Any?>? = null

  override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
    super.configureFlutterEngine(flutterEngine)
    captureZikrReminderIntent(intent)
    alarmChannel =
        MethodChannel(
                flutterEngine.dartExecutor.binaryMessenger,
                "runaki_islam/adhan_alarm",
            )
            .also { channel ->
              channel.setMethodCallHandler { call, result ->
                when (call.method) {
                  "scheduleZikrReminders" -> {
                    val intervalMinutes =
                        call.argument<Int>("intervalMinutes")
                            ?: ((call.argument<Int>("intervalHours") ?: 10) * 60)
                    val rawPeriodic =
                        call.argument<List<Map<String, Any?>>>("periodicReminders").orEmpty()
                    val periodicReminders = rawPeriodic.mapNotNull { parseZikrReminder(it) }
                    val rawMessages = call.argument<List<Any?>>("zikrMessages").orEmpty()
                    val fallbackPeriodic =
                        rawMessages
                            .mapNotNull {
                              it?.toString()?.trim()?.takeIf { value -> value.isNotEmpty() }
                            }
                            .map { body ->
                              ZikrReminderContent(
                                  title = "Ø¨ÛŒØ±Ø¨Ù‡ÛŽÙ†Û•ÙˆÛ•ÛŒ Ø²ÛŒÚ©Ø±",
                                  body = body,
                              )
                            }
                    val morningReminder =
                        call.argument<Map<String, Any?>>("morningReminder")?.let {
                          parseZikrReminder(it)
                        }
                    val eveningReminder =
                        call.argument<Map<String, Any?>>("eveningReminder")?.let {
                          parseZikrReminder(it)
                        }
                    ZikrReminderScheduler.scheduleReminders(
                        applicationContext,
                        intervalMinutes = intervalMinutes,
                        periodicReminders =
                            if (periodicReminders.isNotEmpty()) {
                              periodicReminders
                            } else {
                              fallbackPeriodic
                            },
                        morningReminder = morningReminder,
                        eveningReminder = eveningReminder,
                    )
                    result.success(true)
                  }

                  "cancelZikrReminders" -> {
                    ZikrReminderScheduler.cancelReminders(applicationContext)
                    result.success(true)
                  }

                  "consumePendingZikrReminder" -> {
                    result.success(pendingZikrReminder)
                    pendingZikrReminder = null
                  }

                  else -> result.notImplemented()
                }
              }
            }
  }

  override fun onNewIntent(intent: Intent) {
    super.onNewIntent(intent)
    setIntent(intent)
    captureZikrReminderIntent(intent, notifyFlutter = true)
  }

  private fun parseZikrReminder(raw: Map<String, Any?>): ZikrReminderContent? {
    val title = raw.readString("title") ?: return null
    val body = raw.readString("body").orEmpty()
    val detail = raw.readString("detail").orEmpty().ifEmpty { body }
    val resolvedBody = body.ifEmpty { detail }
    if (resolvedBody.isEmpty() || detail.isEmpty()) return null
    return ZikrReminderContent(
        title = title,
        body = resolvedBody,
        detail = detail,
        kind = raw.readString("kind").orEmpty(),
    )
  }

  private fun Map<String, Any?>.readString(key: String): String? {
    return this[key]?.toString()?.trim()?.takeIf { it.isNotEmpty() }
  }

  private fun captureZikrReminderIntent(intent: Intent?, notifyFlutter: Boolean = false) {
    if (intent?.action != ZikrReminderScheduler.ACTION_OPEN_ZIKR_REMINDER) {
      return
    }

    val title = intent.getStringExtra(ZikrReminderScheduler.EXTRA_ZIKR_TITLE)?.trim().orEmpty()
    val body = intent.getStringExtra(ZikrReminderScheduler.EXTRA_ZIKR_BODY)?.trim().orEmpty()
    val detail = intent.getStringExtra(ZikrReminderScheduler.EXTRA_ZIKR_DETAIL)?.trim().orEmpty()
    val kind =
        intent.getStringExtra(ZikrReminderScheduler.EXTRA_ZIKR_KIND)?.trim().orEmpty()
    val resolvedDetail = if (detail.isNotEmpty()) detail else body
    val resolvedBody = if (body.isNotEmpty()) body else resolvedDetail
    if (title.isEmpty() || resolvedDetail.isEmpty()) {
      return
    }

    val payload =
        linkedMapOf<String, Any>(
            "title" to title,
            "body" to resolvedBody,
            "detail" to resolvedDetail,
            "kind" to kind.ifEmpty { "periodic" },
        )
    pendingZikrReminder = payload
    if (notifyFlutter) {
      try {
        alarmChannel?.invokeMethod("openZikrReminder", payload)
        pendingZikrReminder = null
      } catch (_: Exception) {}
    }
  }
}
