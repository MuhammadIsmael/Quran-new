# Runaki Islam

## Latest Release

Current app version: `1.0.4+7`

### Google Play "What's New" short version

- Improved push notifications and background zikr reminder reliability.
- Improved Android 16 compatibility and Play Store release readiness.
- Fixed Kurdish localization startup issues on current Flutter versions.
- Improved app stability and removed unused code.

### Highlights in 1.0.4+7

- Targets Android 16 (API 36).
- Uses a proper monochrome Android notification icon and high-priority channels.
- Reschedules zikr reminders safely after reboot, time changes, and app updates.
- Isolates notification startup tasks so one failing service cannot block another.
- Removes unused Athan alarm code, exact-alarm permission, and old audio resources.
- Updates compatible dependencies and clears all Flutter analyzer diagnostics.
- Prevents Play Store releases from being signed with the Android debug key.

See [CHANGELOG.md](CHANGELOG.md) for the full release notes.

## نوێکارییەکانی وەشانی نوێ (Google Play)

### دەقی کورت بۆ "What’s New"

- ئاگادارکردنەوەکان و بیربهێنەرەوەکانی زیکر باشتر کران.
- پشتیوانی Android 16 و ئامادەکاری بۆ Google Play باشتر کرا.
- کێشەی دەستپێکردنی زمانی کوردی چارەسەر کرا.
- جێگیری بەرنامە باشتر کرا و کۆدی بەکارنەهاتوو سڕایەوە.
