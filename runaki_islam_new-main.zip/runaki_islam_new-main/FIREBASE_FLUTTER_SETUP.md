# Flutter Firebase Setup

This project is now Firebase-ready on the Flutter side, but it still needs the
real Firebase project configuration before Firebase will initialize.

## 1. Install the required CLI tools

```powershell
npm install -g firebase-tools
dart pub global activate flutterfire_cli
firebase login
```

## 2. Open the Flutter app directory

```powershell
cd "c:\Users\Amin's PC\StudioProjects\Runaki Islam Project\Flutter App\runaki_islam"
```

## 3. Configure this app with your Firebase project

Use your existing Firebase project and register both mobile platforms:

```powershell
flutterfire configure --project YOUR_FIREBASE_PROJECT_ID --platforms=android,ios
```

Use these app identifiers when prompted:

- Android application ID: `com.amin.runakeislam`
- iOS bundle ID: `com.amin.runakeislam`

The command should generate or update:

- `lib/firebase_options.dart`
- `android/app/google-services.json`
- `ios/Runner/GoogleService-Info.plist`

## 4. Rebuild the app

```powershell
flutter clean
flutter pub get
flutter run
```

## 5. If you do not want to run FlutterFire CLI yet

This repo includes a temporary placeholder `lib/firebase_options.dart`.
You can provide the values manually for local testing with `--dart-define`:

```powershell
flutter run `
  --dart-define=ANDROID_FIREBASE_API_KEY=... `
  --dart-define=ANDROID_FIREBASE_APP_ID=... `
  --dart-define=ANDROID_FIREBASE_MESSAGING_SENDER_ID=... `
  --dart-define=ANDROID_FIREBASE_PROJECT_ID=... `
  --dart-define=IOS_FIREBASE_API_KEY=... `
  --dart-define=IOS_FIREBASE_APP_ID=... `
  --dart-define=IOS_FIREBASE_MESSAGING_SENDER_ID=... `
  --dart-define=IOS_FIREBASE_PROJECT_ID=...
```

This is only a temporary path. The recommended setup is still
`flutterfire configure`.

## 6. What is already done in the codebase

- `firebase_core` was added to `pubspec.yaml`
- `lib/main.dart` now initializes Firebase safely when config exists
- the app will not crash if Firebase is not configured yet

## 7. Next Flutter steps after core setup

After Firebase core is working, the next packages to add are:

```powershell
flutter pub add firebase_auth firebase_messaging
```

Then wire:

- Firebase Authentication
- FCM device token registration
- foreground/background push handling
