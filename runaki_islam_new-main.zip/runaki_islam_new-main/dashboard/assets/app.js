(() => {
  const ADMIN_API = './api/admin_books.php';
  const CATEGORY_API = './api/categories.php';
  const CSRF_TOKEN = document.querySelector('meta[name="csrf-token"]')?.getAttribute('content') || '';
  const SEARCH_DEBOUNCE_MS = 300;

  const els = {
    refreshBtn: document.getElementById('refreshBtn'),
    form: document.getElementById('bookForm'),
    formTitle: document.getElementById('formTitle'),
    cancelEditBtn: document.getElementById('cancelEditBtn'),
    submitBtn: document.getElementById('submitBtn'),
    bookId: document.getElementById('bookId'),
    title: document.getElementById('title'),
    description: document.getElementById('description'),
    category: document.getElementById('category'),
    reloadCategoriesBtn: document.getElementById('reloadCategoriesBtn'),
    pdfSourceLink: document.getElementById('pdfSourceLink'),
    pdfSourceUpload: document.getElementById('pdfSourceUpload'),
    pdfUrlWrap: document.getElementById('pdfUrlWrap'),
    pdfFileWrap: document.getElementById('pdfFileWrap'),
    pdfUrl: document.getElementById('pdfUrl'),
    pdfFile: document.getElementById('pdfFile'),
    pdfDropzone: document.getElementById('pdfDropzone'),
    pdfSelectedFile: document.getElementById('pdfSelectedFile'),
    coverFile: document.getElementById('coverFile'),
    clearCoverBtn: document.getElementById('clearCoverBtn'),
    removeCover: document.getElementById('removeCover'),
    coverPreviewWrap: document.getElementById('coverPreviewWrap'),
    coverPreviewImage: document.getElementById('coverPreviewImage'),
    coverPreviewText: document.getElementById('coverPreviewText'),
    currentPdfNote: document.getElementById('currentPdfNote'),
    currentCoverNote: document.getElementById('currentCoverNote'),
    uploadStatusWrap: document.getElementById('uploadStatusWrap'),
    uploadStatusText: document.getElementById('uploadStatusText'),
    uploadProgressBar: document.getElementById('uploadProgressBar'),
    searchInput: document.getElementById('searchInput'),
    sortBySelect: document.getElementById('sortBySelect'),
    sortDirSelect: document.getElementById('sortDirSelect'),
    perPageSelect: document.getElementById('perPageSelect'),
    prevPageBtn: document.getElementById('prevPageBtn'),
    nextPageBtn: document.getElementById('nextPageBtn'),
    pageInfo: document.getElementById('pageInfo'),
    booksList: document.getElementById('booksList'),
    loadingState: document.getElementById('loadingState'),
    emptyState: document.getElementById('emptyState'),
    errorState: document.getElementById('errorState'),
    totalBooks: document.getElementById('totalBooks'),
    latestCategory: document.getElementById('latestCategory'),
    brokenLinks: document.getElementById('brokenLinks'),
    toast: document.getElementById('toast'),
  };

  if (!els.form) {
    return;
  }

  const state = {
    books: [],
    categories: [],
    loading: false,
    editingCoverUrl: '',
    coverObjectUrl: '',
    query: {
      page: 1,
      perPage: 12,
      search: '',
      sortBy: 'created_at',
      sortDir: 'desc',
    },
    pagination: {
      total: 0,
      totalPages: 1,
      page: 1,
      perPage: 12,
    },
  };

  let pdfDragDepth = 0;

  function normalizeText(value) {
    return String(value || '').trim();
  }

  function toPositiveInt(value, fallback) {
    const parsed = Number(value);
    if (!Number.isFinite(parsed) || parsed <= 0) {
      return fallback;
    }
    return Math.trunc(parsed);
  }

  function escapeHtml(value) {
    return String(value || '')
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#039;');
  }

  function showToast(message, isError = false) {
    els.toast.textContent = message;
    els.toast.classList.remove('hidden');
    els.toast.style.background = isError ? '#7f1d1d' : '#18212b';
    window.clearTimeout(showToast.timer);
    showToast.timer = window.setTimeout(() => {
      els.toast.classList.add('hidden');
    }, 3200);
  }

  function setLoading(flag) {
    state.loading = flag;
    els.loadingState.classList.toggle('hidden', !flag);
    els.refreshBtn.disabled = flag;
    els.reloadCategoriesBtn.disabled = flag;
    els.submitBtn.disabled = flag;
    els.prevPageBtn.disabled = flag || state.pagination.page <= 1;
    els.nextPageBtn.disabled = flag || state.pagination.page >= state.pagination.totalPages;
  }

  function setError(message) {
    const hasMessage = Boolean(message);
    els.errorState.classList.toggle('hidden', !hasMessage);
    els.errorState.textContent = hasMessage ? message : '';
  }

  function setEmpty(flag) {
    els.emptyState.classList.toggle('hidden', !flag);
  }

  function setUploadStatus(kind, message, progress = 0) {
    els.uploadStatusWrap.classList.remove('hidden', 'is-uploading', 'is-success', 'is-error');
    els.uploadStatusWrap.classList.add(`is-${kind}`);
    els.uploadStatusText.textContent = message;
    els.uploadProgressBar.style.width = `${Math.max(0, Math.min(100, Number(progress) || 0))}%`;
  }

  function resetUploadStatus() {
    els.uploadStatusWrap.classList.add('hidden');
    els.uploadStatusWrap.classList.remove('is-uploading', 'is-success', 'is-error');
    els.uploadStatusText.textContent = '';
    els.uploadProgressBar.style.width = '0%';
  }

  function buildQueryString(id = null, query = null) {
    const params = new URLSearchParams();

    if (id) {
      params.set('id', String(id));
    }

    if (query && typeof query === 'object') {
      for (const [key, value] of Object.entries(query)) {
        if (value === null || value === undefined) {
          continue;
        }
        const text = String(value).trim();
        if (text === '') {
          continue;
        }
        params.set(key, text);
      }
    }

    const text = params.toString();
    return text ? `?${text}` : '';
  }

  async function requestJson(endpoint, { method = 'GET', data = null, id = null, query = null } = {}) {
    const upperMethod = String(method || 'GET').toUpperCase();
    const url = `${endpoint}${buildQueryString(id, query)}`;

    if (upperMethod !== 'GET' && !CSRF_TOKEN) {
      throw new Error('توکنی CSRF نەدۆزرایەوە. تکایە پەڕەکە نوێ بکەرەوە.');
    }

    const options = {
      method: upperMethod,
      credentials: 'same-origin',
      headers: {
        Accept: 'application/json',
      },
    };

    if (upperMethod !== 'GET') {
      options.headers['X-CSRF-Token'] = CSRF_TOKEN;
    }

    if (data instanceof FormData) {
      if (upperMethod !== 'GET' && CSRF_TOKEN && !data.has('_csrf_token')) {
        data.append('_csrf_token', CSRF_TOKEN);
      }
      options.body = data;
    } else if (data) {
      const payload = upperMethod !== 'GET' ? { ...data, _csrf_token: CSRF_TOKEN } : data;
      options.headers['Content-Type'] = 'application/json';
      options.body = JSON.stringify(payload);
    }

    const response = await fetch(url, options);
    let payload = {};

    try {
      payload = await response.json();
    } catch (_) {
      throw new Error('وەڵامی JSONی سێرڤەر دروست نییە.');
    }

    if (!response.ok || payload.status === false) {
      const message = payload.message || `داواکارییەکە سەرکەوتوو نەبوو (${response.status})`;
      const detail = payload.error ? ` - ${payload.error}` : '';
      throw new Error(`${message}${detail}`);
    }

    return payload;
  }

  function requestFormWithProgress(endpoint, {
    method = 'POST',
    data = null,
    id = null,
    query = null,
    onProgress = null,
  } = {}) {
    return new Promise((resolve, reject) => {
      const upperMethod = String(method || 'POST').toUpperCase();
      const url = `${endpoint}${buildQueryString(id, query)}`;

      if (!(data instanceof FormData)) {
        reject(new Error('داواکارییەکە پێویستە FormData بێت.'));
        return;
      }

      if (upperMethod !== 'GET' && !CSRF_TOKEN) {
        reject(new Error('توکنی CSRF نەدۆزرایەوە. تکایە پەڕەکە نوێ بکەرەوە.'));
        return;
      }

      if (upperMethod !== 'GET' && CSRF_TOKEN && !data.has('_csrf_token')) {
        data.append('_csrf_token', CSRF_TOKEN);
      }

      const xhr = new XMLHttpRequest();
      xhr.open(upperMethod, url, true);
      xhr.withCredentials = true;
      xhr.setRequestHeader('Accept', 'application/json');
      if (upperMethod !== 'GET') {
        xhr.setRequestHeader('X-CSRF-Token', CSRF_TOKEN);
      }

      xhr.upload.onprogress = (event) => {
        if (typeof onProgress !== 'function') {
          return;
        }
        if (event.lengthComputable) {
          const percent = Math.round((event.loaded / event.total) * 100);
          onProgress(percent, event.loaded, event.total);
        }
      };

      xhr.onerror = () => {
        reject(new Error('پەیوەندی بە سێرڤەرەوە نەکرا.'));
      };

      xhr.onload = () => {
        let payload = {};

        try {
          payload = JSON.parse(xhr.responseText || '{}');
        } catch (_) {
          reject(new Error('وەڵامی JSONی سێرڤەر دروست نییە.'));
          return;
        }

        if (xhr.status < 200 || xhr.status >= 300 || payload.status === false) {
          const message = payload.message || `داواکارییەکە سەرکەوتوو نەبوو (${xhr.status})`;
          const detail = payload.error ? ` - ${payload.error}` : '';
          reject(new Error(`${message}${detail}`));
          return;
        }

        resolve(payload);
      };

      xhr.send(data);
    });
  }

  function selectedSource() {
    return els.pdfSourceUpload.checked ? 'upload' : 'link';
  }

  function selectedPdfFile() {
    return els.pdfFile.files && els.pdfFile.files[0] ? els.pdfFile.files[0] : null;
  }

  function selectedCoverFile() {
    return els.coverFile.files && els.coverFile.files[0] ? els.coverFile.files[0] : null;
  }

  function togglePdfSourceUi() {
    const upload = selectedSource() === 'upload';
    els.pdfUrlWrap.classList.toggle('hidden', upload);
    els.pdfFileWrap.classList.toggle('hidden', !upload);
    if (!upload) {
      els.pdfDropzone.classList.remove('is-dragover');
    }
  }

  function hasBrokenPdf(url) {
    const value = normalizeText(url);
    if (!value) {
      return true;
    }

    if (/^https?:\/\//i.test(value)) {
      try {
        new URL(value);
        return false;
      } catch (_) {
        return true;
      }
    }

    return !value.startsWith('/');
  }

  function resolveAssetUrl(url) {
    const value = normalizeText(url);
    if (!value) {
      return '';
    }

    if (/^https?:\/\//i.test(value)) {
      return value;
    }

    return new URL(value, window.location.origin).toString();
  }

  function safeResolveAssetUrl(url) {
    try {
      return resolveAssetUrl(url);
    } catch (_) {
      return '';
    }
  }

  function formatDate(value) {
    const parsed = new Date(value);
    if (Number.isNaN(parsed.getTime())) {
      return value || '-';
    }

    return parsed.toLocaleString('ku-IQ');
  }

  function ensureCategoryOption(name) {
    const value = normalizeText(name);
    if (!value) {
      return;
    }

    const exists = Array.from(els.category.options).some((option) => normalizeText(option.value) === value);
    if (!exists) {
      const option = document.createElement('option');
      option.value = value;
      option.textContent = `${value} (تۆمارنەکراو)`;
      els.category.appendChild(option);
    }
  }

  function renderCategoryOptions(selected = '') {
    const targetValue = normalizeText(selected || els.category.value);

    els.category.innerHTML = '';

    const emptyOption = document.createElement('option');
    emptyOption.value = '';
    emptyOption.textContent = 'بێ پۆل';
    els.category.appendChild(emptyOption);

    for (const category of state.categories) {
      const name = normalizeText(category && category.name);
      if (!name) {
        continue;
      }

      const option = document.createElement('option');
      option.value = name;
      option.textContent = `${name} (${Number(category.books_count || 0)})`;
      els.category.appendChild(option);
    }

    if (targetValue) {
      ensureCategoryOption(targetValue);
    }

    els.category.value = targetValue;
  }

  async function loadCategories({ silent = false, preserveValue = true } = {}) {
    const currentValue = preserveValue ? normalizeText(els.category.value) : '';

    try {
      const payload = await requestJson(CATEGORY_API, { method: 'GET' });
      state.categories = Array.isArray(payload.categories) ? payload.categories : [];
      renderCategoryOptions(currentValue);
    } catch (error) {
      if (!silent) {
        const message = error && error.message ? error.message : 'نەتوانرا پۆلەکان بخوێندرێنەوە.';
        showToast(message, true);
      }
    }
  }

  function updateStats(books, totalCount) {
    const safeTotal = Number.isFinite(Number(totalCount)) ? Number(totalCount) : books.length;
    els.totalBooks.textContent = String(safeTotal);

    const latest = books[0];
    els.latestCategory.textContent = normalizeText(latest && latest.category) || '-';

    const broken = books.filter((book) => hasBrokenPdf(book.pdf_url)).length;
    els.brokenLinks.textContent = String(broken);
  }

  function updatePagination(payload) {
    const total = toPositiveInt(payload.total, 0);
    const totalPages = toPositiveInt(payload.total_pages, 1);
    const page = toPositiveInt(payload.page, 1);
    const perPage = toPositiveInt(payload.per_page, state.query.perPage);

    state.pagination.total = total;
    state.pagination.totalPages = totalPages;
    state.pagination.page = page;
    state.pagination.perPage = perPage;

    state.query.page = page;
    state.query.perPage = perPage;

    if (els.perPageSelect.value !== String(perPage)) {
      els.perPageSelect.value = String(perPage);
    }

    els.pageInfo.textContent = `پەڕەی ${page} لە ${totalPages} - ${total} دانە`;
  }

  function renderBooks() {
    const books = state.books;

    els.booksList.innerHTML = '';
    setEmpty(!state.loading && books.length === 0);

    for (const book of books) {
      const broken = hasBrokenPdf(book.pdf_url);
      const coverUrl = normalizeText(book.cover_url);
      const coverPreview = safeResolveAssetUrl(coverUrl);
      const coverHtml = coverPreview
        ? `<a class="book-cover-link" href="${escapeHtml(coverPreview)}" target="_blank" rel="noopener noreferrer"><img class="book-cover-thumb" src="${escapeHtml(coverPreview)}" alt="بەرگی ${escapeHtml(book.title)}" loading="lazy"></a>`
        : '';

      const wrapper = document.createElement('article');
      wrapper.className = 'book-card';
      wrapper.innerHTML = `
        <div class="book-head">
          <h4 class="book-title">${escapeHtml(book.title)}</h4>
          <span class="badge ${broken ? 'badge-danger' : ''}">${broken ? 'PDF شکاوە' : 'PDF دروستە'}</span>
        </div>
        ${coverHtml}
        <p class="book-description">${escapeHtml(book.description)}</p>
        <div class="book-meta">
          <span>ژمارە: ${book.id}</span>
          <span>پۆل: ${escapeHtml(normalizeText(book.category) || '-')}</span>
          <span>بەروار: ${escapeHtml(formatDate(book.created_at))}</span>
        </div>
        <div class="book-meta">بەستەری PDF: ${escapeHtml(book.pdf_url)}</div>
        ${coverUrl ? `<div class="book-meta">بەرگ: ${escapeHtml(coverUrl)}</div>` : ''}
        <div class="book-actions">
          <button class="btn btn-neutral" data-action="view" data-id="${book.id}">بینینی PDF</button>
          <button class="btn btn-neutral" data-action="edit" data-id="${book.id}">دەستکاریکردن</button>
          <button class="btn btn-danger" data-action="delete" data-id="${book.id}">سڕینەوە</button>
        </div>
      `;
      els.booksList.appendChild(wrapper);
    }
  }

  async function loadBooks() {
    setLoading(true);
    setError('');

    try {
      const payload = await requestJson(ADMIN_API, {
        method: 'GET',
        query: {
          page: state.query.page,
          per_page: state.query.perPage,
          search: state.query.search,
          sort_by: state.query.sortBy,
          sort_dir: state.query.sortDir,
        },
      });

      state.query.sortBy = normalizeText(payload.sort_by) || state.query.sortBy;
      state.query.sortDir = normalizeText(payload.sort_dir) || state.query.sortDir;
      if (els.sortBySelect.value !== state.query.sortBy) {
        els.sortBySelect.value = state.query.sortBy;
      }
      if (els.sortDirSelect.value !== state.query.sortDir) {
        els.sortDirSelect.value = state.query.sortDir;
      }

      state.books = Array.isArray(payload.books) ? payload.books : [];
      updatePagination(payload);
      updateStats(state.books, payload.total);
      renderBooks();
    } catch (error) {
      const message = error && error.message ? error.message : 'نەتوانرا کتێبەکان بخوێندرێنەوە.';
      setError(message);
      state.books = [];
      updatePagination({ page: 1, total_pages: 1, total: 0, per_page: state.query.perPage });
      updateStats([], 0);
      renderBooks();
    } finally {
      setLoading(false);
    }
  }

  function clearFileInput(input) {
    input.value = '';
  }

  function clearCoverObjectUrl() {
    if (state.coverObjectUrl) {
      URL.revokeObjectURL(state.coverObjectUrl);
      state.coverObjectUrl = '';
    }
  }

  function clearCoverPreview() {
    clearCoverObjectUrl();
    els.coverPreviewImage.removeAttribute('src');
    els.coverPreviewText.textContent = '';
    els.coverPreviewWrap.classList.add('hidden');
  }

  function showCoverPreview(url, text) {
    els.coverPreviewImage.src = url;
    els.coverPreviewText.textContent = text;
    els.coverPreviewWrap.classList.remove('hidden');
  }

  function showCurrentCoverPreview() {
    const url = normalizeText(state.editingCoverUrl);
    if (!url || normalizeText(els.removeCover.value) === '1') {
      clearCoverPreview();
      return;
    }

    const resolved = safeResolveAssetUrl(url);
    if (!resolved) {
      clearCoverPreview();
      return;
    }

    clearCoverObjectUrl();
    showCoverPreview(resolved, 'بەرگی ئێستا');
  }

  function updateCurrentCoverNote() {
    const hasExistingCover = normalizeText(state.editingCoverUrl) !== '';
    if (!hasExistingCover) {
      els.currentCoverNote.classList.add('hidden');
      els.currentCoverNote.textContent = '';
      return;
    }

    if (normalizeText(els.removeCover.value) === '1') {
      els.currentCoverNote.classList.remove('hidden');
      els.currentCoverNote.textContent = 'بەرگی ئێستا لە پاش پاشەکەوتکردن دەسڕدرێتەوە.';
      return;
    }

    els.currentCoverNote.classList.remove('hidden');
    els.currentCoverNote.textContent = `بەرگی ئێستا: ${state.editingCoverUrl}`;
  }

  function refreshCoverClearButton() {
    const hasNewFile = Boolean(selectedCoverFile());
    const hasExisting = normalizeText(state.editingCoverUrl) !== '';
    const removeRequested = normalizeText(els.removeCover.value) === '1';

    els.clearCoverBtn.classList.toggle('hidden', !(hasNewFile || hasExisting));

    if (hasNewFile) {
      els.clearCoverBtn.textContent = 'لابردنی هەڵبژاردە';
      return;
    }

    if (hasExisting) {
      els.clearCoverBtn.textContent = removeRequested ? 'گەڕاندنەوەی بەرگ' : 'لابردنی بەرگی ئێستا';
    }
  }

  function updatePdfSelectedFileLabel(file) {
    if (!file) {
      els.pdfSelectedFile.textContent = 'هیچ فایلێک هەڵنەبژێردراوە.';
      return;
    }
    els.pdfSelectedFile.textContent = `فایلی هەڵبژێردراو: ${file.name}`;
  }

  function resetForm() {
    els.form.reset();
    els.bookId.value = '';
    els.formTitle.textContent = 'زیادکردنی کتێبی نوێ';
    els.submitBtn.textContent = 'زیادکردنی کتێب';
    els.cancelEditBtn.classList.add('hidden');

    els.currentPdfNote.classList.add('hidden');
    els.currentPdfNote.textContent = '';

    state.editingCoverUrl = '';
    els.removeCover.value = '0';
    clearFileInput(els.coverFile);
    clearCoverPreview();
    updateCurrentCoverNote();
    refreshCoverClearButton();

    els.pdfSourceLink.checked = true;
    togglePdfSourceUi();
    clearFileInput(els.pdfFile);
    updatePdfSelectedFileLabel(null);
    renderCategoryOptions('');
    resetUploadStatus();
  }

  function setEditMode(book) {
    els.bookId.value = String(book.id);
    els.title.value = normalizeText(book.title);
    els.description.value = normalizeText(book.description);
    renderCategoryOptions(normalizeText(book.category));
    els.pdfUrl.value = normalizeText(book.pdf_url);

    els.formTitle.textContent = `دەستکاریکردنی کتێب #${book.id}`;
    els.submitBtn.textContent = 'نوێکردنەوەی کتێب';
    els.cancelEditBtn.classList.remove('hidden');

    els.currentPdfNote.classList.remove('hidden');
    els.currentPdfNote.textContent = `PDFی ئێستا: ${book.pdf_url}`;

    state.editingCoverUrl = normalizeText(book.cover_url);
    els.removeCover.value = '0';
    clearFileInput(els.coverFile);
    showCurrentCoverPreview();
    updateCurrentCoverNote();
    refreshCoverClearButton();

    els.pdfSourceLink.checked = true;
    togglePdfSourceUi();
    clearFileInput(els.pdfFile);
    updatePdfSelectedFileLabel(null);
    resetUploadStatus();

    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  function buildLinkPayload() {
    return {
      title: normalizeText(els.title.value),
      description: normalizeText(els.description.value),
      category: normalizeText(els.category.value),
      pdf_source: 'link',
      pdf_url: normalizeText(els.pdfUrl.value),
    };
  }

  function buildMultipartFormData(isEdit, id) {
    const formData = new FormData();
    formData.append('title', normalizeText(els.title.value));
    formData.append('description', normalizeText(els.description.value));
    formData.append('category', normalizeText(els.category.value));
    formData.append('pdf_source', selectedSource());

    if (selectedSource() === 'upload') {
      const pdfFile = selectedPdfFile();
      if (pdfFile) {
        formData.append('pdf_file', pdfFile);
      }
    } else {
      formData.append('pdf_url', normalizeText(els.pdfUrl.value));
    }

    const coverFile = selectedCoverFile();
    if (coverFile) {
      formData.append('cover_file', coverFile);
    }

    formData.append('remove_cover', normalizeText(els.removeCover.value) === '1' ? '1' : '0');

    if (isEdit) {
      formData.append('_method', 'PUT');
      formData.append('id', String(id));
    }

    return formData;
  }

  async function submitForm(event) {
    event.preventDefault();

    const id = Number(els.bookId.value || 0);
    const isEdit = id > 0;

    const hasPdfFile = Boolean(selectedPdfFile());
    const hasCoverFile = Boolean(selectedCoverFile());
    const removeCoverRequested = normalizeText(els.removeCover.value) === '1';
    const useMultipart = selectedSource() === 'upload' || hasCoverFile || removeCoverRequested;
    const hasUploadFiles = hasPdfFile || hasCoverFile;

    try {
      setLoading(true);
      setError('');

      if (useMultipart) {
        const formData = buildMultipartFormData(isEdit, id);

        if (hasUploadFiles) {
          setUploadStatus('uploading', 'هەڵگرتن لە جێبەجێکردندایە...', 0);
        } else {
          resetUploadStatus();
        }

        await requestFormWithProgress(ADMIN_API, {
          method: 'POST',
          data: formData,
          id: isEdit ? id : null,
          onProgress: hasUploadFiles
            ? (percent) => setUploadStatus('uploading', `هەڵگرتن... ${percent}%`, percent)
            : null,
        });

        if (hasUploadFiles) {
          setUploadStatus('success', 'هەڵگرتن بە سەرکەوتوویی تەواو بوو.', 100);
        }
      } else {
        const payload = buildLinkPayload();
        if (isEdit) {
          await requestJson(ADMIN_API, { method: 'PUT', data: payload, id });
        } else {
          await requestJson(ADMIN_API, { method: 'POST', data: payload });
        }
        resetUploadStatus();
      }

      showToast(isEdit ? 'کتێبەکە نوێکرایەوە.' : 'کتێبەکە زیادکرا.');
      resetForm();
      await Promise.all([
        loadBooks(),
        loadCategories({ silent: true }),
      ]);
    } catch (error) {
      const message = error && error.message ? error.message : 'هەڵەیەک ڕوویدا لە پاشەکەوتکردن.';
      showToast(message, true);
      setError(message);
      if (hasUploadFiles) {
        setUploadStatus('error', message, 0);
      }
    } finally {
      setLoading(false);
    }
  }

  async function deleteBook(id) {
    if (!window.confirm('دڵنیایت لە سڕینەوەی ئەم کتێبە؟')) {
      return;
    }

    try {
      setLoading(true);
      await requestJson(ADMIN_API, { method: 'DELETE', id });
      showToast('کتێبەکە سڕایەوە.');
      await Promise.all([
        loadBooks(),
        loadCategories({ silent: true }),
      ]);
    } catch (error) {
      const message = error && error.message ? error.message : 'سڕینەوە سەرکەوتوو نەبوو.';
      showToast(message, true);
      setError(message);
    } finally {
      setLoading(false);
    }
  }

  function onBooksListClick(event) {
    const target = event.target;
    if (!(target instanceof HTMLButtonElement)) {
      return;
    }

    const action = target.dataset.action;
    const id = Number(target.dataset.id || 0);
    if (!action || id <= 0) {
      return;
    }

    const book = state.books.find((item) => Number(item.id) === id);
    if (!book) {
      return;
    }

    if (action === 'edit') {
      setEditMode(book);
      return;
    }

    if (action === 'delete') {
      deleteBook(id);
      return;
    }

    if (action === 'view') {
      if (hasBrokenPdf(book.pdf_url)) {
        showToast('بەستەری PDF هەڵەیە یان کار ناکات.', true);
        return;
      }
      window.open(resolveAssetUrl(book.pdf_url), '_blank', 'noopener,noreferrer');
    }
  }

  function debounce(fn, delayMs) {
    let timer = 0;
    return (...args) => {
      window.clearTimeout(timer);
      timer = window.setTimeout(() => fn(...args), delayMs);
    };
  }

  function onSearchInput() {
    state.query.search = normalizeText(els.searchInput.value);
    state.query.page = 1;
    loadBooks();
  }

  function onSortByChange() {
    state.query.sortBy = normalizeText(els.sortBySelect.value) || 'created_at';
    state.query.page = 1;
    loadBooks();
  }

  function onSortDirChange() {
    state.query.sortDir = normalizeText(els.sortDirSelect.value) || 'desc';
    state.query.page = 1;
    loadBooks();
  }

  function onPerPageChange() {
    state.query.perPage = toPositiveInt(els.perPageSelect.value, 12);
    state.query.page = 1;
    loadBooks();
  }

  function goToPreviousPage() {
    if (state.loading || state.query.page <= 1) {
      return;
    }

    state.query.page -= 1;
    loadBooks();
  }

  function goToNextPage() {
    if (state.loading || state.query.page >= state.pagination.totalPages) {
      return;
    }

    state.query.page += 1;
    loadBooks();
  }

  function assignFileToInput(input, file) {
    if (typeof DataTransfer === 'undefined') {
      return false;
    }

    const transfer = new DataTransfer();
    transfer.items.add(file);
    input.files = transfer.files;
    return true;
  }

  function onPdfFileInputChange() {
    const file = selectedPdfFile();
    updatePdfSelectedFileLabel(file);
    if (file) {
      els.pdfSourceUpload.checked = true;
      togglePdfSourceUi();
    }
  }

  function onPdfDrop(event) {
    event.preventDefault();
    pdfDragDepth = 0;
    els.pdfDropzone.classList.remove('is-dragover');

    const files = Array.from(event.dataTransfer?.files || []);
    const file = files.find((item) => item.type === 'application/pdf' || /\.pdf$/i.test(item.name));

    if (!file) {
      showToast('تەنها فایلی PDF ڕێگەپێدراوە.', true);
      return;
    }

    if (!assignFileToInput(els.pdfFile, file)) {
      showToast('نەتوانرا فایلەکە دابنرێت. تکایە بە دوگمەی هەڵبژاردن بەکاریبهێنە.', true);
      return;
    }

    onPdfFileInputChange();
  }

  function onPdfDragEnter(event) {
    event.preventDefault();
    pdfDragDepth += 1;
    els.pdfDropzone.classList.add('is-dragover');
  }

  function onPdfDragLeave(event) {
    event.preventDefault();
    pdfDragDepth = Math.max(0, pdfDragDepth - 1);
    if (pdfDragDepth === 0) {
      els.pdfDropzone.classList.remove('is-dragover');
    }
  }

  function onPdfDragOver(event) {
    event.preventDefault();
    event.dataTransfer.dropEffect = 'copy';
  }

  function onCoverFileChange() {
    const file = selectedCoverFile();

    if (file) {
      els.removeCover.value = '0';
      clearCoverObjectUrl();
      state.coverObjectUrl = URL.createObjectURL(file);
      showCoverPreview(state.coverObjectUrl, `وێنەی هەڵبژێردراو: ${file.name}`);
    } else if (normalizeText(state.editingCoverUrl) && normalizeText(els.removeCover.value) !== '1') {
      showCurrentCoverPreview();
    } else {
      clearCoverPreview();
    }

    updateCurrentCoverNote();
    refreshCoverClearButton();
  }

  function onClearCoverClick() {
    const hasNewFile = Boolean(selectedCoverFile());
    const hasExisting = normalizeText(state.editingCoverUrl) !== '';
    const removeRequested = normalizeText(els.removeCover.value) === '1';

    if (hasNewFile) {
      clearFileInput(els.coverFile);
      if (hasExisting && !removeRequested) {
        showCurrentCoverPreview();
      } else {
        clearCoverPreview();
      }
      updateCurrentCoverNote();
      refreshCoverClearButton();
      return;
    }

    if (hasExisting && !removeRequested) {
      els.removeCover.value = '1';
      clearCoverPreview();
      updateCurrentCoverNote();
      refreshCoverClearButton();
      return;
    }

    if (hasExisting && removeRequested) {
      els.removeCover.value = '0';
      showCurrentCoverPreview();
      updateCurrentCoverNote();
      refreshCoverClearButton();
    }
  }

  function boot() {
    togglePdfSourceUi();
    updatePdfSelectedFileLabel(null);
    updateCurrentCoverNote();
    refreshCoverClearButton();
    resetUploadStatus();

    els.sortBySelect.value = state.query.sortBy;
    els.sortDirSelect.value = state.query.sortDir;
    els.perPageSelect.value = String(state.query.perPage);

    const debouncedSearch = debounce(onSearchInput, SEARCH_DEBOUNCE_MS);

    els.refreshBtn.addEventListener('click', () => loadBooks());
    els.reloadCategoriesBtn.addEventListener('click', () => loadCategories({ silent: false }));
    els.form.addEventListener('submit', submitForm);
    els.cancelEditBtn.addEventListener('click', resetForm);
    els.searchInput.addEventListener('input', debouncedSearch);
    els.sortBySelect.addEventListener('change', onSortByChange);
    els.sortDirSelect.addEventListener('change', onSortDirChange);
    els.perPageSelect.addEventListener('change', onPerPageChange);
    els.prevPageBtn.addEventListener('click', goToPreviousPage);
    els.nextPageBtn.addEventListener('click', goToNextPage);
    els.booksList.addEventListener('click', onBooksListClick);
    els.pdfSourceLink.addEventListener('change', togglePdfSourceUi);
    els.pdfSourceUpload.addEventListener('change', togglePdfSourceUi);

    els.pdfFile.addEventListener('change', onPdfFileInputChange);
    els.pdfDropzone.addEventListener('click', () => els.pdfFile.click());
    els.pdfDropzone.addEventListener('keydown', (event) => {
      if (event.key === 'Enter' || event.key === ' ') {
        event.preventDefault();
        els.pdfFile.click();
      }
    });
    els.pdfDropzone.addEventListener('dragenter', onPdfDragEnter);
    els.pdfDropzone.addEventListener('dragleave', onPdfDragLeave);
    els.pdfDropzone.addEventListener('dragover', onPdfDragOver);
    els.pdfDropzone.addEventListener('drop', onPdfDrop);

    els.coverFile.addEventListener('change', onCoverFileChange);
    els.clearCoverBtn.addEventListener('click', onClearCoverClick);

    Promise.all([
      loadCategories({ silent: true, preserveValue: false }),
      loadBooks(),
    ]);
  }

  boot();
})();
