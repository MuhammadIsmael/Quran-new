(() => {
  const API = './api/categories.php';
  const CSRF_TOKEN = document.querySelector('meta[name="csrf-token"]')?.getAttribute('content') || '';

  const els = {
    form: document.getElementById('categoryForm'),
    categoryName: document.getElementById('categoryName'),
    saveCategoryBtn: document.getElementById('saveCategoryBtn'),
    refreshBtn: document.getElementById('refreshCategoriesBtn'),
    loading: document.getElementById('categoriesLoading'),
    empty: document.getElementById('categoriesEmpty'),
    error: document.getElementById('categoriesError'),
    list: document.getElementById('categoriesList'),
    toast: document.getElementById('toast'),
  };

  if (!els.form) {
    return;
  }

  const state = {
    categories: [],
    loading: false,
  };

  function normalizeText(value) {
    return String(value || '').trim();
  }

  function escapeHtml(value) {
    return String(value || '')
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#039;');
  }

  function showToast(message, isError = false) {
    els.toast.textContent = message;
    els.toast.classList.remove('hidden');
    els.toast.style.background = isError ? '#7f1d1d' : '#18212b';
    window.clearTimeout(showToast.timer);
    showToast.timer = window.setTimeout(() => {
      els.toast.classList.add('hidden');
    }, 3200);
  }

  function setLoading(flag) {
    state.loading = flag;
    els.loading.classList.toggle('hidden', !flag);
    els.refreshBtn.disabled = flag;
    els.saveCategoryBtn.disabled = flag;
  }

  function setError(message) {
    const hasMessage = Boolean(message);
    els.error.classList.toggle('hidden', !hasMessage);
    els.error.textContent = hasMessage ? message : '';
  }

  function setEmpty(flag) {
    els.empty.classList.toggle('hidden', !flag);
  }

  function buildQueryString(id = null) {
    if (!id) {
      return '';
    }
    return `?id=${encodeURIComponent(String(id))}`;
  }

  async function requestApi({ method = 'GET', data = null, id = null } = {}) {
    const upperMethod = String(method || 'GET').toUpperCase();
    const url = `${API}${buildQueryString(id)}`;

    if (upperMethod !== 'GET' && !CSRF_TOKEN) {
      throw new Error('توکنی CSRF نەدۆزرایەوە. تکایە پەڕەکە نوێ بکەرەوە.');
    }

    const options = {
      method: upperMethod,
      credentials: 'same-origin',
      headers: {
        Accept: 'application/json',
      },
    };

    if (upperMethod !== 'GET') {
      options.headers['X-CSRF-Token'] = CSRF_TOKEN;
    }

    if (data) {
      options.headers['Content-Type'] = 'application/json';
      options.body = JSON.stringify(upperMethod === 'GET' ? data : { ...data, _csrf_token: CSRF_TOKEN });
    }

    const response = await fetch(url, options);
    let payload = {};

    try {
      payload = await response.json();
    } catch (_) {
      throw new Error('وەڵامی JSONی سێرڤەر دروست نییە.');
    }

    if (!response.ok || payload.status === false) {
      const message = payload.message || `داواکارییەکە سەرکەوتوو نەبوو (${response.status})`;
      const detail = payload.error ? ` - ${payload.error}` : '';
      throw new Error(`${message}${detail}`);
    }

    return payload;
  }

  function renderList() {
    els.list.innerHTML = '';
    setEmpty(!state.loading && state.categories.length === 0);

    for (const category of state.categories) {
      const wrapper = document.createElement('article');
      wrapper.className = 'category-card';
      wrapper.innerHTML = `
        <div class="category-info">
          <h4>${escapeHtml(category.name)}</h4>
          <p>${Number(category.books_count || 0)} کتێب</p>
        </div>
        <div class="category-actions">
          <button class="btn btn-neutral" data-action="rename" data-id="${category.id}" data-name="${escapeHtml(category.name)}">گۆڕینی ناو</button>
          <button class="btn btn-danger" data-action="delete" data-id="${category.id}" data-name="${escapeHtml(category.name)}">سڕینەوە</button>
        </div>
      `;
      els.list.appendChild(wrapper);
    }
  }

  async function loadCategories() {
    setLoading(true);
    setError('');

    try {
      const payload = await requestApi({ method: 'GET' });
      state.categories = Array.isArray(payload.categories) ? payload.categories : [];
      renderList();
    } catch (error) {
      const message = error && error.message ? error.message : 'نەتوانرا پۆلەکان بخوێندرێنەوە.';
      setError(message);
      state.categories = [];
      renderList();
    } finally {
      setLoading(false);
    }
  }

  async function createCategory(event) {
    event.preventDefault();
    const name = normalizeText(els.categoryName.value);
    if (!name) {
      showToast('ناوی پۆل پێویستە.', true);
      return;
    }

    try {
      setLoading(true);
      await requestApi({
        method: 'POST',
        data: { name },
      });
      els.categoryName.value = '';
      showToast('پۆلەکە زیادکرا.');
      await loadCategories();
    } catch (error) {
      const message = error && error.message ? error.message : 'زیادکردنی پۆل سەرکەوتوو نەبوو.';
      showToast(message, true);
      setError(message);
    } finally {
      setLoading(false);
    }
  }

  async function renameCategory(id, currentName) {
    const newName = normalizeText(window.prompt('ناوی نوێی پۆل بنووسە:', currentName));
    if (!newName || newName === currentName) {
      return;
    }

    try {
      setLoading(true);
      await requestApi({
        method: 'PUT',
        id,
        data: { name: newName },
      });
      showToast('پۆلەکە نوێکرایەوە.');
      await loadCategories();
    } catch (error) {
      const message = error && error.message ? error.message : 'نوێکردنەوەی پۆل سەرکەوتوو نەبوو.';
      showToast(message, true);
      setError(message);
    } finally {
      setLoading(false);
    }
  }

  async function deleteCategory(id, name) {
    if (!window.confirm(`دڵنیایت لە سڕینەوەی پۆلی "${name}"؟ کتێبەکان بێ پۆل دەبن.`)) {
      return;
    }

    try {
      setLoading(true);
      await requestApi({
        method: 'DELETE',
        id,
      });
      showToast('پۆلەکە سڕایەوە.');
      await loadCategories();
    } catch (error) {
      const message = error && error.message ? error.message : 'سڕینەوە سەرکەوتوو نەبوو.';
      showToast(message, true);
      setError(message);
    } finally {
      setLoading(false);
    }
  }

  function onListClick(event) {
    const target = event.target;
    if (!(target instanceof HTMLButtonElement)) {
      return;
    }

    const action = normalizeText(target.dataset.action);
    const id = Number(target.dataset.id || 0);
    const name = normalizeText(target.dataset.name);
    if (!action || id <= 0) {
      return;
    }

    if (action === 'rename') {
      renameCategory(id, name);
      return;
    }

    if (action === 'delete') {
      deleteCategory(id, name);
    }
  }

  function boot() {
    els.form.addEventListener('submit', createCategory);
    els.refreshBtn.addEventListener('click', loadCategories);
    els.list.addEventListener('click', onListClick);
    loadCategories();
  }

  boot();
})();
