# Books Dashboard (PHP + HTML + CSS + JS)

This folder provides:
- Public API for Flutter: `dashboard/api/books.php`
- Admin API (session-protected): `dashboard/api/admin_books.php`
- Categories API (session-protected): `dashboard/api/categories.php`
- Responsive admin panel: `dashboard/index.php`
- Categories manager page: `dashboard/categories.php`
- Login page: `dashboard/login.php`

## 1) Setup database
1. Create MySQL database and table:
   - Import: `dashboard/db.sql`
2. Configure DB settings (recommended via environment variables):
   - `DB_HOST`
   - `DB_PORT`
   - `DB_NAME`
   - `DB_USER`
   - `DB_PASS`
3. Dashboard login credentials (recommended via environment variables):
   - `DASHBOARD_USERNAME`
   - `DASHBOARD_PASSWORD_HASH` (recommended)
   - `DASHBOARD_PASSWORD` (fallback only for non-production)
   - `APP_ENV=production` to disable plain-password fallback
4. Login lockout policy:
   - `DASHBOARD_LOGIN_MAX_ATTEMPTS` (default: 5)
   - `DASHBOARD_LOGIN_LOCKOUT_SECONDS` (default: 900)
5. Default fallback credentials in `dashboard/config.php`:
   - Username: `bestun`
   - Password: `12345@#`
6. To generate a secure hash for `DASHBOARD_PASSWORD_HASH`:
   - `php -r "echo password_hash('your-password', PASSWORD_DEFAULT), PHP_EOL;"`

## 2) API URLs
- Flutter should call: `https://your-domain.com/dashboard/api/books.php`
- Dashboard admin API needs an authenticated login session.

## 3) Flutter base URL note
If needed, you can still override Flutter endpoint through `BOOKS_API_URL`:

```bash
flutter run --dart-define=BOOKS_API_URL=https://your-domain.com/dashboard/api/books.php
```

Or for release builds, pass the same `--dart-define` value.

## 4) Query parameters (books APIs)
Both `api/books.php` and `api/admin_books.php` support:
- `search` (title, description, category)
- `sort_by`: `created_at`, `title`, `category`, `id`
- `sort_dir`: `asc`, `desc`
- `page`
- `per_page`
- `paginate=true|false`

Notes:
- `api/admin_books.php` defaults to paginated responses.
- `api/admin_books.php` write actions require `X-CSRF-Token` from an authenticated dashboard session.
- `api/books.php` keeps backward compatibility (non-paginated by default) unless paging params are sent.

## 5) Expected JSON fields (already returned)
- `id`
- `title`
- `description`
- `category` (nullable)
- `pdf_url`
- `cover_url` (nullable)
- `created_at`

## 6) Upload notes
- PDF upload: drag-and-drop supported in admin form
- Upload progress bar is shown during file uploads
- Optional cover image upload is supported (`jpg`, `jpeg`, `png`, `webp`, `gif`)
- Uploaded files are stored in:
  - `dashboard/uploads/books`
  - `dashboard/uploads/covers`
