<?php

declare(strict_types=1);

require_once __DIR__ . '/config.php';
requireDashboardAuthPage('login.php');
?>
<!doctype html>
<html lang="ku" dir="rtl">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Ø¨Û•Ú•ÛŽÙˆÛ•Ø¨Û•Ø±ÛŒ Ù¾Û†Ù„Û•Ú©Ø§Ù†</title>
  <meta name="csrf-token" content="<?= htmlspecialchars(ensureDashboardCsrfToken(), ENT_QUOTES, 'UTF-8') ?>">
  <link rel="stylesheet" href="./assets/styles.css">
</head>
<body>
  <main class="app-shell">
    <header class="top-bar">
      <div>
        <p class="eyebrow">Ú•ÙˆÙˆÙ†Ø§Ú©ÛŒ Ø¦ÛŒØ³Ù„Ø§Ù…</p>
        <h1>Ø¨Û•Ú•ÛŽÙˆÛ•Ø¨Û•Ø±ÛŒ Ù¾Û†Ù„Û•Ú©Ø§Ù†</h1>
        <p class="sub-text">Ù¾Û†Ù„ Ø¯Ø±ÙˆØ³Øª Ø¨Ú©Û•ØŒ Ù†Ø§ÙˆÛŒ Ø¨Ú¯Û†Ú•Û•ØŒ ÛŒØ§Ù† Ø¨ÛŒØ³Ú•Û•ÙˆÛ•.</p>
      </div>
      <div class="header-actions">
        <a class="btn btn-ghost" href="./index.php">Ù…ÙˆØ¯ÛŒÙˆÙ„Û•Ú©Ø§Ù†</a>
        <a class="btn btn-neutral" href="./books.php">Ú©ØªÛŽØ¨Û•Ú©Ø§Ù†</a>
        <a class="btn btn-danger" href="./logout.php">Ú†ÙˆÙˆÙ†Û•Ø¯Û•Ø±Û•ÙˆÛ•</a>
      </div>
    </header>

    <section class="panel-grid categories-grid">
      <article class="panel">
        <div class="panel-title-row">
          <h3>Ø²ÛŒØ§Ø¯Ú©Ø±Ø¯Ù†ÛŒ Ù¾Û†Ù„ÛŒ Ù†ÙˆÛŽ</h3>
        </div>

        <form id="categoryForm" class="category-form" novalidate>
          <label for="categoryName">Ù†Ø§ÙˆÛŒ Ù¾Û†Ù„</label>
          <input id="categoryName" name="categoryName" maxlength="120" required placeholder="ÙˆÛ•Ú©: ÙÛ•Ù‚Ù‡ØŒ ØªÛ•ÙØ³ÛŒØ±ØŒ Ø­Û•Ø¯ÛŒØ³">
          <div class="form-actions">
            <button id="saveCategoryBtn" class="btn" type="submit">Ø²ÛŒØ§Ø¯Ú©Ø±Ø¯Ù†ÛŒ Ù¾Û†Ù„</button>
          </div>
        </form>
      </article>

      <article class="panel">
        <div class="panel-title-row">
          <h3>Ù„ÛŒØ³ØªÛŒ Ù¾Û†Ù„Û•Ú©Ø§Ù†</h3>
          <button id="refreshCategoriesBtn" class="btn btn-ghost" type="button">Ù†ÙˆÛŽÚ©Ø±Ø¯Ù†Û•ÙˆÛ•</button>
        </div>

        <div id="categoriesLoading" class="state">Ú†Ø§ÙˆÛ•Ú•ÛŽ Ø¨Ú©Û•...</div>
        <div id="categoriesEmpty" class="state hidden">Ù‡ÛŽØ´ØªØ§ Ù‡ÛŒÚ† Ù¾Û†Ù„ÛŽÚ© ØªÛ†Ù…Ø§Ø± Ù†Û•Ú©Ø±Ø§ÙˆÛ•.</div>
        <div id="categoriesError" class="state state-error hidden"></div>

        <div id="categoriesList" class="categories-list"></div>
      </article>
    </section>

    <p id="toast" class="toast hidden" role="status" aria-live="polite"></p>
  </main>

  <script src="./assets/categories.js" defer></script>
</body>
</html>
