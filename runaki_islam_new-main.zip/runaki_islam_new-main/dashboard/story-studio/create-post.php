<?php

declare(strict_types=1);

require_once __DIR__ . '/includes/bootstrap.php';

$pdo = db();
require_login($pdo);

$settings = app_settings($pdo);
$templates = fetch_story_templates($pdo);
$duplicateId = normalize_int_value($_GET['duplicate'] ?? 0, 0, 0, 1000000);
$duplicatePost = $duplicateId > 0 ? fetch_story_post($pdo, $duplicateId) : null;

$selectedTemplateId = $duplicatePost !== null
    ? (int) $duplicatePost['template_id']
    : (int) ($templates[0]['id'] ?? 0);

$selectedTemplate = $selectedTemplateId > 0 ? find_story_template($pdo, $selectedTemplateId) : null;
$templateConfig = is_array($selectedTemplate) ? ($selectedTemplate['config'] ?? []) : [];

$defaultBackgroundColor = $duplicatePost !== null
    ? normalize_hex_color((string) $duplicatePost['background_color'], '#0B241D')
    : normalize_hex_color(setting_value($settings, 'default_background_color', (string) ($templateConfig['background_color'] ?? '#0B241D')), '#0B241D');

$defaultAccentColor = $duplicatePost !== null
    ? normalize_hex_color((string) $duplicatePost['accent_color'], '#D7B56D')
    : normalize_hex_color(setting_value($settings, 'default_accent_color', (string) ($templateConfig['accent_color'] ?? '#D7B56D')), '#D7B56D');

$defaultArabicColor = $duplicatePost !== null
    ? normalize_hex_color((string) $duplicatePost['arabic_text_color'], '#FFF9ED')
    : normalize_hex_color(setting_value($settings, 'default_arabic_text_color', (string) ($templateConfig['arabic_text_color'] ?? '#FFF9ED')), '#FFF9ED');

$defaultMeaningColor = $duplicatePost !== null
    ? normalize_hex_color((string) $duplicatePost['meaning_text_color'], '#F4E7C8')
    : normalize_hex_color(setting_value($settings, 'default_meaning_text_color', (string) ($templateConfig['meaning_text_color'] ?? '#F4E7C8')), '#F4E7C8');

$defaultArabicFontSize = $duplicatePost !== null
    ? (int) $duplicatePost['arabic_font_size']
    : normalize_int_value(setting_value($settings, 'default_arabic_font_size', (string) ($templateConfig['arabic_font_size'] ?? 64)), 64, 34, 96);

$defaultMeaningFontSize = $duplicatePost !== null
    ? (int) $duplicatePost['meaning_font_size']
    : normalize_int_value(setting_value($settings, 'default_meaning_font_size', (string) ($templateConfig['meaning_font_size'] ?? 35)), 35, 22, 60);

$existingBackgroundPath = $duplicatePost !== null && is_local_storage_reference((string) $duplicatePost['background_image_path'])
    ? (string) $duplicatePost['background_image_path']
    : '';

$existingBrandingPath = $duplicatePost !== null && is_local_storage_reference((string) $duplicatePost['branding_path'])
    ? (string) $duplicatePost['branding_path']
    : '';

$brandingMode = $duplicatePost !== null
    ? (string) $duplicatePost['branding_mode']
    : 'logo';

$editorDefaults = [
    'selectedTemplateId' => $selectedTemplateId,
    'existingBackgroundUrl' => $existingBackgroundPath !== '' ? storage_relative_url($existingBackgroundPath) : '',
    'existingBrandingUrl' => $existingBrandingPath !== '' ? storage_relative_url($existingBrandingPath) : '',
    'defaultLogoUrl' => setting_value($settings, 'default_logo_path') !== '' ? storage_relative_url(setting_value($settings, 'default_logo_path')) : '',
    'defaultWatermarkUrl' => setting_value($settings, 'default_watermark_path') !== '' ? storage_relative_url(setting_value($settings, 'default_watermark_path')) : '',
];

render_app_start(
    'Create Post',
    'create-post',
    'Compose an ayah story, preview the final design live, export it as an image, and save it into the dashboard.'
);
?>
<?php if ($duplicatePost !== null): ?>
  <div class="alert alert-info">This form was pre-filled from post #<?= h((string) $duplicatePost['id']) ?> so you can duplicate and refine an existing story.</div>
<?php endif; ?>

<section class="editor-grid">
  <article class="panel">
    <div class="panel-heading">
      <div>
        <p class="eyebrow">Content</p>
        <h2>Story composer</h2>
      </div>
    </div>

    <form id="storyForm" class="form-grid" enctype="multipart/form-data" autocomplete="off">
      <?= csrf_input() ?>
      <input type="hidden" name="existing_background_path" value="<?= h($existingBackgroundPath) ?>">
      <input type="hidden" name="existing_branding_path" value="<?= h($existingBrandingPath) ?>">

      <div class="field-row">
        <div>
          <label for="surah_name">Surah name</label>
          <input id="surah_name" name="surah_name" type="text" maxlength="160" value="<?= h((string) ($duplicatePost['surah_name'] ?? '')) ?>" required>
        </div>
        <div>
          <label for="ayah_number">Ayah number</label>
          <input id="ayah_number" name="ayah_number" type="text" maxlength="40" value="<?= h((string) ($duplicatePost['ayah_number'] ?? '')) ?>" required>
        </div>
      </div>

      <label for="ayah_text">Arabic ayah short text</label>
      <textarea id="ayah_text" name="ayah_text" rows="5" required dir="rtl"><?= h((string) ($duplicatePost['ayah_text'] ?? '')) ?></textarea>

      <label for="kurdish_meaning">Kurdish meaning</label>
      <textarea id="kurdish_meaning" name="kurdish_meaning" rows="6" required dir="rtl"><?= h((string) ($duplicatePost['kurdish_meaning'] ?? '')) ?></textarea>

      <label for="template_id">Template selection</label>
      <select id="template_id" name="template_id" required>
        <?php foreach ($templates as $template): ?>
          <option value="<?= h((string) $template['id']) ?>"<?= (int) $template['id'] === $selectedTemplateId ? ' selected' : '' ?>>
            <?= h((string) $template['name']) ?>
          </option>
        <?php endforeach; ?>
      </select>

      <div class="field-row">
        <div>
          <label for="background_color">Background color</label>
          <input id="background_color" name="background_color" type="color" value="<?= h($defaultBackgroundColor) ?>">
        </div>
        <div>
          <label for="background_image">Background image</label>
          <input id="background_image" name="background_image" type="file" accept="image/png,image/jpeg,image/webp">
        </div>
      </div>

      <div class="field-row field-row--three">
        <div>
          <label for="accent_color">Accent color</label>
          <input id="accent_color" name="accent_color" type="color" value="<?= h($defaultAccentColor) ?>">
        </div>
        <div>
          <label for="arabic_text_color">Arabic text color</label>
          <input id="arabic_text_color" name="arabic_text_color" type="color" value="<?= h($defaultArabicColor) ?>">
        </div>
        <div>
          <label for="meaning_text_color">Kurdish text color</label>
          <input id="meaning_text_color" name="meaning_text_color" type="color" value="<?= h($defaultMeaningColor) ?>">
        </div>
      </div>

      <div class="field-row field-row--three">
        <div>
          <label for="arabic_font_size">Arabic font size</label>
          <input id="arabic_font_size" name="arabic_font_size" type="number" min="34" max="96" value="<?= h((string) $defaultArabicFontSize) ?>">
        </div>
        <div>
          <label for="meaning_font_size">Kurdish font size</label>
          <input id="meaning_font_size" name="meaning_font_size" type="number" min="22" max="60" value="<?= h((string) $defaultMeaningFontSize) ?>">
        </div>
        <div>
          <label for="branding_mode">Logo / watermark</label>
          <select id="branding_mode" name="branding_mode">
            <option value="none"<?= $brandingMode === 'none' ? ' selected' : '' ?>>No branding</option>
            <option value="logo"<?= $brandingMode === 'logo' ? ' selected' : '' ?>>Logo badge</option>
            <option value="watermark"<?= $brandingMode === 'watermark' ? ' selected' : '' ?>>Watermark</option>
          </select>
        </div>
      </div>

      <label for="branding_file">Upload custom logo / watermark</label>
      <input id="branding_file" name="branding_file" type="file" accept="image/png,image/jpeg,image/webp">

      <div class="button-row">
        <button class="button button-ghost" id="previewButton" type="button">Preview Design</button>
        <button class="button button-secondary" id="generateButton" type="button">Generate Image</button>
        <button class="button" id="saveButton" type="submit">Save to Dashboard</button>
        <a class="button button-ghost is-disabled" id="downloadButton" href="#" download>Download Image</a>
      </div>

      <div class="status-box" id="editorStatus">The canvas preview updates as you type. Generate the image before downloading it.</div>
    </form>
  </article>

  <article class="panel panel-preview">
    <div class="panel-heading">
      <div>
        <p class="eyebrow">Preview</p>
        <h2>1080x1920 story canvas</h2>
      </div>
    </div>

    <div class="story-preview-shell">
      <canvas id="storyCanvas" width="1080" height="1920"></canvas>
    </div>

    <div class="preview-meta">
      <div>
        <strong>Responsive preview</strong>
        <p>The canvas keeps the export size at 1080x1920 while scaling down visually for desktop and mobile admin use.</p>
      </div>
      <div>
        <strong>Future publishing</strong>
        <p>Saved posts can later be pushed to the Instagram queue without changing how designs are generated today.</p>
      </div>
    </div>
  </article>
</section>
<?php
render_app_end('create-post', [
    'templates' => $templates,
    'editorDefaults' => $editorDefaults,
]);
