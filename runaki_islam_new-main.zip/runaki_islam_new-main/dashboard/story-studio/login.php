<?php

declare(strict_types=1);

require_once __DIR__ . '/includes/bootstrap.php';

$pdo = db();

if (is_logged_in($pdo)) {
    redirect_to('dashboard.php');
}

header('Location: ' . shared_dashboard_login_url());
exit;
