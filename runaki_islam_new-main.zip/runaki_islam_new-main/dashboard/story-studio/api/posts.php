<?php

declare(strict_types=1);

require_once __DIR__ . '/../includes/bootstrap.php';

header('Content-Type: application/json; charset=utf-8');

function api_response(array $payload, int $status = 200)
{
    http_response_code($status);
    echo json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

$pdo = db();

if (!is_logged_in($pdo)) {
    api_response([
        'status' => false,
        'message' => 'Authentication required.',
    ], 401);
}

if (($_SERVER['REQUEST_METHOD'] ?? 'GET') !== 'POST') {
    api_response([
        'status' => false,
        'message' => 'Method not allowed.',
    ], 405);
}

if (!csrf_token_is_valid()) {
    api_response([
        'status' => false,
        'message' => 'Invalid CSRF token.',
    ], 419);
}

$settings = app_settings($pdo);
$currentUser = current_admin_user($pdo);

if ($currentUser === null) {
    api_response([
        'status' => false,
        'message' => 'Authentication expired. Please log in again.',
    ], 401);
}

$templateId = normalize_int_value($_POST['template_id'] ?? 0, 0, 0, 1000000);
$template = $templateId > 0 ? find_story_template($pdo, $templateId) : null;

if ($template === null || !($template['is_active'] ?? false)) {
    api_response([
        'status' => false,
        'message' => 'Please select a valid template.',
    ], 422);
}

$surahName = normalize_text((string) ($_POST['surah_name'] ?? ''), 160);
$ayahNumber = normalize_text((string) ($_POST['ayah_number'] ?? ''), 40);
$ayahText = normalize_multiline_text((string) ($_POST['ayah_text'] ?? ''), 1500);
$kurdishMeaning = normalize_multiline_text((string) ($_POST['kurdish_meaning'] ?? ''), 2400);

if ($surahName === '' || $ayahNumber === '' || $ayahText === '' || $kurdishMeaning === '') {
    api_response([
        'status' => false,
        'message' => 'Surah name, ayah number, Arabic ayah text, and Kurdish meaning are required.',
    ], 422);
}

if (!isset($_FILES['generated_image']) || (int) ($_FILES['generated_image']['error'] ?? UPLOAD_ERR_NO_FILE) === UPLOAD_ERR_NO_FILE) {
    api_response([
        'status' => false,
        'message' => 'Generate the story image before saving the post.',
    ], 422);
}

$templateConfig = is_array($template['config'] ?? null) ? $template['config'] : [];
$backgroundColor = normalize_hex_color(
    (string) ($_POST['background_color'] ?? ($templateConfig['background_color'] ?? '#0B241D')),
    (string) ($templateConfig['background_color'] ?? '#0B241D')
);
$accentColor = normalize_hex_color(
    (string) ($_POST['accent_color'] ?? ($templateConfig['accent_color'] ?? '#D7B56D')),
    (string) ($templateConfig['accent_color'] ?? '#D7B56D')
);
$arabicTextColor = normalize_hex_color(
    (string) ($_POST['arabic_text_color'] ?? ($templateConfig['arabic_text_color'] ?? '#FFF9ED')),
    (string) ($templateConfig['arabic_text_color'] ?? '#FFF9ED')
);
$meaningTextColor = normalize_hex_color(
    (string) ($_POST['meaning_text_color'] ?? ($templateConfig['meaning_text_color'] ?? '#F4E7C8')),
    (string) ($templateConfig['meaning_text_color'] ?? '#F4E7C8')
);
$arabicFontSize = normalize_int_value($_POST['arabic_font_size'] ?? ($templateConfig['arabic_font_size'] ?? 64), (int) ($templateConfig['arabic_font_size'] ?? 64), 34, 96);
$meaningFontSize = normalize_int_value($_POST['meaning_font_size'] ?? ($templateConfig['meaning_font_size'] ?? 35), (int) ($templateConfig['meaning_font_size'] ?? 35), 22, 60);

$brandingMode = (string) ($_POST['branding_mode'] ?? 'none');
if (!in_array($brandingMode, ['none', 'logo', 'watermark'], true)) {
    $brandingMode = 'none';
}

$existingBackgroundPath = trim((string) ($_POST['existing_background_path'] ?? ''));
$existingBrandingPath = trim((string) ($_POST['existing_branding_path'] ?? ''));
$backgroundImagePath = is_local_storage_reference($existingBackgroundPath) ? $existingBackgroundPath : '';
$brandingPath = '';
$newFiles = [];

try {
    if (isset($_FILES['background_image']) && (int) ($_FILES['background_image']['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_NO_FILE) {
        $backgroundImagePath = store_uploaded_image($_FILES['background_image'], 'uploads/backgrounds', 12);
        $newFiles[] = $backgroundImagePath;
    }

    if ($brandingMode !== 'none') {
        if (isset($_FILES['branding_file']) && (int) ($_FILES['branding_file']['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_NO_FILE) {
            $brandingPath = store_uploaded_image($_FILES['branding_file'], 'uploads/branding', 6);
            $newFiles[] = $brandingPath;
        } elseif (is_local_storage_reference($existingBrandingPath)) {
            $brandingPath = $existingBrandingPath;
        } else {
            $brandingPath = active_branding_path($settings, $brandingMode);
        }
    }

    $generatedImagePath = store_generated_story_image($_FILES['generated_image']);
    $newFiles[] = $generatedImagePath;

    $designPayload = [
        'template' => [
            'id' => (int) $template['id'],
            'slug' => (string) $template['slug'],
            'name' => (string) $template['name'],
        ],
        'content' => [
            'surah_name' => $surahName,
            'ayah_number' => $ayahNumber,
            'ayah_text' => $ayahText,
            'kurdish_meaning' => $kurdishMeaning,
        ],
        'design' => [
            'background_color' => $backgroundColor,
            'background_image_path' => $backgroundImagePath,
            'branding_mode' => $brandingMode,
            'branding_path' => $brandingPath,
            'accent_color' => $accentColor,
            'arabic_text_color' => $arabicTextColor,
            'meaning_text_color' => $meaningTextColor,
            'arabic_font_size' => $arabicFontSize,
            'meaning_font_size' => $meaningFontSize,
        ],
    ];

    $pdo->beginTransaction();

    $postId = insert_story_post($pdo, [
        'user_id' => (int) $currentUser['id'],
        'template_id' => (int) $template['id'],
        'surah_name' => $surahName,
        'ayah_number' => $ayahNumber,
        'ayah_text' => $ayahText,
        'kurdish_meaning' => $kurdishMeaning,
        'background_type' => $backgroundImagePath !== '' ? 'image' : 'color',
        'background_color' => $backgroundColor,
        'background_image_path' => $backgroundImagePath !== '' ? $backgroundImagePath : null,
        'branding_mode' => $brandingMode,
        'branding_path' => $brandingPath !== '' ? $brandingPath : null,
        'arabic_text_color' => $arabicTextColor,
        'meaning_text_color' => $meaningTextColor,
        'accent_color' => $accentColor,
        'arabic_font_size' => $arabicFontSize,
        'meaning_font_size' => $meaningFontSize,
        'generated_image_path' => $generatedImagePath,
        'design_payload' => json_encode($designPayload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
        'instagram_status' => 'ready',
    ]);

    $pdo->commit();

    $autoQueueEnabled = setting_value($settings, 'instagram_auto_queue') === '1';
    $queued = false;
    $queueWarning = '';

    if ($autoQueueEnabled) {
        try {
            queue_story_for_instagram($pdo, $postId);
            $queued = true;
        } catch (Throwable $queueException) {
            $queueWarning = $queueException->getMessage();
        }
    }

    api_response([
        'status' => true,
        'message' => $queued
            ? 'Post saved and queued for the future Instagram publisher.'
            : ('Post saved successfully.' . ($queueWarning !== '' ? ' Queue notice: ' . $queueWarning : '')),
        'post_id' => $postId,
        'download_url' => storage_relative_url($generatedImagePath),
        'history_url' => app_url('history.php'),
    ]);
} catch (Throwable $exception) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }

    foreach ($newFiles as $relativePath) {
        delete_local_storage_file($relativePath);
    }

    api_response([
        'status' => false,
        'message' => $exception->getMessage(),
    ], 500);
}
