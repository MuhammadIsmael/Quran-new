<?php

declare(strict_types=1);

function h(string $value): string
{
    return htmlspecialchars($value, ENT_QUOTES, 'UTF-8');
}

function app_base_path(): string
{
    $scriptName = str_replace('\\', '/', (string) ($_SERVER['SCRIPT_NAME'] ?? ''));
    $directory = rtrim(dirname($scriptName), '/');

    if (story_studio_ends_with($directory, '/api')) {
        $directory = substr($directory, 0, -4);
    }

    if ($directory === '' || $directory === '.') {
        return '';
    }

    return $directory === '/' ? '' : $directory;
}

function app_url(string $path = ''): string
{
    $basePath = app_base_path();
    $cleanPath = ltrim($path, '/');

    if ($cleanPath === '') {
        return $basePath === '' ? '/' : $basePath . '/';
    }

    return $basePath === '' ? '/' . $cleanPath : $basePath . '/' . $cleanPath;
}

function redirect_to(string $path)
{
    header('Location: ' . app_url($path));
    exit;
}

function normalize_text(string $value, int $maxLength = 0): string
{
    $value = trim(preg_replace('/\s+/u', ' ', $value) ?? $value);

    if ($maxLength > 0) {
        if (function_exists('mb_substr')) {
            return mb_substr($value, 0, $maxLength);
        }

        return substr($value, 0, $maxLength);
    }

    return $value;
}

function normalize_multiline_text(string $value, int $maxLength = 0): string
{
    $value = str_replace(["\r\n", "\r"], "\n", trim($value));
    $value = preg_replace("/\n{3,}/", "\n\n", $value) ?? $value;

    if ($maxLength > 0) {
        if (function_exists('mb_substr')) {
            return mb_substr($value, 0, $maxLength);
        }

        return substr($value, 0, $maxLength);
    }

    return $value;
}

function normalize_hex_color(string $value, string $fallback): string
{
    $candidate = strtoupper(trim($value));
    if (preg_match('/^#?[0-9A-F]{6}$/', $candidate) === 1) {
        return '#' . ltrim($candidate, '#');
    }

    return strtoupper($fallback);
}

function normalize_int_value($value, int $fallback, int $min, int $max): int
{
    $filtered = filter_var($value, FILTER_VALIDATE_INT);

    if ($filtered === false) {
        return $fallback;
    }

    $number = (int) $filtered;

    if ($number < $min) {
        return $min;
    }

    if ($number > $max) {
        return $max;
    }

    return $number;
}

function storage_root_path(string $relativePath = ''): string
{
    $base = __DIR__ . '/../';
    $cleanPath = trim(str_replace(['\\', '//'], '/', $relativePath), '/');

    if ($cleanPath === '') {
        return realpath($base) ?: $base;
    }

    return rtrim($base, '/\\') . DIRECTORY_SEPARATOR . str_replace('/', DIRECTORY_SEPARATOR, $cleanPath);
}

function ensure_storage_directory(string $relativeDirectory): string
{
    $path = storage_root_path($relativeDirectory);

    if (!is_dir($path) && !mkdir($path, 0775, true) && !is_dir($path)) {
        throw new RuntimeException('Unable to create the upload directory.');
    }

    return $path;
}

function storage_relative_url(string $relativePath): string
{
    return app_url(trim($relativePath, '/'));
}

function is_local_storage_reference(string $path): bool
{
    return preg_match('#^uploads/[a-z0-9_-]+/[A-Za-z0-9._-]+$#i', trim($path)) === 1;
}

function delete_local_storage_file(?string $relativePath): void
{
    $relativePath = trim((string) $relativePath);

    if ($relativePath === '' || !is_local_storage_reference($relativePath)) {
        return;
    }

    $absolutePath = storage_root_path($relativePath);
    if (is_file($absolutePath)) {
        @unlink($absolutePath);
    }
}

function delete_asset_if_unused(PDO $pdo, ?string $relativePath): void
{
    $relativePath = trim((string) $relativePath);

    if ($relativePath === '' || !is_local_storage_reference($relativePath)) {
        return;
    }

    $postStatement = $pdo->prepare(
        'SELECT COUNT(*)
         FROM story_posts
         WHERE background_image_path = :path
            OR branding_path = :path
            OR generated_image_path = :path'
    );
    $postStatement->execute(['path' => $relativePath]);
    $postReferences = (int) $postStatement->fetchColumn();

    if ($postReferences > 0) {
        return;
    }

    $settingStatement = $pdo->prepare(
        'SELECT COUNT(*)
         FROM app_settings
         WHERE setting_value = :path
           AND setting_key IN ("default_logo_path", "default_watermark_path")'
    );
    $settingStatement->execute(['path' => $relativePath]);
    $settingReferences = (int) $settingStatement->fetchColumn();

    if ($settingReferences > 0) {
        return;
    }

    delete_local_storage_file($relativePath);
}

function store_uploaded_image(array $file, string $relativeDirectory, int $maxSizeMb = 10, ?array $allowedMimes = null): string
{
    $allowedMimes = $allowedMimes ?? [
        'image/jpeg' => 'jpg',
        'image/png' => 'png',
        'image/webp' => 'webp',
    ];

    $error = (int) ($file['error'] ?? UPLOAD_ERR_NO_FILE);

    if ($error === UPLOAD_ERR_NO_FILE) {
        throw new RuntimeException('No image was uploaded.');
    }

    if ($error !== UPLOAD_ERR_OK) {
        throw new RuntimeException('The uploaded image could not be processed.');
    }

    $tmpPath = (string) ($file['tmp_name'] ?? '');
    $sizeBytes = (int) ($file['size'] ?? 0);
    $maxBytes = $maxSizeMb * 1024 * 1024;

    if ($sizeBytes <= 0 || $sizeBytes > $maxBytes) {
        throw new RuntimeException('The uploaded image is larger than the allowed limit.');
    }

    if (!is_uploaded_file($tmpPath)) {
        throw new RuntimeException('The uploaded image is not a valid upload.');
    }

    $finfo = new finfo(FILEINFO_MIME_TYPE);
    $mime = (string) $finfo->file($tmpPath);

    if (!array_key_exists($mime, $allowedMimes)) {
        throw new RuntimeException('Only JPG, PNG, and WEBP images are supported.');
    }

    if (!is_array(@getimagesize($tmpPath))) {
        throw new RuntimeException('The uploaded file is not a readable image.');
    }

    $extension = $allowedMimes[$mime];
    $directoryPath = ensure_storage_directory($relativeDirectory);
    $fileName = sprintf('%s_%s.%s', date('Ymd_His'), bin2hex(random_bytes(6)), $extension);
    $targetPath = $directoryPath . DIRECTORY_SEPARATOR . $fileName;

    if (!move_uploaded_file($tmpPath, $targetPath)) {
        throw new RuntimeException('The uploaded image could not be saved.');
    }

    return trim($relativeDirectory, '/') . '/' . $fileName;
}

function store_generated_story_image(array $file): string
{
    return store_uploaded_image($file, 'uploads/generated', 14, [
        'image/png' => 'png',
        'image/jpeg' => 'jpg',
        'image/webp' => 'webp',
    ]);
}

function save_app_settings(PDO $pdo, array $settings): void
{
    $statement = $pdo->prepare(
        'INSERT INTO app_settings (setting_key, setting_value)
         VALUES (:setting_key, :setting_value)
         ON DUPLICATE KEY UPDATE
           setting_value = VALUES(setting_value),
           updated_at = CURRENT_TIMESTAMP'
    );

    foreach ($settings as $key => $value) {
        $statement->execute([
            'setting_key' => (string) $key,
            'setting_value' => (string) $value,
        ]);
    }

    $GLOBALS['story_studio_settings_cache'] = null;
}

function sync_default_settings(PDO $pdo): void
{
    $defaults = [
        'brand_name' => 'Runaki Islam',
        'brand_tagline' => 'Instagram Story Studio',
        'default_background_color' => '#0B241D',
        'default_accent_color' => '#D7B56D',
        'default_arabic_text_color' => '#FFF9ED',
        'default_meaning_text_color' => '#F4E7C8',
        'default_arabic_font_size' => '64',
        'default_meaning_font_size' => '35',
        'default_logo_path' => '',
        'default_watermark_path' => '',
        'instagram_auto_queue' => '0',
        'instagram_business_id' => '',
        'instagram_access_token' => '',
        'instagram_graph_version' => 'v22.0',
        'instagram_notes' => 'Queue records are saved now so Graph API publishing can be added later without changing the dashboard structure.',
    ];

    $existing = app_settings($pdo);
    $missing = [];

    foreach ($defaults as $key => $value) {
        if (!array_key_exists($key, $existing)) {
            $missing[$key] = $value;
        }
    }

    if ($missing !== []) {
        save_app_settings($pdo, $missing);
    }
}

function app_settings(PDO $pdo): array
{
    $cache = $GLOBALS['story_studio_settings_cache'] ?? null;

    if (is_array($cache)) {
        return $cache;
    }

    $rows = $pdo->query('SELECT setting_key, setting_value FROM app_settings')->fetchAll();
    $settings = [];

    foreach ($rows as $row) {
        $settings[(string) $row['setting_key']] = (string) $row['setting_value'];
    }

    $GLOBALS['story_studio_settings_cache'] = $settings;

    return $settings;
}

function setting_value(array $settings, string $key, string $default = ''): string
{
    return array_key_exists($key, $settings) ? (string) $settings[$key] : $default;
}

function active_branding_path(array $settings, string $brandingMode): string
{
    if ($brandingMode === 'logo') {
        return setting_value($settings, 'default_logo_path');
    }

    if ($brandingMode === 'watermark') {
        return setting_value($settings, 'default_watermark_path');
    }

    return '';
}

function fetch_dashboard_overview(PDO $pdo): array
{
    $totalPosts = (int) $pdo->query('SELECT COUNT(*) FROM story_posts')->fetchColumn();
    $postsToday = (int) $pdo->query('SELECT COUNT(*) FROM story_posts WHERE DATE(created_at) = CURDATE()')->fetchColumn();
    $templateCount = (int) $pdo->query('SELECT COUNT(*) FROM story_templates WHERE is_active = 1')->fetchColumn();
    $queuedCount = (int) $pdo->query("SELECT COUNT(*) FROM instagram_publish_queue WHERE queue_status IN ('queued', 'processing')")->fetchColumn();

    return [
        'total_posts' => $totalPosts,
        'posts_today' => $postsToday,
        'template_count' => $templateCount,
        'queued_posts' => $queuedCount,
    ];
}

function fetch_recent_story_posts(PDO $pdo, int $limit = 6): array
{
    $statement = $pdo->prepare(
        'SELECT p.*, t.name AS template_name, u.full_name AS author_name
         FROM story_posts p
         LEFT JOIN story_templates t ON t.id = p.template_id
         LEFT JOIN admin_users u ON u.id = p.user_id
         ORDER BY p.created_at DESC
         LIMIT :limit'
    );
    $statement->bindValue(':limit', $limit, PDO::PARAM_INT);
    $statement->execute();

    return $statement->fetchAll();
}

function fetch_template_usage(PDO $pdo): array
{
    $statement = $pdo->query(
        'SELECT t.name, COUNT(p.id) AS usage_count
         FROM story_templates t
         LEFT JOIN story_posts p ON p.template_id = t.id
         GROUP BY t.id, t.name
         ORDER BY usage_count DESC, t.id ASC'
    );

    return $statement->fetchAll();
}

function fetch_history_posts(PDO $pdo, string $search = '', int $page = 1, int $perPage = 12): array
{
    $page = max(1, $page);
    $perPage = max(1, min($perPage, 30));
    $offset = ($page - 1) * $perPage;
    $search = normalize_text($search, 120);

    $whereSql = '';
    $params = [];

    if ($search !== '') {
        $whereSql = ' WHERE (p.surah_name LIKE :search OR p.ayah_text LIKE :search OR p.kurdish_meaning LIKE :search OR t.name LIKE :search)';
        $params['search'] = '%' . $search . '%';
    }

    $countStatement = $pdo->prepare(
        'SELECT COUNT(*) 
         FROM story_posts p
         LEFT JOIN story_templates t ON t.id = p.template_id'
         . $whereSql
    );

    foreach ($params as $key => $value) {
        $countStatement->bindValue(':' . $key, $value, PDO::PARAM_STR);
    }

    $countStatement->execute();
    $total = (int) $countStatement->fetchColumn();
    $totalPages = max(1, (int) ceil($total / $perPage));

    if ($page > $totalPages) {
        $page = $totalPages;
        $offset = ($page - 1) * $perPage;
    }

    $statement = $pdo->prepare(
        'SELECT p.*, t.name AS template_name, u.full_name AS author_name
         FROM story_posts p
         LEFT JOIN story_templates t ON t.id = p.template_id
         LEFT JOIN admin_users u ON u.id = p.user_id'
         . $whereSql .
        ' ORDER BY p.created_at DESC
          LIMIT :limit OFFSET :offset'
    );

    foreach ($params as $key => $value) {
        $statement->bindValue(':' . $key, $value, PDO::PARAM_STR);
    }

    $statement->bindValue(':limit', $perPage, PDO::PARAM_INT);
    $statement->bindValue(':offset', $offset, PDO::PARAM_INT);
    $statement->execute();

    return [
        'items' => $statement->fetchAll(),
        'total' => $total,
        'page' => $page,
        'per_page' => $perPage,
        'total_pages' => $totalPages,
        'search' => $search,
    ];
}

function fetch_story_post(PDO $pdo, int $postId): ?array
{
    $statement = $pdo->prepare(
        'SELECT p.*, t.name AS template_name, t.slug AS template_slug, u.full_name AS author_name
         FROM story_posts p
         LEFT JOIN story_templates t ON t.id = p.template_id
         LEFT JOIN admin_users u ON u.id = p.user_id
         WHERE p.id = :id
         LIMIT 1'
    );
    $statement->execute(['id' => $postId]);
    $row = $statement->fetch();

    return is_array($row) ? $row : null;
}

function insert_story_post(PDO $pdo, array $payload): int
{
    $statement = $pdo->prepare(
        'INSERT INTO story_posts (
            user_id,
            template_id,
            surah_name,
            ayah_number,
            ayah_text,
            kurdish_meaning,
            background_type,
            background_color,
            background_image_path,
            branding_mode,
            branding_path,
            arabic_text_color,
            meaning_text_color,
            accent_color,
            arabic_font_size,
            meaning_font_size,
            generated_image_path,
            design_payload,
            instagram_status
        ) VALUES (
            :user_id,
            :template_id,
            :surah_name,
            :ayah_number,
            :ayah_text,
            :kurdish_meaning,
            :background_type,
            :background_color,
            :background_image_path,
            :branding_mode,
            :branding_path,
            :arabic_text_color,
            :meaning_text_color,
            :accent_color,
            :arabic_font_size,
            :meaning_font_size,
            :generated_image_path,
            :design_payload,
            :instagram_status
        )'
    );
    $statement->execute([
        'user_id' => $payload['user_id'],
        'template_id' => $payload['template_id'],
        'surah_name' => $payload['surah_name'],
        'ayah_number' => $payload['ayah_number'],
        'ayah_text' => $payload['ayah_text'],
        'kurdish_meaning' => $payload['kurdish_meaning'],
        'background_type' => $payload['background_type'],
        'background_color' => $payload['background_color'],
        'background_image_path' => $payload['background_image_path'],
        'branding_mode' => $payload['branding_mode'],
        'branding_path' => $payload['branding_path'],
        'arabic_text_color' => $payload['arabic_text_color'],
        'meaning_text_color' => $payload['meaning_text_color'],
        'accent_color' => $payload['accent_color'],
        'arabic_font_size' => $payload['arabic_font_size'],
        'meaning_font_size' => $payload['meaning_font_size'],
        'generated_image_path' => $payload['generated_image_path'],
        'design_payload' => $payload['design_payload'],
        'instagram_status' => $payload['instagram_status'],
    ]);

    return (int) $pdo->lastInsertId();
}

function delete_story_post(PDO $pdo, int $postId): bool
{
    $post = fetch_story_post($pdo, $postId);

    if ($post === null) {
        return false;
    }

    $pdo->beginTransaction();

    try {
        $deleteQueue = $pdo->prepare('DELETE FROM instagram_publish_queue WHERE post_id = :post_id');
        $deleteQueue->execute(['post_id' => $postId]);

        $deletePost = $pdo->prepare('DELETE FROM story_posts WHERE id = :id');
        $deletePost->execute(['id' => $postId]);

        $pdo->commit();
    } catch (Throwable $exception) {
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }

        throw $exception;
    }

    delete_asset_if_unused($pdo, (string) ($post['generated_image_path'] ?? ''));
    delete_asset_if_unused($pdo, (string) ($post['background_image_path'] ?? ''));
    delete_asset_if_unused($pdo, (string) ($post['branding_path'] ?? ''));

    return true;
}

function format_app_datetime(?string $value): string
{
    if ($value === null || trim($value) === '') {
        return '-';
    }

    try {
        $date = new DateTimeImmutable($value);
    } catch (Throwable) {
        return $value;
    }

    return $date->format('M d, Y g:i A');
}
