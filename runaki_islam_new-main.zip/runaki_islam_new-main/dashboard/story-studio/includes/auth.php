<?php

declare(strict_types=1);

function start_secure_session(): void
{
    if (session_status() === PHP_SESSION_ACTIVE) {
        return;
    }

    $isHttps = !empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off';
    session_name(story_studio_session_name());

    session_set_cookie_params([
        'lifetime' => 0,
        'path' => story_studio_session_cookie_path(),
        'domain' => '',
        'secure' => $isHttps,
        'httponly' => true,
        'samesite' => 'Lax',
    ]);

    session_start();
}

function story_studio_session_name(): string
{
    return 'RUNAKI_ADMIN_SESSION';
}

function story_studio_session_cookie_path(): string
{
    return '/';
}

function shared_dashboard_login_url(): string
{
    $basePath = trim(app_base_path(), '/');
    if ($basePath === '') {
        return '/login.php';
    }

    $segments = explode('/', $basePath);
    array_pop($segments);

    if ($segments === []) {
        return '/login.php';
    }

    return '/' . implode('/', $segments) . '/login.php';
}

function shared_dashboard_session_is_active(): bool
{
    start_secure_session();

    $sessionUser = trim((string) ($_SESSION['dashboard_user'] ?? ''));
    $loginAt = (int) ($_SESSION['dashboard_login_at'] ?? 0);

    if ($sessionUser === '' || $loginAt <= 0) {
        return false;
    }

    if ((time() - $loginAt) > STORY_STUDIO_SESSION_TIMEOUT_SECONDS) {
        unset($_SESSION['dashboard_user'], $_SESSION['dashboard_login_at'], $_SESSION['dashboard_csrf_token']);
        return false;
    }

    $_SESSION['dashboard_login_at'] = time();

    return true;
}

function clear_story_studio_auth_state(): void
{
    unset(
        $_SESSION['story_studio_user_id'],
        $_SESSION['story_studio_login_at'],
        $_SESSION['story_studio_csrf_token'],
        $_SESSION['story_studio_flash'],
        $_SESSION['story_studio_login_limit']
    );
    $GLOBALS['story_studio_current_user'] = null;
}

function shared_dashboard_admin_user(PDO $pdo): ?array
{
    if (!shared_dashboard_session_is_active()) {
        return null;
    }

    $statement = $pdo->query(
        'SELECT id, username, full_name, role
         FROM admin_users
         ORDER BY id ASC
         LIMIT 1'
    );
    $row = $statement->fetch();

    if (!is_array($row)) {
        return null;
    }

    $dashboardUser = trim((string) ($_SESSION['dashboard_user'] ?? ''));

    return [
        'id' => (int) $row['id'],
        'username' => $dashboardUser !== '' ? $dashboardUser : (string) $row['username'],
        'full_name' => trim((string) $row['full_name']) !== '' ? (string) $row['full_name'] : 'Dashboard Administrator',
        'role' => (string) $row['role'],
    ];
}

function csrf_token(): string
{
    start_secure_session();

    $token = (string) ($_SESSION['story_studio_csrf_token'] ?? '');

    if ($token !== '' && strlen($token) >= 32) {
        return $token;
    }

    return reset_csrf_token();
}

function reset_csrf_token(): string
{
    start_secure_session();

    $token = bin2hex(random_bytes(32));
    $_SESSION['story_studio_csrf_token'] = $token;

    return $token;
}

function csrf_token_is_valid(?string $incomingToken = null): bool
{
    start_secure_session();

    $token = trim((string) ($incomingToken ?? $_POST['_csrf'] ?? $_SERVER['HTTP_X_CSRF_TOKEN'] ?? ''));
    $sessionToken = (string) ($_SESSION['story_studio_csrf_token'] ?? '');

    if ($token === '' || $sessionToken === '') {
        return false;
    }

    return hash_equals($sessionToken, $token);
}

function csrf_input(): string
{
    return '<input type="hidden" name="_csrf" value="' . h(csrf_token()) . '">';
}

function verify_csrf_or_fail(?string $incomingToken = null): void
{
    if (!csrf_token_is_valid($incomingToken)) {
        http_response_code(419);
        exit('Invalid CSRF token.');
    }
}

function set_flash_message(string $type, string $message): void
{
    start_secure_session();

    if (!isset($_SESSION['story_studio_flash']) || !is_array($_SESSION['story_studio_flash'])) {
        $_SESSION['story_studio_flash'] = [];
    }

    $_SESSION['story_studio_flash'][] = [
        'type' => $type,
        'message' => $message,
    ];
}

function pull_flash_messages(): array
{
    start_secure_session();

    $messages = $_SESSION['story_studio_flash'] ?? [];
    $_SESSION['story_studio_flash'] = [];

    return is_array($messages) ? $messages : [];
}

function login_bucket(string $username = ''): string
{
    $ip = trim((string) ($_SERVER['REMOTE_ADDR'] ?? 'unknown'));
    $agent = trim((string) ($_SERVER['HTTP_USER_AGENT'] ?? 'unknown'));

    return hash('sha256', strtolower(trim($username)) . '|' . $ip . '|' . $agent);
}

function login_attempt_state(string $bucket): array
{
    start_secure_session();

    if (!isset($_SESSION['story_studio_login_limit']) || !is_array($_SESSION['story_studio_login_limit'])) {
        $_SESSION['story_studio_login_limit'] = [];
    }

    $state = $_SESSION['story_studio_login_limit'][$bucket] ?? [
        'attempts' => 0,
        'locked_until' => 0,
    ];

    $state['attempts'] = (int) ($state['attempts'] ?? 0);
    $state['locked_until'] = (int) ($state['locked_until'] ?? 0);

    if ($state['locked_until'] > 0 && $state['locked_until'] <= time()) {
        $state = [
            'attempts' => 0,
            'locked_until' => 0,
        ];
    }

    $_SESSION['story_studio_login_limit'][$bucket] = $state;

    return $state;
}

function register_failed_login(string $bucket): void
{
    $state = login_attempt_state($bucket);
    $attempts = (int) $state['attempts'] + 1;
    $lockUntil = 0;

    if ($attempts >= 5) {
        $attempts = 0;
        $lockUntil = time() + 900;
    }

    $_SESSION['story_studio_login_limit'][$bucket] = [
        'attempts' => $attempts,
        'locked_until' => $lockUntil,
    ];
}

function clear_failed_logins(string $bucket): void
{
    start_secure_session();
    $_SESSION['story_studio_login_limit'][$bucket] = [
        'attempts' => 0,
        'locked_until' => 0,
    ];
}

function login_is_locked(string $bucket): bool
{
    $state = login_attempt_state($bucket);
    return (int) $state['locked_until'] > time();
}

function login_lock_message(string $bucket): string
{
    $state = login_attempt_state($bucket);
    $remaining = (int) $state['locked_until'] - time();

    if ($remaining <= 0) {
        return 'Invalid username or password.';
    }

    $minutes = max(1, (int) ceil($remaining / 60));

    return 'Too many login attempts. Please wait ' . $minutes . ' minute(s) and try again.';
}

function base64url_decode_safe(string $value): string
{
    $padding = 4 - (strlen($value) % 4);

    if ($padding < 4) {
        $value .= str_repeat('=', $padding);
    }

    $decoded = base64_decode(strtr($value, '-_', '+/'), true);

    return $decoded === false ? '' : $decoded;
}

function verify_password_hash_value(string $password, string $storedHash): bool
{
    if ($storedHash === '') {
        return false;
    }

    if (preg_match('/^\$2[aby]\$/', $storedHash) === 1 || story_studio_starts_with($storedHash, '$argon')) {
        return password_verify($password, $storedHash);
    }

    if (story_studio_starts_with($storedHash, 'pbkdf2_sha256$')) {
        $parts = explode('$', $storedHash);

        if (count($parts) !== 4) {
            return false;
        }

        $iterations = filter_var($parts[1], FILTER_VALIDATE_INT);
        $salt = base64url_decode_safe($parts[2]);
        $expectedHash = base64url_decode_safe($parts[3]);

        if ($iterations === false || $salt === '' || $expectedHash === '') {
            return false;
        }

        $derived = hash_pbkdf2('sha256', $password, $salt, (int) $iterations, 32, true);

        return hash_equals($expectedHash, $derived);
    }

    return false;
}

function authenticate_admin(PDO $pdo, string $username, string $password): bool
{
    start_secure_session();

    $normalizedUsername = normalize_text($username, 80);
    $bucket = login_bucket($normalizedUsername);

    if (login_is_locked($bucket)) {
        return false;
    }

    $statement = $pdo->prepare(
        'SELECT id, username, full_name, password_hash, role
         FROM admin_users
         WHERE username = :username
         LIMIT 1'
    );
    $statement->execute(['username' => $normalizedUsername]);
    $user = $statement->fetch();

    if (!is_array($user) || !verify_password_hash_value($password, (string) $user['password_hash'])) {
        register_failed_login($bucket);
        return false;
    }

    clear_failed_logins($bucket);
    session_regenerate_id(true);

    $_SESSION['story_studio_user_id'] = (int) $user['id'];
    $_SESSION['story_studio_login_at'] = time();
    reset_csrf_token();

    $updateStatement = $pdo->prepare('UPDATE admin_users SET last_login_at = NOW() WHERE id = :id');
    $updateStatement->execute(['id' => (int) $user['id']]);

    $GLOBALS['story_studio_current_user'] = [
        'id' => (int) $user['id'],
        'username' => (string) $user['username'],
        'full_name' => (string) $user['full_name'],
        'role' => (string) $user['role'],
    ];

    return true;
}

function current_admin_user(PDO $pdo): ?array
{
    start_secure_session();

    $cached = $GLOBALS['story_studio_current_user'] ?? null;
    if (is_array($cached)) {
        return $cached;
    }

    $userId = (int) ($_SESSION['story_studio_user_id'] ?? 0);
    $loginAt = (int) ($_SESSION['story_studio_login_at'] ?? 0);

    if ($userId <= 0 || $loginAt <= 0) {
        $sharedUser = shared_dashboard_admin_user($pdo);
        if (is_array($sharedUser)) {
            $GLOBALS['story_studio_current_user'] = $sharedUser;
        }
        return $sharedUser;
    }

    if ((time() - $loginAt) > STORY_STUDIO_SESSION_TIMEOUT_SECONDS) {
        clear_story_studio_auth_state();
        $sharedUser = shared_dashboard_admin_user($pdo);
        if (is_array($sharedUser)) {
            $GLOBALS['story_studio_current_user'] = $sharedUser;
        }
        return $sharedUser;
    }

    $_SESSION['story_studio_login_at'] = time();

    $statement = $pdo->prepare(
        'SELECT id, username, full_name, role
         FROM admin_users
         WHERE id = :id
         LIMIT 1'
    );
    $statement->execute(['id' => $userId]);
    $user = $statement->fetch();

    if (!is_array($user)) {
        clear_story_studio_auth_state();
        $sharedUser = shared_dashboard_admin_user($pdo);
        if (is_array($sharedUser)) {
            $GLOBALS['story_studio_current_user'] = $sharedUser;
        }
        return $sharedUser;
    }

    $GLOBALS['story_studio_current_user'] = [
        'id' => (int) $user['id'],
        'username' => (string) $user['username'],
        'full_name' => (string) $user['full_name'],
        'role' => (string) $user['role'],
    ];

    return $GLOBALS['story_studio_current_user'];
}

function is_logged_in(PDO $pdo): bool
{
    return current_admin_user($pdo) !== null;
}

function require_login(PDO $pdo): void
{
    if (is_logged_in($pdo)) {
        return;
    }

    header('Location: ' . shared_dashboard_login_url());
    exit;
}

function logout_admin(): void
{
    start_secure_session();

    $_SESSION = [];

    if (ini_get('session.use_cookies')) {
        $params = session_get_cookie_params();
        setcookie(
            session_name(),
            '',
            time() - 42000,
            (string) ($params['path'] ?? story_studio_session_cookie_path()),
            (string) ($params['domain'] ?? ''),
            (bool) ($params['secure'] ?? false),
            (bool) ($params['httponly'] ?? true)
        );
    }

    session_destroy();
    clear_story_studio_auth_state();
}
