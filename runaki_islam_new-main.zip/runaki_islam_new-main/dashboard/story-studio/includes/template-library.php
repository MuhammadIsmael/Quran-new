<?php

declare(strict_types=1);

function default_story_templates(): array
{
    return [
        [
            'slug' => 'noor-gold',
            'name' => 'Noor Gold',
            'description' => 'Deep emerald story with a gold frame, balanced spacing, and a centered Quran card.',
            'preview_tagline' => 'Classic emerald and gold storytelling.',
            'config' => [
                'variant' => 'noor-gold',
                'background_color' => '#0B241D',
                'accent_color' => '#D7B56D',
                'arabic_text_color' => '#FFF9ED',
                'meaning_text_color' => '#F4E7C8',
                'arabic_font_size' => 64,
                'meaning_font_size' => 35,
                'features' => [
                    'Gold ornamental frame',
                    'Centered ayah focus',
                    'Soft bottom translation panel',
                ],
            ],
        ],
        [
            'slug' => 'safa-light',
            'name' => 'Safa Light',
            'description' => 'Warm parchment palette with airy cards that keep Kurdish meaning highly readable.',
            'preview_tagline' => 'Light, elegant, and editorial.',
            'config' => [
                'variant' => 'safa-light',
                'background_color' => '#E7D9BE',
                'accent_color' => '#0F5A46',
                'arabic_text_color' => '#17352A',
                'meaning_text_color' => '#24473B',
                'arabic_font_size' => 60,
                'meaning_font_size' => 33,
                'features' => [
                    'Parchment-inspired background',
                    'Two-card stacked layout',
                    'Readable high-contrast translation area',
                ],
            ],
        ],
        [
            'slug' => 'crescent-night',
            'name' => 'Crescent Night',
            'description' => 'Night-sky gradient with a glass card, crescent accents, and modern contrast.',
            'preview_tagline' => 'A modern story with celestial motion.',
            'config' => [
                'variant' => 'crescent-night',
                'background_color' => '#08141E',
                'accent_color' => '#7ED9B1',
                'arabic_text_color' => '#FAF7F0',
                'meaning_text_color' => '#DDEDE7',
                'arabic_font_size' => 62,
                'meaning_font_size' => 34,
                'features' => [
                    'Glassmorphism text panel',
                    'Crescent accent drawing',
                    'High-contrast dark story mode',
                ],
            ],
        ],
    ];
}

function sync_default_templates(PDO $pdo): void
{
    $statement = $pdo->prepare(
        'INSERT IGNORE INTO story_templates (slug, name, description, preview_tagline, config_json, is_active)
         VALUES (:slug, :name, :description, :preview_tagline, :config_json, 1)'
    );

    foreach (default_story_templates() as $template) {
        $statement->execute([
            'slug' => $template['slug'],
            'name' => $template['name'],
            'description' => $template['description'],
            'preview_tagline' => $template['preview_tagline'],
            'config_json' => json_encode($template['config'], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
        ]);
    }
}

function fetch_story_templates(PDO $pdo, bool $onlyActive = true): array
{
    $sql = 'SELECT id, slug, name, description, preview_tagline, config_json, is_active, created_at, updated_at
            FROM story_templates';

    if ($onlyActive) {
        $sql .= ' WHERE is_active = 1';
    }

    $sql .= ' ORDER BY id ASC';

    $rows = $pdo->query($sql)->fetchAll();
    $templates = [];

    foreach ($rows as $row) {
        $config = json_decode((string) $row['config_json'], true);
        $templates[] = [
            'id' => (int) $row['id'],
            'slug' => (string) $row['slug'],
            'name' => (string) $row['name'],
            'description' => (string) $row['description'],
            'preview_tagline' => (string) $row['preview_tagline'],
            'config' => is_array($config) ? $config : [],
            'is_active' => (bool) $row['is_active'],
            'created_at' => (string) $row['created_at'],
            'updated_at' => (string) $row['updated_at'],
        ];
    }

    return $templates;
}

function find_story_template(PDO $pdo, int $templateId): ?array
{
    $statement = $pdo->prepare(
        'SELECT id, slug, name, description, preview_tagline, config_json, is_active, created_at, updated_at
         FROM story_templates
         WHERE id = :id
         LIMIT 1'
    );
    $statement->execute(['id' => $templateId]);
    $row = $statement->fetch();

    if (!is_array($row)) {
        return null;
    }

    $config = json_decode((string) $row['config_json'], true);

    return [
        'id' => (int) $row['id'],
        'slug' => (string) $row['slug'],
        'name' => (string) $row['name'],
        'description' => (string) $row['description'],
        'preview_tagline' => (string) $row['preview_tagline'],
        'config' => is_array($config) ? $config : [],
        'is_active' => (bool) $row['is_active'],
        'created_at' => (string) $row['created_at'],
        'updated_at' => (string) $row['updated_at'],
    ];
}
