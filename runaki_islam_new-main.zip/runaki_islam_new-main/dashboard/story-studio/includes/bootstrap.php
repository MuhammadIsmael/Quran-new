<?php

declare(strict_types=1);

require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/template-library.php';
require_once __DIR__ . '/helpers.php';
require_once __DIR__ . '/auth.php';
require_once __DIR__ . '/instagram-publisher.php';
require_once __DIR__ . '/layout.php';

start_secure_session();

try {
    $pdo = db();
    sync_default_templates($pdo);
    sync_default_settings($pdo);
} catch (Throwable $exception) {
    http_response_code(500);
    header('Content-Type: text/html; charset=utf-8');

    $safeMessage = htmlspecialchars($exception->getMessage(), ENT_QUOTES, 'UTF-8');

    echo '<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">';
    echo '<title>Story Studio Setup Error</title>';
    echo '<style>body{font-family:Segoe UI,Tahoma,sans-serif;background:#0b1713;color:#f6efdf;padding:32px;line-height:1.7}';
    echo '.card{max-width:760px;margin:0 auto;background:#11241d;border:1px solid #2a4a3c;border-radius:18px;padding:24px}';
    echo 'code{background:#09130f;padding:2px 6px;border-radius:6px;color:#f6d68f}';
    echo 'h1{margin-top:0;color:#f6d68f}</style></head><body><div class="card">';
    echo '<h1>Story Studio could not start</h1>';
    echo '<p>This is usually one of these issues:</p>';
    echo '<ol>';
    echo '<li>Your live MySQL credentials in <code>config.php</code> are still using local defaults.</li>';
    echo '<li>Your MySQL user cannot create or read the Story Studio tables. Grant table privileges, or import <code>db.sql</code> manually.</li>';
    echo '<li>Your hosting PHP version is too old. Use PHP 7.4+ at minimum, preferably PHP 8.1+.</li>';
    echo '</ol>';
    echo '<p><strong>Server message:</strong> ' . $safeMessage . '</p>';
    echo '</div></body></html>';
    exit;
}
