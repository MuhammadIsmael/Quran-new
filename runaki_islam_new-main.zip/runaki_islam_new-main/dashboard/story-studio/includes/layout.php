<?php

declare(strict_types=1);

function render_app_start(string $pageTitle, string $activePage, string $pageDescription = ''): void
{
    $pdo = db();
    $settings = app_settings($pdo);
    $brandName = setting_value($settings, 'brand_name', 'Runaki Islam');
    $brandTagline = setting_value($settings, 'brand_tagline', 'Instagram Story Studio');
    $currentUser = current_admin_user($pdo);
    $flashMessages = pull_flash_messages();

    $navItems = [
        'dashboard' => ['label' => 'Dashboard', 'path' => 'dashboard.php'],
        'create-post' => ['label' => 'Create Post', 'path' => 'create-post.php'],
        'templates' => ['label' => 'Templates', 'path' => 'templates.php'],
        'history' => ['label' => 'Post History', 'path' => 'history.php'],
        'settings' => ['label' => 'Settings', 'path' => 'settings.php'],
    ];
    ?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title><?= h($pageTitle) ?> | <?= h($brandName) ?></title>
  <meta name="csrf-token" content="<?= h(csrf_token()) ?>">
  <link rel="stylesheet" href="<?= h(app_url('style.css')) ?>">
</head>
<body class="studio-body">
  <div class="studio-shell">
    <aside class="sidebar" id="sidebar">
      <a class="brand-card" href="<?= h(app_url('dashboard.php')) ?>">
        <span class="brand-mark">RI</span>
        <span>
          <strong><?= h($brandName) ?></strong>
          <small><?= h($brandTagline) ?></small>
        </span>
      </a>

      <nav class="sidebar-nav" aria-label="Main navigation">
        <?php foreach ($navItems as $pageKey => $item): ?>
          <a class="sidebar-link<?= $pageKey === $activePage ? ' is-active' : '' ?>" href="<?= h(app_url($item['path'])) ?>">
            <?= h($item['label']) ?>
          </a>
        <?php endforeach; ?>
      </nav>

      <div class="sidebar-note">
        <p>Story output is rendered on a 1080x1920 canvas and stored for download and future Instagram publishing.</p>
      </div>
    </aside>

    <div class="main-column">
      <header class="topbar">
        <div class="topbar-intro">
          <button class="sidebar-toggle" id="sidebarToggle" type="button" aria-label="Open sidebar">Menu</button>
          <div>
            <p class="eyebrow"><?= h($brandName) ?></p>
            <h1><?= h($pageTitle) ?></h1>
            <?php if ($pageDescription !== ''): ?>
              <p class="page-description"><?= h($pageDescription) ?></p>
            <?php endif; ?>
          </div>
        </div>

        <div class="topbar-actions">
          <span class="user-pill"><?= h((string) ($currentUser['full_name'] ?? 'Administrator')) ?></span>
          <a class="button button-ghost" href="<?= h(app_url('logout.php')) ?>">Logout</a>
        </div>
      </header>

      <?php foreach ($flashMessages as $message): ?>
        <?php
        $type = is_array($message) ? (string) ($message['type'] ?? 'info') : 'info';
        $text = is_array($message) ? (string) ($message['message'] ?? '') : '';
        ?>
        <div class="alert alert-<?= h($type) ?>" data-auto-dismiss="1">
          <?= h($text) ?>
        </div>
      <?php endforeach; ?>

      <main class="page-content" data-page="<?= h($activePage) ?>">
    <?php
}

function render_app_end(string $pageId, array $pageData = []): void
{
    $payload = [
        'page' => $pageId,
        'baseUrl' => app_url(),
        'csrfToken' => csrf_token(),
        'api' => [
            'savePost' => app_url('api/posts.php'),
        ],
    ];

    if ($pageData !== []) {
        $payload = array_merge($payload, $pageData);
    }
    ?>
      </main>
    </div>
  </div>

  <script>
    window.STORY_STUDIO = <?= json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) ?>;
  </script>
  <script src="<?= h(app_url('script.js')) ?>" defer></script>
</body>
</html>
    <?php
}
