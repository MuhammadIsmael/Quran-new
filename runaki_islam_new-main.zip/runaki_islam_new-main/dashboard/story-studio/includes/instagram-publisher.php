<?php

declare(strict_types=1);

function build_instagram_caption(array $post): string
{
    $surah = trim((string) ($post['surah_name'] ?? ''));
    $ayahNumber = trim((string) ($post['ayah_number'] ?? ''));
    $meaning = trim((string) ($post['kurdish_meaning'] ?? ''));

    $caption = $surah !== '' ? $surah : 'Runaki Islam Story';

    if ($ayahNumber !== '') {
        $caption .= ' - Ayah ' . $ayahNumber;
    }

    if ($meaning !== '') {
        $caption .= "\n\n" . $meaning;
    }

    return $caption;
}

function queue_story_for_instagram(PDO $pdo, int $postId): void
{
    $post = fetch_story_post($pdo, $postId);

    if ($post === null) {
        throw new RuntimeException('The selected post could not be found.');
    }

    $existingQueueStatement = $pdo->prepare(
        "SELECT id
         FROM instagram_publish_queue
         WHERE post_id = :post_id
           AND queue_status IN ('queued', 'processing')
         LIMIT 1"
    );
    $existingQueueStatement->execute(['post_id' => $postId]);

    if ($existingQueueStatement->fetchColumn()) {
        throw new RuntimeException('This post is already waiting in the Instagram queue.');
    }

    $payload = [
        'post_id' => $postId,
        'caption' => build_instagram_caption($post),
        'image_path' => (string) ($post['generated_image_path'] ?? ''),
        'template_name' => (string) ($post['template_name'] ?? ''),
    ];

    $pdo->beginTransaction();

    try {
        $queueStatement = $pdo->prepare(
            'INSERT INTO instagram_publish_queue (post_id, queue_status, payload_json, scheduled_at)
             VALUES (:post_id, :queue_status, :payload_json, NOW())'
        );
        $queueStatement->execute([
            'post_id' => $postId,
            'queue_status' => 'queued',
            'payload_json' => json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
        ]);

        $statusStatement = $pdo->prepare(
            'UPDATE story_posts
             SET instagram_status = :instagram_status, updated_at = NOW()
             WHERE id = :id'
        );
        $statusStatement->execute([
            'instagram_status' => 'queued',
            'id' => $postId,
        ]);

        $pdo->commit();
    } catch (Throwable $exception) {
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }

        throw $exception;
    }
}

function fetch_recent_instagram_queue(PDO $pdo, int $limit = 5): array
{
    $statement = $pdo->prepare(
        'SELECT q.*, p.surah_name, p.ayah_number
         FROM instagram_publish_queue q
         LEFT JOIN story_posts p ON p.id = q.post_id
         ORDER BY q.created_at DESC
         LIMIT :limit'
    );
    $statement->bindValue(':limit', $limit, PDO::PARAM_INT);
    $statement->execute();

    return $statement->fetchAll();
}
