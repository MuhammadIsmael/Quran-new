<?php

declare(strict_types=1);

require_once __DIR__ . '/includes/bootstrap.php';

$pdo = db();
require_login($pdo);

$templates = fetch_story_templates($pdo, false);

render_app_start(
    'Templates',
    'templates',
    'Review the reusable story layouts included in this MVP and use them as a base for future design expansion.'
);
?>
<section class="template-grid">
  <?php foreach ($templates as $template): ?>
    <?php
    $config = is_array($template['config']) ? $template['config'] : [];
    $variant = (string) ($config['variant'] ?? 'noor-gold');
    $features = is_array($config['features'] ?? null) ? $config['features'] : [];
    ?>
    <article class="panel template-card">
      <div class="template-preview template-preview--<?= h($variant) ?>">
        <div class="template-preview__meta"><?= h((string) $template['name']) ?></div>
        <div class="template-preview__arabic">إِنَّ مَعَ الْعُسْرِ يُسْرًا</div>
        <div class="template-preview__meaning">لەگەڵ تەنگانەدا، ئاسانی هەیە.</div>
      </div>

      <div class="template-copy">
        <p class="eyebrow">Template</p>
        <h2><?= h((string) $template['name']) ?></h2>
        <p><?= h((string) $template['description']) ?></p>
        <p class="template-tagline"><?= h((string) $template['preview_tagline']) ?></p>

        <div class="color-row">
          <span style="background: <?= h((string) ($config['background_color'] ?? '#0B241D')) ?>"></span>
          <span style="background: <?= h((string) ($config['accent_color'] ?? '#D7B56D')) ?>"></span>
          <span style="background: <?= h((string) ($config['arabic_text_color'] ?? '#FFF9ED')) ?>"></span>
        </div>

        <ul class="feature-list">
          <?php foreach ($features as $feature): ?>
            <li><?= h((string) $feature) ?></li>
          <?php endforeach; ?>
        </ul>

        <a class="button button-ghost" href="<?= h(app_url('create-post.php')) ?>">Use this template</a>
      </div>
    </article>
  <?php endforeach; ?>
</section>
<?php
render_app_end('templates');
