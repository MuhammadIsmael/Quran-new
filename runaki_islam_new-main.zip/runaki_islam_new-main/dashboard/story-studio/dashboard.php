<?php

declare(strict_types=1);

require_once __DIR__ . '/includes/bootstrap.php';

$pdo = db();
require_login($pdo);

$overview = fetch_dashboard_overview($pdo);
$recentPosts = fetch_recent_story_posts($pdo, 6);
$templateUsage = fetch_template_usage($pdo);
$recentQueue = fetch_recent_instagram_queue($pdo, 5);

render_app_start(
    'Dashboard',
    'dashboard',
    'Monitor saved stories, template usage, and the publishing queue from one responsive workspace.'
);
?>
<section class="stats-grid">
  <article class="stat-card">
    <span>Total posts</span>
    <strong><?= h((string) $overview['total_posts']) ?></strong>
    <small>Saved story records in the dashboard.</small>
  </article>
  <article class="stat-card">
    <span>Created today</span>
    <strong><?= h((string) $overview['posts_today']) ?></strong>
    <small>Posts generated on the current server date.</small>
  </article>
  <article class="stat-card">
    <span>Active templates</span>
    <strong><?= h((string) $overview['template_count']) ?></strong>
    <small>Reusable story designs ready to select.</small>
  </article>
  <article class="stat-card">
    <span>Instagram queue</span>
    <strong><?= h((string) $overview['queued_posts']) ?></strong>
    <small>Stories waiting for future API publishing.</small>
  </article>
</section>

<section class="content-grid">
  <article class="panel">
    <div class="panel-heading">
      <div>
        <p class="eyebrow">Quick Actions</p>
        <h2>Story workflow</h2>
      </div>
    </div>
    <div class="quick-links">
      <a class="quick-link" href="<?= h(app_url('create-post.php')) ?>">
        <strong>Create a story</strong>
        <span>Compose a new ayah post, preview it, and export a 1080x1920 image.</span>
      </a>
      <a class="quick-link" href="<?= h(app_url('templates.php')) ?>">
        <strong>Review templates</strong>
        <span>Browse the three built-in layouts and their default palettes.</span>
      </a>
      <a class="quick-link" href="<?= h(app_url('history.php')) ?>">
        <strong>Open history</strong>
        <span>Download previous posts, duplicate them, or queue them for Instagram.</span>
      </a>
    </div>
  </article>

  <article class="panel">
    <div class="panel-heading">
      <div>
        <p class="eyebrow">Recent Stories</p>
        <h2>Latest saved posts</h2>
      </div>
      <a class="button button-ghost" href="<?= h(app_url('history.php')) ?>">View all</a>
    </div>

    <div class="stack-list">
      <?php if ($recentPosts === []): ?>
        <div class="empty-state">No stories have been saved yet. Create the first one from the Create Post page.</div>
      <?php endif; ?>

      <?php foreach ($recentPosts as $post): ?>
        <article class="list-card">
          <div>
            <strong><?= h((string) $post['surah_name']) ?><?= trim((string) $post['ayah_number']) !== '' ? ' - Ayah ' . h((string) $post['ayah_number']) : '' ?></strong>
            <p><?= h((string) $post['template_name']) ?> - <?= h(format_app_datetime((string) $post['created_at'])) ?></p>
          </div>
          <div class="inline-actions">
            <a class="button button-ghost" href="<?= h(app_url('create-post.php?duplicate=' . (int) $post['id'])) ?>">Duplicate</a>
            <?php if (trim((string) $post['generated_image_path']) !== ''): ?>
              <a class="button button-ghost" href="<?= h(storage_relative_url((string) $post['generated_image_path'])) ?>" download>Download</a>
            <?php endif; ?>
          </div>
        </article>
      <?php endforeach; ?>
    </div>
  </article>
</section>

<section class="content-grid content-grid--secondary">
  <article class="panel">
    <div class="panel-heading">
      <div>
        <p class="eyebrow">Template Usage</p>
        <h2>Design performance</h2>
      </div>
    </div>

    <div class="stack-list">
      <?php foreach ($templateUsage as $row): ?>
        <article class="list-card">
          <div>
            <strong><?= h((string) $row['name']) ?></strong>
            <p>Used in <?= h((string) $row['usage_count']) ?> saved posts.</p>
          </div>
        </article>
      <?php endforeach; ?>
    </div>
  </article>

  <article class="panel">
    <div class="panel-heading">
      <div>
        <p class="eyebrow">Publishing Queue</p>
        <h2>Prepared for Instagram</h2>
      </div>
      <a class="button button-ghost" href="<?= h(app_url('settings.php')) ?>">Integration settings</a>
    </div>

    <div class="stack-list">
      <?php if ($recentQueue === []): ?>
        <div class="empty-state">Nothing is queued yet. Queue a post from the Post History page to test the future integration structure.</div>
      <?php endif; ?>

      <?php foreach ($recentQueue as $queueItem): ?>
        <article class="list-card">
          <div>
            <strong><?= h((string) $queueItem['surah_name']) ?><?= trim((string) $queueItem['ayah_number']) !== '' ? ' - Ayah ' . h((string) $queueItem['ayah_number']) : '' ?></strong>
            <p><?= h((string) $queueItem['queue_status']) ?> - <?= h(format_app_datetime((string) $queueItem['created_at'])) ?></p>
          </div>
        </article>
      <?php endforeach; ?>
    </div>
  </article>
</section>
<?php
render_app_end('dashboard');
