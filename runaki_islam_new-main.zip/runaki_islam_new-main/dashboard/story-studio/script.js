(function () {
  const app = window.STORY_STUDIO || {};

  initSharedUi();

  if (app.page === "create-post") {
    initStoryEditor(app);
  }

  function initSharedUi() {
    const sidebar = document.getElementById("sidebar");
    const toggle = document.getElementById("sidebarToggle");

    if (sidebar && toggle) {
      toggle.addEventListener("click", function () {
        sidebar.classList.toggle("is-open");
      });

      document.addEventListener("click", function (event) {
        if (!sidebar.classList.contains("is-open")) {
          return;
        }

        const target = event.target;
        if (!(target instanceof Node)) {
          return;
        }

        if (!sidebar.contains(target) && target !== toggle) {
          sidebar.classList.remove("is-open");
        }
      });
    }

    document.querySelectorAll("[data-auto-dismiss]").forEach(function (item) {
      window.setTimeout(function () {
        item.style.opacity = "0";
        item.style.transform = "translateY(-6px)";
        window.setTimeout(function () {
          item.remove();
        }, 180);
      }, 4200);
    });
  }

  function initStoryEditor(appConfig) {
    const form = document.getElementById("storyForm");
    const canvas = document.getElementById("storyCanvas");

    if (!(form instanceof HTMLFormElement) || !(canvas instanceof HTMLCanvasElement)) {
      return;
    }

    const ctx = canvas.getContext("2d");
    if (!ctx) {
      return;
    }

    const elements = {
      form,
      canvas,
      surahName: document.getElementById("surah_name"),
      ayahNumber: document.getElementById("ayah_number"),
      ayahText: document.getElementById("ayah_text"),
      kurdishMeaning: document.getElementById("kurdish_meaning"),
      templateId: document.getElementById("template_id"),
      backgroundColor: document.getElementById("background_color"),
      backgroundImage: document.getElementById("background_image"),
      accentColor: document.getElementById("accent_color"),
      arabicTextColor: document.getElementById("arabic_text_color"),
      meaningTextColor: document.getElementById("meaning_text_color"),
      arabicFontSize: document.getElementById("arabic_font_size"),
      meaningFontSize: document.getElementById("meaning_font_size"),
      brandingMode: document.getElementById("branding_mode"),
      brandingFile: document.getElementById("branding_file"),
      previewButton: document.getElementById("previewButton"),
      generateButton: document.getElementById("generateButton"),
      saveButton: document.getElementById("saveButton"),
      downloadButton: document.getElementById("downloadButton"),
      status: document.getElementById("editorStatus"),
    };

    const templates = Array.isArray(appConfig.templates) ? appConfig.templates : [];
    const templateMap = new Map(
      templates.map(function (template) {
        return [String(template.id), template];
      })
    );
    const editorDefaults = appConfig.editorDefaults || {};
    const state = {
      backgroundUrl: editorDefaults.existingBackgroundUrl || "",
      brandingUrl: editorDefaults.existingBrandingUrl || "",
      defaultLogoUrl: editorDefaults.defaultLogoUrl || "",
      defaultWatermarkUrl: editorDefaults.defaultWatermarkUrl || "",
      backgroundObjectUrl: "",
      brandingObjectUrl: "",
      generatedObjectUrl: "",
      generatedBlob: null,
      isBusy: false,
      imageCache: new Map(),
      renderFrame: 0,
    };

    function currentTemplate() {
      return templateMap.get(String(elements.templateId.value)) || templates[0] || { config: {} };
    }

    function slugify(value) {
      return String(value || "")
        .toLowerCase()
        .replace(/[^a-z0-9]+/g, "-")
        .replace(/^-+|-+$/g, "")
        .slice(0, 60);
    }

    function buildFilename() {
      const surahSlug = slugify(elements.surahName.value) || "runaki-islam";
      const ayahSlug = slugify(elements.ayahNumber.value) || "ayah";
      return surahSlug + "-" + ayahSlug + "-story.png";
    }

    function setBusy(flag) {
      state.isBusy = Boolean(flag);
      [elements.previewButton, elements.generateButton, elements.saveButton].forEach(function (button) {
        if (button instanceof HTMLButtonElement) {
          button.disabled = state.isBusy;
        }
      });
    }

    function setStatus(message, tone) {
      elements.status.textContent = message;
      elements.status.classList.remove("is-success", "is-error");

      if (tone === "success") {
        elements.status.classList.add("is-success");
      }

      if (tone === "error") {
        elements.status.classList.add("is-error");
      }
    }

    function currentBackgroundSource() {
      if (elements.backgroundImage.files && elements.backgroundImage.files[0] && state.backgroundObjectUrl) {
        return state.backgroundObjectUrl;
      }

      return state.backgroundUrl;
    }

    function currentBrandingSource() {
      const brandingMode = elements.brandingMode.value || "none";
      if (brandingMode === "none") {
        return "";
      }

      if (elements.brandingFile.files && elements.brandingFile.files[0] && state.brandingObjectUrl) {
        return state.brandingObjectUrl;
      }

      if (state.brandingUrl) {
        return state.brandingUrl;
      }

      return brandingMode === "watermark" ? state.defaultWatermarkUrl : state.defaultLogoUrl;
    }

    function revokeObjectUrl(key) {
      if (state[key]) {
        URL.revokeObjectURL(state[key]);
        state[key] = "";
      }
    }

    function onBackgroundFileChange() {
      revokeObjectUrl("backgroundObjectUrl");
      const file = elements.backgroundImage.files && elements.backgroundImage.files[0];

      if (file) {
        state.backgroundObjectUrl = URL.createObjectURL(file);
      }

      scheduleRender();
    }

    function onBrandingFileChange() {
      revokeObjectUrl("brandingObjectUrl");
      const file = elements.brandingFile.files && elements.brandingFile.files[0];

      if (file) {
        state.brandingObjectUrl = URL.createObjectURL(file);
      }

      scheduleRender();
    }

    function hexToRgb(hex) {
      const clean = String(hex || "").replace("#", "");
      const normalized = clean.length === 6 ? clean : "000000";
      return {
        r: parseInt(normalized.slice(0, 2), 16),
        g: parseInt(normalized.slice(2, 4), 16),
        b: parseInt(normalized.slice(4, 6), 16),
      };
    }

    function rgba(hex, alpha) {
      const rgb = hexToRgb(hex);
      return "rgba(" + rgb.r + ", " + rgb.g + ", " + rgb.b + ", " + alpha + ")";
    }

    function adjustColor(hex, amount) {
      const rgb = hexToRgb(hex);
      const scale = function (value) {
        if (amount >= 0) {
          return Math.min(255, Math.round(value + (255 - value) * amount));
        }
        return Math.max(0, Math.round(value * (1 + amount)));
      };

      return (
        "#" +
        [scale(rgb.r), scale(rgb.g), scale(rgb.b)]
          .map(function (part) {
            return part.toString(16).padStart(2, "0");
          })
          .join("")
      );
    }

    function roundedRect(x, y, width, height, radius) {
      const safeRadius = Math.min(radius, width / 2, height / 2);
      ctx.beginPath();
      ctx.moveTo(x + safeRadius, y);
      ctx.arcTo(x + width, y, x + width, y + height, safeRadius);
      ctx.arcTo(x + width, y + height, x, y + height, safeRadius);
      ctx.arcTo(x, y + height, x, y, safeRadius);
      ctx.arcTo(x, y, x + width, y, safeRadius);
      ctx.closePath();
    }

    function fillRoundedRect(x, y, width, height, radius, fillStyle) {
      ctx.save();
      ctx.fillStyle = fillStyle;
      roundedRect(x, y, width, height, radius);
      ctx.fill();
      ctx.restore();
    }

    function strokeRoundedRect(x, y, width, height, radius, strokeStyle, lineWidth) {
      ctx.save();
      ctx.lineWidth = lineWidth;
      ctx.strokeStyle = strokeStyle;
      roundedRect(x, y, width, height, radius);
      ctx.stroke();
      ctx.restore();
    }

    function drawImageCover(image, x, y, width, height, alpha) {
      const scale = Math.max(width / image.width, height / image.height);
      const drawWidth = image.width * scale;
      const drawHeight = image.height * scale;
      const drawX = x + (width - drawWidth) / 2;
      const drawY = y + (height - drawHeight) / 2;

      ctx.save();
      ctx.globalAlpha = typeof alpha === "number" ? alpha : 1;
      ctx.drawImage(image, drawX, drawY, drawWidth, drawHeight);
      ctx.restore();
    }

    function drawLine(x1, y1, x2, y2, color, width) {
      ctx.save();
      ctx.strokeStyle = color;
      ctx.lineWidth = width;
      ctx.beginPath();
      ctx.moveTo(x1, y1);
      ctx.lineTo(x2, y2);
      ctx.stroke();
      ctx.restore();
    }

    function wrapTextLines(text, maxWidth) {
      const paragraphs = String(text || "").replace(/\r/g, "").split("\n");
      const lines = [];

      paragraphs.forEach(function (paragraph, paragraphIndex) {
        const normalized = paragraph.trim();

        if (!normalized) {
          lines.push("");
          return;
        }

        const words = normalized.split(/\s+/);
        let line = "";

        words.forEach(function (word) {
          const candidate = line ? line + " " + word : word;
          if (!line || ctx.measureText(candidate).width <= maxWidth) {
            line = candidate;
          } else {
            lines.push(line);
            line = word;
          }
        });

        if (line) {
          lines.push(line);
        }

        if (paragraphIndex < paragraphs.length - 1) {
          lines.push("");
        }
      });

      return lines.length > 0 ? lines : [""];
    }

    function trimLineToWidth(text, maxWidth) {
      let value = String(text || "");
      while (value && ctx.measureText(value + "...").width > maxWidth) {
        value = value.slice(0, -1);
      }
      return value !== text ? value + "..." : value;
    }

    function fitTextBlock(options) {
      const config = Object.assign(
        {
          minSize: 20,
          maxSize: 40,
          weight: "400",
          lineHeightRatio: 1.6,
          family: "RunakiSans",
          text: "",
        },
        options || {}
      );

      let size = config.maxSize;

      while (size >= config.minSize) {
        ctx.font = config.weight + " " + size + "px " + config.family;
        const lineHeight = Math.round(size * config.lineHeightRatio);
        const lines = wrapTextLines(config.text, config.width);

        if (lines.length * lineHeight <= config.height) {
          return { size: size, lineHeight: lineHeight, lines: lines };
        }

        size -= 2;
      }

      ctx.font = config.weight + " " + config.minSize + "px " + config.family;
      const fallbackLineHeight = Math.round(config.minSize * config.lineHeightRatio);
      let fallbackLines = wrapTextLines(config.text, config.width);
      const maxLines = Math.max(1, Math.floor(config.height / fallbackLineHeight));

      if (fallbackLines.length > maxLines) {
        fallbackLines = fallbackLines.slice(0, maxLines);
        fallbackLines[maxLines - 1] = trimLineToWidth(fallbackLines[maxLines - 1], config.width);
      }

      return { size: config.minSize, lineHeight: fallbackLineHeight, lines: fallbackLines };
    }

    function drawTextBlock(options) {
      const fitted = fitTextBlock(options);
      const drawX = options.align === "center" ? options.x + options.width / 2 : options.x + options.width;
      let drawY = options.y;

      ctx.save();
      ctx.direction = "rtl";
      ctx.textAlign = options.align || "right";
      ctx.textBaseline = "top";
      ctx.fillStyle = options.color;
      ctx.font = (options.weight || "400") + " " + fitted.size + "px " + options.family;

      fitted.lines.forEach(function (line) {
        ctx.fillText(line, drawX, drawY, options.width);
        drawY += fitted.lineHeight;
      });

      ctx.restore();
    }

    function drawMeta(draft, color, align) {
      ctx.save();
      ctx.direction = "ltr";
      ctx.textAlign = align || "center";
      ctx.textBaseline = "top";
      ctx.fillStyle = color;
      ctx.font = "600 34px RunakiSans";
      const x = align === "left" ? 92 : align === "right" ? 988 : 540;
      ctx.fillText(draft.surahName + " - Ayah " + draft.ayahNumber, x, 118, 860);
      ctx.restore();
    }

    function drawSignature(color) {
      ctx.save();
      ctx.direction = "ltr";
      ctx.textAlign = "center";
      ctx.textBaseline = "middle";
      ctx.fillStyle = color;
      ctx.font = "600 26px RunakiSans";
      ctx.fillText("Runaki Islam", 540, 1834, 380);
      ctx.restore();
    }

    function drawLogoBadge(image, accentColor) {
      if (!image) {
        return;
      }

      ctx.save();
      ctx.beginPath();
      ctx.arc(540, 172, 68, 0, Math.PI * 2);
      ctx.closePath();
      ctx.fillStyle = rgba(accentColor, 0.2);
      ctx.fill();
      ctx.lineWidth = 4;
      ctx.strokeStyle = rgba(accentColor, 0.8);
      ctx.stroke();
      ctx.clip();
      drawImageCover(image, 472, 104, 136, 136, 1);
      ctx.restore();
    }

    function drawWatermark(image, accentColor) {
      if (!image) {
        return;
      }

      ctx.save();
      ctx.globalAlpha = 0.12;
      drawImageCover(image, 340, 1370, 400, 400, 1);
      ctx.restore();

      ctx.save();
      ctx.lineWidth = 2;
      ctx.strokeStyle = rgba(accentColor, 0.18);
      ctx.beginPath();
      ctx.arc(540, 1570, 180, 0, Math.PI * 2);
      ctx.stroke();
      ctx.restore();
    }

    function drawBranding(draft, brandImage) {
      if (!brandImage || draft.brandingMode === "none") {
        return;
      }

      if (draft.brandingMode === "logo") {
        drawLogoBadge(brandImage, draft.accentColor);
      } else {
        drawWatermark(brandImage, draft.accentColor);
      }
    }

    function drawBaseBackground(draft, bgImage) {
      const variant = String(draft.template.config.variant || "noor-gold");
      const topColor =
        variant === "safa-light"
          ? adjustColor(draft.backgroundColor, 0.1)
          : variant === "crescent-night"
            ? adjustColor(draft.backgroundColor, -0.08)
            : adjustColor(draft.backgroundColor, 0.04);
      const bottomColor =
        variant === "safa-light"
          ? adjustColor(draft.backgroundColor, -0.12)
          : adjustColor(draft.backgroundColor, -0.2);

      const gradient = ctx.createLinearGradient(0, 0, 1080, 1920);
      gradient.addColorStop(0, topColor);
      gradient.addColorStop(1, bottomColor);
      ctx.fillStyle = gradient;
      ctx.fillRect(0, 0, 1080, 1920);

      if (bgImage) {
        drawImageCover(bgImage, 0, 0, 1080, 1920, variant === "safa-light" ? 0.18 : 0.36);
      }

      ctx.fillStyle = variant === "safa-light" ? rgba("#fff7ea", 0.2) : rgba("#05110d", 0.26);
      ctx.fillRect(0, 0, 1080, 1920);

      ctx.fillStyle = rgba(draft.accentColor, 0.08);
      for (let index = 0; index < 26; index += 1) {
        const size = 4 + (index % 3) * 2;
        ctx.beginPath();
        ctx.arc(120 + ((index * 173) % 840), 140 + ((index * 191) % 1640), size, 0, Math.PI * 2);
        ctx.fill();
      }
    }

    function drawNoorGold(draft, bgImage, brandImage) {
      drawBaseBackground(draft, bgImage);
      strokeRoundedRect(58, 58, 964, 1804, 42, rgba(draft.accentColor, 0.56), 3);
      strokeRoundedRect(84, 84, 912, 1752, 36, rgba(draft.accentColor, 0.18), 1);
      drawMeta(draft, rgba(draft.arabicTextColor, 0.9), "center");

      fillRoundedRect(96, 320, 888, 720, 54, rgba("#04110d", 0.44));
      strokeRoundedRect(96, 320, 888, 720, 54, rgba(draft.accentColor, 0.45), 2);
      drawTextBlock({
        text: draft.ayahText,
        x: 170,
        y: 430,
        width: 740,
        height: 420,
        color: draft.arabicTextColor,
        family: "RunakiArabic",
        weight: "400",
        maxSize: draft.arabicFontSize,
        minSize: 40,
        lineHeightRatio: 1.95,
        align: "center",
      });

      fillRoundedRect(132, 1115, 816, 450, 40, rgba("#fff7e8", 0.08));
      drawLine(182, 1190, 898, 1190, rgba(draft.accentColor, 0.72), 2);
      drawTextBlock({
        text: draft.meaningText,
        x: 190,
        y: 1250,
        width: 700,
        height: 255,
        color: draft.meaningTextColor,
        family: "RunakiKurdish, RunakiSans",
        weight: "600",
        maxSize: draft.meaningFontSize,
        minSize: 24,
        lineHeightRatio: 1.7,
        align: "right",
      });

      drawBranding(draft, brandImage);
      drawSignature(rgba(draft.meaningTextColor, 0.9));
    }

    function drawSafaLight(draft, bgImage, brandImage) {
      drawBaseBackground(draft, bgImage);
      fillRoundedRect(70, 70, 940, 1780, 48, rgba("#fff8eb", 0.08));
      drawMeta(draft, rgba("#143328", 0.9), "center");

      fillRoundedRect(78, 260, 924, 660, 58, rgba("#fff8eb", 0.78));
      strokeRoundedRect(78, 260, 924, 660, 58, rgba(draft.accentColor, 0.24), 2);
      drawTextBlock({
        text: draft.ayahText,
        x: 160,
        y: 390,
        width: 760,
        height: 380,
        color: adjustColor(draft.arabicTextColor, -0.82),
        family: "RunakiArabic",
        weight: "400",
        maxSize: draft.arabicFontSize,
        minSize: 40,
        lineHeightRatio: 1.9,
        align: "center",
      });

      fillRoundedRect(120, 1040, 840, 560, 42, rgba("#0f5a46", 0.16));
      fillRoundedRect(120, 1040, 12, 560, 6, draft.accentColor);
      drawTextBlock({
        text: draft.meaningText,
        x: 210,
        y: 1168,
        width: 660,
        height: 300,
        color: adjustColor(draft.meaningTextColor, -0.78),
        family: "RunakiKurdish, RunakiSans",
        weight: "600",
        maxSize: draft.meaningFontSize,
        minSize: 24,
        lineHeightRatio: 1.68,
        align: "right",
      });

      drawBranding(draft, brandImage);
      drawSignature(rgba("#183227", 0.76));
    }

    function drawCrescentNight(draft, bgImage, brandImage) {
      drawBaseBackground(draft, bgImage);
      ctx.save();
      ctx.lineWidth = 16;
      ctx.strokeStyle = rgba(draft.accentColor, 0.24);
      ctx.beginPath();
      ctx.arc(860, 220, 120, 0.3, Math.PI * 1.7);
      ctx.stroke();
      ctx.restore();

      drawMeta(draft, rgba("#dfeee7", 0.9), "left");
      fillRoundedRect(122, 248, 836, 1288, 64, rgba("#f8fbff", 0.08));
      strokeRoundedRect(122, 248, 836, 1288, 64, rgba(draft.accentColor, 0.26), 2);
      drawLine(180, 970, 900, 970, rgba(draft.accentColor, 0.44), 2);

      drawTextBlock({
        text: draft.ayahText,
        x: 180,
        y: 390,
        width: 720,
        height: 430,
        color: draft.arabicTextColor,
        family: "RunakiArabic",
        weight: "400",
        maxSize: draft.arabicFontSize,
        minSize: 40,
        lineHeightRatio: 1.92,
        align: "center",
      });

      drawTextBlock({
        text: draft.meaningText,
        x: 190,
        y: 1080,
        width: 700,
        height: 300,
        color: draft.meaningTextColor,
        family: "RunakiKurdish, RunakiSans",
        weight: "600",
        maxSize: draft.meaningFontSize,
        minSize: 24,
        lineHeightRatio: 1.72,
        align: "right",
      });

      drawBranding(draft, brandImage);
      drawSignature(rgba(draft.meaningTextColor, 0.86));
    }

    function readDraft() {
      return {
        surahName: elements.surahName.value.trim() || "Surah Name",
        ayahNumber: elements.ayahNumber.value.trim() || "1",
        ayahText: elements.ayahText.value.trim() || "Add the Arabic ayah here",
        meaningText: elements.kurdishMeaning.value.trim() || "Add the Kurdish meaning here",
        template: currentTemplate(),
        backgroundColor: elements.backgroundColor.value || "#0B241D",
        accentColor: elements.accentColor.value || "#D7B56D",
        arabicTextColor: elements.arabicTextColor.value || "#FFF9ED",
        meaningTextColor: elements.meaningTextColor.value || "#F4E7C8",
        arabicFontSize: Number(elements.arabicFontSize.value || 64),
        meaningFontSize: Number(elements.meaningFontSize.value || 35),
        brandingMode: elements.brandingMode.value || "none",
      };
    }

    function loadImage(source) {
      if (!source) {
        return Promise.resolve(null);
      }

      if (state.imageCache.has(source)) {
        return state.imageCache.get(source);
      }

      const promise = new Promise(function (resolve, reject) {
        const image = new Image();
        image.onload = function () {
          resolve(image);
        };
        image.onerror = function () {
          reject(new Error("Could not load one of the selected images."));
        };
        image.src = source;
      });

      state.imageCache.set(source, promise);
      return promise;
    }

    function renderStory() {
      const draft = readDraft();

      return Promise.all([
        loadImage(currentBackgroundSource()).catch(function () {
          return null;
        }),
        loadImage(currentBrandingSource()).catch(function () {
          return null;
        }),
      ]).then(function (assets) {
        const backgroundImage = assets[0];
        const brandingImage = assets[1];

        ctx.clearRect(0, 0, canvas.width, canvas.height);

        const variant = String(draft.template.config && draft.template.config.variant ? draft.template.config.variant : "noor-gold");

        if (variant === "safa-light") {
          drawSafaLight(draft, backgroundImage, brandingImage);
        } else if (variant === "crescent-night") {
          drawCrescentNight(draft, backgroundImage, brandingImage);
        } else {
          drawNoorGold(draft, backgroundImage, brandingImage);
        }
      });
    }

    function scheduleRender() {
      invalidateGeneratedImage();
      window.cancelAnimationFrame(state.renderFrame);
      state.renderFrame = window.requestAnimationFrame(function () {
        renderStory().catch(function (error) {
          setStatus(error.message || "The preview could not be rendered.", "error");
        });
      });
    }

    function applyTemplateDefaults() {
      const template = currentTemplate();
      const config = template && template.config ? template.config : {};

      if (config.background_color) {
        elements.backgroundColor.value = config.background_color;
      }

      if (config.accent_color) {
        elements.accentColor.value = config.accent_color;
      }

      if (config.arabic_text_color) {
        elements.arabicTextColor.value = config.arabic_text_color;
      }

      if (config.meaning_text_color) {
        elements.meaningTextColor.value = config.meaning_text_color;
      }

      if (config.arabic_font_size) {
        elements.arabicFontSize.value = String(config.arabic_font_size);
      }

      if (config.meaning_font_size) {
        elements.meaningFontSize.value = String(config.meaning_font_size);
      }

      scheduleRender();
    }

    function prepareDownload(url) {
      elements.downloadButton.href = url;
      elements.downloadButton.download = buildFilename();
      elements.downloadButton.classList.remove("is-disabled");
    }

    function invalidateGeneratedImage() {
      state.generatedBlob = null;
      revokeObjectUrl("generatedObjectUrl");
      elements.downloadButton.href = "#";
      elements.downloadButton.classList.add("is-disabled");
    }

    function generateImage() {
      return renderStory().then(function () {
        return new Promise(function (resolve, reject) {
          canvas.toBlob(function (blob) {
            if (!blob) {
              reject(new Error("The canvas image could not be generated."));
              return;
            }

            state.generatedBlob = blob;
            revokeObjectUrl("generatedObjectUrl");
            state.generatedObjectUrl = URL.createObjectURL(blob);
            prepareDownload(state.generatedObjectUrl);
            setStatus("Image generated. You can now download it or save it to the dashboard.", "success");
            resolve(blob);
          }, "image/png", 1);
        });
      });
    }

    function savePost(event) {
      event.preventDefault();

      if (state.isBusy) {
        return;
      }

      setBusy(true);

      const imagePromise = state.generatedBlob ? Promise.resolve(state.generatedBlob) : generateImage();

      imagePromise
        .then(function (blob) {
          const formData = new FormData(form);
          formData.set("generated_image", blob, buildFilename());

          return fetch((appConfig.api && appConfig.api.savePost) || "api/posts.php", {
            method: "POST",
            credentials: "same-origin",
            headers: {
              "X-CSRF-Token": appConfig.csrfToken || "",
            },
            body: formData,
          });
        })
        .then(function (response) {
          return response.text().then(function (text) {
            let payload = {};

            try {
              payload = JSON.parse(text);
            } catch (error) {
              throw new Error(text || "The server returned an invalid response.");
            }

            if (!response.ok || payload.status === false) {
              throw new Error(payload.message || "The story could not be saved.");
            }

            return payload;
          });
        })
        .then(function (payload) {
          if (payload.download_url) {
            prepareDownload(payload.download_url);
          }

          setStatus(
            (payload.message || "Post saved successfully.") + " Open Post History to manage the saved record.",
            "success"
          );
        })
        .catch(function (error) {
          setStatus(error.message || "The story could not be saved.", "error");
        })
        .finally(function () {
          setBusy(false);
        });
    }

    [
      elements.surahName,
      elements.ayahNumber,
      elements.ayahText,
      elements.kurdishMeaning,
      elements.backgroundColor,
      elements.accentColor,
      elements.arabicTextColor,
      elements.meaningTextColor,
      elements.arabicFontSize,
      elements.meaningFontSize,
      elements.brandingMode,
    ].forEach(function (element) {
      if (element) {
        element.addEventListener("input", scheduleRender);
      }
    });

    elements.templateId.addEventListener("change", applyTemplateDefaults);
    elements.brandingMode.addEventListener("change", scheduleRender);
    elements.backgroundImage.addEventListener("change", onBackgroundFileChange);
    elements.brandingFile.addEventListener("change", onBrandingFileChange);
    elements.previewButton.addEventListener("click", function () {
      renderStory()
        .then(function () {
          setStatus("Preview updated.", "success");
        })
        .catch(function (error) {
          setStatus(error.message || "The preview could not be updated.", "error");
        });
    });
    elements.generateButton.addEventListener("click", function () {
      setBusy(true);
      generateImage()
        .catch(function (error) {
          setStatus(error.message || "The image could not be generated.", "error");
        })
        .finally(function () {
          setBusy(false);
        });
    });
    form.addEventListener("submit", savePost);

    const fontsReady = document.fonts && document.fonts.ready ? document.fonts.ready : Promise.resolve();
    fontsReady.finally(function () {
      scheduleRender();
    });

    window.addEventListener("beforeunload", function () {
      revokeObjectUrl("backgroundObjectUrl");
      revokeObjectUrl("brandingObjectUrl");
      revokeObjectUrl("generatedObjectUrl");
    });
  }
})();
