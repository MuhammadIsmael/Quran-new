<?php

declare(strict_types=1);

date_default_timezone_set('Asia/Baghdad');

const STORY_STUDIO_APP_NAME = 'Runaki Islam Story Studio';
const STORY_STUDIO_DB_HOST = 'localhost';
const STORY_STUDIO_DB_PORT = 3306;
const STORY_STUDIO_DB_NAME = 'u588374711_runaki_story';
const STORY_STUDIO_DB_USER = 'u588374711_runaki_story';
const STORY_STUDIO_DB_PASS = '1FF~+nRS3#v';
const STORY_STUDIO_SESSION_TIMEOUT_SECONDS = 28800;

function env_setting(string $key, ?string $default = null): ?string
{
    $value = getenv($key);

    if ($value === false && array_key_exists($key, $_ENV)) {
        $value = $_ENV[$key];
    }

    if ($value === false && array_key_exists($key, $_SERVER)) {
        $value = $_SERVER[$key];
    }

    if (!is_string($value)) {
        return $default;
    }

    $trimmed = trim($value);
    if ($trimmed === '') {
        return $default;
    }

    return $trimmed;
}

function story_studio_starts_with(string $haystack, string $needle): bool
{
    if ($needle === '') {
        return true;
    }

    return substr($haystack, 0, strlen($needle)) === $needle;
}

function story_studio_ends_with(string $haystack, string $needle): bool
{
    if ($needle === '') {
        return true;
    }

    return substr($haystack, -strlen($needle)) === $needle;
}

function story_studio_db_host(): string
{
    return env_setting('STORY_STUDIO_DB_HOST', env_setting('DB_HOST', STORY_STUDIO_DB_HOST)) ?? STORY_STUDIO_DB_HOST;
}

function story_studio_db_port(): int
{
    $rawValue = env_setting('STORY_STUDIO_DB_PORT', env_setting('DB_PORT', (string) STORY_STUDIO_DB_PORT));
    $port = filter_var($rawValue, FILTER_VALIDATE_INT, [
        'options' => [
            'min_range' => 1,
            'max_range' => 65535,
        ],
    ]);

    return $port === false ? STORY_STUDIO_DB_PORT : (int) $port;
}

function story_studio_db_name(): string
{
    return env_setting('STORY_STUDIO_DB_NAME', env_setting('DB_NAME', STORY_STUDIO_DB_NAME)) ?? STORY_STUDIO_DB_NAME;
}

function story_studio_db_user(): string
{
    return env_setting('STORY_STUDIO_DB_USER', env_setting('DB_USER', STORY_STUDIO_DB_USER)) ?? STORY_STUDIO_DB_USER;
}

function story_studio_db_pass(): string
{
    return env_setting('STORY_STUDIO_DB_PASS', env_setting('DB_PASS', STORY_STUDIO_DB_PASS)) ?? STORY_STUDIO_DB_PASS;
}

function db(): PDO
{
    static $pdo = null;

    if ($pdo instanceof PDO) {
        return $pdo;
    }

    $dsn = sprintf(
        'mysql:host=%s;port=%d;dbname=%s;charset=utf8mb4',
        story_studio_db_host(),
        story_studio_db_port(),
        story_studio_db_name()
    );

    $pdo = new PDO($dsn, story_studio_db_user(), story_studio_db_pass(), [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false,
    ]);

    ensure_story_studio_schema($pdo);

    return $pdo;
}

function ensure_story_studio_schema(PDO $pdo): void
{
    $pdo->exec(
        "CREATE TABLE IF NOT EXISTS admin_users (
            id INT UNSIGNED NOT NULL AUTO_INCREMENT,
            full_name VARCHAR(120) NOT NULL,
            username VARCHAR(80) NOT NULL,
            password_hash VARCHAR(255) NOT NULL,
            role VARCHAR(40) NOT NULL DEFAULT 'admin',
            last_login_at DATETIME DEFAULT NULL,
            created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            UNIQUE KEY uq_admin_users_username (username)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci"
    );

    $pdo->exec(
        "CREATE TABLE IF NOT EXISTS story_templates (
            id INT UNSIGNED NOT NULL AUTO_INCREMENT,
            slug VARCHAR(80) NOT NULL,
            name VARCHAR(120) NOT NULL,
            description TEXT NOT NULL,
            preview_tagline VARCHAR(180) NOT NULL,
            config_json LONGTEXT NOT NULL,
            is_active TINYINT(1) NOT NULL DEFAULT 1,
            created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            UNIQUE KEY uq_story_templates_slug (slug)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci"
    );

    $pdo->exec(
        "CREATE TABLE IF NOT EXISTS app_settings (
            setting_key VARCHAR(120) NOT NULL,
            setting_value LONGTEXT NOT NULL,
            created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (setting_key)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci"
    );

    $pdo->exec(
        "CREATE TABLE IF NOT EXISTS story_posts (
            id INT UNSIGNED NOT NULL AUTO_INCREMENT,
            user_id INT UNSIGNED NOT NULL,
            template_id INT UNSIGNED NOT NULL,
            surah_name VARCHAR(160) NOT NULL,
            ayah_number VARCHAR(40) NOT NULL,
            ayah_text TEXT NOT NULL,
            kurdish_meaning TEXT NOT NULL,
            background_type VARCHAR(20) NOT NULL DEFAULT 'color',
            background_color CHAR(7) NOT NULL DEFAULT '#0B241D',
            background_image_path VARCHAR(255) DEFAULT NULL,
            branding_mode VARCHAR(20) NOT NULL DEFAULT 'none',
            branding_path VARCHAR(255) DEFAULT NULL,
            arabic_text_color CHAR(7) NOT NULL DEFAULT '#FFF9ED',
            meaning_text_color CHAR(7) NOT NULL DEFAULT '#F4E7C8',
            accent_color CHAR(7) NOT NULL DEFAULT '#D7B56D',
            arabic_font_size INT UNSIGNED NOT NULL DEFAULT 64,
            meaning_font_size INT UNSIGNED NOT NULL DEFAULT 35,
            generated_image_path VARCHAR(255) DEFAULT NULL,
            design_payload LONGTEXT NOT NULL,
            instagram_status VARCHAR(20) NOT NULL DEFAULT 'ready',
            created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY idx_story_posts_template (template_id),
            KEY idx_story_posts_user (user_id),
            KEY idx_story_posts_created_at (created_at),
            CONSTRAINT fk_story_posts_template FOREIGN KEY (template_id) REFERENCES story_templates (id) ON DELETE RESTRICT ON UPDATE CASCADE,
            CONSTRAINT fk_story_posts_user FOREIGN KEY (user_id) REFERENCES admin_users (id) ON DELETE RESTRICT ON UPDATE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci"
    );

    $pdo->exec(
        "CREATE TABLE IF NOT EXISTS instagram_publish_queue (
            id INT UNSIGNED NOT NULL AUTO_INCREMENT,
            post_id INT UNSIGNED NOT NULL,
            queue_status VARCHAR(20) NOT NULL DEFAULT 'queued',
            payload_json LONGTEXT NOT NULL,
            scheduled_at DATETIME DEFAULT NULL,
            published_at DATETIME DEFAULT NULL,
            error_message TEXT DEFAULT NULL,
            created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY idx_instagram_queue_status (queue_status),
            KEY idx_instagram_queue_post (post_id),
            CONSTRAINT fk_instagram_queue_post FOREIGN KEY (post_id) REFERENCES story_posts (id) ON DELETE CASCADE ON UPDATE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci"
    );

    seed_default_story_studio_admin($pdo);
}

function seed_default_story_studio_admin(PDO $pdo): void
{
    $userCount = (int) $pdo->query('SELECT COUNT(*) FROM admin_users')->fetchColumn();
    if ($userCount > 0) {
        return;
    }

    $statement = $pdo->prepare(
        'INSERT INTO admin_users (full_name, username, password_hash, role)
         VALUES (:full_name, :username, :password_hash, :role)'
    );
    $statement->execute([
        'full_name' => 'Runaki Islam Admin',
        'username' => 'admin',
        'password_hash' => 'pbkdf2_sha256$600000$5YDaOxMiZ4IsBkx4vnmWbw$pmU5UTMdNI9W9nHJQtXedjEWIU9AEtoMLwhbw-Pt5nQ',
        'role' => 'super_admin',
    ]);
}
