CREATE DATABASE IF NOT EXISTS u588374711_runaki_story CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE u588374711_runaki_story;

CREATE TABLE IF NOT EXISTS admin_users (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  full_name VARCHAR(120) NOT NULL,
  username VARCHAR(80) NOT NULL,
  password_hash VARCHAR(255) NOT NULL,
  role VARCHAR(40) NOT NULL DEFAULT 'admin',
  last_login_at DATETIME DEFAULT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uq_admin_users_username (username)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS story_templates (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  slug VARCHAR(80) NOT NULL,
  name VARCHAR(120) NOT NULL,
  description TEXT NOT NULL,
  preview_tagline VARCHAR(180) NOT NULL,
  config_json LONGTEXT NOT NULL,
  is_active TINYINT(1) NOT NULL DEFAULT 1,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uq_story_templates_slug (slug)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS story_posts (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  user_id INT UNSIGNED NOT NULL,
  template_id INT UNSIGNED NOT NULL,
  surah_name VARCHAR(160) NOT NULL,
  ayah_number VARCHAR(40) NOT NULL,
  ayah_text TEXT NOT NULL,
  kurdish_meaning TEXT NOT NULL,
  background_type VARCHAR(20) NOT NULL DEFAULT 'color',
  background_color CHAR(7) NOT NULL DEFAULT '#0B241D',
  background_image_path VARCHAR(255) DEFAULT NULL,
  branding_mode VARCHAR(20) NOT NULL DEFAULT 'none',
  branding_path VARCHAR(255) DEFAULT NULL,
  arabic_text_color CHAR(7) NOT NULL DEFAULT '#FFF9ED',
  meaning_text_color CHAR(7) NOT NULL DEFAULT '#F4E7C8',
  accent_color CHAR(7) NOT NULL DEFAULT '#D7B56D',
  arabic_font_size INT UNSIGNED NOT NULL DEFAULT 64,
  meaning_font_size INT UNSIGNED NOT NULL DEFAULT 35,
  generated_image_path VARCHAR(255) DEFAULT NULL,
  design_payload LONGTEXT NOT NULL,
  instagram_status VARCHAR(20) NOT NULL DEFAULT 'ready',
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_story_posts_template (template_id),
  KEY idx_story_posts_user (user_id),
  KEY idx_story_posts_created_at (created_at),
  CONSTRAINT fk_story_posts_template FOREIGN KEY (template_id) REFERENCES story_templates (id) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT fk_story_posts_user FOREIGN KEY (user_id) REFERENCES admin_users (id) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS app_settings (
  setting_key VARCHAR(120) NOT NULL,
  setting_value LONGTEXT NOT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (setting_key)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS instagram_publish_queue (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  post_id INT UNSIGNED NOT NULL,
  queue_status VARCHAR(20) NOT NULL DEFAULT 'queued',
  payload_json LONGTEXT NOT NULL,
  scheduled_at DATETIME DEFAULT NULL,
  published_at DATETIME DEFAULT NULL,
  error_message TEXT DEFAULT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_instagram_queue_status (queue_status),
  KEY idx_instagram_queue_post (post_id),
  CONSTRAINT fk_instagram_queue_post FOREIGN KEY (post_id) REFERENCES story_posts (id) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO admin_users (id, full_name, username, password_hash, role)
VALUES
  (1, 'Runaki Islam Admin', 'admin', 'pbkdf2_sha256$600000$5YDaOxMiZ4IsBkx4vnmWbw$pmU5UTMdNI9W9nHJQtXedjEWIU9AEtoMLwhbw-Pt5nQ', 'super_admin')
ON DUPLICATE KEY UPDATE
  full_name = VALUES(full_name),
  password_hash = VALUES(password_hash),
  role = VALUES(role);

INSERT INTO story_templates (id, slug, name, description, preview_tagline, config_json, is_active)
VALUES
  (
    1,
    'noor-gold',
    'Noor Gold',
    'Deep emerald story with a gold frame, balanced spacing, and a centered Quran card.',
    'Classic emerald and gold storytelling.',
    '{"variant":"noor-gold","background_color":"#0B241D","accent_color":"#D7B56D","arabic_text_color":"#FFF9ED","meaning_text_color":"#F4E7C8","arabic_font_size":64,"meaning_font_size":35,"features":["Gold ornamental frame","Centered ayah focus","Soft bottom translation panel"]}',
    1
  ),
  (
    2,
    'safa-light',
    'Safa Light',
    'Warm parchment palette with airy cards that keep Kurdish meaning highly readable.',
    'Light, elegant, and editorial.',
    '{"variant":"safa-light","background_color":"#E7D9BE","accent_color":"#0F5A46","arabic_text_color":"#17352A","meaning_text_color":"#24473B","arabic_font_size":60,"meaning_font_size":33,"features":["Parchment-inspired background","Two-card stacked layout","Readable high-contrast translation area"]}',
    1
  ),
  (
    3,
    'crescent-night',
    'Crescent Night',
    'Night-sky gradient with a glass card, crescent accents, and modern contrast.',
    'A modern story with celestial motion.',
    '{"variant":"crescent-night","background_color":"#08141E","accent_color":"#7ED9B1","arabic_text_color":"#FAF7F0","meaning_text_color":"#DDEDE7","arabic_font_size":62,"meaning_font_size":34,"features":["Glassmorphism text panel","Crescent accent drawing","High-contrast dark story mode"]}',
    1
  )
ON DUPLICATE KEY UPDATE
  name = VALUES(name),
  description = VALUES(description),
  preview_tagline = VALUES(preview_tagline),
  config_json = VALUES(config_json),
  is_active = VALUES(is_active);

INSERT INTO app_settings (setting_key, setting_value)
VALUES
  ('brand_name', 'Runaki Islam'),
  ('brand_tagline', 'Instagram Story Studio'),
  ('default_background_color', '#0B241D'),
  ('default_accent_color', '#D7B56D'),
  ('default_arabic_text_color', '#FFF9ED'),
  ('default_meaning_text_color', '#F4E7C8'),
  ('default_arabic_font_size', '64'),
  ('default_meaning_font_size', '35'),
  ('default_logo_path', ''),
  ('default_watermark_path', ''),
  ('instagram_auto_queue', '0'),
  ('instagram_business_id', ''),
  ('instagram_access_token', ''),
  ('instagram_graph_version', 'v22.0'),
  ('instagram_notes', 'Queue records are saved now so Graph API publishing can be added later without changing the dashboard structure.')
ON DUPLICATE KEY UPDATE
  setting_value = VALUES(setting_value);

INSERT INTO story_posts (
  id,
  user_id,
  template_id,
  surah_name,
  ayah_number,
  ayah_text,
  kurdish_meaning,
  background_type,
  background_color,
  background_image_path,
  branding_mode,
  branding_path,
  arabic_text_color,
  meaning_text_color,
  accent_color,
  arabic_font_size,
  meaning_font_size,
  generated_image_path,
  design_payload,
  instagram_status
)
VALUES
  (
    1,
    1,
    1,
    'Ash-Sharh',
    '6',
    'إِنَّ مَعَ الْعُسْرِ يُسْرًا',
    'لەگەڵ تەنگانەدا، ئاسانی هەیە.',
    'color',
    '#0B241D',
    NULL,
    'logo',
    NULL,
    '#FFF9ED',
    '#F4E7C8',
    '#D7B56D',
    64,
    35,
    NULL,
    '{"template":{"slug":"noor-gold"},"content":{"surah_name":"Ash-Sharh","ayah_number":"6"},"design":{"background_color":"#0B241D","accent_color":"#D7B56D"}}',
    'queued'
  ),
  (
    2,
    1,
    2,
    'Ar-Rahman',
    '13',
    'فَبِأَيِّ آلَاءِ رَبِّكُمَا تُكَذِّبَانِ',
    'کامی نعمتەکانی پەروەردگارتان دەردەخەننەوە؟',
    'color',
    '#E7D9BE',
    NULL,
    'watermark',
    NULL,
    '#17352A',
    '#24473B',
    '#0F5A46',
    60,
    33,
    NULL,
    '{"template":{"slug":"safa-light"},"content":{"surah_name":"Ar-Rahman","ayah_number":"13"},"design":{"background_color":"#E7D9BE","accent_color":"#0F5A46"}}',
    'ready'
  )
ON DUPLICATE KEY UPDATE
  surah_name = VALUES(surah_name),
  ayah_number = VALUES(ayah_number),
  ayah_text = VALUES(ayah_text),
  kurdish_meaning = VALUES(kurdish_meaning),
  background_color = VALUES(background_color),
  accent_color = VALUES(accent_color),
  instagram_status = VALUES(instagram_status);

INSERT INTO instagram_publish_queue (id, post_id, queue_status, payload_json, scheduled_at)
VALUES
  (
    1,
    1,
    'queued',
    '{"post_id":1,"caption":"Ash-Sharh - Ayah 6\n\nلەگەڵ تەنگانەدا، ئاسانی هەیە.","image_path":"","template_name":"Noor Gold"}',
    NOW()
  )
ON DUPLICATE KEY UPDATE
  queue_status = VALUES(queue_status),
  payload_json = VALUES(payload_json),
  scheduled_at = VALUES(scheduled_at);
