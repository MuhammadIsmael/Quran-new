# Runaki Islam Story Studio

Responsive PHP admin app for creating Instagram Story graphics from Quran ayah text and Kurdish meaning.

## Included pages
- `index.php`: entry redirect
- `login.php`: admin login
- `dashboard.php`: overview and stats
- `create-post.php`: story composer with live canvas preview
- `templates.php`: built-in design gallery
- `history.php`: saved post management
- `settings.php`: brand defaults and Instagram-ready settings
- `api/posts.php`: save endpoint for generated stories

## Core features
- Admin session login
- MySQL schema for users, templates, posts, settings, and Instagram queue
- 3 reusable story templates
- Responsive sidebar dashboard
- Live 1080x1920 canvas preview
- PNG export and download
- Background color or image support
- Optional logo or watermark support
- Saved post history with duplicate, download, delete, and queue actions
- Future Instagram integration structure through `instagram_publish_queue`

## Setup
1. Update DB credentials in [`config.php`](/c:/Users/Amin's%20PC/StudioProjects/runaki_islam%20-%20Copy/dashboard/story-studio/config.php) or provide matching environment variables:
   - `STORY_STUDIO_DB_HOST`
   - `STORY_STUDIO_DB_PORT`
   - `STORY_STUDIO_DB_NAME`
   - `STORY_STUDIO_DB_USER`
   - `STORY_STUDIO_DB_PASS`
2. Point your web server document root at this repo and open `/dashboard/story-studio/`.
   Story Studio now creates its required tables automatically on first run when the configured MySQL user has permission.
   Import [`db.sql`](/c:/Users/Amin's%20PC/StudioProjects/runaki_islam%20-%20Copy/dashboard/story-studio/db.sql) only if you want the bundled sample data.
3. Ensure PHP can write to:
   - `dashboard/story-studio/uploads/backgrounds`
   - `dashboard/story-studio/uploads/generated`
   - `dashboard/story-studio/uploads/branding`

## Default admin login
- Username: `admin`
- Password: `Runaki123!`

## Notes
- The seeded password uses PBKDF2 so the app works even when PHP CLI is not available during setup.
- Built-in templates and default settings are auto-seeded on first run if their rows are missing.
- New posts are rendered client-side on canvas and then uploaded to PHP as images for storage.
- Instagram publishing is not implemented yet, but queue records and settings are already stored so you can add a Graph API worker later.
