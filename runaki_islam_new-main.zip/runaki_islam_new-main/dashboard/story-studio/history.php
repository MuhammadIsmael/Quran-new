<?php

declare(strict_types=1);

require_once __DIR__ . '/includes/bootstrap.php';

$pdo = db();
require_login($pdo);

if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST') {
    verify_csrf_or_fail();

    $action = (string) ($_POST['action'] ?? '');
    $postId = normalize_int_value($_POST['post_id'] ?? 0, 0, 0, 1000000);

    try {
        if ($action === 'delete' && $postId > 0) {
            delete_story_post($pdo, $postId);
            set_flash_message('success', 'The post was deleted successfully.');
        } elseif ($action === 'queue' && $postId > 0) {
            queue_story_for_instagram($pdo, $postId);
            set_flash_message('success', 'The post was added to the Instagram queue.');
        }
    } catch (Throwable $exception) {
        set_flash_message('error', $exception->getMessage());
    }

    redirect_to('history.php');
}

$search = normalize_text((string) ($_GET['q'] ?? ''), 120);
$page = normalize_int_value($_GET['page'] ?? 1, 1, 1, 1000000);
$history = fetch_history_posts($pdo, $search, $page, 12);

render_app_start(
    'Post History',
    'history',
    'Review saved story designs, download them again, duplicate content, or send them to the publishing queue.'
);
?>
<section class="panel">
  <form class="history-toolbar" method="get">
    <input type="search" name="q" placeholder="Search by surah, ayah text, meaning, or template" value="<?= h($history['search']) ?>">
    <button class="button button-ghost" type="submit">Search</button>
    <a class="button button-ghost" href="<?= h(app_url('history.php')) ?>">Reset</a>
  </form>
</section>

<section class="history-grid">
  <?php if ($history['items'] === []): ?>
    <article class="panel empty-state">No saved posts matched the current filter.</article>
  <?php endif; ?>

  <?php foreach ($history['items'] as $post): ?>
    <?php $imagePath = trim((string) ($post['generated_image_path'] ?? '')); ?>
    <article class="panel history-card">
      <div class="history-card__preview" style="background: <?= h(normalize_hex_color((string) ($post['background_color'] ?? '#0B241D'), '#0B241D')) ?>;">
        <?php if ($imagePath !== ''): ?>
          <img src="<?= h(storage_relative_url($imagePath)) ?>" alt="<?= h((string) $post['surah_name']) ?>">
        <?php else: ?>
          <div class="history-card__fallback">
            <strong><?= h((string) $post['surah_name']) ?></strong>
            <span>Ayah <?= h((string) $post['ayah_number']) ?></span>
          </div>
        <?php endif; ?>
      </div>

      <div class="history-card__body">
        <p class="eyebrow"><?= h((string) $post['template_name']) ?></p>
        <h2><?= h((string) $post['surah_name']) ?> <span>#<?= h((string) $post['ayah_number']) ?></span></h2>
        <p><?= h(format_app_datetime((string) $post['created_at'])) ?> - <?= h((string) $post['instagram_status']) ?></p>

        <div class="button-row button-row--tight">
          <?php if ($imagePath !== ''): ?>
            <a class="button button-ghost" href="<?= h(storage_relative_url($imagePath)) ?>" download>Download</a>
          <?php endif; ?>
          <a class="button button-ghost" href="<?= h(app_url('create-post.php?duplicate=' . (int) $post['id'])) ?>">Duplicate</a>

          <form method="post">
            <?= csrf_input() ?>
            <input type="hidden" name="post_id" value="<?= h((string) $post['id']) ?>">
            <input type="hidden" name="action" value="queue">
            <button class="button button-ghost" type="submit">Queue</button>
          </form>

          <form method="post" onsubmit="return confirm('Delete this saved post?');">
            <?= csrf_input() ?>
            <input type="hidden" name="post_id" value="<?= h((string) $post['id']) ?>">
            <input type="hidden" name="action" value="delete">
            <button class="button button-danger" type="submit">Delete</button>
          </form>
        </div>
      </div>
    </article>
  <?php endforeach; ?>
</section>

<?php if ((int) $history['total_pages'] > 1): ?>
  <section class="pagination">
    <?php if ((int) $history['page'] > 1): ?>
      <a class="button button-ghost" href="<?= h(app_url('history.php?q=' . urlencode($history['search']) . '&page=' . ((int) $history['page'] - 1))) ?>">Previous</a>
    <?php endif; ?>

    <span>Page <?= h((string) $history['page']) ?> of <?= h((string) $history['total_pages']) ?></span>

    <?php if ((int) $history['page'] < (int) $history['total_pages']): ?>
      <a class="button button-ghost" href="<?= h(app_url('history.php?q=' . urlencode($history['search']) . '&page=' . ((int) $history['page'] + 1))) ?>">Next</a>
    <?php endif; ?>
  </section>
<?php endif; ?>
<?php
render_app_end('history');
