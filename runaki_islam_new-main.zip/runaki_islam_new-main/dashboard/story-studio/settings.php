<?php

declare(strict_types=1);

require_once __DIR__ . '/includes/bootstrap.php';

$pdo = db();
require_login($pdo);

$settings = app_settings($pdo);

if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST') {
    verify_csrf_or_fail();

    $formSection = (string) ($_POST['form_section'] ?? 'visual');
    $values = [];

    try {
        $cleanupCandidates = [];
        $newFiles = [];

        if ($formSection === 'instagram') {
            $values = [
                'instagram_auto_queue' => isset($_POST['instagram_auto_queue']) ? '1' : '0',
                'instagram_business_id' => normalize_text((string) ($_POST['instagram_business_id'] ?? ''), 120),
                'instagram_access_token' => trim((string) ($_POST['instagram_access_token'] ?? '')),
                'instagram_graph_version' => normalize_text((string) ($_POST['instagram_graph_version'] ?? 'v22.0'), 20),
                'instagram_notes' => normalize_multiline_text((string) ($_POST['instagram_notes'] ?? ''), 1000),
            ];
        } else {
            $values = [
                'brand_name' => normalize_text((string) ($_POST['brand_name'] ?? setting_value($settings, 'brand_name', 'Runaki Islam')), 120),
                'brand_tagline' => normalize_text((string) ($_POST['brand_tagline'] ?? setting_value($settings, 'brand_tagline', 'Instagram Story Studio')), 180),
                'default_background_color' => normalize_hex_color((string) ($_POST['default_background_color'] ?? '#0B241D'), '#0B241D'),
                'default_accent_color' => normalize_hex_color((string) ($_POST['default_accent_color'] ?? '#D7B56D'), '#D7B56D'),
                'default_arabic_text_color' => normalize_hex_color((string) ($_POST['default_arabic_text_color'] ?? '#FFF9ED'), '#FFF9ED'),
                'default_meaning_text_color' => normalize_hex_color((string) ($_POST['default_meaning_text_color'] ?? '#F4E7C8'), '#F4E7C8'),
                'default_arabic_font_size' => (string) normalize_int_value($_POST['default_arabic_font_size'] ?? 64, 64, 34, 96),
                'default_meaning_font_size' => (string) normalize_int_value($_POST['default_meaning_font_size'] ?? 35, 35, 22, 60),
            ];

            if ($values['brand_name'] === '') {
                $values['brand_name'] = setting_value($settings, 'brand_name', 'Runaki Islam');
            }

            if ($values['brand_tagline'] === '') {
                $values['brand_tagline'] = setting_value($settings, 'brand_tagline', 'Instagram Story Studio');
            }

            $oldLogoPath = setting_value($settings, 'default_logo_path');
            $oldWatermarkPath = setting_value($settings, 'default_watermark_path');

            if (!empty($_POST['remove_default_logo'])) {
                $values['default_logo_path'] = '';
                $cleanupCandidates[] = $oldLogoPath;
            } elseif (isset($_FILES['default_logo_file']) && (int) ($_FILES['default_logo_file']['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_NO_FILE) {
                $newLogoPath = store_uploaded_image($_FILES['default_logo_file'], 'uploads/branding', 6);
                $values['default_logo_path'] = $newLogoPath;
                $cleanupCandidates[] = $oldLogoPath;
                $newFiles[] = $newLogoPath;
            }

            if (!empty($_POST['remove_default_watermark'])) {
                $values['default_watermark_path'] = '';
                $cleanupCandidates[] = $oldWatermarkPath;
            } elseif (isset($_FILES['default_watermark_file']) && (int) ($_FILES['default_watermark_file']['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_NO_FILE) {
                $newWatermarkPath = store_uploaded_image($_FILES['default_watermark_file'], 'uploads/branding', 6);
                $values['default_watermark_path'] = $newWatermarkPath;
                $cleanupCandidates[] = $oldWatermarkPath;
                $newFiles[] = $newWatermarkPath;
            }
        }

        save_app_settings($pdo, $values);

        foreach ($cleanupCandidates as $path) {
            delete_asset_if_unused($pdo, $path);
        }

        set_flash_message('success', 'Settings saved successfully.');
        redirect_to('settings.php');
    } catch (Throwable $exception) {
        if (isset($newFiles) && is_array($newFiles)) {
            foreach ($newFiles as $path) {
                delete_local_storage_file($path);
            }
        }

        set_flash_message('error', $exception->getMessage());
        redirect_to('settings.php');
    }
}

$settings = app_settings($pdo);

render_app_start(
    'Settings',
    'settings',
    'Manage brand defaults, reusable visual settings, and the future Instagram integration fields.'
);
?>
<section class="content-grid">
  <article class="panel">
    <div class="panel-heading">
      <div>
        <p class="eyebrow">Brand Settings</p>
        <h2>Visual defaults</h2>
      </div>
    </div>

    <form class="form-grid" method="post" enctype="multipart/form-data">
      <?= csrf_input() ?>
      <input type="hidden" name="form_section" value="visual">

      <div class="field-row">
        <div>
          <label for="brand_name">Brand name</label>
          <input id="brand_name" name="brand_name" type="text" maxlength="120" value="<?= h(setting_value($settings, 'brand_name', 'Runaki Islam')) ?>" required>
        </div>
        <div>
          <label for="brand_tagline">Brand tagline</label>
          <input id="brand_tagline" name="brand_tagline" type="text" maxlength="180" value="<?= h(setting_value($settings, 'brand_tagline', 'Instagram Story Studio')) ?>">
        </div>
      </div>

      <div class="field-row field-row--three">
        <div>
          <label for="default_background_color">Default background</label>
          <input id="default_background_color" name="default_background_color" type="color" value="<?= h(setting_value($settings, 'default_background_color', '#0B241D')) ?>">
        </div>
        <div>
          <label for="default_accent_color">Default accent</label>
          <input id="default_accent_color" name="default_accent_color" type="color" value="<?= h(setting_value($settings, 'default_accent_color', '#D7B56D')) ?>">
        </div>
        <div>
          <label for="default_arabic_text_color">Default Arabic text</label>
          <input id="default_arabic_text_color" name="default_arabic_text_color" type="color" value="<?= h(setting_value($settings, 'default_arabic_text_color', '#FFF9ED')) ?>">
        </div>
      </div>

      <div class="field-row field-row--three">
        <div>
          <label for="default_meaning_text_color">Default Kurdish text</label>
          <input id="default_meaning_text_color" name="default_meaning_text_color" type="color" value="<?= h(setting_value($settings, 'default_meaning_text_color', '#F4E7C8')) ?>">
        </div>
        <div>
          <label for="default_arabic_font_size">Default Arabic size</label>
          <input id="default_arabic_font_size" name="default_arabic_font_size" type="number" min="34" max="96" value="<?= h(setting_value($settings, 'default_arabic_font_size', '64')) ?>">
        </div>
        <div>
          <label for="default_meaning_font_size">Default Kurdish size</label>
          <input id="default_meaning_font_size" name="default_meaning_font_size" type="number" min="22" max="60" value="<?= h(setting_value($settings, 'default_meaning_font_size', '35')) ?>">
        </div>
      </div>

      <div class="field-row">
        <div>
          <label for="default_logo_file">Default logo file</label>
          <input id="default_logo_file" name="default_logo_file" type="file" accept="image/png,image/jpeg,image/webp">
          <label class="checkbox-row"><input name="remove_default_logo" type="checkbox" value="1"> Remove current default logo</label>
          <?php if (setting_value($settings, 'default_logo_path') !== ''): ?>
            <div class="asset-preview"><img src="<?= h(storage_relative_url(setting_value($settings, 'default_logo_path'))) ?>" alt="Default logo"></div>
          <?php endif; ?>
        </div>
        <div>
          <label for="default_watermark_file">Default watermark file</label>
          <input id="default_watermark_file" name="default_watermark_file" type="file" accept="image/png,image/jpeg,image/webp">
          <label class="checkbox-row"><input name="remove_default_watermark" type="checkbox" value="1"> Remove current default watermark</label>
          <?php if (setting_value($settings, 'default_watermark_path') !== ''): ?>
            <div class="asset-preview"><img src="<?= h(storage_relative_url(setting_value($settings, 'default_watermark_path'))) ?>" alt="Default watermark"></div>
          <?php endif; ?>
        </div>
      </div>

      <button class="button" type="submit">Save visual settings</button>
    </form>
  </article>

  <article class="panel">
    <div class="panel-heading">
      <div>
        <p class="eyebrow">Instagram Integration</p>
        <h2>Future-ready structure</h2>
      </div>
    </div>

    <form class="form-grid" method="post" enctype="multipart/form-data">
      <?= csrf_input() ?>
      <input type="hidden" name="form_section" value="instagram">

      <label class="checkbox-row"><input name="instagram_auto_queue" type="checkbox" value="1"<?= setting_value($settings, 'instagram_auto_queue') === '1' ? ' checked' : '' ?>> Automatically queue new saved posts</label>

      <div class="field-row">
        <div>
          <label for="instagram_business_id">Instagram business account ID</label>
          <input id="instagram_business_id" name="instagram_business_id" type="text" value="<?= h(setting_value($settings, 'instagram_business_id')) ?>">
        </div>
        <div>
          <label for="instagram_graph_version">Graph API version</label>
          <input id="instagram_graph_version" name="instagram_graph_version" type="text" value="<?= h(setting_value($settings, 'instagram_graph_version', 'v22.0')) ?>">
        </div>
      </div>

      <label for="instagram_access_token">Access token</label>
      <textarea id="instagram_access_token" name="instagram_access_token" rows="4"><?= h(setting_value($settings, 'instagram_access_token')) ?></textarea>

      <label for="instagram_notes">Integration notes</label>
      <textarea id="instagram_notes" name="instagram_notes" rows="6"><?= h(setting_value($settings, 'instagram_notes')) ?></textarea>

      <button class="button" type="submit">Save integration settings</button>
    </form>
  </article>
</section>
<?php
render_app_end('settings');
