<?php

declare(strict_types=1);

require_once __DIR__ . '/config.php';
requireDashboardAuthPage('login.php');
?>
<!doctype html>
<html lang="ku" dir="rtl">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>داشبۆردی مودیولەکان</title>
  <link rel="stylesheet" href="./assets/styles.css">
</head>
<body>
  <main class="app-shell">
    <header class="top-bar">
      <div>
        <p class="eyebrow">ڕووناکی ئیسلام</p>
        <h1>داشبۆردی مودیولەکان</h1>
        <p class="sub-text">لەم لاپەڕەیەوە بچۆ بۆ هەر بەشیکی بەڕێوەبەری. کتێبەکان یەکێکن لە مودیولەکان، نەک لاپەڕەی سەرەکی.</p>
      </div>
      <div class="header-actions">
        <a class="btn btn-danger" href="./logout.php">چوونەدەرەوە</a>
      </div>
    </header>

    <section class="stats-grid stats-grid-modules" aria-label="خێرایی داشبۆرد">
      <article class="stat-card">
        <p>مودیولە بەردەستەکان</p>
        <h2>3</h2>
      </article>
      <article class="stat-card">
        <p>بەشی سەرەکی</p>
        <h2>مودیولەکان</h2>
      </article>
      <article class="stat-card">
        <p>ئامانج</p>
        <h2>رێکخستنی داشبۆرد</h2>
      </article>
    </section>

    <section class="modules-grid">
      <article class="panel module-card">
        <p class="eyebrow">Module 01</p>
        <h3>بەڕێوەبەری کتێبەکان</h3>
        <p class="sub-text">زیادکردن، دەستکاریکردن، PDF هەڵگرتن، و گەڕان بە ناو کتێبەکان.</p>
        <div class="module-actions">
          <a class="btn" href="./books.php">چوون بۆ کتێبەکان</a>
          <a class="btn btn-neutral" href="./categories.php">پۆلەکان</a>
        </div>
      </article>

      <article class="panel module-card">
        <p class="eyebrow">Module 02</p>
        <h3>Story Studio</h3>
        <p class="sub-text">دروستکردنی ستۆریی ئینستاگرام بۆ ئایەت، مانای کوردی، preview، download، و save.</p>
        <div class="module-actions">
          <a class="btn" href="./story-studio/">چوون بۆ Story Studio</a>
        </div>
      </article>

      <article class="panel module-card">
        <p class="eyebrow">Module 03</p>
        <h3>بەڕێوەبەری پۆلەکان</h3>
        <p class="sub-text">دروستکردنو رێکخستنی پۆلەکان بۆ تەواو مودیولەکانی dashboard.</p>
        <div class="module-actions">
          <a class="btn" href="./categories.php">چوون بۆ پۆلەکان</a>
        </div>
      </article>
    </section>
  </main>
</body>
</html>
