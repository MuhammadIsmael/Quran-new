<?php

declare(strict_types=1);

require_once __DIR__ . '/config.php';
requireDashboardAuthPage('login.php');
?>
<!doctype html>
<html lang="ku" dir="rtl">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Ø¨Û•Ú•ÛŽÙˆÛ•Ø¨Û•Ø±ÛŒ Ú©ØªÛŽØ¨Û•Ú©Ø§Ù†</title>
  <meta name="csrf-token" content="<?= htmlspecialchars(ensureDashboardCsrfToken(), ENT_QUOTES, 'UTF-8') ?>">
  <link rel="stylesheet" href="./assets/styles.css">
</head>
<body>
  <main class="app-shell">
    <header class="top-bar">
      <div>
        <p class="eyebrow">Ú•ÙˆÙˆÙ†Ø§Ú©ÛŒ Ø¦ÛŒØ³Ù„Ø§Ù…</p>
        <h1>Ø¯Ø§Ø´Ø¨Û†Ø±Ø¯ÛŒ Ú©ØªÛŽØ¨Û•Ú©Ø§Ù†</h1>
        <p class="sub-text">Ú©ØªÛŽØ¨Û•Ú©Ø§Ù† Ø¨Û•Ú•ÛŽÙˆÛ•Ø¨Ø¨Û•ØŒ Ù†ÙˆÛŽÛŒØ§Ù† Ø¨Ú©Û•ÙˆÛ•ØŒ PDF Ø²ÛŒØ§Ø¯ Ø¨Ú©Û• Ø¨Û• Ø¨Û•Ø³ØªÛ•Ø± ÛŒØ§Ù† ÙØ§ÛŒÙ„.</p>
      </div>
      <div class="header-actions">
        <a class="btn btn-ghost" href="./index.php">Ù…ÙˆØ¯ÛŒÙˆÙ„Û•Ú©Ø§Ù†</a>
        <button id="refreshBtn" class="btn btn-ghost" type="button">Ù†ÙˆÛŽÚ©Ø±Ø¯Ù†Û•ÙˆÛ•</button>
        <a class="btn btn-neutral" href="./categories.php">Ø¨Û•Ú•ÛŽÙˆÛ•Ø¨Û•Ø±ÛŒ Ù¾Û†Ù„Û•Ú©Ø§Ù†</a>
        <a class="btn btn-danger" href="./logout.php">Ú†ÙˆÙˆÙ†Û•Ø¯Û•Ø±Û•ÙˆÛ•</a>
      </div>
    </header>

    <section class="stats-grid" aria-label="Ø¦Ø§Ù…Ø§Ø±Û•Ú©Ø§Ù†">
      <article class="stat-card">
        <p>Ú©Û†ÛŒ Ú©ØªÛŽØ¨Û•Ú©Ø§Ù†</p>
        <h2 id="totalBooks">0</h2>
      </article>
      <article class="stat-card">
        <p>Ø¯ÙˆØ§ÛŒÛŒÙ† Ù¾Û†Ù„</p>
        <h2 id="latestCategory">-</h2>
      </article>
      <article class="stat-card">
        <p>Ø¨Û•Ø³ØªÛ•Ø±ÛŒ Ø´Ú©Ø§Ùˆ</p>
        <h2 id="brokenLinks">0</h2>
      </article>
    </section>

    <section class="panel-grid">
      <article class="panel form-panel">
        <div class="panel-title-row">
          <h3 id="formTitle">Ø²ÛŒØ§Ø¯Ú©Ø±Ø¯Ù†ÛŒ Ú©ØªÛŽØ¨ÛŒ Ù†ÙˆÛŽ</h3>
          <button id="cancelEditBtn" class="btn btn-ghost hidden" type="button">Ù‡Û•ÚµÙˆÛ•Ø´Ø§Ù†Ø¯Ù†Û•ÙˆÛ•ÛŒ Ø¯Û•Ø³ØªÚ©Ø§Ø±ÛŒÚ©Ø±Ø¯Ù†</button>
        </div>

        <form id="bookForm" novalidate>
          <input type="hidden" id="bookId">

          <label for="title">Ù†Ø§ÙˆÙ†ÛŒØ´Ø§Ù†</label>
          <input id="title" name="title" required maxlength="255" placeholder="Ù†Ø§ÙˆÙ†ÛŒØ´Ø§Ù†ÛŒ Ú©ØªÛŽØ¨">

          <label for="description">ÙˆÛ•Ø³Ù</label>
          <textarea id="description" name="description" required rows="4" placeholder="Ù¾ÙˆØ®ØªÛ•ÛŒ Ú©ØªÛŽØ¨"></textarea>

          <label for="category">Ù¾Û†Ù„ (Ø¦Ø§Ø±Û•Ø²ÙˆÙˆÙ…Û•Ù†Ø¯Ø§Ù†Û•)</label>
          <div class="inline-field">
            <select id="category" name="category">
              <option value="">Ø¨ÛŽ Ù¾Û†Ù„</option>
            </select>
            <button id="reloadCategoriesBtn" class="btn btn-neutral btn-small" type="button">Ù†ÙˆÛŽÚ©Ø±Ø¯Ù†Û•ÙˆÛ•ÛŒ Ù¾Û†Ù„Û•Ú©Ø§Ù†</button>
          </div>

          <label>Ø¬Û†Ø±ÛŒ PDF</label>
          <div class="source-switch">
            <label class="source-option">
              <input id="pdfSourceLink" type="radio" name="pdfSource" value="link" checked>
              Ø¨Û•Ø³ØªÛ•Ø±ÛŒ Ú•Ø§Ø³ØªÛ•ÙˆØ®Û†
            </label>
            <label class="source-option">
              <input id="pdfSourceUpload" type="radio" name="pdfSource" value="upload">
              Ù‡Û•ÚµÚ¯Ø±ØªÙ†ÛŒ ÙØ§ÛŒÙ„ PDF
            </label>
          </div>

          <div id="pdfUrlWrap">
            <label for="pdfUrl">Ø¨Û•Ø³ØªÛ•Ø±ÛŒ PDF</label>
            <input id="pdfUrl" name="pdfUrl" placeholder="https://example.com/book.pdf ÛŒØ§Ù† /uploads/books/book.pdf">
          </div>

          <div id="pdfFileWrap" class="hidden">
            <label for="pdfFile">ÙØ§ÛŒÙ„ÛŒ PDF</label>
            <div id="pdfDropzone" class="dropzone" tabindex="0" role="button" aria-label="Ù‡Û•ÚµØ¨Ú˜Ø§Ø±Ø¯Ù†ÛŒ ÙØ§ÛŒÙ„ PDF">
              <p id="pdfDropzoneHint">ÙØ§ÛŒÙ„ÛŒ PDF Ø¨Ú©ÛŽØ´Û• Ùˆ ÙÚ•ÛŽØ¨Ø¯Û• Ù„ÛŽØ±Û• ÛŒØ§Ù† Ú©Ø±ØªÛ• Ø¨Ú©Û• Ø¨Û† Ù‡Û•ÚµØ¨Ú˜Ø§Ø±Ø¯Ù†</p>
              <p id="pdfSelectedFile" class="sub-note">Ù‡ÛŒÚ† ÙØ§ÛŒÙ„ÛŽÚ© Ù‡Û•ÚµÙ†Û•Ø¨Ú˜ÛŽØ±Ø¯Ø±Ø§ÙˆÛ•.</p>
            </div>
            <input id="pdfFile" name="pdfFile" class="visually-hidden" type="file" accept="application/pdf,.pdf">
          </div>

          <label for="coverFile">ÙˆÛŽÙ†Û•ÛŒ Ø¨Û•Ø±Ú¯ÛŒ Ú©ØªÛŽØ¨ (Ø¦Ø§Ø±Û•Ø²ÙˆÙˆÙ…Û•Ù†Ø¯Ø§Ù†Û•)</label>
          <div class="cover-upload-row">
            <input id="coverFile" name="coverFile" type="file" accept="image/jpeg,image/png,image/webp,image/gif">
            <button id="clearCoverBtn" class="btn btn-ghost btn-small hidden" type="button">Ù„Ø§Ø¨Ø±Ø¯Ù†ÛŒ Ø¨Û•Ø±Ú¯</button>
          </div>
          <input type="hidden" id="removeCover" value="0">
          <div id="coverPreviewWrap" class="cover-preview hidden">
            <img id="coverPreviewImage" alt="ÙˆÛŽÙ†Û•ÛŒ Ø¨Û•Ø±Ú¯">
            <p id="coverPreviewText" class="sub-note"></p>
          </div>

          <p id="currentPdfNote" class="sub-note hidden"></p>
          <p id="currentCoverNote" class="sub-note hidden"></p>

          <div id="uploadStatusWrap" class="upload-status hidden" aria-live="polite">
            <p id="uploadStatusText" class="upload-status-text">Ú†Ø§ÙˆÛ•Ú•ÛŽ Ø¨Ú©Û•...</p>
            <div class="progress-track">
              <div id="uploadProgressBar" class="progress-bar"></div>
            </div>
          </div>

          <div class="form-actions">
            <button id="submitBtn" class="btn" type="submit">Ø²ÛŒØ§Ø¯Ú©Ø±Ø¯Ù†ÛŒ Ú©ØªÛŽØ¨</button>
          </div>
        </form>
      </article>

      <article class="panel list-panel">
        <div class="panel-title-row">
          <h3>Ù„ÛŒØ³ØªÛŒ Ú©ØªÛŽØ¨Û•Ú©Ø§Ù†</h3>
          <div class="list-controls">
            <input id="searchInput" type="search" placeholder="Ú¯Û•Ú•Ø§Ù† Ø¨Û• Ù†Ø§ÙˆÙ†ÛŒØ´Ø§Ù†ØŒ Ù¾Û†Ù„ØŒ ÙˆÛ•Ø³Ù">
            <select id="sortBySelect" aria-label="Ø¯Ø§Ú•Ø´ØªÙ† Ø¨Û•">
              <option value="created_at">Ù†ÙˆÛŽØªØ±ÛŒÙ†</option>
              <option value="title">Ù†Ø§ÙˆÙ†ÛŒØ´Ø§Ù†</option>
              <option value="category">Ù¾Û†Ù„</option>
              <option value="id">Ú˜Ù…Ø§Ø±Û•</option>
            </select>
            <select id="sortDirSelect" aria-label="Ø¦Ø§Ø±Ø§Ø³ØªÛ•ÛŒ Ø¯Ø§Ú•Ø´ØªÙ†">
              <option value="desc">Ø¯Ø§Ú•Ø´ØªÙ† (Ø¯ÙˆØ§ Ø¨Û† ÛŒÛ•Ú©Û•Ù…)</option>
              <option value="asc">Ø¯Ø§Ú•Ø´ØªÙ† (ÛŒÛ•Ú©Û•Ù… Ø¨Û† Ø¯ÙˆØ§)</option>
            </select>
            <select id="perPageSelect" aria-label="Ø¯Ø§Ù†Û• Ù„Û• Ù‡Û•Ø± Ù¾Û•Ú•Û•ÛŒÛ•Ú©">
              <option value="8">8 / Ù¾Û•Ú•Û•</option>
              <option value="12" selected>12 / Ù¾Û•Ú•Û•</option>
              <option value="20">20 / Ù¾Û•Ú•Û•</option>
              <option value="30">30 / Ù¾Û•Ú•Û•</option>
            </select>
          </div>
        </div>

        <div id="loadingState" class="state">Ú†Ø§ÙˆÛ•Ú•ÛŽ Ø¨Ú©Û•...</div>
        <div id="emptyState" class="state hidden">Ù‡ÛŒÚ† Ú©ØªÛŽØ¨ÛŽÚ© Ù†Û•Ø¯Û†Ø²Ø±Ø§ÛŒÛ•ÙˆÛ•.</div>
        <div id="errorState" class="state state-error hidden"></div>

        <div id="booksList" class="books-list"></div>
        <div id="paginationWrap" class="pagination-wrap">
          <button id="prevPageBtn" class="btn btn-neutral" type="button">Ù¾ÛŽØ´ÙˆÙˆ</button>
          <p id="pageInfo" class="page-info">Ù¾Û•Ú•Û•ÛŒ 1 Ù„Û• 1</p>
          <button id="nextPageBtn" class="btn btn-neutral" type="button">Ø¯ÙˆØ§ØªØ±</button>
        </div>
      </article>
    </section>

    <p id="toast" class="toast hidden" role="status" aria-live="polite"></p>
  </main>

  <script src="./assets/app.js" defer></script>
</body>
</html>
