<?php

declare(strict_types=1);

date_default_timezone_set('Asia/Baghdad');

const DB_HOST = 'localhost';
const DB_PORT = 3306;
const DB_NAME = 'u588374711_runaki';
const DB_USER = 'u588374711_runaki';
const DB_PASS = 'O1m&/FwX#o4;';

const DASHBOARD_USERNAME = 'bestun';
const DASHBOARD_PASSWORD = '12345@#';
const DASHBOARD_SESSION_NAME = 'RUNAKI_ADMIN_SESSION';
const DASHBOARD_SESSION_TIMEOUT_SECONDS = 28800;
const DASHBOARD_LOGIN_MAX_ATTEMPTS = 5;
const DASHBOARD_LOGIN_LOCKOUT_SECONDS = 900;
const BOOKS_DEFAULT_PER_PAGE = 12;
const BOOKS_MAX_PER_PAGE = 100;
const PDF_UPLOAD_MAX_MB = 40;
const PDF_UPLOAD_DIR = 'uploads/books';
const COVER_UPLOAD_MAX_MB = 8;
const COVER_UPLOAD_DIR = 'uploads/covers';

function db(): PDO
{
    static $pdo = null;
    if ($pdo instanceof PDO) {
        return $pdo;
    }

    $dsn = sprintf(
        'mysql:host=%s;port=%d;dbname=%s;charset=utf8mb4',
        dbHost(),
        dbPort(),
        dbName()
    );

    $pdo = new PDO($dsn, dbUser(), dbPass(), [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    ]);

    ensureBooksTable($pdo);
    ensureCategoriesTable($pdo);

    return $pdo;
}

function ensureBooksTable(PDO $pdo): void
{
    $pdo->exec(
        "CREATE TABLE IF NOT EXISTS books (
            id INT UNSIGNED NOT NULL AUTO_INCREMENT,
            title VARCHAR(255) NOT NULL,
            description TEXT NOT NULL,
            category VARCHAR(120) DEFAULT NULL,
            pdf_url VARCHAR(1024) NOT NULL,
            cover_url VARCHAR(1024) DEFAULT NULL,
            created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY idx_created_at (created_at)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci"
    );

    $columns = [];
    foreach ($pdo->query('SHOW COLUMNS FROM books') as $column) {
        if (is_array($column) && isset($column['Field'])) {
            $columns[(string) $column['Field']] = true;
        }
    }

    if (!isset($columns['cover_url'])) {
        $pdo->exec("ALTER TABLE books ADD COLUMN cover_url VARCHAR(1024) DEFAULT NULL AFTER pdf_url");
    }
}

function ensureCategoriesTable(PDO $pdo): void
{
    $pdo->exec(
        "CREATE TABLE IF NOT EXISTS categories (
            id INT UNSIGNED NOT NULL AUTO_INCREMENT,
            name VARCHAR(120) NOT NULL,
            created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            UNIQUE KEY uq_categories_name (name)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci"
    );

    $pdo->exec(
        "INSERT IGNORE INTO categories (name)
         SELECT DISTINCT TRIM(category)
         FROM books
         WHERE category IS NOT NULL AND TRIM(category) <> ''"
    );
}

function normalizeCategoryName(string $value): string
{
    $trimmed = trim($value);
    if ($trimmed === '') {
        return '';
    }

    if (function_exists('mb_substr')) {
        return mb_substr($trimmed, 0, 120);
    }

    return substr($trimmed, 0, 120);
}

function syncCategoryName(PDO $pdo, ?string $name): ?string
{
    $normalized = normalizeCategoryName((string) $name);
    if ($normalized === '') {
        return null;
    }

    $stmt = $pdo->prepare(
        'INSERT INTO categories (name) VALUES (:name) ON DUPLICATE KEY UPDATE updated_at = CURRENT_TIMESTAMP'
    );
    $stmt->execute(['name' => $normalized]);

    return $normalized;
}

function startSecureSession(): void
{
    if (session_status() === PHP_SESSION_ACTIVE) {
        return;
    }

    $isHttps = !empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off';
    session_name(dashboardSessionName());
    session_set_cookie_params([
        'lifetime' => 0,
        'path' => dashboardSessionCookiePath(),
        'domain' => '',
        'secure' => $isHttps,
        'httponly' => true,
        'samesite' => 'Lax',
    ]);

    session_start();
}

function dashboardSessionName(): string
{
    return envValue('DASHBOARD_SESSION_NAME') ?? DASHBOARD_SESSION_NAME;
}

function dashboardSessionCookiePath(): string
{
    return '/';
}

function envValue(string $key): ?string
{
    $value = getenv($key);
    if ($value === false && array_key_exists($key, $_ENV)) {
        $value = $_ENV[$key];
    }
    if ($value === false && array_key_exists($key, $_SERVER)) {
        $value = $_SERVER[$key];
    }

    if (!is_string($value)) {
        return null;
    }

    $trimmed = trim($value);
    if ($trimmed === '') {
        return null;
    }

    return $trimmed;
}

function dbHost(): string
{
    return envValue('DB_HOST') ?? DB_HOST;
}

function dbPort(): int
{
    $raw = envValue('DB_PORT');
    if ($raw === null) {
        return DB_PORT;
    }

    $value = filter_var($raw, FILTER_VALIDATE_INT, [
        'options' => [
            'min_range' => 1,
            'max_range' => 65535,
        ],
    ]);

    return $value === false ? DB_PORT : (int) $value;
}

function dbName(): string
{
    return envValue('DB_NAME') ?? DB_NAME;
}

function dbUser(): string
{
    return envValue('DB_USER') ?? DB_USER;
}

function dbPass(): string
{
    return envValue('DB_PASS') ?? DB_PASS;
}

function appEnvironment(): string
{
    $raw = envValue('APP_ENV');
    if ($raw === null) {
        return 'development';
    }
    return strtolower($raw);
}

function isProductionEnvironment(): bool
{
    $env = appEnvironment();
    return $env === 'production' || $env === 'prod';
}

function dashboardUsername(): string
{
    return envValue('DASHBOARD_USERNAME') ?? DASHBOARD_USERNAME;
}

function dashboardPasswordHash(): ?string
{
    return envValue('DASHBOARD_PASSWORD_HASH');
}

function dashboardPasswordPlain(): string
{
    return envValue('DASHBOARD_PASSWORD') ?? DASHBOARD_PASSWORD;
}

function isDashboardPlainPasswordFallbackAllowed(): bool
{
    return !isProductionEnvironment();
}

function dashboardLoginMaxAttempts(): int
{
    $raw = envValue('DASHBOARD_LOGIN_MAX_ATTEMPTS');
    if ($raw === null) {
        return DASHBOARD_LOGIN_MAX_ATTEMPTS;
    }

    $value = filter_var($raw, FILTER_VALIDATE_INT);
    if ($value === false) {
        return DASHBOARD_LOGIN_MAX_ATTEMPTS;
    }

    $attempts = (int) $value;
    if ($attempts < 1) {
        return 1;
    }
    if ($attempts > 50) {
        return 50;
    }
    return $attempts;
}

function dashboardLoginLockoutSeconds(): int
{
    $raw = envValue('DASHBOARD_LOGIN_LOCKOUT_SECONDS');
    if ($raw === null) {
        return DASHBOARD_LOGIN_LOCKOUT_SECONDS;
    }

    $value = filter_var($raw, FILTER_VALIDATE_INT);
    if ($value === false) {
        return DASHBOARD_LOGIN_LOCKOUT_SECONDS;
    }

    $seconds = (int) $value;
    if ($seconds < 10) {
        return 10;
    }
    if ($seconds > 86400) {
        return 86400;
    }
    return $seconds;
}

function dashboardLoginBucket(string $username = ''): string
{
    $ip = trim((string) ($_SERVER['REMOTE_ADDR'] ?? 'unknown'));
    $agent = trim((string) ($_SERVER['HTTP_USER_AGENT'] ?? 'unknown'));
    $normalizedUser = strtolower(trim($username));
    return hash('sha256', $ip . '|' . $agent . '|' . $normalizedUser);
}

function dashboardLoginState(string $bucket): array
{
    startSecureSession();

    if (!isset($_SESSION['dashboard_login_rate']) || !is_array($_SESSION['dashboard_login_rate'])) {
        $_SESSION['dashboard_login_rate'] = [];
    }

    $state = $_SESSION['dashboard_login_rate'][$bucket] ?? null;
    if (!is_array($state)) {
        $state = [
            'attempts' => 0,
            'locked_until' => 0,
        ];
    }

    $state['attempts'] = (int) ($state['attempts'] ?? 0);
    $state['locked_until'] = (int) ($state['locked_until'] ?? 0);

    if ($state['locked_until'] > 0 && $state['locked_until'] <= time()) {
        $state = [
            'attempts' => 0,
            'locked_until' => 0,
        ];
    }

    $_SESSION['dashboard_login_rate'][$bucket] = $state;
    return $state;
}

function setDashboardLoginState(string $bucket, array $state): void
{
    startSecureSession();
    if (!isset($_SESSION['dashboard_login_rate']) || !is_array($_SESSION['dashboard_login_rate'])) {
        $_SESSION['dashboard_login_rate'] = [];
    }
    $_SESSION['dashboard_login_rate'][$bucket] = [
        'attempts' => max(0, (int) ($state['attempts'] ?? 0)),
        'locked_until' => max(0, (int) ($state['locked_until'] ?? 0)),
    ];
}

function isDashboardLoginLocked(string $bucket): bool
{
    $state = dashboardLoginState($bucket);
    return (int) ($state['locked_until'] ?? 0) > time();
}

function dashboardLoginRemainingLockSeconds(string $bucket): int
{
    $state = dashboardLoginState($bucket);
    $remaining = (int) ($state['locked_until'] ?? 0) - time();
    return $remaining > 0 ? $remaining : 0;
}

function registerDashboardLoginFailure(string $bucket): void
{
    $state = dashboardLoginState($bucket);
    $attempts = ((int) ($state['attempts'] ?? 0)) + 1;

    if ($attempts >= dashboardLoginMaxAttempts()) {
        $state = [
            'attempts' => 0,
            'locked_until' => time() + dashboardLoginLockoutSeconds(),
        ];
    } else {
        $state = [
            'attempts' => $attempts,
            'locked_until' => (int) ($state['locked_until'] ?? 0),
        ];
    }

    setDashboardLoginState($bucket, $state);
}

function clearDashboardLoginFailures(string $bucket): void
{
    setDashboardLoginState($bucket, [
        'attempts' => 0,
        'locked_until' => 0,
    ]);
}

function dashboardLoginFailureMessage(string $username = ''): string
{
    $bucket = dashboardLoginBucket($username);
    $remaining = dashboardLoginRemainingLockSeconds($bucket);
    if ($remaining > 0) {
        $minutes = (int) ceil($remaining / 60);
        if ($minutes < 1) {
            $minutes = 1;
        }
        return "هەوڵەکانی چوونەژوورەوە زۆر بوون. تکایە {$minutes} خولەک چاوەڕێ بکە.";
    }

    return 'ناوی بەکارهێنەر یان وشەی نهێنی هەڵەیە.';
}

function ensureDashboardCsrfToken(): string
{
    startSecureSession();

    $token = (string) ($_SESSION['dashboard_csrf_token'] ?? '');
    if ($token !== '' && strlen($token) >= 32) {
        return $token;
    }

    $token = bin2hex(random_bytes(32));
    $_SESSION['dashboard_csrf_token'] = $token;
    return $token;
}

function requireDashboardCsrfForWrite(?array $input = null): void
{
    $method = strtoupper((string) ($_SERVER['REQUEST_METHOD'] ?? 'GET'));
    if (in_array($method, ['GET', 'HEAD', 'OPTIONS'], true)) {
        return;
    }

    $sentToken = trim((string) ($_SERVER['HTTP_X_CSRF_TOKEN'] ?? ''));
    if ($sentToken === '' && is_array($input)) {
        $sentToken = trim((string) ($input['_csrf_token'] ?? $input['_csrf'] ?? ''));
    }
    if ($sentToken === '' && isset($_POST['_csrf_token'])) {
        $sentToken = trim((string) $_POST['_csrf_token']);
    }
    if ($sentToken === '' && isset($_POST['_csrf'])) {
        $sentToken = trim((string) $_POST['_csrf']);
    }

    $sessionToken = ensureDashboardCsrfToken();

    if ($sentToken === '' || !hash_equals($sessionToken, $sentToken)) {
        jsonResponse([
            'status' => false,
            'message' => 'توکنی CSRF دروست نییە.',
        ], 419);
    }
}

function isDashboardAuthenticated(): bool
{
    startSecureSession();

    $sessionUser = (string) ($_SESSION['dashboard_user'] ?? '');
    if ($sessionUser === '' || !hash_equals(dashboardUsername(), $sessionUser)) {
        return false;
    }

    $loginAt = (int) ($_SESSION['dashboard_login_at'] ?? 0);
    if ($loginAt <= 0 || (time() - $loginAt) > DASHBOARD_SESSION_TIMEOUT_SECONDS) {
        logoutDashboard();
        return false;
    }

    return true;
}

function attemptDashboardLogin(string $username, string $password): bool
{
    startSecureSession();

    $normalizedUser = trim($username);
    $bucket = dashboardLoginBucket($normalizedUser);

    if (isDashboardLoginLocked($bucket)) {
        return false;
    }

    if (!hash_equals(dashboardUsername(), $normalizedUser)) {
        registerDashboardLoginFailure($bucket);
        return false;
    }

    $passwordHash = dashboardPasswordHash();
    $passwordOk = false;

    if ($passwordHash !== null && $passwordHash !== '') {
        $passwordOk = password_verify($password, $passwordHash);
    } elseif (isDashboardPlainPasswordFallbackAllowed()) {
        $passwordOk = hash_equals(dashboardPasswordPlain(), $password);
    } else {
        $passwordOk = false;
        error_log('Dashboard login refused: DASHBOARD_PASSWORD_HASH is required in production.');
    }

    if (!$passwordOk) {
        registerDashboardLoginFailure($bucket);
        return false;
    }

    clearDashboardLoginFailures($bucket);
    session_regenerate_id(true);
    $_SESSION['dashboard_user'] = dashboardUsername();
    $_SESSION['dashboard_login_at'] = time();
    $_SESSION['dashboard_csrf_token'] = bin2hex(random_bytes(32));
    return true;
}

function logoutDashboard(): void
{
    startSecureSession();

    $_SESSION = [];
    if (ini_get('session.use_cookies')) {
        $params = session_get_cookie_params();
        setcookie(
            session_name(),
            '',
            time() - 42000,
            (string) ($params['path'] ?? dashboardSessionCookiePath()),
            (string) ($params['domain'] ?? ''),
            (bool) ($params['secure'] ?? false),
            (bool) ($params['httponly'] ?? true)
        );
    }

    session_destroy();
}

function requireDashboardAuthPage(string $redirectTo = 'login.php'): void
{
    if (isDashboardAuthenticated()) {
        return;
    }

    header('Location: ' . $redirectTo);
    exit;
}

function requireDashboardAuthApi(): void
{
    if (isDashboardAuthenticated()) {
        return;
    }

    jsonResponse([
        'status' => false,
        'message' => 'تۆ دەسەڵاتت نییە. تکایە بچۆ بۆ لاپەڕەی چوونەژوورەوە.',
    ], 401);
}

function allowCors(): void
{
    header('Access-Control-Allow-Origin: *');
    header('Access-Control-Allow-Methods: GET, POST, PUT, PATCH, DELETE, OPTIONS');
    header('Access-Control-Allow-Headers: Content-Type, X-API-KEY, X-CSRF-Token');

    if (($_SERVER['REQUEST_METHOD'] ?? '') === 'OPTIONS') {
        http_response_code(204);
        exit;
    }
}

function jsonResponse(array $payload, int $status = 200): void
{
    http_response_code($status);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($payload, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
    exit;
}

function readJsonBody(): array
{
    $raw = file_get_contents('php://input');
    if ($raw === false || trim($raw) === '') {
        return [];
    }

    $decoded = json_decode($raw, true);
    if (!is_array($decoded)) {
        jsonResponse([
            'status' => false,
            'message' => 'داتای JSON هەڵەیە.',
        ], 400);
    }

    return $decoded;
}

function isMultipartRequest(): bool
{
    $contentType = strtolower((string) ($_SERVER['CONTENT_TYPE'] ?? ''));
    return str_starts_with($contentType, 'multipart/form-data');
}

function readIncomingBody(): array
{
    if (isMultipartRequest()) {
        return $_POST;
    }
    return readJsonBody();
}

function normalizeBook(array $row): array
{
    return [
        'id' => (int) $row['id'],
        'title' => (string) $row['title'],
        'description' => (string) $row['description'],
        'category' => isset($row['category']) && $row['category'] !== '' ? (string) $row['category'] : null,
        'pdf_url' => (string) $row['pdf_url'],
        'cover_url' => isset($row['cover_url']) && trim((string) $row['cover_url']) !== '' ? (string) $row['cover_url'] : null,
        'created_at' => (string) $row['created_at'],
    ];
}

function queryStringValue(array $query, string $key, int $maxLength = 160): string
{
    if (!array_key_exists($key, $query)) {
        return '';
    }

    $value = trim((string) $query[$key]);
    if ($value === '') {
        return '';
    }

    if (function_exists('mb_substr')) {
        return mb_substr($value, 0, $maxLength);
    }

    return substr($value, 0, $maxLength);
}

function queryIntValue(array $query, string $key, int $default, int $min, int $max): int
{
    if (!array_key_exists($key, $query)) {
        return $default;
    }

    $value = filter_var($query[$key], FILTER_VALIDATE_INT);
    if ($value === false) {
        return $default;
    }

    $result = (int) $value;
    if ($result < $min) {
        return $min;
    }
    if ($result > $max) {
        return $max;
    }

    return $result;
}

function normalizeBooksSortColumn(string $requested): string
{
    $allowed = [
        'created_at' => 'created_at',
        'title' => 'title',
        'category' => 'category',
        'id' => 'id',
    ];

    $key = strtolower(trim($requested));
    return $allowed[$key] ?? 'created_at';
}

function normalizeBooksSortDirection(string $requested): string
{
    return strtolower(trim($requested)) === 'asc' ? 'ASC' : 'DESC';
}

function escapeSqlLike(string $value): string
{
    return strtr($value, [
        '\\' => '\\\\',
        '%' => '\%',
        '_' => '\_',
    ]);
}

function fetchBooksListPayload(PDO $pdo, array $query, bool $paginateByDefault = true): array
{
    $search = queryStringValue($query, 'search', 120);
    $sortBy = normalizeBooksSortColumn(queryStringValue($query, 'sort_by', 20));
    $sortDir = normalizeBooksSortDirection(queryStringValue($query, 'sort_dir', 10));

    $paginate = $paginateByDefault
        || array_key_exists('page', $query)
        || array_key_exists('per_page', $query);

    if (array_key_exists('paginate', $query)) {
        $explicit = filter_var($query['paginate'], FILTER_VALIDATE_BOOLEAN, FILTER_NULL_ON_FAILURE);
        if ($explicit !== null) {
            $paginate = $explicit;
        }
    }

    $whereSql = '';
    $whereSearch = '';
    if ($search !== '') {
        $whereSql = " WHERE (title LIKE :search ESCAPE '\\\\' OR description LIKE :search ESCAPE '\\\\' OR category LIKE :search ESCAPE '\\\\')";
        $whereSearch = '%' . escapeSqlLike($search) . '%';
    }

    $orderSql = sprintf(' ORDER BY %s %s, id DESC', $sortBy, $sortDir);

    if (!$paginate) {
        $sql = 'SELECT id, title, description, category, pdf_url, cover_url, created_at FROM books' . $whereSql . $orderSql;
        $stmt = $pdo->prepare($sql);
        if ($whereSearch !== '') {
            $stmt->bindValue(':search', $whereSearch, PDO::PARAM_STR);
        }
        $stmt->execute();
        $rows = $stmt->fetchAll();

        $books = [];
        foreach ($rows as $row) {
            $books[] = normalizeBook($row);
        }

        $total = count($books);
        return [
            'books' => $books,
            'total' => $total,
            'page' => 1,
            'per_page' => $total === 0 ? 1 : $total,
            'total_pages' => 1,
            'search' => $search,
            'sort_by' => $sortBy,
            'sort_dir' => strtolower($sortDir),
            'paginated' => false,
        ];
    }

    $perPage = queryIntValue($query, 'per_page', BOOKS_DEFAULT_PER_PAGE, 1, BOOKS_MAX_PER_PAGE);
    $page = queryIntValue($query, 'page', 1, 1, 1000000);

    $countStmt = $pdo->prepare('SELECT COUNT(*) FROM books' . $whereSql);
    if ($whereSearch !== '') {
        $countStmt->bindValue(':search', $whereSearch, PDO::PARAM_STR);
    }
    $countStmt->execute();
    $total = (int) $countStmt->fetchColumn();

    $totalPages = max(1, (int) ceil($total / $perPage));
    if ($page > $totalPages) {
        $page = $totalPages;
    }

    $offset = ($page - 1) * $perPage;
    $sql = 'SELECT id, title, description, category, pdf_url, cover_url, created_at FROM books'
        . $whereSql
        . $orderSql
        . ' LIMIT :limit OFFSET :offset';
    $stmt = $pdo->prepare($sql);
    if ($whereSearch !== '') {
        $stmt->bindValue(':search', $whereSearch, PDO::PARAM_STR);
    }
    $stmt->bindValue(':limit', $perPage, PDO::PARAM_INT);
    $stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
    $stmt->execute();

    $rows = $stmt->fetchAll();
    $books = [];
    foreach ($rows as $row) {
        $books[] = normalizeBook($row);
    }

    return [
        'books' => $books,
        'total' => $total,
        'page' => $page,
        'per_page' => $perPage,
        'total_pages' => $totalPages,
        'search' => $search,
        'sort_by' => $sortBy,
        'sort_dir' => strtolower($sortDir),
        'paginated' => true,
    ];
}

function bookExists(PDO $pdo, int $id): bool
{
    $stmt = $pdo->prepare('SELECT 1 FROM books WHERE id = :id LIMIT 1');
    $stmt->execute(['id' => $id]);
    return (bool) $stmt->fetchColumn();
}

function validPdfReference(string $value): bool
{
    $candidate = trim($value);
    if ($candidate === '') {
        return false;
    }

    if (preg_match('~^https?://~i', $candidate) === 1) {
        return filter_var($candidate, FILTER_VALIDATE_URL) !== false;
    }

    return preg_match('~^/[A-Za-z0-9_./%+-]+$~i', $candidate) === 1;
}

function validImageReference(string $value): bool
{
    $candidate = trim($value);
    if ($candidate === '') {
        return true;
    }

    if (preg_match('~^https?://~i', $candidate) === 1) {
        return filter_var($candidate, FILTER_VALIDATE_URL) !== false;
    }

    return preg_match('~^/[A-Za-z0-9_./%+-]+$~i', $candidate) === 1;
}

function validationPayload(array $input): array
{
    $title = trim((string) ($input['title'] ?? ''));
    $description = trim((string) ($input['description'] ?? ''));
    $category = trim((string) ($input['category'] ?? ''));
    $pdfUrl = trim((string) ($input['pdf_url'] ?? ''));
    $coverUrl = trim((string) ($input['cover_url'] ?? ''));

    $errors = [];
    if ($title === '') {
        $errors[] = 'ناونیشان پێویستە.';
    }
    if ($description === '') {
        $errors[] = 'وەسف پێویستە.';
    }
    if ($pdfUrl === '') {
        $errors[] = 'بەستەری PDF یان فایلەکە پێویستە.';
    } elseif (!validPdfReference($pdfUrl)) {
        $errors[] = 'بەستەری PDF دروست نییە.';
    }
    if (!validImageReference($coverUrl)) {
        $errors[] = 'بەستەری وێنەی بەرگ دروست نییە.';
    }

    return [
        'title' => $title,
        'description' => $description,
        'category' => $category === '' ? null : $category,
        'pdf_url' => $pdfUrl,
        'cover_url' => $coverUrl === '' ? null : $coverUrl,
        'errors' => $errors,
    ];
}

function dashboardBasePath(): string
{
    $scriptName = str_replace('\\', '/', (string) ($_SERVER['SCRIPT_NAME'] ?? ''));
    $dir = rtrim(dirname($scriptName), '/');

    if (str_ends_with($dir, '/api')) {
        $dir = substr($dir, 0, -4);
    }

    if ($dir === '' || $dir === '.') {
        return '';
    }

    return $dir === '/' ? '' : $dir;
}

function ensureUploadDirectory(string $relativeDir): string
{
    $path = __DIR__ . DIRECTORY_SEPARATOR . str_replace('/', DIRECTORY_SEPARATOR, trim($relativeDir, '/'));
    if (!is_dir($path) && !mkdir($path, 0775, true) && !is_dir($path)) {
        throw new RuntimeException('نەتوانرا فولدەری فایلەکان دروست بکرێت.');
    }
    return $path;
}

function buildManagedUploadUrl(string $relativeDir, string $fileName): string
{
    $basePath = dashboardBasePath();
    $relativePath = trim($relativeDir, '/');

    if ($basePath !== '') {
        return $basePath . '/' . $relativePath . '/' . $fileName;
    }

    return '/' . $relativePath . '/' . $fileName;
}

function ensurePdfUploadsDirectory(): string
{
    return ensureUploadDirectory(PDF_UPLOAD_DIR);
}

function ensureCoverUploadsDirectory(): string
{
    return ensureUploadDirectory(COVER_UPLOAD_DIR);
}

function hasPdfFileSignature(string $path): bool
{
    $handle = @fopen($path, 'rb');
    if ($handle === false) {
        return false;
    }

    $signature = (string) fread($handle, 5);
    fclose($handle);

    return $signature === '%PDF-';
}

function storeUploadedPdf(array $file): string
{
    $error = (int) ($file['error'] ?? UPLOAD_ERR_NO_FILE);
    if ($error === UPLOAD_ERR_NO_FILE) {
        throw new RuntimeException('هیچ فایلی PDF هەڵنەبژێردراوە.');
    }
    if ($error !== UPLOAD_ERR_OK) {
        throw new RuntimeException('هەڵەیەک لە هەڵگرتنی فایل ڕوویدا.');
    }

    $tmpPath = (string) ($file['tmp_name'] ?? '');
    $originalName = (string) ($file['name'] ?? '');
    $sizeBytes = (int) ($file['size'] ?? 0);

    $maxBytes = PDF_UPLOAD_MAX_MB * 1024 * 1024;
    if ($sizeBytes <= 0 || $sizeBytes > $maxBytes) {
        throw new RuntimeException('قەبارەی فایل زۆرە. تکایە PDF بچووکتر بەکاربهێنە.');
    }

    $extension = strtolower((string) pathinfo($originalName, PATHINFO_EXTENSION));
    if ($extension !== 'pdf') {
        throw new RuntimeException('تەنها فایلەی PDF ڕێگەپێدراوە.');
    }

    if (!is_uploaded_file($tmpPath)) {
        throw new RuntimeException('فایلەکە دروست نییە.');
    }

    $finfo = new finfo(FILEINFO_MIME_TYPE);
    $mime = (string) $finfo->file($tmpPath);
    $allowedMimes = [
        'application/pdf',
        'application/x-pdf',
        'application/acrobat',
        'applications/vnd.pdf',
        'text/pdf',
        'text/x-pdf',
        'application/octet-stream',
    ];

    if (!in_array($mime, $allowedMimes, true)) {
        throw new RuntimeException('ئەم فایلە PDF نییە.');
    }

    if (!hasPdfFileSignature($tmpPath)) {
        throw new RuntimeException('ئیمزای فایلەکە PDF دروست نییە.');
    }

    $uploadDir = ensurePdfUploadsDirectory();
    $fileName = sprintf('%s_%s.pdf', date('Ymd_His'), bin2hex(random_bytes(6)));
    $targetPath = $uploadDir . DIRECTORY_SEPARATOR . $fileName;

    if (!move_uploaded_file($tmpPath, $targetPath)) {
        throw new RuntimeException('نەتوانرا فایلەکە هەڵبگرێت.');
    }

    return buildManagedUploadUrl(PDF_UPLOAD_DIR, $fileName);
}

function storeUploadedCover(array $file): string
{
    $error = (int) ($file['error'] ?? UPLOAD_ERR_NO_FILE);
    if ($error === UPLOAD_ERR_NO_FILE) {
        throw new RuntimeException('هیچ وێنەیەک هەڵنەبژێردراوە.');
    }
    if ($error !== UPLOAD_ERR_OK) {
        throw new RuntimeException('هەڵەیەک لە هەڵگرتنی وێنە ڕوویدا.');
    }

    $tmpPath = (string) ($file['tmp_name'] ?? '');
    $originalName = (string) ($file['name'] ?? '');
    $sizeBytes = (int) ($file['size'] ?? 0);

    $maxBytes = COVER_UPLOAD_MAX_MB * 1024 * 1024;
    if ($sizeBytes <= 0 || $sizeBytes > $maxBytes) {
        throw new RuntimeException('قەبارەی وێنە زۆرە. تکایە فایلێکی بچووکتر بەکاربهێنە.');
    }

    if (!is_uploaded_file($tmpPath)) {
        throw new RuntimeException('وێنەکە دروست نییە.');
    }

    $extension = strtolower((string) pathinfo($originalName, PATHINFO_EXTENSION));
    $allowedExtensions = ['jpg', 'jpeg', 'png', 'webp', 'gif'];
    if (!in_array($extension, $allowedExtensions, true)) {
        throw new RuntimeException('تەنها JPG, PNG, WEBP, GIF ڕێگەپێدراون.');
    }

    $finfo = new finfo(FILEINFO_MIME_TYPE);
    $mime = (string) $finfo->file($tmpPath);
    $allowedMimes = ['image/jpeg', 'image/png', 'image/webp', 'image/gif'];
    if (!in_array($mime, $allowedMimes, true)) {
        throw new RuntimeException('ئەم فایلە وێنەی دروست نییە.');
    }

    $imageInfo = @getimagesize($tmpPath);
    if (!is_array($imageInfo)) {
        throw new RuntimeException('وێنەکە دروست نییە یان تێکچووە.');
    }

    $uploadDir = ensureCoverUploadsDirectory();
    $fileName = sprintf('%s_%s.%s', date('Ymd_His'), bin2hex(random_bytes(6)), $extension);
    $targetPath = $uploadDir . DIRECTORY_SEPARATOR . $fileName;

    if (!move_uploaded_file($tmpPath, $targetPath)) {
        throw new RuntimeException('نەتوانرا وێنەکە هەڵبگیرێت.');
    }

    return buildManagedUploadUrl(COVER_UPLOAD_DIR, $fileName);
}
