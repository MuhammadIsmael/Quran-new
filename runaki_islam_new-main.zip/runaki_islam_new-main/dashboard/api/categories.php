<?php

declare(strict_types=1);

require_once __DIR__ . '/../config.php';

allowCors();
requireDashboardAuthApi();

$input = readIncomingBody();
requireDashboardCsrfForWrite($input);
$method = strtoupper((string) ($_SERVER['REQUEST_METHOD'] ?? 'GET'));
$overrideMethod = strtoupper(trim((string) ($input['_method'] ?? '')));
if ($method === 'POST' && in_array($overrideMethod, ['PUT', 'PATCH', 'DELETE'], true)) {
    $method = $overrideMethod;
}

$idFromQuery = isset($_GET['id']) ? (int) $_GET['id'] : 0;
$idFromBody = isset($input['id']) ? (int) $input['id'] : 0;
$categoryId = $idFromQuery > 0 ? $idFromQuery : $idFromBody;

try {
    $pdo = db();

    if ($method === 'GET') {
        jsonResponse([
            'status' => true,
            'categories' => fetchCategories($pdo),
        ]);
    }

    if ($method === 'POST') {
        $name = normalizeCategoryName((string) ($input['name'] ?? ''));
        if ($name === '') {
            jsonResponse([
                'status' => false,
                'message' => 'ناوی پۆل پێویستە.',
            ], 422);
        }

        $name = (string) syncCategoryName($pdo, $name);
        $category = fetchCategoryByName($pdo, $name);
        if ($category === null) {
            jsonResponse([
                'status' => false,
                'message' => 'نەتوانرا پۆلەکە دروست بکرێت.',
            ], 500);
        }

        jsonResponse([
            'status' => true,
            'message' => 'پۆلەکە دروستکرا.',
            'category' => $category,
        ], 201);
    }

    if ($method === 'PUT' || $method === 'PATCH') {
        if ($categoryId <= 0) {
            jsonResponse([
                'status' => false,
                'message' => 'ناسنامەی پۆل پێویستە.',
            ], 400);
        }

        $current = fetchCategoryById($pdo, $categoryId);
        if ($current === null) {
            jsonResponse([
                'status' => false,
                'message' => 'پۆل نەدۆزرایەوە.',
            ], 404);
        }

        $newName = normalizeCategoryName((string) ($input['name'] ?? ''));
        if ($newName === '') {
            jsonResponse([
                'status' => false,
                'message' => 'ناوی نوێی پۆل پێویستە.',
            ], 422);
        }

        $oldName = (string) $current['name'];
        if ($newName === $oldName) {
            jsonResponse([
                'status' => true,
                'message' => 'هیچ گۆڕانکارییەک نەکرا.',
                'category' => $current,
            ]);
        }

        $pdo->beginTransaction();
        syncCategoryName($pdo, $newName);
        $updateBooks = $pdo->prepare('UPDATE books SET category = :new_name WHERE category = :old_name');
        $updateBooks->execute([
            'new_name' => $newName,
            'old_name' => $oldName,
        ]);
        $deleteOld = $pdo->prepare('DELETE FROM categories WHERE id = :id');
        $deleteOld->execute(['id' => $categoryId]);
        $pdo->commit();

        $updated = fetchCategoryByName($pdo, $newName);
        if ($updated === null) {
            jsonResponse([
                'status' => false,
                'message' => 'پۆلەکە نوێکرایەوە، بەڵام نەتوانرا دۆزرێتەوە.',
            ], 500);
        }

        jsonResponse([
            'status' => true,
            'message' => 'پۆلەکە نوێکرایەوە.',
            'category' => $updated,
        ]);
    }

    if ($method === 'DELETE') {
        if ($categoryId <= 0) {
            jsonResponse([
                'status' => false,
                'message' => 'ناسنامەی پۆل پێویستە.',
            ], 400);
        }

        $current = fetchCategoryById($pdo, $categoryId);
        if ($current === null) {
            jsonResponse([
                'status' => false,
                'message' => 'پۆل نەدۆزرایەوە.',
            ], 404);
        }

        $pdo->beginTransaction();
        $clearBooks = $pdo->prepare('UPDATE books SET category = NULL WHERE category = :name');
        $clearBooks->execute(['name' => $current['name']]);
        $delete = $pdo->prepare('DELETE FROM categories WHERE id = :id');
        $delete->execute(['id' => $categoryId]);
        $pdo->commit();

        jsonResponse([
            'status' => true,
            'message' => 'پۆلەکە سڕایەوە.',
        ]);
    }

    jsonResponse([
        'status' => false,
        'message' => 'جۆری داواکاری ڕێگەپێنەدراوە.',
    ], 405);
} catch (Throwable $error) {
    if (isset($pdo) && $pdo instanceof PDO && $pdo->inTransaction()) {
        $pdo->rollBack();
    }

    jsonResponse([
        'status' => false,
        'message' => 'هەڵەی سێرڤەر.',
        'error' => $error->getMessage(),
    ], 500);
}

function fetchCategories(PDO $pdo): array
{
    $stmt = $pdo->query(
        'SELECT c.id, c.name, c.created_at, c.updated_at, COUNT(b.id) AS books_count
         FROM categories c
         LEFT JOIN books b ON b.category = c.name
         GROUP BY c.id
         ORDER BY c.name ASC'
    );

    $rows = $stmt->fetchAll();
    $categories = [];
    foreach ($rows as $row) {
        if (!is_array($row)) {
            continue;
        }

        $categories[] = [
            'id' => (int) ($row['id'] ?? 0),
            'name' => (string) ($row['name'] ?? ''),
            'books_count' => (int) ($row['books_count'] ?? 0),
            'created_at' => (string) ($row['created_at'] ?? ''),
            'updated_at' => (string) ($row['updated_at'] ?? ''),
        ];
    }

    return $categories;
}

function fetchCategoryById(PDO $pdo, int $id): ?array
{
    $stmt = $pdo->prepare(
        'SELECT c.id, c.name, c.created_at, c.updated_at, COUNT(b.id) AS books_count
         FROM categories c
         LEFT JOIN books b ON b.category = c.name
         WHERE c.id = :id
         GROUP BY c.id
         LIMIT 1'
    );
    $stmt->execute(['id' => $id]);
    $row = $stmt->fetch();
    return normalizeCategoryRow($row);
}

function fetchCategoryByName(PDO $pdo, string $name): ?array
{
    $stmt = $pdo->prepare(
        'SELECT c.id, c.name, c.created_at, c.updated_at, COUNT(b.id) AS books_count
         FROM categories c
         LEFT JOIN books b ON b.category = c.name
         WHERE c.name = :name
         GROUP BY c.id
         LIMIT 1'
    );
    $stmt->execute(['name' => $name]);
    $row = $stmt->fetch();
    return normalizeCategoryRow($row);
}

function normalizeCategoryRow($row): ?array
{
    if (!is_array($row)) {
        return null;
    }

    return [
        'id' => (int) ($row['id'] ?? 0),
        'name' => (string) ($row['name'] ?? ''),
        'books_count' => (int) ($row['books_count'] ?? 0),
        'created_at' => (string) ($row['created_at'] ?? ''),
        'updated_at' => (string) ($row['updated_at'] ?? ''),
    ];
}
