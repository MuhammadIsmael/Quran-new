<?php

declare(strict_types=1);

require_once __DIR__ . '/../config.php';

allowCors();
requireDashboardAuthApi();

$input = readIncomingBody();
requireDashboardCsrfForWrite($input);
$method = strtoupper((string) ($_SERVER['REQUEST_METHOD'] ?? 'GET'));
$overrideMethod = strtoupper(trim((string) ($input['_method'] ?? '')));
if ($method === 'POST' && in_array($overrideMethod, ['PUT', 'PATCH', 'DELETE'], true)) {
    $method = $overrideMethod;
}

$idFromQuery = isset($_GET['id']) ? (int) $_GET['id'] : 0;
$idFromBody = isset($input['id']) ? (int) $input['id'] : 0;
$bookId = $idFromQuery > 0 ? $idFromQuery : $idFromBody;

try {
    $pdo = db();

    if ($method === 'GET') {
        $list = fetchBooksListPayload($pdo, $_GET, true);

        jsonResponse([
            'status' => true,
            'books' => $list['books'],
            'total' => $list['total'],
            'page' => $list['page'],
            'per_page' => $list['per_page'],
            'total_pages' => $list['total_pages'],
            'search' => $list['search'],
            'sort_by' => $list['sort_by'],
            'sort_dir' => $list['sort_dir'],
        ]);
    }

    if ($method === 'POST') {
        $payload = buildBookPayload($input, null);
        if (!empty($payload['errors'])) {
            jsonResponse([
                'status' => false,
                'message' => implode(' ', $payload['errors']),
            ], 422);
        }

        $payload['category'] = syncCategoryName($pdo, (string) ($payload['category'] ?? ''));

        $stmt = $pdo->prepare(
            'INSERT INTO books (title, description, category, pdf_url, cover_url) VALUES (:title, :description, :category, :pdf_url, :cover_url)'
        );
        $stmt->execute([
            'title' => $payload['title'],
            'description' => $payload['description'],
            'category' => $payload['category'],
            'pdf_url' => $payload['pdf_url'],
            'cover_url' => $payload['cover_url'],
        ]);

        $id = (int) $pdo->lastInsertId();
        $book = fetchBookById($pdo, $id);
        if ($book === null) {
            jsonResponse([
                'status' => false,
                'message' => 'کتێب زیادکرا، بەڵام نەتوانرا دۆزرێتەوە.',
            ], 500);
        }

        jsonResponse([
            'status' => true,
            'message' => 'کتێبەکە بە سەرکەوتوویی زیادکرا.',
            'book' => normalizeBook($book),
        ], 201);
    }

    if ($method === 'PUT' || $method === 'PATCH') {
        if ($bookId <= 0) {
            jsonResponse([
                'status' => false,
                'message' => 'ناسنامەی کتێب پێویستە.',
            ], 400);
        }

        $currentBook = fetchBookById($pdo, $bookId);
        if ($currentBook === null) {
            jsonResponse([
                'status' => false,
                'message' => 'کتێب نەدۆزرایەوە.',
            ], 404);
        }

        $payload = buildBookPayload($input, $currentBook);
        if (!empty($payload['errors'])) {
            jsonResponse([
                'status' => false,
                'message' => implode(' ', $payload['errors']),
            ], 422);
        }

        $payload['category'] = syncCategoryName($pdo, (string) ($payload['category'] ?? ''));

        $stmt = $pdo->prepare(
            'UPDATE books SET title = :title, description = :description, category = :category, pdf_url = :pdf_url, cover_url = :cover_url WHERE id = :id'
        );
        $stmt->execute([
            'id' => $bookId,
            'title' => $payload['title'],
            'description' => $payload['description'],
            'category' => $payload['category'],
            'pdf_url' => $payload['pdf_url'],
            'cover_url' => $payload['cover_url'],
        ]);

        if (($payload['new_pdf_uploaded'] ?? false) && ($payload['previous_pdf_url'] ?? '') !== ($payload['pdf_url'] ?? '')) {
            deleteManagedUploadIfManaged((string) ($payload['previous_pdf_url'] ?? ''), PDF_UPLOAD_DIR);
        }
        $shouldRemoveOldCover = ($payload['new_cover_uploaded'] ?? false)
            || ($payload['remove_cover_requested'] ?? false);
        if (
            $shouldRemoveOldCover
            && ($payload['previous_cover_url'] ?? '') !== ''
            && ($payload['previous_cover_url'] ?? '') !== ($payload['cover_url'] ?? '')
        ) {
            deleteManagedUploadIfManaged((string) ($payload['previous_cover_url'] ?? ''), COVER_UPLOAD_DIR);
        }

        $book = fetchBookById($pdo, $bookId);
        if ($book === null) {
            jsonResponse([
                'status' => false,
                'message' => 'کتێب نوێکرایەوە، بەڵام نەتوانرا دۆزرێتەوە.',
            ], 500);
        }

        jsonResponse([
            'status' => true,
            'message' => 'کتێبەکە بە سەرکەوتوویی نوێکرایەوە.',
            'book' => normalizeBook($book),
        ]);
    }

    if ($method === 'DELETE') {
        if ($bookId <= 0) {
            jsonResponse([
                'status' => false,
                'message' => 'ناسنامەی کتێب پێویستە.',
            ], 400);
        }

        $book = fetchBookById($pdo, $bookId);
        if ($book === null) {
            jsonResponse([
                'status' => false,
                'message' => 'کتێب نەدۆزرایەوە.',
            ], 404);
        }

        $stmt = $pdo->prepare('DELETE FROM books WHERE id = :id');
        $stmt->execute(['id' => $bookId]);

        deleteManagedUploadIfManaged((string) ($book['pdf_url'] ?? ''), PDF_UPLOAD_DIR);
        deleteManagedUploadIfManaged((string) ($book['cover_url'] ?? ''), COVER_UPLOAD_DIR);

        jsonResponse([
            'status' => true,
            'message' => 'کتێبەکە سڕایەوە.',
        ]);
    }

    jsonResponse([
        'status' => false,
        'message' => 'جۆری داواکاری ڕێگەپێنەدراوە.',
    ], 405);
} catch (Throwable $error) {
    jsonResponse([
        'status' => false,
        'message' => 'هەڵەی سێرڤەر.',
        'error' => $error->getMessage(),
    ], 500);
}

function fetchBookById(PDO $pdo, int $id): ?array
{
    $stmt = $pdo->prepare(
        'SELECT id, title, description, category, pdf_url, cover_url, created_at FROM books WHERE id = :id LIMIT 1'
    );
    $stmt->execute(['id' => $id]);
    $row = $stmt->fetch();
    return is_array($row) ? $row : null;
}

function hasUploadedFile($file): bool
{
    return is_array($file) && ((int) ($file['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_NO_FILE);
}

function buildBookPayload(array $input, ?array $currentBook): array
{
    $source = strtolower(trim((string) ($input['pdf_source'] ?? 'link')));
    if (!in_array($source, ['link', 'upload'], true)) {
        $source = 'link';
    }

    $currentPdfUrl = trim((string) ($currentBook['pdf_url'] ?? ''));
    $currentCoverUrl = trim((string) ($currentBook['cover_url'] ?? ''));

    $pdfUrl = trim((string) ($input['pdf_url'] ?? ''));
    $coverUrl = $currentBook === null ? '' : $currentCoverUrl;

    $newPdfUploaded = false;
    $newCoverUploaded = false;
    $removeCoverRequested = filter_var($input['remove_cover'] ?? false, FILTER_VALIDATE_BOOLEAN);

    if ($source === 'upload') {
        $pdfFile = $_FILES['pdf_file'] ?? null;
        if (hasUploadedFile($pdfFile)) {
            $pdfUrl = storeUploadedPdf($pdfFile);
            $newPdfUploaded = true;
        } elseif ($currentBook !== null) {
            $pdfUrl = $currentPdfUrl;
        }
    }

    $coverFile = $_FILES['cover_file'] ?? null;
    if (hasUploadedFile($coverFile)) {
        $coverUrl = storeUploadedCover($coverFile);
        $newCoverUploaded = true;
        $removeCoverRequested = false;
    } elseif ($removeCoverRequested) {
        $coverUrl = '';
    }

    $validated = validationPayload([
        'title' => $input['title'] ?? '',
        'description' => $input['description'] ?? '',
        'category' => normalizeCategoryName((string) ($input['category'] ?? '')),
        'pdf_url' => $pdfUrl,
        'cover_url' => $coverUrl,
    ]);

    $validated['new_pdf_uploaded'] = $newPdfUploaded;
    $validated['new_cover_uploaded'] = $newCoverUploaded;
    $validated['remove_cover_requested'] = $removeCoverRequested;
    $validated['previous_pdf_url'] = $currentPdfUrl;
    $validated['previous_cover_url'] = $currentCoverUrl;

    if (!empty($validated['errors'])) {
        if ($newPdfUploaded) {
            deleteManagedUploadIfManaged((string) $pdfUrl, PDF_UPLOAD_DIR);
        }
        if ($newCoverUploaded) {
            deleteManagedUploadIfManaged((string) $coverUrl, COVER_UPLOAD_DIR);
        }
    }

    return $validated;
}

function deleteManagedUploadIfManaged(string $fileUrl, string $uploadsDir): void
{
    if ($fileUrl === '' || str_starts_with($fileUrl, 'http://') || str_starts_with($fileUrl, 'https://')) {
        return;
    }

    $path = (string) parse_url($fileUrl, PHP_URL_PATH);
    if ($path === '') {
        $path = $fileUrl;
    }

    $relative = ltrim($path, '/');
    $base = trim(dashboardBasePath(), '/');
    if ($base !== '' && str_starts_with($relative, $base . '/')) {
        $relative = substr($relative, strlen($base) + 1);
    }

    $uploadsPrefix = trim($uploadsDir, '/');
    if (!str_starts_with($relative, $uploadsPrefix . '/')) {
        return;
    }

    $fullPath = realpath(__DIR__ . '/../' . $relative);
    $uploadsPath = realpath(__DIR__ . '/../' . $uploadsPrefix);

    if ($fullPath === false || $uploadsPath === false) {
        return;
    }

    $uploadsPath = rtrim($uploadsPath, DIRECTORY_SEPARATOR) . DIRECTORY_SEPARATOR;
    if (!str_starts_with($fullPath, $uploadsPath)) {
        return;
    }

    if (is_file($fullPath)) {
        @unlink($fullPath);
    }
}
