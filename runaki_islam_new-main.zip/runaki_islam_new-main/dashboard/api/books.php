<?php

declare(strict_types=1);

require_once __DIR__ . '/../config.php';

allowCors();

if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'GET') {
    jsonResponse([
        'status' => false,
        'message' => 'جۆری داواکارییەکە ڕێگەپێنەدراوە.',
    ], 405);
}

try {
    $pdo = db();
    $list = fetchBooksListPayload($pdo, $_GET, false);

    jsonResponse([
        'status' => true,
        'books' => $list['books'],
        'total' => $list['total'],
        'page' => $list['page'],
        'per_page' => $list['per_page'],
        'total_pages' => $list['total_pages'],
        'search' => $list['search'],
        'sort_by' => $list['sort_by'],
        'sort_dir' => $list['sort_dir'],
        'paginated' => $list['paginated'],
    ]);
} catch (Throwable $error) {
    jsonResponse([
        'status' => false,
        'message' => 'هەڵەی سێرڤەر لە وەرگرتنی کتێبەکان.',
        'error' => $error->getMessage(),
    ], 500);
}
