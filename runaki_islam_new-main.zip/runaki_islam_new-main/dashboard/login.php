<?php

declare(strict_types=1);

require_once __DIR__ . '/config.php';

if (isDashboardAuthenticated()) {
    header('Location: index.php');
    exit;
}

$errorMessage = '';
if (($_SERVER['REQUEST_METHOD'] ?? '') === 'POST') {
    $username = (string) ($_POST['username'] ?? '');
    $password = (string) ($_POST['password'] ?? '');

    if (attemptDashboardLogin($username, $password)) {
        header('Location: index.php');
        exit;
    }

    $errorMessage = dashboardLoginFailureMessage($username);
}
?>
<!doctype html>
<html lang="ku" dir="rtl">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>چوونەژوورەوە - داشبۆرد</title>
  <link rel="stylesheet" href="./assets/styles.css">
</head>
<body class="login-body">
  <main class="login-shell">
    <section class="login-card">
      <p class="eyebrow">ڕووناکی ئیسلام</p>
      <h1>چوونەژوورەوەی داشبۆرد</h1>
      <p class="sub-text">تەنها بەڕێوەبەر دەتوانێت بچێتە ژوورەوە.</p>

      <?php if ($errorMessage !== ''): ?>
        <div class="state state-error"><?= htmlspecialchars($errorMessage, ENT_QUOTES, 'UTF-8') ?></div>
      <?php endif; ?>

      <form method="post" class="login-form" autocomplete="off">
        <label for="username">ناوی بەکارهێنەر</label>
        <input id="username" name="username" type="text" required autofocus>

        <label for="password">وشەی نهێنی</label>
        <input id="password" name="password" type="password" required>

        <button class="btn" type="submit">چوونەژوورەوە</button>
      </form>
    </section>
  </main>
</body>
</html>